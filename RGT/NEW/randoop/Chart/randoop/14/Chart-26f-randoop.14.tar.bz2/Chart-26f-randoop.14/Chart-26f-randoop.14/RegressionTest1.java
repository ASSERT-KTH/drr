import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = statisticalLineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj2 = defaultCategoryDataset1.clone();
        java.util.List list3 = defaultCategoryDataset1.getColumnKeys();
        boolean boolean4 = color0.equals((java.lang.Object) defaultCategoryDataset1);
        java.awt.Color color5 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot16.getIndexOf(xYItemRenderer18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.util.Size2D size2D23 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D23.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D29 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D23, (double) (short) -1, (double) ' ', rectangleAnchor28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = null;
        dateAxis32.setTickUnit(dateTickUnit33);
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis32.getTickUnit();
        dateAxis32.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = null;
        dateAxis39.setTickUnit(dateTickUnit40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = dateAxis39.getTickUnit();
        dateAxis39.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis39, xYItemRenderer45);
        xYPlot46.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        dateAxis49.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis49.setStandardTickUnits(tickUnitSource52);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D55 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D55.setMinimumBarLength((double) (byte) -1);
        boolean boolean60 = stackedBarRenderer3D55.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D55.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator63 = stackedBarRenderer3D55.getBaseToolTipGenerator();
        stackedBarRenderer3D55.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer70 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color72 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer70.setSeriesOutlinePaint(4, (java.awt.Paint) color72);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot(categoryDataset67, categoryAxis68, valueAxis69, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer70);
        categoryPlot74.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent78 = null;
        categoryPlot74.markerChanged(markerChangeEvent78);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit82 = null;
        dateAxis81.setTickUnit(dateTickUnit82);
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = dateAxis81.getTickUnit();
        double double85 = dateAxis81.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        stackedBarRenderer3D55.drawRangeGridline(graphics2D66, categoryPlot74, (org.jfree.chart.axis.ValueAxis) dateAxis81, rectangle2D86, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis90 = new org.jfree.chart.axis.DateAxis("");
        dateAxis90.setNegativeArrowVisible(false);
        org.jfree.data.Range range93 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis90.setRangeWithMargins(range93);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray95 = new org.jfree.chart.axis.ValueAxis[] { dateAxis49, dateAxis81, dateAxis90 };
        xYPlot46.setRangeAxes(valueAxisArray95);
        java.util.List list97 = xYPlot46.getAnnotations();
        xYPlot16.drawRangeTickBands(graphics2D20, rectangle2D29, list97);
        boolean boolean99 = xYPlot16.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNull(dateTickUnit35);
        org.junit.Assert.assertNull(dateTickUnit42);
        org.junit.Assert.assertNotNull(tickUnitSource52);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator63);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNull(dateTickUnit84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 2.0d + "'", double85 == 2.0d);
        org.junit.Assert.assertNotNull(range93);
        org.junit.Assert.assertNotNull(valueAxisArray95);
        org.junit.Assert.assertNotNull(list97);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + true + "'", boolean99 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D1.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        boolean boolean18 = standardGradientPaintTransformer15.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj2 = defaultCategoryDataset1.clone();
        java.util.List list3 = defaultCategoryDataset1.getColumnKeys();
        boolean boolean4 = color0.equals((java.lang.Object) defaultCategoryDataset1);
        try {
            defaultCategoryDataset1.removeColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        java.util.Date date11 = year9.getEnd();
        int int13 = year9.compareTo((java.lang.Object) 0.05d);
        task7.setDuration((org.jfree.data.time.TimePeriod) year9);
        java.util.Date date15 = year9.getEnd();
        java.awt.Color color16 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date15, (java.awt.Paint) color16, stroke17);
        java.util.Date date19 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.jfree.chart.axis.TickUnits tickUnits3 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit4, dataset5);
        tickUnits3.add((org.jfree.chart.axis.TickUnit) dateTickUnit4);
        int int8 = dateTickUnit4.getUnit();
        boolean boolean9 = categoryAnchor0.equals((java.lang.Object) dateTickUnit4);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((int) ' ', serialDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        try {
            org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) month5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        numberAxis3D0.setAutoRangeStickyZero(true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D1.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D1.setAutoPopulateSeriesOutlineStroke(true);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        boolean boolean22 = stackedBarRenderer3D1.equals((java.lang.Object) axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        java.lang.Boolean boolean5 = stackedBarRenderer3D1.getSeriesCreateEntities(9999);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Shape shape0 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer1 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer1.setSeriesOutlinePaint(4, (java.awt.Paint) color3);
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2019);
        java.lang.Object obj3 = objectList1.get(0);
        java.lang.Object obj5 = objectList1.get((int) '4');
        objectList1.clear();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D3.setMinimumBarLength((double) (byte) -1);
        boolean boolean8 = stackedBarRenderer3D3.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D3.setDrawBarOutline(true);
        double double11 = stackedBarRenderer3D3.getYOffset();
        boolean boolean12 = horizontalAlignment1.equals((java.lang.Object) stackedBarRenderer3D3);
        boolean boolean15 = stackedBarRenderer3D3.getItemCreateEntity((int) (short) 1, 31);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        double double4 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis1, shape5, "", "Last");
        dateAxis1.setUpperMargin(0.2d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.configure();
        org.jfree.data.Range range14 = numberAxis3D12.getDefaultAutoRange();
        dateAxis1.setRange(range14);
        boolean boolean18 = range14.intersects(0.0d, (double) 1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = statisticalLineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 2);
        org.jfree.data.Range range5 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        double double6 = range5.getLength();
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleAnchor.BOTTOM_RIGHT");
        taskSeries1.setNotify(true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color6, false);
        int int9 = statisticalLineAndShapeRenderer0.getPassCount();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent13);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        boolean boolean18 = statisticalLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.lang.Boolean boolean20 = statisticalLineAndShapeRenderer0.getSeriesVisibleInLegend((int) '#');
        statisticalLineAndShapeRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(boolean20);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.awt.Paint paint2 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer7.setSeriesOutlinePaint(4, (java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer7);
        categoryPlot11.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        boolean boolean19 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot11.getLegendItems();
        float float21 = categoryPlot11.getBackgroundImageAlpha();
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font23, (java.awt.Paint) color24);
        categoryPlot11.setNoDataMessageFont(font23);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) false, font23);
        java.awt.Font font29 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.2d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer5.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer5);
        categoryPlot9.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Image image17 = categoryPlot9.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot9.getRenderer((-3695));
        int int20 = month0.compareTo((java.lang.Object) (-3695));
        int int21 = month0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        waferMapPlot1.notifyListeners(plotChangeEvent2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        categoryAxis0.setCategoryMargin((double) 100L);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis0.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        double double4 = ringPlot1.getInnerSeparatorExtension();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.util.Date date4 = dateAxis1.getMinimumDate();
        dateAxis1.setTickLabelsVisible(false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D8.setMinimumBarLength((double) (byte) -1);
        boolean boolean13 = stackedBarRenderer3D8.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D8.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedBarRenderer3D8.getBaseToolTipGenerator();
        stackedBarRenderer3D8.setRenderAsPercentages(true);
        java.awt.Paint paint21 = stackedBarRenderer3D8.getItemPaint(0, (int) (byte) 100);
        dateAxis1.setAxisLinePaint(paint21);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray9, comparableArray10, numberArray11, numberArray12);
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) defaultIntervalCategoryDataset13);
        dateAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        java.lang.Object obj8 = piePlot3D1.clone();
        java.awt.Stroke stroke9 = piePlot3D1.getOutlineStroke();
        double double10 = piePlot3D1.getMinimumArcAngleToDraw();
        double double11 = piePlot3D1.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-5d + "'", double10 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        java.lang.Boolean boolean17 = stackedBarRenderer3D1.getSeriesVisibleInLegend(10);
        java.awt.Paint paint20 = stackedBarRenderer3D1.getItemFillPaint((int) (short) 10, (int) (byte) -1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer6.setSeriesOutlinePaint(4, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer6);
        categoryPlot10.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot10.setDomainAxis(categoryAxis14);
        java.awt.Paint paint16 = categoryAxis14.getLabelPaint();
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font2, paint16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font20 = categoryAxis19.getTickLabelFont();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer21 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint24 = ganttRenderer21.getItemOutlinePaint(0, (int) ' ');
        textBlock17.addLine("{0}", font20, paint24);
        java.lang.Object obj26 = null;
        boolean boolean27 = textBlock17.equals(obj26);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType35 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition37 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor31, textBlockAnchor32, textAnchor33, (double) (-3695), categoryLabelWidthType35, (float) 10);
        try {
            java.awt.Shape shape41 = textBlock17.calculateBounds(graphics2D28, (float) (byte) 0, (float) 2958465, textBlockAnchor32, 0.0f, (float) (-3695), 0.35d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(categoryLabelWidthType35);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxisForDataset(2019);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = new org.jfree.chart.LegendItemCollection();
        categoryPlot7.setFixedLegendItems(legendItemCollection18);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAxis17);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer20.setSeriesOutlinePaint(4, (java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer20);
        categoryPlot24.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot24.setDomainAxis(categoryAxis28);
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font31, (java.awt.Paint) color32);
        categoryPlot24.setNoDataMessageFont(font31);
        dateAxis9.setTickLabelFont(font31);
        dateAxis9.setTickMarkInsideLength((float) (byte) 10);
        java.awt.Font font38 = dateAxis9.getTickLabelFont();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) ' ', serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2958465, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        java.text.DateFormat dateFormat38 = null;
        dateAxis29.setDateFormatOverride(dateFormat38);
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = dateAxis29.getStandardTickUnits();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(tickUnitSource40);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        dateAxis25.setNegativeArrowVisible(false);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis25, shape29, "", "Last");
        dateAxis25.setUpperMargin(0.2d);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline38 = dateAxis37.getTimeline();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit41 = null;
        dateAxis40.setTickUnit(dateTickUnit41);
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = dateAxis40.getTickUnit();
        double double44 = dateAxis40.getAutoRangeMinimumSize();
        java.util.Date date45 = dateAxis40.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date48 = dateAxis47.getMaximumDate();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis25, dateAxis37, dateAxis40, dateAxis47 };
        xYPlot16.setDomainAxes(valueAxisArray49);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(timeline38);
        org.junit.Assert.assertNull(dateTickUnit43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(valueAxisArray49);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 2);
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) defaultCategoryDataset1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=255,g=128,b=128]"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        boolean boolean3 = month0.equals((java.lang.Object) 15);
        long long4 = month0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        segmentedTimeline3.addException((long) 0);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        int int9 = year8.getYear();
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        int int13 = year12.getYear();
        org.jfree.data.gantt.Task task14 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year12);
        task10.addSubtask(task14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        java.util.Date date18 = year16.getEnd();
        int int20 = year16.compareTo((java.lang.Object) 0.05d);
        task14.setDuration((org.jfree.data.time.TimePeriod) year16);
        java.util.Date date22 = year16.getEnd();
        java.awt.Color color23 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date22, (java.awt.Paint) color23, stroke24);
        long long26 = segmentedTimeline3.toTimelineValue(date22);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 15622431679L + "'", long26 == 15622431679L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets7.calculateTopOutset((double) (byte) -1);
        dateAxis1.setLabelInsets(rectangleInsets7);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesCreateEntities(8, (java.lang.Boolean) false, true);
        boolean boolean7 = statisticalLineAndShapeRenderer0.getItemShapeVisible(0, 6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer11.setSeriesOutlinePaint(4, (java.awt.Paint) color13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer11);
        categoryPlot15.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21);
        boolean boolean23 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot15.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        int int26 = categoryPlot15.getDomainAxisIndex(categoryAxis25);
        java.awt.Image image27 = categoryPlot15.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot15.getDataset();
        categoryPlot15.setWeight(0);
        statisticalLineAndShapeRenderer0.setPlot(categoryPlot15);
        categoryPlot15.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNull(categoryDataset28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj3 = defaultCategoryDataset2.clone();
        java.util.List list4 = defaultCategoryDataset2.getColumnKeys();
        boolean boolean5 = color1.equals((java.lang.Object) defaultCategoryDataset2);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        categoryPlot13.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryPlot13.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot13.setDataset(categoryDataset22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot13.setRangeCrosshairPaint(paint24);
        boolean boolean26 = defaultCategoryDataset2.hasListener((java.util.EventListener) categoryPlot13);
        try {
            java.lang.String str28 = intervalCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        textTitle2.setID("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double7 = rectangleInsets5.calculateBottomOutset((double) (short) -1);
        textTitle2.setPadding(rectangleInsets5);
        boolean boolean9 = standardCategoryURLGenerator1.equals((java.lang.Object) rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj4 = defaultCategoryDataset3.clone();
        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        keyToGroupMap5.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year7);
        defaultCategoryDataset3.removeValue((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) 8.0d);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateAxis1, (org.jfree.data.general.Dataset) defaultCategoryDataset3);
        java.lang.String str13 = datasetChangeEvent12.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleAnchor.BOTTOM_RIGHT");
        try {
            org.jfree.data.gantt.Task task3 = taskSeries1.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray9, comparableArray10, numberArray11, numberArray12);
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) defaultIntervalCategoryDataset13);
        java.text.DateFormat dateFormat17 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat17);
        java.lang.String str20 = dateTickUnit18.valueToString((double) 9999);
        try {
            int int21 = defaultIntervalCategoryDataset13.getColumnIndex((java.lang.Comparable) str20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "12/31/69" + "'", str20.equals("12/31/69"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth(0.35d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.35d + "'", double2 == 16.35d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        double double4 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        defaultKeyedValues0.removeValue((java.lang.Comparable) 10L);
        defaultKeyedValues0.insertValue(0, (java.lang.Comparable) 1.0E-5d, (double) 6);
        defaultKeyedValues0.setValue((java.lang.Comparable) 0.25d, 1.0E-8d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = stackedBarRenderer3D1.getURLGenerator((int) '#', 0);
        boolean boolean12 = stackedBarRenderer3D1.getAutoPopulateSeriesOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D(pieDataset13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        piePlot3D14.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke17);
        java.awt.Color color19 = java.awt.Color.darkGray;
        piePlot3D14.setShadowPaint((java.awt.Paint) color19);
        stackedBarRenderer3D1.setBaseFillPaint((java.awt.Paint) color19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer4.setSeriesOutlinePaint(4, (java.awt.Paint) color6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder((double) 1900, (double) (byte) 0, 0.0d, (double) 0.5f, (java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.configureDomainAxes();
        java.awt.Stroke stroke22 = categoryPlot7.getRangeGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint26 = categoryMarker25.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D28 = new org.jfree.chart.plot.PiePlot3D(pieDataset27);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextOutlineStroke();
        piePlot3D28.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke31);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 2, paint26, stroke31);
        categoryPlot7.setOutlineStroke(stroke31);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.Object obj2 = dataPackageResources0.getObject("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot20.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray30 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis29 };
        categoryPlot20.setDomainAxes(categoryAxisArray30);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D(pieDataset32);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextOutlineStroke();
        piePlot3D33.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke36);
        java.awt.Color color38 = java.awt.Color.darkGray;
        piePlot3D33.setShadowPaint((java.awt.Paint) color38);
        categoryPlot20.setOutlinePaint((java.awt.Paint) color38);
        boolean boolean41 = categoryAxis11.equals((java.lang.Object) color38);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "({0}, {1}) = {2}", "0,-100,100,100,-100,100,-100,100");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(categoryAxisArray30);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.plot.Plot plot2 = waferMapPlot1.getRootPlot();
        float float3 = waferMapPlot1.getBackgroundAlpha();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(plot2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        org.jfree.data.Range range2 = numberAxis3D0.getDefaultAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis3D0.getMarkerBand();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNull(markerAxisBand3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        stackedBarRenderer3D1.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, true);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (byte) 0);
        java.awt.Paint paint24 = stackedBarRenderer3D1.getItemLabelPaint(4, 9999);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray5 = new double[] { (short) -1 };
        double[] doubleArray7 = new double[] { (short) -1 };
        double[] doubleArray9 = new double[] { (short) -1 };
        double[] doubleArray11 = new double[] { (short) -1 };
        double[] doubleArray13 = new double[] { (short) -1 };
        double[] doubleArray15 = new double[] { (short) -1 };
        double[][] doubleArray16 = new double[][] { doubleArray5, doubleArray7, doubleArray9, doubleArray11, doubleArray13, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("WMAP_Plot", "12/31/69 3:59 PM", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=128,b=128]", "TextAnchor.TOP_CENTER", doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB((int) (byte) 1, 9999, (int) (short) 1, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        java.awt.Stroke stroke4 = ringPlot1.getSeparatorStroke();
        java.lang.Object obj5 = ringPlot1.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        java.awt.Stroke stroke8 = categoryMarker7.getOutlineStroke();
        ringPlot1.setSeparatorStroke(stroke8);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) 1.0f, 0.0f, (float) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.chart.util.Size2D size2D6 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D6.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, (double) (short) -1, (double) ' ', rectangleAnchor11);
        try {
            org.jfree.chart.util.Size2D size2D13 = rectangleConstraint2.calculateConstrainedSize(size2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getRangeZeroBaselineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double21 = rectangleInsets20.getLeft();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint25 = categoryMarker24.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D(pieDataset26);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextOutlineStroke();
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke30);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 2, paint25, stroke30);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, paint25);
        try {
            xYPlot16.setQuadrantPaint((int) (short) 100, paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D20.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, (double) (short) -1, (double) ' ', rectangleAnchor25);
        try {
            categoryPlot7.drawBackground(graphics2D17, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(1);
        statisticalLineAndShapeRenderer0.setBaseCreateEntities(false);
        statisticalLineAndShapeRenderer0.setSeriesShapesFilled(5, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Point2D point2D4 = null;
        try {
            int int5 = plotRenderingInfo3.getSubplotIndex(point2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.util.Date date4 = dateAxis1.getMinimumDate();
        java.lang.String str5 = dateAxis1.getLabelURL();
        boolean boolean6 = dateAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int3 = defaultKeyedValues2D1.getRowIndex((java.lang.Comparable) 'a');
        org.jfree.chart.axis.TickUnits tickUnits4 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit5, dataset6);
        tickUnits4.add((org.jfree.chart.axis.TickUnit) dateTickUnit5);
        java.lang.Comparable comparable9 = null;
        try {
            java.lang.Number number10 = defaultKeyedValues2D1.getValue((java.lang.Comparable) dateTickUnit5, comparable9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot16.rendererChanged(rendererChangeEvent20);
        xYPlot16.setDomainCrosshairValue(3.0d);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        java.awt.Font font6 = statisticalLineAndShapeRenderer0.getItemLabelFont((int) (short) 1, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setSeriesCreateEntities(9, (java.lang.Boolean) false);
        java.awt.Color color10 = java.awt.Color.orange;
        statisticalLineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int3 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-3695));
        defaultCategoryDataset0.addValue(0.0d, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 0L);
        java.lang.Object obj8 = defaultCategoryDataset0.clone();
        java.lang.Object obj9 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        java.awt.Paint paint20 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Font font21 = categoryPlot7.getNoDataMessageFont();
        java.lang.Object obj22 = categoryPlot7.clone();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot7.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        java.util.List list67 = xYPlot16.getAnnotations();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation68 = null;
        try {
            xYPlot16.addAnnotation(xYAnnotation68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNotNull(list67);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat17 = dateAxis14.getDateFormatOverride();
        java.awt.Shape shape18 = dateAxis14.getRightArrow();
        dateAxis14.setAutoTickUnitSelection(true);
        java.awt.Paint paint21 = dateAxis14.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("{0}", font12, paint21);
        stackedBarRenderer3D1.setBasePaint(paint21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D26.setMinimumBarLength((double) (byte) -1);
        boolean boolean31 = stackedBarRenderer3D26.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D26.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = statisticalLineAndShapeRenderer34.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D26.setBasePositiveItemLabelPosition(itemLabelPosition37);
        double double39 = itemLabelPosition37.getAngle();
        stackedBarRenderer3D1.setSeriesPositiveItemLabelPosition(0, itemLabelPosition37);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint4 = ringPlot1.getBackgroundPaint();
        ringPlot1.setPieIndex((int) (byte) 1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "TextAnchor.TOP_CENTER", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "ERROR : Relative To String");
        java.lang.String str5 = basicProjectInfo4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str5.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer10.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer10);
        categoryPlot14.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        boolean boolean22 = categoryPlot14.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot14.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        int int25 = categoryPlot14.getDomainAxisIndex(categoryAxis24);
        java.awt.Image image26 = categoryPlot14.getBackgroundImage();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        int int28 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(image26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke1 = minMaxCategoryRenderer0.getGroupStroke();
        javax.swing.Icon icon2 = minMaxCategoryRenderer0.getMinIcon();
        boolean boolean3 = minMaxCategoryRenderer0.isDrawLines();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(icon2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(126.0d, (double) 2019);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color6, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint13 = categoryMarker12.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D(pieDataset14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        piePlot3D15.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) 2, paint13, stroke18);
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(3, paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color6, false);
        int int9 = statisticalLineAndShapeRenderer0.getPassCount();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent13);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        boolean boolean18 = statisticalLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        java.awt.Color color21 = java.awt.Color.red;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot20.getDomainAxisEdge();
        int int36 = categoryPlot20.getWeight();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer8.setSeriesOutlinePaint(4, (java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer8);
        categoryPlot12.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot12.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot12.addDomainMarker(categoryMarker19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot12.getDomainAxisForDataset(2019);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.awt.Stroke stroke24 = dateAxis1.getTickMarkStroke();
        double double25 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(categoryAxis22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        ganttRenderer0.setCompletePaint(paint3);
        double double5 = ganttRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        int int19 = xYPlot16.indexOf(xYDataset18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setNegativeArrowVisible(false);
        java.util.Date date24 = dateAxis21.getMinimumDate();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.setPositiveArrowVisible(true);
        boolean boolean29 = dateAxis21.isHiddenValue((long) (byte) -1);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        int int4 = year0.compareTo((java.lang.Object) 0.05d);
        long long5 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
        boolean boolean4 = stackedBarRenderer1.equals((java.lang.Object) standardCategoryURLGenerator3);
        java.awt.Paint paint6 = stackedBarRenderer1.getSeriesOutlinePaint((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.text.AttributedString attributedString0 = null;
        java.awt.Color color4 = java.awt.Color.green;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        boolean boolean7 = color4.equals((java.lang.Object) shape6);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D10 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 10, (double) ' ');
        java.awt.Stroke stroke12 = barRenderer3D10.lookupSeriesStroke(9999);
        java.awt.Color color13 = java.awt.Color.pink;
        int int14 = color13.getAlpha();
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "Size2D[width=97.0, height=0.0]", "12/31/69 3:59 PM", "12/31/69 3:59 PM", shape6, stroke12, (java.awt.Paint) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke19 = xYPlot16.getRangeGridlineStroke();
        java.awt.Paint paint20 = xYPlot16.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = xYPlot16.getDomainMarkers((int) '4', layer22);
        xYPlot16.setOutlineVisible(true);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        multiplePiePlot4.setLimit(10.0d);
        java.lang.Comparable comparable7 = multiplePiePlot4.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "Other" + "'", comparable7.equals("Other"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, 15, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultKeyedValues0.equals(obj4);
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByValues(sortOrder6);
        try {
            java.lang.Number number9 = defaultKeyedValues0.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean2 = categoryLabelPositions0.equals((java.lang.Object) 1L);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        boolean boolean4 = categoryLabelPositions0.equals((java.lang.Object) year3);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions0.getLabelPosition(rectangleEdge5);
        float float7 = categoryLabelPosition6.getWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(categoryLabelPosition6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.RingPlot ringPlot2 = new org.jfree.chart.plot.RingPlot(pieDataset1);
        ringPlot2.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint5 = ringPlot2.getBackgroundPaint();
        ganttRenderer0.setIncompletePaint(paint5);
        double double7 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.35d + "'", double7 == 0.35d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setStartAngle(1.0E-5d);
        piePlot3D1.setShadowXOffset((double) (short) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D8.setMinimumBarLength((double) (byte) -1);
        boolean boolean13 = stackedBarRenderer3D8.isItemLabelVisible((int) '#', 0);
        java.awt.Paint paint14 = stackedBarRenderer3D8.getWallPaint();
        piePlot3D1.setBaseSectionPaint(paint14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D3.setSeriesPaint((int) (byte) 100, paint5, false);
        double double8 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer17.setSeriesOutlinePaint(4, (java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer17);
        categoryPlot21.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot21.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27);
        java.awt.Image image29 = categoryPlot21.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline32 = null;
        dateAxis31.setTimeline(timeline32);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker35.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D13, categoryPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.plot.Marker) categoryMarker35, rectangle2D38);
        java.text.DateFormat dateFormat40 = null;
        dateAxis31.setDateFormatOverride(dateFormat40);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        ringPlot43.setOuterSeparatorExtension(100.0d);
        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
        ringPlot43.setLabelPaint((java.awt.Paint) color46);
        java.awt.Paint paint48 = ringPlot43.getLabelOutlinePaint();
        java.awt.Stroke stroke49 = ringPlot43.getSeparatorStroke();
        java.awt.Paint paint50 = ringPlot43.getLabelBackgroundPaint();
        dateAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) ringPlot43);
        boolean boolean52 = rectangleEdge0.equals((java.lang.Object) ringPlot43);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(image29);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        boolean boolean4 = size2D2.equals((java.lang.Object) 100.0f);
        double double5 = size2D2.height;
        size2D2.setWidth((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        java.awt.Paint paint20 = categoryPlot7.getDomainGridlinePaint();
        categoryPlot7.clearRangeAxes();
        boolean boolean22 = categoryPlot7.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.axis.TickUnits tickUnits1 = new org.jfree.chart.axis.TickUnits();
        boolean boolean2 = numberTickUnit0.equals((java.lang.Object) tickUnits1);
        int int3 = tickUnits1.size();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj5 = defaultCategoryDataset4.clone();
        org.jfree.data.KeyToGroupMap keyToGroupMap6 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        keyToGroupMap6.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year8);
        defaultCategoryDataset4.removeValue((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) 8.0d);
        org.jfree.data.general.DatasetGroup datasetGroup12 = defaultCategoryDataset4.getGroup();
        java.lang.Object obj13 = datasetGroup12.clone();
        boolean boolean14 = tickUnits1.equals(obj13);
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(datasetGroup12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis1, shape5, "", "Last");
        dateAxis1.setUpperMargin(0.2d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.configure();
        org.jfree.data.Range range14 = numberAxis3D12.getDefaultAutoRange();
        dateAxis1.setRange(range14);
        dateAxis1.setRange((double) 3100L, (double) 9999);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("0,-100,100,100,-100,100,-100,100");
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        segment10.moveIndexToStart();
        java.util.Date date12 = segment10.getDate();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Paint paint1 = minMaxCategoryRenderer0.getGroupPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D2.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D8 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) (short) -1, (double) ' ', rectangleAnchor7);
        double double9 = size2D2.width;
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.0d + "'", double9 == 97.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer6.setSeriesOutlinePaint(4, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer6);
        categoryPlot10.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot10.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16);
        boolean boolean18 = categoryPlot10.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot10.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        int int21 = categoryPlot10.getDomainAxisIndex(categoryAxis20);
        java.awt.Image image22 = categoryPlot10.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset23 = categoryPlot10.getDataset();
        categoryPlot10.configureDomainAxes();
        java.awt.Stroke stroke25 = categoryPlot10.getRangeGridlineStroke();
        categoryPlot10.mapDatasetToDomainAxis(100, (int) 'a');
        java.awt.Color color29 = java.awt.Color.black;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color29);
        minMaxCategoryRenderer0.setGroupPaint((java.awt.Paint) color29);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(image22);
        org.junit.Assert.assertNull(categoryDataset23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Stroke stroke4 = dateAxis1.getAxisLineStroke();
        try {
            dateAxis1.zoomRange((double) (short) 100, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (7.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        java.awt.Paint paint16 = categoryPlot7.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        dateAxis4.setNegativeArrowVisible(false);
        java.awt.Stroke stroke7 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis4.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer9);
        dateAxis4.setTickMarkOutsideLength((float) (byte) 100);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset3, 6);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths((int) ' ', serialDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-3695), serialDate3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot3D5.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot3D5.setLabelGenerator(pieSectionLabelGenerator10);
        java.lang.Object obj12 = piePlot3D5.clone();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        ringPlot14.setOuterSeparatorExtension(100.0d);
        double double17 = ringPlot14.getOuterSeparatorExtension();
        ringPlot14.setShadowXOffset(1.0E-8d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot14.getLegendLabelGenerator();
        piePlot3D5.setLegendLabelToolTipGenerator(pieSectionLabelGenerator20);
        ringPlot1.setLegendLabelGenerator(pieSectionLabelGenerator20);
        java.awt.Paint paint23 = ringPlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        categoryPlot13.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryPlot13.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot13.setDataset(categoryDataset22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot13.setRangeCrosshairPaint(paint24);
        java.awt.Paint paint26 = categoryPlot13.getDomainGridlinePaint();
        java.awt.Font font27 = categoryPlot13.getNoDataMessageFont();
        lineAndShapeRenderer2.setSeriesItemLabelFont(100, font27, false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        int int4 = year3.getYear();
        java.util.Date date5 = year3.getEnd();
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("12/31/69", (org.jfree.data.time.TimePeriod) year3);
        taskSeries1.add(task6);
        boolean boolean8 = taskSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 2);
        org.jfree.data.Range range5 = stackedBarRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, 9359.5d);
        org.junit.Assert.assertNotNull(pieDataset4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Color color6 = java.awt.Color.darkGray;
        statisticalLineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color6, false);
        int int9 = statisticalLineAndShapeRenderer0.getPassCount();
        statisticalLineAndShapeRenderer0.setSeriesShapesVisible(12, (java.lang.Boolean) true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent13);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        boolean boolean18 = statisticalLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.lang.Object obj19 = statisticalLineAndShapeRenderer0.clone();
        boolean boolean20 = statisticalLineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        boolean boolean16 = stackedBarRenderer3D1.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer22.setSeriesOutlinePaint(4, (java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer22);
        categoryPlot26.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo31, point2D32);
        java.awt.Image image34 = categoryPlot26.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        dateAxis36.setNegativeArrowVisible(false);
        java.awt.Stroke stroke39 = dateAxis36.getAxisLineStroke();
        categoryPlot26.setDomainGridlineStroke(stroke39);
        stackedBarRenderer3D1.setBaseOutlineStroke(stroke39);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = dateAxis1.getDownArrow();
        org.jfree.data.Range range5 = null;
        try {
            dateAxis1.setRange(range5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        piePlot3D2.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D2.setLabelGenerator(pieSectionLabelGenerator7);
        java.lang.Object obj9 = piePlot3D2.clone();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot(pieDataset10);
        ringPlot11.setOuterSeparatorExtension(100.0d);
        double double14 = ringPlot11.getOuterSeparatorExtension();
        ringPlot11.setShadowXOffset(1.0E-8d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = ringPlot11.getLegendLabelGenerator();
        piePlot3D2.setLegendLabelToolTipGenerator(pieSectionLabelGenerator17);
        boolean boolean19 = textAnchor0.equals((java.lang.Object) pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        java.awt.Paint paint21 = xYPlot16.getQuadrantPaint((int) (short) 1);
        xYPlot16.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = null;
        try {
            xYPlot16.setRangeAxes(valueAxisArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat17 = dateAxis14.getDateFormatOverride();
        java.awt.Shape shape18 = dateAxis14.getRightArrow();
        dateAxis14.setAutoTickUnitSelection(true);
        java.awt.Paint paint21 = dateAxis14.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("{0}", font12, paint21);
        stackedBarRenderer3D1.setBasePaint(paint21);
        java.lang.Object obj24 = null;
        boolean boolean25 = stackedBarRenderer3D1.equals(obj24);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.configureDomainAxes();
        java.awt.Stroke stroke22 = categoryPlot7.getRangeGridlineStroke();
        categoryPlot7.mapDatasetToDomainAxis(100, (int) 'a');
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = textTitle26.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D29.setMinimumBarLength((double) (byte) -1);
        boolean boolean34 = stackedBarRenderer3D29.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D29.setDrawBarOutline(true);
        double double37 = stackedBarRenderer3D29.getYOffset();
        boolean boolean38 = horizontalAlignment27.equals((java.lang.Object) stackedBarRenderer3D29);
        org.jfree.chart.util.VerticalAlignment verticalAlignment39 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement42 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment27, verticalAlignment39, 0.2d, (double) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer46 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer46.setSeriesOutlinePaint(4, (java.awt.Paint) color48);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer46);
        categoryPlot50.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot50.setDomainAxis(categoryAxis54);
        double double56 = categoryAxis54.getCategoryMargin();
        boolean boolean57 = columnArrangement42.equals((java.lang.Object) categoryAxis54);
        java.util.List list58 = categoryPlot7.getCategoriesForAxis(categoryAxis54);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 8.0d + "'", double37 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.2d + "'", double56 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(list58);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        java.awt.Paint paint16 = categoryPlot7.getOutlinePaint();
        java.awt.Stroke stroke17 = categoryPlot7.getDomainGridlineStroke();
        double[][] doubleArray20 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray20);
        boolean boolean22 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset21);
        categoryPlot7.setDataset(categoryDataset21);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        boolean boolean11 = categoryLabelWidthType5.equals((java.lang.Object) multiplePiePlot10);
        boolean boolean12 = defaultCategoryDataset0.hasListener((java.util.EventListener) multiplePiePlot10);
        try {
            java.lang.Comparable comparable14 = defaultCategoryDataset0.getRowKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = ringPlot1.getLegendLabelToolTipGenerator();
        double double3 = ringPlot1.getOuterSeparatorExtension();
        org.junit.Assert.assertNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        keyToGroupMap0.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year2);
        java.util.List list4 = keyToGroupMap0.getGroups();
        int int6 = keyToGroupMap0.getGroupIndex((java.lang.Comparable) "WMAP_Plot");
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick8 = new org.jfree.chart.axis.DateTick(date2, "12/31/69", textAnchor4, textAnchor6, 0.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean11 = categoryLabelPositions9.equals((java.lang.Object) 1L);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        boolean boolean13 = categoryLabelPositions9.equals((java.lang.Object) year12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions9.getLabelPosition(rectangleEdge14);
        boolean boolean16 = dateTick8.equals((java.lang.Object) categoryLabelPosition15);
        double double17 = dateTick8.getValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str5.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(categoryLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setLabel("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.junit.Assert.assertNull(dateTickUnit4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextOutlinePaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        piePlot3D0.setBaseSectionOutlinePaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        double double3 = categoryLabelPosition1.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "12/31/69", "ThreadContext", "ThreadContext", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "12/31/69", "ThreadContext", "ThreadContext", "");
        java.lang.String str12 = basicProjectInfo11.getCopyright();
        basicProjectInfo5.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo11);
        java.lang.String str14 = basicProjectInfo11.getInfo();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ThreadContext" + "'", str12.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ThreadContext" + "'", str14.equals("ThreadContext"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        boolean boolean3 = waferMapPlot1.equals((java.lang.Object) 100L);
        java.lang.String str4 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        org.jfree.chart.plot.Plot plot38 = categoryPlot19.getRootPlot();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNotNull(plot38);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        piePlot3D1.setLabelLinksVisible(false);
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font11, (java.awt.Paint) color12);
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color12.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        piePlot3D1.setBaseSectionPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext19);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        java.awt.Shape shape16 = stackedBarRenderer3D1.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset17.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range22 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateBottomOutset((double) (short) -1);
        boolean boolean26 = defaultCategoryDataset17.equals((java.lang.Object) double25);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline3.getBaseTimeline();
        int int6 = segmentedTimeline3.getSegmentsIncluded();
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ERROR : Relative To String");
        java.lang.Object obj2 = null;
        boolean boolean3 = standardCategorySeriesLabelGenerator1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        stackedBarRenderer3D1.setSeriesShape((int) (short) 0, shape16);
        java.awt.Paint paint19 = stackedBarRenderer3D1.getSeriesFillPaint(4);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        statisticalLineAndShapeRenderer3.setSeriesShape((int) (byte) 100, shape11, true);
        java.awt.Stroke stroke14 = null;
        try {
            statisticalLineAndShapeRenderer3.setBaseOutlineStroke(stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setDefaultAutoRange(range7);
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit10, dataset11);
        java.lang.String str14 = dateTickUnit10.valueToString((double) (-1.0f));
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        int int17 = year16.getYear();
        org.jfree.data.gantt.Task task18 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        int int21 = year20.getYear();
        org.jfree.data.gantt.Task task22 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year20);
        task18.addSubtask(task22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        int int25 = year24.getYear();
        java.util.Date date26 = year24.getEnd();
        int int28 = year24.compareTo((java.lang.Object) 0.05d);
        task22.setDuration((org.jfree.data.time.TimePeriod) year24);
        java.util.Date date30 = year24.getEnd();
        java.text.DateFormat dateFormat33 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat33);
        java.lang.String str36 = dateTickUnit34.valueToString((double) 9999);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        java.util.Date date38 = year37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date40 = dateTickUnit34.rollDate(date38, timeZone39);
        java.util.Date date41 = dateTickUnit10.addToDate(date30, timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        java.util.Date date44 = year42.getEnd();
        org.jfree.chart.JFreeChart jFreeChart45 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date44, jFreeChart45);
        java.util.Date date47 = dateTickUnit10.addToDate(date44);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.image.ColorModel colorModel49 = null;
        java.awt.Rectangle rectangle50 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D51.configure();
        java.text.NumberFormat numberFormat53 = null;
        numberAxis3D51.setNumberFormatOverride(numberFormat53);
        org.jfree.chart.util.Size2D size2D58 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D58.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor63 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D64 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D58, (double) (short) -1, (double) ' ', rectangleAnchor63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double66 = numberAxis3D51.valueToJava2D((double) 'a', rectangle2D64, rectangleEdge65);
        java.awt.geom.AffineTransform affineTransform67 = null;
        java.awt.RenderingHints renderingHints68 = null;
        java.awt.PaintContext paintContext69 = color48.createContext(colorModel49, rectangle50, rectangle2D64, affineTransform67, renderingHints68);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle();
        textTitle70.setID("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = textTitle70.getPosition();
        try {
            double double74 = dateAxis1.dateToJava2D(date47, (java.awt.geom.Rectangle2D) rectangle50, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "12/31/69 3:59 PM" + "'", str14.equals("12/31/69 3:59 PM"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "12/31/69" + "'", str36.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(rectangleAnchor63);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 9359.5d + "'", double66 == 9359.5d);
        org.junit.Assert.assertNotNull(paintContext69);
        org.junit.Assert.assertNotNull(rectangleEdge73);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1), (double) 128);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection21 = null;
        chartRenderingInfo20.setEntityCollection(entityCollection21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit27 = null;
        dateAxis26.setTickUnit(dateTickUnit27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = dateAxis26.getTickUnit();
        dateAxis26.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = null;
        dateAxis33.setTickUnit(dateTickUnit34);
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis33.getTickUnit();
        dateAxis33.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer39);
        xYPlot40.configureRangeAxes();
        java.awt.Stroke stroke42 = xYPlot40.getRangeZeroBaselineStroke();
        xYPlot40.setRangeCrosshairValue((double) (-3695));
        xYPlot40.setRangeZeroBaselineVisible(true);
        java.awt.geom.Point2D point2D47 = xYPlot40.getQuadrantOrigin();
        try {
            xYPlot16.zoomRangeAxes((double) 7, 1.0E-8d, plotRenderingInfo23, point2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (7.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(dateTickUnit29);
        org.junit.Assert.assertNull(dateTickUnit36);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 10, (double) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer3D2.setSeriesURLGenerator(0, categoryURLGenerator4, false);
        java.lang.Boolean boolean8 = barRenderer3D2.getSeriesItemLabelsVisible((-1));
        java.awt.Paint paint10 = barRenderer3D2.lookupSeriesFillPaint((int) '4');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer3D2.notifyListeners(rendererChangeEvent11);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = null;
        java.awt.Stroke[] strokeArray3 = new java.awt.Stroke[] {};
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis11);
        categoryPlot7.axisChanged(axisChangeEvent12);
        categoryPlot7.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean2 = statisticalLineAndShapeRenderer0.isSeriesItemLabelsVisible((int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalLineAndShapeRenderer0.getNegativeItemLabelPosition(5, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date2, jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent4.setChart(jFreeChart5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.getItemCreateEntity(2019, 31);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        stackedBarRenderer3D1.setBaseItemLabelGenerator(categoryItemLabelGenerator7);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj10 = defaultCategoryDataset9.clone();
        int int12 = defaultCategoryDataset9.getRowIndex((java.lang.Comparable) (-3695));
        defaultCategoryDataset9.addValue(0.0d, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 0L);
        java.util.List list17 = defaultCategoryDataset9.getRowKeys();
        org.jfree.data.Range range18 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        task7.setPercentComplete((double) 0.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setCursor(97.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.configure();
        java.text.NumberFormat numberFormat6 = null;
        numberAxis3D4.setNumberFormatOverride(numberFormat6);
        org.jfree.chart.util.Size2D size2D11 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D11.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D17 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D11, (double) (short) -1, (double) ' ', rectangleAnchor16);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double19 = numberAxis3D4.valueToJava2D((double) 'a', rectangle2D17, rectangleEdge18);
        axisState0.moveCursor((double) 1.0f, rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 9359.5d + "'", double19 == 9359.5d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot7.getDomainAxisLocation(10);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot7.getRangeMarkers(1900, layer20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D3.setSeriesPaint((int) (byte) 100, paint5, false);
        double double8 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer17.setSeriesOutlinePaint(4, (java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer17);
        categoryPlot21.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot21.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27);
        java.awt.Image image29 = categoryPlot21.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline32 = null;
        dateAxis31.setTimeline(timeline32);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker35.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D13, categoryPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.plot.Marker) categoryMarker35, rectangle2D38);
        stackedBarRenderer3D3.setSeriesItemLabelsVisible((int) '#', true);
        boolean boolean43 = textBlock0.equals((java.lang.Object) stackedBarRenderer3D3);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(image29);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        chartRenderingInfo38.setEntityCollection(entityCollection39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        boolean boolean42 = categoryPlot20.render(graphics2D35, rectangle2D36, (-3695), plotRenderingInfo41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = plotRenderingInfo41.getOwner();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chartRenderingInfo43);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = stackedBarRenderer3D1.getSeriesToolTipGenerator(0);
        java.awt.Paint paint10 = stackedBarRenderer3D1.getSeriesFillPaint((int) (short) 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(1);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D(pieDataset8);
        double double10 = piePlot3D9.getMinimumArcAngleToDraw();
        boolean boolean11 = itemLabelPosition7.equals((java.lang.Object) double10);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-5d + "'", double10 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D18.setSeriesPaint((int) (byte) 100, paint20, false);
        double double23 = stackedBarRenderer3D18.getItemMargin();
        stackedBarRenderer3D18.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint29 = null;
        stackedBarRenderer3D18.setSeriesPaint((int) (byte) 0, paint29);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer35.setSeriesOutlinePaint(4, (java.awt.Paint) color37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer35);
        org.jfree.data.general.DatasetGroup datasetGroup40 = categoryPlot39.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        stackedBarRenderer3D18.drawRangeGridline(graphics2D31, categoryPlot39, (org.jfree.chart.axis.ValueAxis) dateAxis42, rectangle2D43, (double) (short) 10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset47 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit46, dataset47);
        java.util.Date date49 = dateAxis42.calculateHighestVisibleTickValue(dateTickUnit46);
        dateAxis2.setMinimumDate(date49);
        boolean boolean51 = dateAxis2.isTickMarksVisible();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNull(datasetGroup40);
        org.junit.Assert.assertNotNull(dateTickUnit46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        boolean boolean16 = stackedBarRenderer3D1.isDrawBarOutline();
        java.awt.Paint paint18 = stackedBarRenderer3D1.getSeriesFillPaint((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.clear();
        int int4 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) (byte) 1);
        java.lang.Comparable comparable5 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.axis.TickUnits tickUnits7 = new org.jfree.chart.axis.TickUnits();
        boolean boolean8 = numberTickUnit6.equals((java.lang.Object) tickUnits7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.RingPlot ringPlot10 = new org.jfree.chart.plot.RingPlot(pieDataset9);
        ringPlot10.setOuterSeparatorExtension(100.0d);
        double double13 = ringPlot10.getOuterSeparatorExtension();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer17.setSeriesOutlinePaint(4, (java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer17);
        categoryPlot21.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot21.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot21.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray31 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis30 };
        categoryPlot21.setDomainAxes(categoryAxisArray31);
        org.jfree.data.general.PieDataset pieDataset33 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D34 = new org.jfree.chart.plot.PiePlot3D(pieDataset33);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        piePlot3D34.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        piePlot3D34.setShadowPaint((java.awt.Paint) color39);
        categoryPlot21.setOutlinePaint((java.awt.Paint) color39);
        ringPlot10.setLabelLinkPaint((java.awt.Paint) color39);
        boolean boolean43 = numberTickUnit6.equals((java.lang.Object) ringPlot10);
        try {
            java.lang.Number number44 = defaultKeyedValues2D1.getValue(comparable5, (java.lang.Comparable) boolean43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(categoryAxisArray31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        java.awt.Paint paint19 = xYPlot16.getDomainCrosshairPaint();
        java.awt.Stroke stroke20 = xYPlot16.getDomainCrosshairStroke();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        java.text.DateFormat dateFormat38 = null;
        dateAxis29.setDateFormatOverride(dateFormat38);
        boolean boolean40 = dateAxis29.isPositiveArrowVisible();
        try {
            dateAxis29.zoomRange((double) 10.0f, 12.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeries1.fireSeriesChanged();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        int int5 = year4.getYear();
        org.jfree.data.gantt.Task task6 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year4);
        taskSeries1.remove(task6);
        int int8 = task6.getSubtaskCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        java.util.List list67 = xYPlot16.getAnnotations();
        boolean boolean68 = xYPlot16.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        java.awt.Shape shape5 = dateAxis1.getRightArrow();
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font14, (java.awt.Paint) color15);
        categoryPlot7.setNoDataMessageFont(font14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        int int19 = categoryPlot7.getDomainAxisIndex(categoryAxis18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font21 = categoryAxis20.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer25.setSeriesOutlinePaint(4, (java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer25);
        categoryPlot29.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot29.setDomainAxis(categoryAxis33);
        double double35 = categoryAxis33.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        double double39 = categoryAxis38.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray40 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis20, categoryAxis33, categoryAxis36, categoryAxis38 };
        categoryPlot7.setDomainAxes(categoryAxisArray40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        double double44 = categoryAxis43.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis43.getCategoryMiddle((int) (short) 0, 10, rectangle2D47, rectangleEdge48);
        categoryAxis43.setCategoryMargin((double) 100L);
        boolean boolean52 = categoryAxis43.isVisible();
        categoryPlot7.setDomainAxis(2, categoryAxis43, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNotNull(categoryAxisArray40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.2d + "'", double44 == 0.2d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        stackedBarRenderer3D1.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D22 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D22.setSeriesPaint((int) (byte) 100, paint24, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer30.setSeriesOutlinePaint(4, (java.awt.Paint) color32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer30);
        org.jfree.data.general.DatasetGroup datasetGroup35 = categoryPlot34.getDatasetGroup();
        stackedBarRenderer3D22.setPlot(categoryPlot34);
        categoryPlot34.setRangeCrosshairValue((double) 0, true);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = null;
        dateAxis41.setTickUnit(dateTickUnit42);
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = dateAxis41.getTickUnit();
        double double45 = dateAxis41.getAutoRangeMinimumSize();
        java.util.Date date46 = dateAxis41.getMinimumDate();
        java.util.TimeZone timeZone47 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        dateAxis41.setTimeZone(timeZone47);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment51 = textTitle50.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D53.setMinimumBarLength((double) (byte) -1);
        boolean boolean58 = stackedBarRenderer3D53.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D53.setDrawBarOutline(true);
        double double61 = stackedBarRenderer3D53.getYOffset();
        boolean boolean62 = horizontalAlignment51.equals((java.lang.Object) stackedBarRenderer3D53);
        org.jfree.chart.util.VerticalAlignment verticalAlignment63 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement66 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment51, verticalAlignment63, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer67 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement66);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D68 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D68.configure();
        java.text.NumberFormat numberFormat70 = null;
        numberAxis3D68.setNumberFormatOverride(numberFormat70);
        org.jfree.chart.util.Size2D size2D75 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D75.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D81 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D75, (double) (short) -1, (double) ' ', rectangleAnchor80);
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double83 = numberAxis3D68.valueToJava2D((double) 'a', rectangle2D81, rectangleEdge82);
        blockContainer67.setBounds(rectangle2D81);
        org.jfree.chart.title.TextTitle textTitle85 = new org.jfree.chart.title.TextTitle();
        textTitle85.setID("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = textTitle85.getPosition();
        double double89 = dateAxis41.lengthToJava2D(97.0d, rectangle2D81, rectangleEdge88);
        try {
            stackedBarRenderer3D1.drawOutline(graphics2D20, categoryPlot34, rectangle2D81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNull(dateTickUnit44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.0d + "'", double45 == 2.0d);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(horizontalAlignment51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 8.0d + "'", double61 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 9359.5d + "'", double83 == 9359.5d);
        org.junit.Assert.assertNotNull(rectangleEdge88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 9409.0d + "'", double89 == 9409.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        java.awt.Shape shape16 = stackedBarRenderer3D1.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset17.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range22 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        boolean boolean24 = range22.contains((double) 12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        multiplePiePlot4.setLimit(10.0d);
        org.jfree.data.category.CategoryDataset categoryDataset7 = multiplePiePlot4.getDataset();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        try {
            multiplePiePlot4.setPieChart(jFreeChart8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'pieChart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(categoryDataset7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) -1, (float) (byte) 10, (float) 1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesCreateEntities(8, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getNegativeItemLabelPosition((int) 'a', 7);
        java.awt.Shape shape8 = statisticalLineAndShapeRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) '4', (double) ' ');
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot16.getIndexOf(xYItemRenderer18);
        org.jfree.data.general.WaferMapDataset waferMapDataset20 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot21 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset20);
        boolean boolean23 = waferMapPlot21.equals((java.lang.Object) 100L);
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit24, dataset25);
        waferMapPlot21.datasetChanged(datasetChangeEvent26);
        xYPlot16.datasetChanged(datasetChangeEvent26);
        java.awt.Paint paint30 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer31 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke32 = minMaxCategoryRenderer31.getGroupStroke();
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) 2, paint30, stroke32);
        xYPlot16.setRangeCrosshairStroke(stroke32);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTickUnit24);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis5.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer12 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer12.setSeriesOutlinePaint(4, (java.awt.Paint) color14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer12);
        categoryPlot16.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot16.markerChanged(markerChangeEvent20);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot16.addDomainMarker(categoryMarker23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot16.getDomainAxisForDataset(2019);
        dateAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        java.awt.Stroke stroke28 = dateAxis5.getTickMarkStroke();
        dateAxis5.setPositiveArrowVisible(true);
        org.jfree.data.Range range31 = dateAxis5.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range31);
        org.junit.Assert.assertNull(dateTickUnit8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(categoryAxis26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 5);
        categoryAxis11.setMaximumCategoryLabelWidthRatio(0.0f);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultKeyedValues0.equals(obj4);
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByValues(sortOrder6);
        java.lang.Comparable comparable8 = null;
        try {
            defaultKeyedValues0.removeValue(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer6.setSeriesOutlinePaint(4, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer6);
        categoryPlot10.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot10.setDomainAxis(categoryAxis14);
        java.awt.Paint paint16 = categoryAxis14.getLabelPaint();
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font2, paint16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font20 = categoryAxis19.getTickLabelFont();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer21 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint24 = ganttRenderer21.getItemOutlinePaint(0, (int) ' ');
        textBlock17.addLine("{0}", font20, paint24);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = textLine26.calculateDimensions(graphics2D27);
        textBlock17.addLine(textLine26);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        double double31 = categoryAxis30.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis30.getCategoryMiddle((int) (short) 0, 10, rectangle2D34, rectangleEdge35);
        boolean boolean37 = textBlock17.equals((java.lang.Object) rectangle2D34);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot7.getDatasetGroup();
        java.util.List list9 = categoryPlot7.getCategories();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(datasetGroup8);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        categoryPlot13.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19);
        boolean boolean21 = categoryPlot13.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot13.getLegendItems();
        boolean boolean23 = statisticalLineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot13);
        java.awt.Paint paint25 = statisticalLineAndShapeRenderer0.getSeriesOutlinePaint(10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        double double17 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateBottomOutset((double) (short) -1);
        categoryPlot7.setAxisOffset(rectangleInsets18);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot7.getRangeAxisForDataset((int) (byte) 100);
        boolean boolean24 = categoryPlot7.isRangeZoomable();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        stackedBarRenderer3D1.notifyListeners(rendererChangeEvent7);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font12, (java.awt.Paint) color13);
        stackedBarRenderer3D1.setBaseItemLabelFont(font12, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        java.awt.color.ColorSpace colorSpace4 = color2.getColorSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        stackedBarRenderer3D1.notifyListeners(rendererChangeEvent7);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit0, dataset1);
        java.lang.String str4 = dateTickUnit0.valueToString((double) (-1.0f));
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        int int7 = year6.getYear();
        org.jfree.data.gantt.Task task8 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year6);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        int int11 = year10.getYear();
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year10);
        task8.addSubtask(task12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        int int15 = year14.getYear();
        java.util.Date date16 = year14.getEnd();
        int int18 = year14.compareTo((java.lang.Object) 0.05d);
        task12.setDuration((org.jfree.data.time.TimePeriod) year14);
        java.util.Date date20 = year14.getEnd();
        java.text.DateFormat dateFormat23 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat23);
        java.lang.String str26 = dateTickUnit24.valueToString((double) 9999);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        java.util.Date date28 = year27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date30 = dateTickUnit24.rollDate(date28, timeZone29);
        java.util.Date date31 = dateTickUnit0.addToDate(date20, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        int int33 = year32.getYear();
        java.util.Date date34 = year32.getEnd();
        org.jfree.chart.JFreeChart jFreeChart35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date34, jFreeChart35);
        java.util.Date date37 = dateTickUnit0.addToDate(date34);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit40 = null;
        dateAxis39.setTickUnit(dateTickUnit40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit42 = dateAxis39.getTickUnit();
        double double43 = dateAxis39.getAutoRangeMinimumSize();
        java.util.Date date44 = dateAxis39.getMinimumDate();
        java.util.TimeZone timeZone45 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        dateAxis39.setTimeZone(timeZone45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date34, timeZone45);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "12/31/69 3:59 PM" + "'", str4.equals("12/31/69 3:59 PM"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "12/31/69" + "'", str26.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(dateTickUnit42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        java.awt.Stroke stroke4 = defaultDrawingSupplier2.getNextOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke4, rectangleInsets5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        int int9 = month7.getMonth();
        boolean boolean10 = lineBorder6.equals((java.lang.Object) month7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        java.awt.Color color16 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        java.awt.Stroke stroke19 = defaultDrawingSupplier17.getNextOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color16, stroke19, rectangleInsets20);
        stackedBarRenderer3D1.setBaseStroke(stroke19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        int int1 = keyToGroupMap0.getGroupCount();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date6 = dateAxis5.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str9 = textAnchor8.toString();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick12 = new org.jfree.chart.axis.DateTick(date6, "12/31/69", textAnchor8, textAnchor10, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date15 = dateAxis14.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str18 = textAnchor17.toString();
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick21 = new org.jfree.chart.axis.DateTick(date15, "12/31/69", textAnchor17, textAnchor19, 0.0d);
        org.jfree.chart.axis.NumberTick numberTick23 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "hi!", textAnchor10, textAnchor17, (double) (short) 10);
        boolean boolean24 = keyToGroupMap0.equals((java.lang.Object) textAnchor17);
        int int25 = keyToGroupMap0.getGroupCount();
        java.lang.Object obj26 = keyToGroupMap0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str9.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str18.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.clear();
        int int4 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) (byte) 1);
        int int5 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        double double3 = dateAxis1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        boolean boolean11 = categoryLabelWidthType5.equals((java.lang.Object) multiplePiePlot10);
        boolean boolean12 = defaultCategoryDataset0.hasListener((java.util.EventListener) multiplePiePlot10);
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        dateAxis1.setUpperMargin((double) 100);
        org.junit.Assert.assertNull(dateFormat4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Color color2 = java.awt.Color.getColor("{0}", (int) (short) 100);
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot16.getRangeAxis();
        xYPlot16.setRangeCrosshairValue((double) 7, false);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis18);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        dateAxis20.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        dateAxis27.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        xYPlot34.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot34.getDomainAxisLocation();
        xYPlot16.setRangeAxisLocation(axisLocation36, false);
        boolean boolean39 = xYPlot16.isDomainCrosshairLockedOnData();
        try {
            xYPlot16.setBackgroundImageAlpha((float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(dateTickUnit23);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.Object obj2 = null;
        boolean boolean3 = projectInfo0.equals(obj2);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        boolean boolean5 = statisticalLineAndShapeRenderer0.isSeriesVisibleInLegend((int) (byte) 10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        statisticalLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) '#', false);
        java.lang.Boolean boolean7 = statisticalLineAndShapeRenderer0.getSeriesLinesVisible((int) (short) -1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleAnchor.BOTTOM_RIGHT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setShadowYOffset((double) 6);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        piePlot3D1.setLabelLinkPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(true);
        double double9 = stackedBarRenderer3D1.getYOffset();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = stackedBarRenderer3D1.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset3, (java.lang.Comparable) 0.0f);
        org.jfree.chart.block.Arrangement arrangement6 = legendItemBlockContainer5.getArrangement();
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(arrangement6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(5, (java.lang.Boolean) true);
        java.lang.Boolean boolean8 = statisticalLineAndShapeRenderer0.getSeriesShapesFilled((int) (byte) 1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = segmentedTimeline3.getBaseTimeline();
        boolean boolean6 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.jfree.data.Range range7 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setDefaultAutoRange(range7);
        boolean boolean9 = dateAxis1.isNegativeArrowVisible();
        boolean boolean11 = dateAxis1.isHiddenValue((long) (byte) -1);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D8.setSeriesPaint((int) (byte) 100, paint10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot20.getDatasetGroup();
        stackedBarRenderer3D8.setPlot(categoryPlot20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer26.setSeriesOutlinePaint(4, (java.awt.Paint) color28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer26);
        categoryPlot30.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot30.zoomRangeAxes(0.0d, plotRenderingInfo35, point2D36);
        categoryPlot30.configureRangeAxes();
        boolean boolean39 = categoryPlot30.isRangeZoomable();
        double double40 = categoryPlot30.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit44 = null;
        dateAxis43.setTickUnit(dateTickUnit44);
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis43.getTickUnit();
        dateAxis43.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit51 = null;
        dateAxis50.setTickUnit(dateTickUnit51);
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = dateAxis50.getTickUnit();
        dateAxis50.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset41, (org.jfree.chart.axis.ValueAxis) dateAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis50, xYItemRenderer56);
        xYPlot57.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer63 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color65 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer63.setSeriesOutlinePaint(4, (java.awt.Paint) color65);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer63);
        categoryPlot67.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        java.awt.geom.Point2D point2D73 = null;
        categoryPlot67.zoomRangeAxes(0.0d, plotRenderingInfo72, point2D73);
        boolean boolean75 = categoryPlot67.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection76 = categoryPlot67.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation78 = categoryPlot67.getDomainAxisLocation(10);
        xYPlot57.setRangeAxisLocation((int) (byte) 10, axisLocation78);
        categoryPlot30.setRangeAxisLocation(axisLocation78, false);
        categoryPlot20.setDomainAxisLocation(axisLocation78, true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit46);
        org.junit.Assert.assertNull(dateTickUnit53);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(legendItemCollection76);
        org.junit.Assert.assertNotNull(axisLocation78);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj2 = defaultCategoryDataset1.clone();
        java.util.List list3 = defaultCategoryDataset1.getColumnKeys();
        boolean boolean4 = color0.equals((java.lang.Object) defaultCategoryDataset1);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, (-32513));
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset6, (java.lang.Comparable) 0.25d, 1.0E-8d, 0);
        org.jfree.chart.plot.RingPlot ringPlot11 = new org.jfree.chart.plot.RingPlot(pieDataset6);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNotNull(pieDataset10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke5 = minMaxCategoryRenderer4.getGroupStroke();
        ringPlot1.setSeparatorStroke(stroke5);
        ringPlot1.setShadowYOffset((double) 60000L);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 2);
        int int3 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.removeRow(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition38 = null;
        try {
            dateAxis29.setTickMarkPosition(dateTickMarkPosition38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range4);
        boolean boolean8 = range4.intersects((double) 7, (double) 2958465);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        java.awt.Color color4 = java.awt.Color.DARK_GRAY;
        ringPlot1.setLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint6 = ringPlot1.getLabelOutlinePaint();
        double double7 = ringPlot1.getSectionDepth();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font10 = categoryAxis9.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer14.setSeriesOutlinePaint(4, (java.awt.Paint) color16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer14);
        categoryPlot18.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot18.setDomainAxis(categoryAxis22);
        java.awt.Paint paint24 = categoryAxis22.getLabelPaint();
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font10, paint24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font28 = categoryAxis27.getTickLabelFont();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer29 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint32 = ganttRenderer29.getItemOutlinePaint(0, (int) ' ');
        textBlock25.addLine("{0}", font28, paint32);
        ringPlot1.setLabelFont(font28);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        java.awt.Shape shape3 = chartEntity2.getArea();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape3, "12/31/69 3:59 PM", "Range[0.0,1.0]");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D1.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D1.setAutoPopulateSeriesOutlineStroke(true);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        java.awt.Paint paint22 = stackedBarRenderer3D1.getSeriesOutlinePaint((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(itemLabelPosition16);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot16.getIndexOf(xYItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot16.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot16.getRangeAxis();
        java.lang.Object obj23 = xYPlot16.clone();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(valueAxis22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 10, (double) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer3D2.setSeriesURLGenerator(0, categoryURLGenerator4, false);
        java.lang.Boolean boolean8 = barRenderer3D2.getSeriesItemLabelsVisible((-1));
        java.awt.Paint paint10 = barRenderer3D2.lookupSeriesFillPaint((int) '4');
        java.awt.Paint paint12 = barRenderer3D2.lookupSeriesOutlinePaint(2);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        piePlot3D7.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke10);
        dateAxis1.setAxisLineStroke(stroke10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        int int14 = year13.getYear();
        java.util.Date date15 = year13.getEnd();
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date15, jFreeChart16);
        dateAxis1.setMaximumDate(date15);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.lang.Object obj2 = textTitle0.clone();
        java.awt.Paint paint3 = textTitle0.getBackgroundPaint();
        java.lang.String str4 = textTitle0.getToolTipText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray9, comparableArray10, numberArray11, numberArray12);
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) defaultIntervalCategoryDataset13);
        java.text.DateFormat dateFormat18 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat18);
        java.lang.String str21 = dateTickUnit19.valueToString(0.0d);
        try {
            java.lang.Number number22 = defaultIntervalCategoryDataset13.getStartValue((java.lang.Comparable) "0,-100,100,100,-100,100,-100,100", (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "12/31/69" + "'", str21.equals("12/31/69"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.setWeight(0);
        java.awt.Image image23 = null;
        categoryPlot7.setBackgroundImage(image23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot7.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setDrawLines(false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("{0}");
        minMaxCategoryRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D7.setSeriesPaint((int) (byte) 100, paint9, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        org.jfree.data.general.DatasetGroup datasetGroup20 = categoryPlot19.getDatasetGroup();
        stackedBarRenderer3D7.setPlot(categoryPlot19);
        boolean boolean22 = stackedBarRenderer3D7.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke25 = stackedBarRenderer3D7.getItemStroke((int) (short) 100, (int) (short) 1);
        minMaxCategoryRenderer0.setGroupStroke(stroke25);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(datasetGroup20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat6 = dateAxis3.getDateFormatOverride();
        java.awt.Shape shape7 = dateAxis3.getRightArrow();
        dateAxis3.setAutoTickUnitSelection(true);
        java.awt.Paint paint10 = dateAxis3.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("{0}", font1, paint10);
        labelBlock11.setToolTipText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        org.jfree.chart.LegendItemCollection legendItemCollection4 = ringPlot1.getLegendItems();
        java.util.Iterator iterator5 = legendItemCollection4.iterator();
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(iterator5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot16.getIndexOf(xYItemRenderer18);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot16.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot16.getRangeAxis();
        valueAxis22.setAxisLineVisible(false);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(valueAxis22);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        java.lang.Object obj8 = piePlot3D1.clone();
        java.awt.Paint paint9 = piePlot3D1.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.TAPER" + "'", str1.equals("AreaRendererEndType.TAPER"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        stackedBarRenderer3D1.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = stackedBarRenderer3D1.getPositiveItemLabelPosition((int) (byte) 1, (int) (byte) 0);
        double double16 = itemLabelPosition15.getAngle();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D(pieDataset2);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        piePlot3D3.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke6);
        strokeList0.setStroke(3, stroke6);
        java.lang.Object obj9 = strokeList0.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) (-3695), (java.lang.Number) 0L);
        try {
            defaultKeyedValues0.insertValue((int) (short) 10, (java.lang.Comparable) 1577865599999L, 9409.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        xYPlot16.setRangeCrosshairValue((double) 6);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot16.setFixedDomainAxisSpace(axisSpace22);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setAutoTickUnitSelection(false);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) (short) 100);
        dateAxis1.setDownArrow(shape9);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 100, (float) 10L);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleAnchor.BOTTOM_RIGHT", "({0}, {1}) = {2}");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot7.getDatasetGroup();
        categoryPlot7.configureRangeAxes();
        categoryPlot7.clearRangeAxes();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(datasetGroup8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        java.lang.String str3 = size2D2.toString();
        size2D2.height = 3.0d;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, 0.0d, (double) 15, rectangleAnchor8);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.util.Date date13 = year12.getStart();
        boolean boolean14 = textAnchor11.equals((java.lang.Object) year12);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType16 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor8, textBlockAnchor10, textAnchor11, (double) 1559372400000L, categoryLabelWidthType16, (float) 0L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=97.0, height=0.0]" + "'", str3.equals("Size2D[width=97.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat2);
        java.lang.String str5 = dateTickUnit3.valueToString((double) 9999);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.util.Date date7 = year6.getStart();
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date9 = dateTickUnit3.rollDate(date7, timeZone8);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, 0.0d, 2.0f, (float) (short) 1);
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) date7, shape15, "ItemLabelAnchor.INSIDE6", "{0}");
        java.lang.Comparable comparable19 = categoryLabelEntity18.getKey();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12/31/69" + "'", str5.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        segment10.moveIndexToStart();
        long long12 = segment10.getSegmentNumber();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textTitle7.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D10.setMinimumBarLength((double) (byte) -1);
        boolean boolean15 = stackedBarRenderer3D10.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D10.setDrawBarOutline(true);
        double double18 = stackedBarRenderer3D10.getYOffset();
        boolean boolean19 = horizontalAlignment8.equals((java.lang.Object) stackedBarRenderer3D10);
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement23 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment20, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer24 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D25.configure();
        java.text.NumberFormat numberFormat27 = null;
        numberAxis3D25.setNumberFormatOverride(numberFormat27);
        org.jfree.chart.util.Size2D size2D32 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D32.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D38 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D32, (double) (short) -1, (double) ' ', rectangleAnchor37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double40 = numberAxis3D25.valueToJava2D((double) 'a', rectangle2D38, rectangleEdge39);
        blockContainer24.setBounds(rectangle2D38);
        piePlot3D1.drawBackgroundImage(graphics2D6, rectangle2D38);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 8.0d + "'", double18 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 9359.5d + "'", double40 == 9359.5d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getFirstMillisecond();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer5.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer5);
        categoryPlot9.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo14, point2D15);
        java.awt.Image image17 = categoryPlot9.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot9.getRenderer((-3695));
        int int20 = month0.compareTo((java.lang.Object) (-3695));
        int int21 = month0.getMonth();
        java.util.Date date22 = month0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1559372400000L + "'", long1 == 1559372400000L);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition12);
        stackedBarRenderer3D1.setMaximumBarWidth((double) (short) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = stackedBarRenderer3D1.getNegativeItemLabelPositionFallback();
        stackedBarRenderer3D1.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot(pieDataset20);
        ringPlot21.setOuterSeparatorExtension((double) (byte) 100);
        java.awt.Stroke stroke24 = ringPlot21.getSeparatorStroke();
        stackedBarRenderer3D1.setSeriesOutlineStroke((int) (short) 0, stroke24);
        double double26 = stackedBarRenderer3D1.getYOffset();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 8.0d + "'", double26 == 8.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D3.setMinimumBarLength((double) (byte) -1);
        boolean boolean8 = stackedBarRenderer3D3.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D3.setDrawBarOutline(true);
        double double11 = stackedBarRenderer3D3.getYOffset();
        boolean boolean12 = horizontalAlignment1.equals((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment13, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D20 = blockContainer17.arrange(graphics2D18, rectangleConstraint19);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
        org.junit.Assert.assertNotNull(size2D20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat4 = dateAxis1.getDateFormatOverride();
        java.awt.Shape shape5 = dateAxis1.getRightArrow();
        dateAxis1.setAutoTickUnitSelection(true);
        org.jfree.data.Range range8 = null;
        try {
            dateAxis1.setDefaultAutoRange(range8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        int int8 = year7.getYear();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year7);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        int int12 = year11.getYear();
        org.jfree.data.gantt.Task task13 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year11);
        task9.addSubtask(task13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        java.util.Date date17 = year15.getEnd();
        int int19 = year15.compareTo((java.lang.Object) 0.05d);
        task13.setDuration((org.jfree.data.time.TimePeriod) year15);
        java.util.Date date21 = year15.getStart();
        segmentedTimeline5.addException(date21);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int27 = segmentedTimeline26.getSegmentsExcluded();
        java.util.List list28 = segmentedTimeline26.getExceptionSegments();
        segmentedTimeline5.setExceptionSegments(list28);
        boolean boolean30 = numberAxis3D0.equals((java.lang.Object) list28);
        org.junit.Assert.assertNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 100 + "'", int27 == 100);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis4.setTickUnit(dateTickUnit5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis4.getTickUnit();
        dateAxis4.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis11.setTickUnit(dateTickUnit12);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis11.getTickUnit();
        dateAxis11.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer17);
        xYPlot18.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis21.setStandardTickUnits(tickUnitSource24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D27.setMinimumBarLength((double) (byte) -1);
        boolean boolean32 = stackedBarRenderer3D27.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D27.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = stackedBarRenderer3D27.getBaseToolTipGenerator();
        stackedBarRenderer3D27.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer42.setSeriesOutlinePaint(4, (java.awt.Paint) color44);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer42);
        categoryPlot46.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        categoryPlot46.markerChanged(markerChangeEvent50);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = null;
        dateAxis53.setTickUnit(dateTickUnit54);
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = dateAxis53.getTickUnit();
        double double57 = dateAxis53.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        stackedBarRenderer3D27.drawRangeGridline(graphics2D38, categoryPlot46, (org.jfree.chart.axis.ValueAxis) dateAxis53, rectangle2D58, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        dateAxis62.setNegativeArrowVisible(false);
        org.jfree.data.Range range65 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis62.setRangeWithMargins(range65);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray67 = new org.jfree.chart.axis.ValueAxis[] { dateAxis21, dateAxis53, dateAxis62 };
        xYPlot18.setRangeAxes(valueAxisArray67);
        org.jfree.chart.plot.CategoryMarker categoryMarker70 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Stroke stroke71 = categoryMarker70.getOutlineStroke();
        org.jfree.chart.util.Layer layer72 = null;
        xYPlot18.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker70, layer72);
        java.awt.Paint paint75 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot18.setQuadrantPaint((int) (byte) 1, paint75);
        org.jfree.chart.text.TextLine textLine77 = new org.jfree.chart.text.TextLine("TextBlockAnchor.BOTTOM_LEFT", font1, paint75);
        org.jfree.data.gantt.TaskSeries taskSeries79 = new org.jfree.data.gantt.TaskSeries("hi!");
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year();
        int int82 = year81.getYear();
        java.util.Date date83 = year81.getEnd();
        org.jfree.data.gantt.Task task84 = new org.jfree.data.gantt.Task("12/31/69", (org.jfree.data.time.TimePeriod) year81);
        taskSeries79.add(task84);
        java.lang.Comparable comparable86 = taskSeries79.getKey();
        boolean boolean87 = textLine77.equals((java.lang.Object) comparable86);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(dateTickUnit7);
        org.junit.Assert.assertNull(dateTickUnit14);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator35);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(dateTickUnit56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertNotNull(valueAxisArray67);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2019 + "'", int82 == 2019);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + comparable86 + "' != '" + "hi!" + "'", comparable86.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint3 = ganttRenderer0.getItemOutlinePaint(0, (int) ' ');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D5.setMinimumBarLength((double) (byte) -1);
        boolean boolean10 = stackedBarRenderer3D5.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D5.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = stackedBarRenderer3D5.getBaseToolTipGenerator();
        stackedBarRenderer3D5.setRenderAsPercentages(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = null;
        stackedBarRenderer3D5.setPositiveItemLabelPositionFallback(itemLabelPosition16);
        java.awt.Paint paint19 = stackedBarRenderer3D5.lookupSeriesPaint((int) (short) 100);
        ganttRenderer0.setIncompletePaint(paint19);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot20.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray30 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis29 };
        categoryPlot20.setDomainAxes(categoryAxisArray30);
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D(pieDataset32);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextOutlineStroke();
        piePlot3D33.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke36);
        java.awt.Color color38 = java.awt.Color.darkGray;
        piePlot3D33.setShadowPaint((java.awt.Paint) color38);
        categoryPlot20.setOutlinePaint((java.awt.Paint) color38);
        boolean boolean41 = categoryAxis11.equals((java.lang.Object) color38);
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 24234L);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertNotNull(categoryAxisArray30);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        java.awt.Paint paint20 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Font font21 = categoryPlot7.getNoDataMessageFont();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            categoryPlot7.addAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        java.lang.String str3 = size2D2.toString();
        size2D2.height = 3.0d;
        size2D2.setWidth((double) (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=97.0, height=0.0]" + "'", str3.equals("Size2D[width=97.0, height=0.0]"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        piePlot3D1.setLabelLinksVisible(false);
        piePlot3D1.setIgnoreZeroValues(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator12 = piePlot3D1.getURLGenerator();
        piePlot3D1.setIgnoreNullValues(true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(pieURLGenerator12);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 2);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) year3);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        piePlot3D2.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D2.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D2.setLabelLinksVisible(false);
        piePlot3D2.setIgnoreNullValues(true);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = piePlot3D2.getLegendItems();
        boolean boolean14 = intervalCategoryToolTipGenerator0.equals((java.lang.Object) legendItemCollection13);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        segment10.inc();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.resizeRange((double) 60000L, 0.0d);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition5 = dateAxis1.getTickMarkPosition();
        org.junit.Assert.assertNotNull(dateTickMarkPosition5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleEdge0.equals(obj1);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("12/31/69 3:59 PM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder();
        textTitle6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder7);
        boolean boolean9 = segmentedTimeline3.equals((java.lang.Object) textTitle6);
        java.util.List list10 = null;
        try {
            segmentedTimeline3.addExceptions(list10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3100L + "'", long5 == 3100L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D3.setMinimumBarLength((double) (byte) -1);
        boolean boolean8 = stackedBarRenderer3D3.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D3.setDrawBarOutline(true);
        double double11 = stackedBarRenderer3D3.getYOffset();
        boolean boolean12 = horizontalAlignment1.equals((java.lang.Object) stackedBarRenderer3D3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement16 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment13, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement16);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.RingPlot ringPlot19 = new org.jfree.chart.plot.RingPlot(pieDataset18);
        ringPlot19.setOuterSeparatorExtension((double) (byte) 100);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer22 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke23 = minMaxCategoryRenderer22.getGroupStroke();
        ringPlot19.setSeparatorStroke(stroke23);
        boolean boolean25 = columnArrangement16.equals((java.lang.Object) ringPlot19);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator26 = ringPlot19.getToolTipGenerator();
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(pieToolTipGenerator26);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        double double17 = categoryPlot7.getRangeCrosshairValue();
        categoryPlot7.configureRangeAxes();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot7.getDomainAxisLocation(10);
        java.lang.String str19 = axisLocation18.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str19.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2019);
        java.lang.Object obj3 = objectList1.get(12);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        double double5 = categoryAxis4.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis4.getCategoryMiddle((int) (short) 0, 10, rectangle2D8, rectangleEdge9);
        categoryAxis4.setCategoryMargin((double) 100L);
        boolean boolean13 = objectList1.equals((java.lang.Object) categoryAxis4);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        boolean boolean16 = stackedBarRenderer3D1.getAutoPopulateSeriesPaint();
        boolean boolean17 = stackedBarRenderer3D1.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        segmentedTimeline3.addException((long) 0);
        int int7 = segmentedTimeline3.getSegmentsExcluded();
        int int8 = segmentedTimeline3.getSegmentsExcluded();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        java.awt.Paint paint21 = xYPlot16.getQuadrantPaint((int) (short) 1);
        java.lang.Object obj22 = xYPlot16.clone();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        java.awt.Paint paint19 = xYPlot16.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        int int21 = xYPlot16.getIndexOf(xYItemRenderer20);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection24 = null;
        chartRenderingInfo23.setEntityCollection(entityCollection24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo23);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        dateAxis29.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = null;
        dateAxis36.setTickUnit(dateTickUnit37);
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis36.getTickUnit();
        dateAxis36.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer42);
        xYPlot43.configureRangeAxes();
        java.awt.Stroke stroke45 = xYPlot43.getRangeZeroBaselineStroke();
        xYPlot43.setRangeCrosshairValue((double) (-3695));
        xYPlot43.setRangeZeroBaselineVisible(true);
        java.awt.geom.Point2D point2D50 = xYPlot43.getQuadrantOrigin();
        xYPlot16.zoomRangeAxes(100.0d, plotRenderingInfo26, point2D50);
        boolean boolean52 = xYPlot16.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(dateTickUnit32);
        org.junit.Assert.assertNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        statisticalLineAndShapeRenderer0.setSeriesVisible((int) ' ', (java.lang.Boolean) true);
        statisticalLineAndShapeRenderer0.setBaseShapesVisible(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer0.getSeriesShapesFilled((-32513));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot20.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot20.getDomainAxisForDataset((int) '#');
        org.jfree.chart.LegendItemCollection legendItemCollection38 = categoryPlot20.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(categoryAxis37);
        org.junit.Assert.assertNull(legendItemCollection38);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "TextAnchor.TOP_CENTER", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "ERROR : Relative To String");
        basicProjectInfo4.setCopyright("Size2D[width=97.0, height=0.0]");
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat17 = dateAxis14.getDateFormatOverride();
        java.awt.Shape shape18 = dateAxis14.getRightArrow();
        dateAxis14.setAutoTickUnitSelection(true);
        java.awt.Paint paint21 = dateAxis14.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("{0}", font12, paint21);
        stackedBarRenderer3D1.setBasePaint(paint21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = stackedBarRenderer3D1.getNegativeItemLabelPosition(4, 7);
        java.lang.Boolean boolean28 = stackedBarRenderer3D1.getSeriesVisible((int) (byte) 10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(dateFormat17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNull(boolean28);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        java.lang.Object obj2 = textTitle0.clone();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle3.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D6.setMinimumBarLength((double) (byte) -1);
        boolean boolean11 = stackedBarRenderer3D6.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D6.setDrawBarOutline(true);
        double double14 = stackedBarRenderer3D6.getYOffset();
        boolean boolean15 = horizontalAlignment4.equals((java.lang.Object) stackedBarRenderer3D6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement19 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment16, 0.2d, (double) (-1));
        textTitle0.setHorizontalAlignment(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 8.0d + "'", double14 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        java.util.Date date11 = year9.getEnd();
        int int13 = year9.compareTo((java.lang.Object) 0.05d);
        task7.setDuration((org.jfree.data.time.TimePeriod) year9);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        int int16 = year15.getYear();
        task7.setDuration((org.jfree.data.time.TimePeriod) year15);
        task7.setPercentComplete(0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.Number number7 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 4, (java.lang.Number) 3.0d, (java.lang.Number) 1L, (java.lang.Number) 0.5f, (java.lang.Number) 32.0d, (java.lang.Number) 2958465, (java.lang.Number) 0.05d, number7, list8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot7.addDomainMarker(categoryMarker14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxisForDataset(2019);
        int int18 = categoryAxis17.getMaximumCategoryLabelLines();
        categoryAxis17.setLabelURL("TextBlockAnchor.BOTTOM_CENTER");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(categoryAxis17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint2 = categoryMarker1.getOutlinePaint();
        categoryMarker1.setDrawAsLine(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        categoryPlot13.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        categoryPlot13.markerChanged(markerChangeEvent17);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot13.addDomainMarker(categoryMarker20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer25.setSeriesOutlinePaint(4, (java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer25);
        categoryPlot29.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot29.setDomainAxis(categoryAxis33);
        java.awt.Font font36 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font36, (java.awt.Paint) color37);
        categoryPlot29.setNoDataMessageFont(font36);
        categoryMarker20.setLabelFont(font36);
        categoryMarker1.setLabelFont(font36);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.RingPlot ringPlot43 = new org.jfree.chart.plot.RingPlot(pieDataset42);
        ringPlot43.setOuterSeparatorExtension(100.0d);
        java.awt.Color color46 = java.awt.Color.DARK_GRAY;
        ringPlot43.setLabelPaint((java.awt.Paint) color46);
        categoryMarker1.setOutlinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        defaultKeyedValues0.removeValue((java.lang.Comparable) 10L);
        defaultKeyedValues0.insertValue(0, (java.lang.Comparable) 1.0E-5d, (double) 6);
        try {
            java.lang.Comparable comparable11 = defaultKeyedValues0.getKey((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeries1.fireSeriesChanged();
        taskSeries1.removeAll();
        java.lang.String str4 = taskSeries1.getDescription();
        taskSeries1.fireSeriesChanged();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        java.awt.Stroke stroke18 = xYPlot16.getRangeZeroBaselineStroke();
        xYPlot16.setRangeCrosshairValue((double) (-3695));
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot16.setRenderer((int) (byte) 0, xYItemRenderer22);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setMaximumBarWidth((double) 1L);
        stackedBarRenderer3D1.setBase(0.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D15.setSeriesPaint((int) (byte) 100, paint17, false);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer23.setSeriesOutlinePaint(4, (java.awt.Paint) color25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer23);
        org.jfree.data.general.DatasetGroup datasetGroup28 = categoryPlot27.getDatasetGroup();
        stackedBarRenderer3D15.setPlot(categoryPlot27);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer34.setSeriesOutlinePaint(4, (java.awt.Paint) color36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer34);
        categoryPlot38.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot38.zoomRangeAxes(0.0d, plotRenderingInfo43, point2D44);
        boolean boolean46 = categoryPlot38.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot38.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot38.getDomainAxisLocation(10);
        categoryPlot27.setRangeAxisLocation((int) '4', axisLocation49);
        boolean boolean51 = stackedBarRenderer3D1.equals((java.lang.Object) categoryPlot27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier52 = categoryPlot27.getDrawingSupplier();
        categoryPlot27.setRangeCrosshairValue((double) 10L, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(datasetGroup28);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(drawingSupplier52);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D2.setSeriesPaint((int) (byte) 100, paint4, false);
        double double7 = stackedBarRenderer3D2.getItemMargin();
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint13 = null;
        stackedBarRenderer3D2.setSeriesPaint((int) (byte) 0, paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer19.setSeriesOutlinePaint(4, (java.awt.Paint) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer19);
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot23.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D15, categoryPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis26, rectangle2D27, (double) (short) 10);
        java.lang.Class<?> wildcardClass30 = dateAxis26.getClass();
        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass30);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(inputStream31);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        defaultCategoryDataset0.addValue((double) 2.0f, (java.lang.Comparable) (byte) 1, (java.lang.Comparable) "TextAnchor.TOP_CENTER");
        java.lang.Object obj9 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font1, (java.awt.Paint) color2);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer4.setSeriesOutlinePaint(4, (java.awt.Paint) color6);
        statisticalLineAndShapeRenderer4.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalLineAndShapeRenderer4.setSeriesToolTipGenerator(0, categoryToolTipGenerator11);
        java.awt.Paint paint14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        statisticalLineAndShapeRenderer4.setSeriesPaint((int) (byte) 0, paint14);
        boolean boolean16 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint) color2, paint14);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        org.jfree.chart.LegendItem legendItem12 = stackedBarRenderer3D1.getLegendItem(2958465, 3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setDrawLines(false);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer3.setDrawLines(false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("{0}");
        minMaxCategoryRenderer3.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator7);
        org.jfree.chart.LegendItem legendItem11 = minMaxCategoryRenderer3.getLegendItem((int) '4', (int) (short) -1);
        javax.swing.Icon icon12 = minMaxCategoryRenderer3.getObjectIcon();
        minMaxCategoryRenderer0.setObjectIcon(icon12);
        org.junit.Assert.assertNull(legendItem11);
        org.junit.Assert.assertNotNull(icon12);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("12/31/69 3:59 PM");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("RectangleAnchor.BOTTOM_RIGHT");
        taskSeries1.setKey((java.lang.Comparable) "0,-100,100,100,-100,100,-100,100");
        taskSeries1.fireSeriesChanged();
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        boolean boolean1 = textTitle0.getNotify();
        boolean boolean2 = textTitle0.getNotify();
        textTitle0.setID("({0}, {1}) = {2}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        boolean boolean3 = color0.equals((java.lang.Object) shape2);
        java.lang.Object obj4 = null;
        boolean boolean5 = color0.equals(obj4);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset3, (java.lang.Comparable) 0.0f);
        flowArrangement0.clear();
        flowArrangement0.clear();
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.setWeight(0);
        java.awt.Image image23 = null;
        categoryPlot7.setBackgroundImage(image23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot7.getDomainAxis();
        categoryAxis25.clearCategoryLabelToolTips();
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) 1L);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(categoryAxis25);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator1 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat2 = intervalCategoryToolTipGenerator1.getNumberFormat();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 1559372400000L, numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26);
        boolean boolean28 = categoryPlot20.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot20.setDataset(categoryDataset29);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot20.setRangeCrosshairPaint(paint31);
        java.awt.Paint paint33 = categoryPlot20.getDomainGridlinePaint();
        java.awt.Font font34 = categoryPlot20.getNoDataMessageFont();
        categoryPlot20.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = statisticalLineAndShapeRenderer3.initialise(graphics2D11, rectangle2D12, categoryPlot20, 4, plotRenderingInfo37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = categoryItemRendererState38.getInfo();
        categoryItemRendererState38.setBarWidth(0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(categoryItemRendererState38);
        org.junit.Assert.assertNull(plotRenderingInfo39);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray3 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, comparableArray1, numberArray2, numberArray3);
        int int5 = defaultIntervalCategoryDataset4.getSeriesCount();
        try {
            defaultIntervalCategoryDataset4.setEndValue(10, (java.lang.Comparable) 10.0d, (java.lang.Number) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.setValue: series outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(3, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "March" + "'", str2.equals("March"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.awt.Color color0 = java.awt.Color.green;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat2);
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D7.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, (double) (short) -1, (double) ' ', rectangleAnchor12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double15 = numberAxis3D0.valueToJava2D((double) 'a', rectangle2D13, rectangleEdge14);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat16);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.axis.TickUnits tickUnits19 = new org.jfree.chart.axis.TickUnits();
        boolean boolean20 = numberTickUnit18.equals((java.lang.Object) tickUnits19);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year22);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = year26.getYear();
        org.jfree.data.gantt.Task task28 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year26);
        task24.addSubtask(task28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        int int31 = year30.getYear();
        java.util.Date date32 = year30.getEnd();
        int int34 = year30.compareTo((java.lang.Object) 0.05d);
        task28.setDuration((org.jfree.data.time.TimePeriod) year30);
        java.util.Date date36 = year30.getEnd();
        java.awt.Color color37 = java.awt.Color.YELLOW;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date36, (java.awt.Paint) color37, stroke38);
        boolean boolean40 = numberTickUnit18.equals((java.lang.Object) categoryMarker39);
        numberAxis3D0.setTickUnit(numberTickUnit18, true, true);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9359.5d + "'", double15 == 9359.5d);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        java.util.Date date6 = dateAxis1.getMinimumDate();
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        dateAxis1.setTimeZone(timeZone7);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textTitle10.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D13.setMinimumBarLength((double) (byte) -1);
        boolean boolean18 = stackedBarRenderer3D13.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D13.setDrawBarOutline(true);
        double double21 = stackedBarRenderer3D13.getYOffset();
        boolean boolean22 = horizontalAlignment11.equals((java.lang.Object) stackedBarRenderer3D13);
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment11, verticalAlignment23, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer27 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D28.configure();
        java.text.NumberFormat numberFormat30 = null;
        numberAxis3D28.setNumberFormatOverride(numberFormat30);
        org.jfree.chart.util.Size2D size2D35 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D35.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D41 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D35, (double) (short) -1, (double) ' ', rectangleAnchor40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double43 = numberAxis3D28.valueToJava2D((double) 'a', rectangle2D41, rectangleEdge42);
        blockContainer27.setBounds(rectangle2D41);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        textTitle45.setID("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = textTitle45.getPosition();
        double double49 = dateAxis1.lengthToJava2D(97.0d, rectangle2D41, rectangleEdge48);
        dateAxis1.setLabel("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9359.5d + "'", double43 == 9359.5d);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 9409.0d + "'", double49 == 9409.0d);
        org.junit.Assert.assertNotNull(tickUnitSource52);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Other");
        java.lang.Object obj2 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset3, (java.lang.Comparable) 0.0f);
        double double6 = legendItemBlockContainer5.getContentXOffset();
        org.jfree.chart.block.Block block7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer11.setSeriesOutlinePaint(4, (java.awt.Paint) color13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer11);
        categoryPlot15.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21);
        boolean boolean23 = categoryPlot15.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot15.setDataset(categoryDataset24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot15.setRangeCrosshairPaint(paint26);
        java.awt.Paint paint28 = categoryPlot15.getDomainGridlinePaint();
        categoryPlot15.setAnchorValue((double) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        double double33 = categoryAxis32.getCategoryMargin();
        categoryPlot15.setDomainAxis(6, categoryAxis32, false);
        legendItemBlockContainer5.add(block7, (java.lang.Object) categoryAxis32);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        java.lang.Object obj4 = null;
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) year1, obj4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        double double7 = categoryAxis6.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis6.getCategoryMiddle((int) (short) 0, 10, rectangle2D10, rectangleEdge11);
        categoryAxis6.setCategoryMargin((double) 100L);
        categoryAxis6.setTickLabelsVisible(true);
        categoryAxis6.setUpperMargin((double) 10.0f);
        boolean boolean19 = keyedObject5.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        xYPlot16.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        xYPlot16.zoomRangeAxes(8.0d, plotRenderingInfo20, point2D21);
        java.awt.Stroke stroke23 = xYPlot16.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        java.awt.Paint paint21 = xYPlot16.getQuadrantPaint((int) (short) 1);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot16.setDomainAxisLocation(31, axisLocation23);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker26.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker26);
        xYPlot16.markerChanged(markerChangeEvent29);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        categoryMarker22.setLabelOffset(rectangleInsets27);
        categoryPlot7.setInsets(rectangleInsets27);
        float float30 = categoryPlot7.getForegroundAlpha();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) 2.0f, (double) 128);
        double double4 = dateRange3.getLength();
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range5, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 31, (org.jfree.data.Range) dateRange3, lengthConstraintType8, (double) (-1), range10, lengthConstraintType11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean14 = lengthConstraintType11.equals((java.lang.Object) rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 126.0d + "'", double4 == 126.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        chartRenderingInfo1.clear();
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        stackedBarRenderer3D1.notifyListeners(rendererChangeEvent7);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setErrorIndicatorPaint((java.awt.Paint) color10);
        java.lang.Object obj12 = statisticalLineAndShapeRenderer9.clone();
        java.awt.Paint paint15 = statisticalLineAndShapeRenderer9.getItemPaint((int) (short) 0, (int) (byte) 10);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator17 = new org.jfree.chart.urls.StandardCategoryURLGenerator("");
        statisticalLineAndShapeRenderer9.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator17);
        stackedBarRenderer3D1.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator17);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        statisticalLineAndShapeRenderer0.setSeriesVisibleInLegend(5, (java.lang.Boolean) true);
        org.jfree.chart.LegendItem legendItem9 = statisticalLineAndShapeRenderer0.getLegendItem((int) 'a', (int) (byte) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        float float17 = categoryPlot7.getBackgroundImageAlpha();
        double double18 = categoryPlot7.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer19.setSeriesOutlinePaint(4, (java.awt.Paint) color21);
        java.awt.Shape shape24 = statisticalLineAndShapeRenderer19.getSeriesShape((int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        statisticalLineAndShapeRenderer19.setBaseURLGenerator(categoryURLGenerator25);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D28.setMinimumBarLength((double) (byte) -1);
        boolean boolean33 = stackedBarRenderer3D28.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D28.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator36 = stackedBarRenderer3D28.getBaseToolTipGenerator();
        stackedBarRenderer3D28.setRenderAsPercentages(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = null;
        stackedBarRenderer3D28.setPositiveItemLabelPositionFallback(itemLabelPosition39);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer41 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D43.setSeriesPaint((int) (byte) 100, paint45, false);
        double double48 = stackedBarRenderer3D43.getItemMargin();
        stackedBarRenderer3D43.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray53 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { statisticalLineAndShapeRenderer19, stackedBarRenderer3D28, stackedBarRenderer41, stackedBarRenderer3D43 };
        categoryPlot7.setRenderers(categoryItemRendererArray53);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator36);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.2d + "'", double48 == 0.2d);
        org.junit.Assert.assertNotNull(categoryItemRendererArray53);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        java.awt.Shape shape16 = stackedBarRenderer3D1.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset17.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.data.Range range22 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        piePlot3D25.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke28);
        java.awt.Color color30 = java.awt.Color.darkGray;
        piePlot3D25.setShadowPaint((java.awt.Paint) color30);
        java.awt.Paint paint32 = piePlot3D25.getLabelBackgroundPaint();
        stackedBarRenderer3D1.setSeriesOutlinePaint(1900, paint32);
        java.awt.Paint paint35 = stackedBarRenderer3D1.getSeriesFillPaint((int) '4');
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(paint35);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource4);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        dateAxis1.setPositiveArrowVisible(false);
        boolean boolean9 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color24 = java.awt.Color.DARK_GRAY;
        float[] floatArray29 = new float[] { 1L, (short) 100, (short) 100, 10 };
        float[] floatArray30 = color24.getColorComponents(floatArray29);
        float[] floatArray31 = color23.getComponents(floatArray29);
        float[] floatArray32 = color22.getRGBColorComponents(floatArray31);
        boolean boolean33 = verticalAlignment21.equals((java.lang.Object) color22);
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color22);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font14, (java.awt.Paint) color15);
        categoryPlot7.setNoDataMessageFont(font14);
        categoryPlot7.clearAnnotations();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedBarRenderer1.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.clear();
        try {
            defaultKeyedValues2D1.removeRow(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(15, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        java.awt.Paint paint21 = xYPlot16.getQuadrantPaint((int) (short) 1);
        org.jfree.chart.plot.Plot plot22 = xYPlot16.getParent();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot16.getRangeMarkers(layer23);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension((double) (byte) 100);
        java.awt.Stroke stroke4 = ringPlot1.getSeparatorStroke();
        try {
            double double5 = ringPlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16 };
        categoryPlot7.setDomainAxes(categoryAxisArray17);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder19 = categoryPlot7.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder19);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        boolean boolean12 = segment10.contains((long) ' ');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        double double4 = ringPlot1.getOuterSeparatorExtension();
        ringPlot1.setShadowXOffset(1.0E-8d);
        ringPlot1.setCircular(false, false);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = ringPlot1.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNull(pieToolTipGenerator10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 86400000L + "'", long1 == 86400000L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        java.awt.Paint paint1 = boxAndWhiskerRenderer0.getArtifactPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D2.setMinimumBarLength((double) (byte) -1);
        boolean boolean7 = stackedBarRenderer3D2.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D2.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = stackedBarRenderer3D2.getBaseToolTipGenerator();
        stackedBarRenderer3D2.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer17 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer17.setSeriesOutlinePaint(4, (java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer17);
        categoryPlot21.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot21.markerChanged(markerChangeEvent25);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit29 = null;
        dateAxis28.setTickUnit(dateTickUnit29);
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = dateAxis28.getTickUnit();
        double double32 = dateAxis28.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D13, categoryPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis28, rectangle2D33, (double) (-1L));
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot21.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot21.getDomainAxisForDataset((int) '#');
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot21.getRangeAxisEdge((int) ' ');
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit43 = null;
        dateAxis42.setTickUnit(dateTickUnit43);
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis42.getTickUnit();
        dateAxis42.setAutoTickUnitSelection(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis42);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis42);
        boolean boolean50 = defaultDrawingSupplier0.equals((java.lang.Object) categoryPlot21);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(dateTickUnit31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(categoryAxis38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNull(dateTickUnit45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        keyToGroupMap2.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year4);
        defaultCategoryDataset0.removeValue((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) 8.0d);
        org.jfree.data.general.DatasetGroup datasetGroup8 = defaultCategoryDataset0.getGroup();
        try {
            java.lang.Number number11 = defaultCategoryDataset0.getValue(3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(datasetGroup8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 2);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        java.util.Date date4 = year3.getStart();
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) year3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        long long11 = segment10.getMillisecond();
        segment10.inc((long) 2958465);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segment10.intersect((long) 6, (long) 31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertNull(segment16);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity9 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis1, shape5, "", "Last");
        dateAxis1.setUpperMargin(0.2d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.configure();
        org.jfree.data.Range range14 = numberAxis3D12.getDefaultAutoRange();
        dateAxis1.setRange(range14);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition16 = dateAxis1.getTickMarkPosition();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D18.setMinimumBarLength((double) (byte) -1);
        boolean boolean23 = stackedBarRenderer3D18.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D18.setDrawBarOutline(false);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = statisticalLineAndShapeRenderer26.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D18.setBasePositiveItemLabelPosition(itemLabelPosition29);
        stackedBarRenderer3D18.setMaximumBarWidth((double) (short) 1);
        stackedBarRenderer3D18.setSeriesItemLabelsVisible(100, (java.lang.Boolean) true, true);
        stackedBarRenderer3D18.setIncludeBaseInRange(false);
        boolean boolean39 = dateTickMarkPosition16.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(dateTickMarkPosition16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) 7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        ganttRenderer0.setCompletePaint(paint3);
        java.io.ObjectOutputStream objectOutputStream5 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint3, objectOutputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setNegativeArrowVisible(false);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        categoryPlot7.setDomainGridlineStroke(stroke20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot7.getDatasetGroup();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot7.getDomainMarkers((int) 'a', layer24);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D27.setSeriesPaint((int) (byte) 100, paint29, false);
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer35.setSeriesOutlinePaint(4, (java.awt.Paint) color37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer35);
        org.jfree.data.general.DatasetGroup datasetGroup40 = categoryPlot39.getDatasetGroup();
        stackedBarRenderer3D27.setPlot(categoryPlot39);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray42 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot39.setRenderers(categoryItemRendererArray42);
        categoryPlot7.setRenderers(categoryItemRendererArray42);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNull(datasetGroup40);
        org.junit.Assert.assertNotNull(categoryItemRendererArray42);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        int int21 = xYPlot16.getRangeAxisIndex(valueAxis20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = xYPlot16.getDatasetGroup();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = null;
        dateAxis25.setTickUnit(dateTickUnit26);
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = dateAxis25.getTickUnit();
        dateAxis25.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = null;
        dateAxis32.setTickUnit(dateTickUnit33);
        org.jfree.chart.axis.DateTickUnit dateTickUnit35 = dateAxis32.getTickUnit();
        dateAxis32.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer38);
        xYPlot39.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer45 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer45.setSeriesOutlinePaint(4, (java.awt.Paint) color47);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer45);
        categoryPlot49.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot49.zoomRangeAxes(0.0d, plotRenderingInfo54, point2D55);
        boolean boolean57 = categoryPlot49.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection58 = categoryPlot49.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation60 = categoryPlot49.getDomainAxisLocation(10);
        xYPlot39.setRangeAxisLocation((int) (byte) 10, axisLocation60);
        org.jfree.chart.axis.AxisLocation axisLocation62 = axisLocation60.getOpposite();
        xYPlot16.setRangeAxisLocation(axisLocation62, true);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNull(dateTickUnit28);
        org.junit.Assert.assertNull(dateTickUnit35);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(legendItemCollection58);
        org.junit.Assert.assertNotNull(axisLocation60);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator6);
        java.lang.Object obj8 = piePlot3D1.clone();
        java.awt.Stroke stroke9 = piePlot3D1.getOutlineStroke();
        double double10 = piePlot3D1.getMinimumArcAngleToDraw();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D13.setMinimumBarLength((double) (byte) -1);
        boolean boolean18 = stackedBarRenderer3D13.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D13.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = stackedBarRenderer3D13.getBaseToolTipGenerator();
        stackedBarRenderer3D13.setMaximumBarWidth((double) 1L);
        stackedBarRenderer3D13.setBase(0.0d);
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        dateAxis29.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit37 = null;
        dateAxis36.setTickUnit(dateTickUnit37);
        org.jfree.chart.axis.DateTickUnit dateTickUnit39 = dateAxis36.getTickUnit();
        dateAxis36.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset27, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer42);
        xYPlot43.configureRangeAxes();
        java.awt.Stroke stroke45 = xYPlot43.getRangeZeroBaselineStroke();
        java.awt.Stroke stroke46 = xYPlot43.getRangeGridlineStroke();
        stackedBarRenderer3D13.setSeriesOutlineStroke((int) 'a', stroke46, false);
        try {
            piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 10.0d, stroke46);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to java.lang.Double");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-5d + "'", double10 == 1.0E-5d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNull(dateTickUnit32);
        org.junit.Assert.assertNull(dateTickUnit39);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        stackedBarRenderer3D1.setSeriesItemLabelsVisible((int) '#', true);
        stackedBarRenderer3D1.setSeriesVisible((int) (short) 10, (java.lang.Boolean) false);
        stackedBarRenderer3D1.setIncludeBaseInRange(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryMiddle((int) (short) 0, 10, rectangle2D4, rectangleEdge5);
        float float7 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "12/31/69", "ThreadContext", "ThreadContext", "");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "12/31/69", "ThreadContext", "ThreadContext", "");
        java.lang.String str14 = basicProjectInfo13.getCopyright();
        basicProjectInfo7.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        java.lang.String str16 = basicProjectInfo13.getCopyright();
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ThreadContext" + "'", str14.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ThreadContext" + "'", str16.equals("ThreadContext"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getUseOutlinePaint();
        statisticalLineAndShapeRenderer3.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true, false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2);
        statisticalLineAndShapeRenderer0.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalLineAndShapeRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        statisticalLineAndShapeRenderer0.setSeriesPaint((int) (byte) 0, paint10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke13 = dateAxis12.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint10, stroke13, rectangleInsets14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(5, 6);
        double double3 = dateTickUnit2.getSize();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6000.0d + "'", double3 == 6000.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, 0.0d, 2.0f, (float) (short) 1);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "hi!");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        chartRenderingInfo0.clear();
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        java.lang.Class<?> wildcardClass29 = dateAxis25.getClass();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int34 = segmentedTimeline33.getSegmentsExcluded();
        java.util.List list35 = segmentedTimeline33.getExceptionSegments();
        boolean boolean38 = segmentedTimeline33.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment40 = segmentedTimeline33.getSegment((long) ' ');
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        int int43 = year42.getYear();
        org.jfree.data.gantt.Task task44 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year42);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        int int47 = year46.getYear();
        org.jfree.data.gantt.Task task48 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year46);
        task44.addSubtask(task48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        int int51 = year50.getYear();
        java.util.Date date52 = year50.getEnd();
        int int54 = year50.compareTo((java.lang.Object) 0.05d);
        task48.setDuration((org.jfree.data.time.TimePeriod) year50);
        java.util.Date date56 = year50.getEnd();
        long long57 = segmentedTimeline33.toTimelineValue(date56);
        java.text.DateFormat dateFormat60 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit61 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat60);
        java.lang.String str63 = dateTickUnit61.valueToString((double) 9999);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        java.util.Date date65 = year64.getStart();
        java.util.TimeZone timeZone66 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date67 = dateTickUnit61.rollDate(date65, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date56, timeZone66);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 100 + "'", int34 == 100);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(segment40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 15622431710L + "'", long57 == 15622431710L);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "12/31/69" + "'", str63.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNull(regularTimePeriod68);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint4 = ringPlot1.getBackgroundPaint();
        double double5 = ringPlot1.getInteriorGap();
        double double6 = ringPlot1.getInteriorGap();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.25d + "'", double5 == 0.25d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.25d + "'", double6 == 0.25d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        statisticalLineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset13 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj14 = defaultCategoryDataset13.clone();
        int int16 = defaultCategoryDataset13.getRowIndex((java.lang.Comparable) (-3695));
        defaultCategoryDataset13.addValue(0.0d, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 0L);
        java.lang.Object obj21 = defaultCategoryDataset13.clone();
        java.util.List list22 = defaultCategoryDataset13.getRowKeys();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot7.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset13);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        int int6 = year5.getYear();
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year5);
        task3.addSubtask(task7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        int int10 = year9.getYear();
        java.util.Date date11 = year9.getEnd();
        int int13 = year9.compareTo((java.lang.Object) 0.05d);
        task7.setDuration((org.jfree.data.time.TimePeriod) year9);
        org.jfree.data.gantt.TaskSeries taskSeries16 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeries16.fireSeriesChanged();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        int int20 = year19.getYear();
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year19);
        taskSeries16.remove(task21);
        task21.setDescription("");
        task7.addSubtask(task21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = stackedBarRenderer3D1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        java.awt.Paint paint16 = categoryPlot7.getOutlinePaint();
        java.awt.Stroke stroke17 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot7.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke4 = defaultDrawingSupplier3.getNextOutlineStroke();
        piePlot3D1.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke4);
        java.awt.Color color6 = java.awt.Color.darkGray;
        piePlot3D1.setShadowPaint((java.awt.Paint) color6);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot3D1.getLegendLabelURLGenerator();
        double double9 = piePlot3D1.getDepthFactor();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(pieURLGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = stackedBarRenderer3D1.getGradientPaintTransformer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = stackedBarRenderer3D1.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNull(itemLabelPosition8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer9.setSeriesOutlinePaint(4, (java.awt.Paint) color11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot13.getDatasetGroup();
        stackedBarRenderer3D1.setPlot(categoryPlot13);
        boolean boolean16 = stackedBarRenderer3D1.getAutoPopulateSeriesPaint();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator20 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        stackedBarRenderer3D1.setSeriesToolTipGenerator((int) (byte) 0, (org.jfree.chart.labels.CategoryToolTipGenerator) intervalCategoryToolTipGenerator20);
        java.text.DateFormat dateFormat22 = intervalCategoryToolTipGenerator20.getDateFormat();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(dateFormat22);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedBarRenderer3D1.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator16, false);
        stackedBarRenderer3D1.setSeriesVisibleInLegend(0, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getStart();
        java.lang.Object obj2 = null;
        int int3 = year0.compareTo(obj2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        int int13 = categoryAxis11.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getTickLabelFont();
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) 60000L);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer5 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6, 2);
        org.jfree.data.Range range9 = stackedBarRenderer5.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint3.toRangeWidth(range9);
        java.lang.String str11 = range9.toString();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange((double) 2.0f, (double) 128);
        double double18 = dateRange17.getLength();
        org.jfree.data.Range range19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range19, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType22 = rectangleConstraint21.getHeightConstraintType();
        org.jfree.data.Range range24 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) 31, (org.jfree.data.Range) dateRange17, lengthConstraintType22, (double) (-1), range24, lengthConstraintType25);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (short) 0, range9, lengthConstraintType12, 8.0d, (org.jfree.data.Range) dateRange17, lengthConstraintType27);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Range[0.0,1.0]" + "'", str11.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 126.0d + "'", double18 == 126.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType22);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) (-3695), (java.lang.Number) 0L);
        java.lang.Comparable comparable4 = null;
        try {
            defaultKeyedValues0.setValue(comparable4, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        boolean boolean3 = color0.equals((java.lang.Object) shape2);
        int int4 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-16711936) + "'", int4 == (-16711936));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("TextAnchor.TOP_CENTER");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle0.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D5.setMinimumBarLength((double) (byte) -1);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = stackedBarRenderer3D5.getDrawingSupplier();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = stackedBarRenderer3D5.getToolTipGenerator(0, (-3695));
        boolean boolean12 = textTitle0.equals((java.lang.Object) (-3695));
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultBoxAndWhiskerCategoryDataset0.getRowKey((-32513));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        stackedBarRenderer3D1.setPositiveItemLabelPositionFallback(itemLabelPosition12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        java.awt.Paint paint24 = statisticalLineAndShapeRenderer18.getSeriesPaint(4);
        boolean boolean25 = statisticalLineAndShapeRenderer18.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer31.setSeriesOutlinePaint(4, (java.awt.Paint) color33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer31);
        categoryPlot35.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot35.zoomRangeAxes(0.0d, plotRenderingInfo40, point2D41);
        boolean boolean43 = categoryPlot35.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot35.setDataset(categoryDataset44);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot35.setRangeCrosshairPaint(paint46);
        java.awt.Paint paint48 = categoryPlot35.getDomainGridlinePaint();
        java.awt.Font font49 = categoryPlot35.getNoDataMessageFont();
        categoryPlot35.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState53 = statisticalLineAndShapeRenderer18.initialise(graphics2D26, rectangle2D27, categoryPlot35, 4, plotRenderingInfo52);
        categoryPlot35.clearDomainMarkers(1);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot35.getRangeAxisEdge((int) (short) 10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D59 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D59.setSeriesPaint((int) (byte) 100, paint61, false);
        double double64 = stackedBarRenderer3D59.getItemMargin();
        stackedBarRenderer3D59.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint70 = null;
        stackedBarRenderer3D59.setSeriesPaint((int) (byte) 0, paint70);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer76 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color78 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer76.setSeriesOutlinePaint(4, (java.awt.Paint) color78);
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, valueAxis75, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer76);
        org.jfree.data.general.DatasetGroup datasetGroup81 = categoryPlot80.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis83 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        stackedBarRenderer3D59.drawRangeGridline(graphics2D72, categoryPlot80, (org.jfree.chart.axis.ValueAxis) dateAxis83, rectangle2D84, (double) (short) 10);
        java.lang.Class<?> wildcardClass87 = dateAxis83.getClass();
        org.jfree.chart.util.Size2D size2D90 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D90.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor95 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D96 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D90, (double) (short) -1, (double) ' ', rectangleAnchor95);
        try {
            stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis83, rectangle2D96, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(categoryItemRendererState53);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.2d + "'", double64 == 0.2d);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNull(datasetGroup81);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertNotNull(rectangleAnchor95);
        org.junit.Assert.assertNotNull(rectangle2D96);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        java.text.NumberFormat numberFormat2 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat2);
        org.jfree.chart.util.Size2D size2D7 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D7.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D13 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D7, (double) (short) -1, (double) ' ', rectangleAnchor12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double15 = numberAxis3D0.valueToJava2D((double) 'a', rectangle2D13, rectangleEdge14);
        numberAxis3D0.setVisible(true);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9359.5d + "'", double15 == 9359.5d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getMinimumArcAngleToDraw();
        piePlot3D1.setStartAngle(1.0E-5d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(5, 6);
        java.awt.Paint paint10 = piePlot3D1.getSectionPaint((java.lang.Comparable) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        java.util.Date date6 = year5.getStart();
        boolean boolean7 = textAnchor4.equals((java.lang.Object) year5);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint11 = categoryMarker10.getOutlinePaint();
        categoryMarker10.setDrawAsLine(false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = null;
        dateAxis16.setTickUnit(dateTickUnit17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        dateAxis16.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = null;
        dateAxis23.setTickUnit(dateTickUnit24);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        dateAxis23.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer29);
        xYPlot30.configureRangeAxes();
        java.awt.Stroke stroke32 = xYPlot30.getRangeZeroBaselineStroke();
        categoryMarker10.setOutlineStroke(stroke32);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date36 = dateAxis35.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str39 = textAnchor38.toString();
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick42 = new org.jfree.chart.axis.DateTick(date36, "12/31/69", textAnchor38, textAnchor40, 0.0d);
        java.lang.String str43 = textAnchor38.toString();
        categoryMarker10.setLabelTextAnchor(textAnchor38);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("DateTickMarkPosition.MIDDLE", graphics2D1, (float) ' ', (float) 500, textAnchor4, 0.0d, textAnchor38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(dateTickUnit19);
        org.junit.Assert.assertNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str39.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str43.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] {};
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] {};
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset13 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray9, comparableArray10, numberArray11, numberArray12);
        boolean boolean14 = dateAxis1.hasListener((java.util.EventListener) defaultIntervalCategoryDataset13);
        try {
            java.lang.Number number17 = defaultIntervalCategoryDataset13.getValue((int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset.getValue(): series index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape5);
        java.awt.Color color7 = java.awt.Color.DARK_GRAY;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer11.setSeriesOutlinePaint(4, (java.awt.Paint) color13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer11);
        categoryPlot15.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21);
        boolean boolean23 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot15.getLegendItems();
        float float25 = categoryPlot15.getBackgroundImageAlpha();
        java.awt.Font font27 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font27, (java.awt.Paint) color28);
        categoryPlot15.setNoDataMessageFont(font27);
        java.awt.Stroke stroke31 = categoryPlot15.getRangeCrosshairStroke();
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        boolean boolean33 = textTitle32.getNotify();
        java.lang.Object obj34 = textTitle32.clone();
        java.awt.Paint paint35 = textTitle32.getPaint();
        try {
            org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem(attributedString0, "Last", "Size2D[width=97.0, height=0.0]", "PlotOrientation.HORIZONTAL", shape5, (java.awt.Paint) color7, stroke31, paint35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedBarRenderer3D1.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator16, false);
        java.awt.Paint paint20 = stackedBarRenderer3D1.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.awt.Paint paint2 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer7.setSeriesOutlinePaint(4, (java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer7);
        categoryPlot11.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17);
        boolean boolean19 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot11.getLegendItems();
        float float21 = categoryPlot11.getBackgroundImageAlpha();
        java.awt.Font font23 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font23, (java.awt.Paint) color24);
        categoryPlot11.setNoDataMessageFont(font23);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) false, font23);
        double double28 = categoryAxis0.getUpperMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryAxis0.getTickLabelInsets();
        java.awt.Font font31 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (byte) -1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.5f + "'", float21 == 0.5f);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) "", (double) 0L);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultKeyedValues0.equals(obj4);
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByValues(sortOrder6);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj9 = defaultCategoryDataset8.clone();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer13.setSeriesOutlinePaint(4, (java.awt.Paint) color15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer13);
        categoryPlot17.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23);
        categoryPlot17.configureRangeAxes();
        boolean boolean26 = categoryPlot17.isRangeZoomable();
        double double27 = categoryPlot17.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateBottomOutset((double) (short) -1);
        categoryPlot17.setAxisOffset(rectangleInsets28);
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot17.getDataset(128);
        boolean boolean34 = defaultCategoryDataset8.hasListener((java.util.EventListener) categoryPlot17);
        boolean boolean35 = sortOrder6.equals((java.lang.Object) defaultCategoryDataset8);
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getStart();
        boolean boolean41 = textAnchor38.equals((java.lang.Object) year39);
        defaultCategoryDataset8.setValue((double) 10L, (java.lang.Comparable) "RectangleAnchor.BOTTOM_RIGHT", (java.lang.Comparable) boolean41);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getAutoPopulateSeriesStroke();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26);
        boolean boolean28 = categoryPlot20.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot20.setDataset(categoryDataset29);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot20.setRangeCrosshairPaint(paint31);
        java.awt.Paint paint33 = categoryPlot20.getDomainGridlinePaint();
        java.awt.Font font34 = categoryPlot20.getNoDataMessageFont();
        categoryPlot20.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState38 = statisticalLineAndShapeRenderer3.initialise(graphics2D11, rectangle2D12, categoryPlot20, 4, plotRenderingInfo37);
        categoryPlot20.clearDomainMarkers(1);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot20.getRangeAxisEdge((int) (short) 10);
        boolean boolean43 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge42);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(categoryItemRendererState38);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setDrawLines(false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("{0}");
        minMaxCategoryRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Paint paint8 = minMaxCategoryRenderer0.getItemFillPaint(0, (int) (byte) 100);
        minMaxCategoryRenderer0.setDrawLines(true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int3 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-3695));
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot3D5.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke8);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot3D5.setLabelGenerator(pieSectionLabelGenerator10);
        java.lang.Object obj12 = piePlot3D5.clone();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.RingPlot ringPlot14 = new org.jfree.chart.plot.RingPlot(pieDataset13);
        ringPlot14.setOuterSeparatorExtension(100.0d);
        double double17 = ringPlot14.getOuterSeparatorExtension();
        ringPlot14.setShadowXOffset(1.0E-8d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator20 = ringPlot14.getLegendLabelGenerator();
        piePlot3D5.setLegendLabelToolTipGenerator(pieSectionLabelGenerator20);
        boolean boolean22 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot3D5);
        boolean boolean23 = piePlot3D5.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setHighFarOut(false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setLowerBound((double) 255);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        categoryPlot7.setAnchorValue(126.0d);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        java.awt.Color color3 = java.awt.Color.pink;
        int int4 = color3.getAlpha();
        java.lang.String str5 = org.jfree.chart.util.PaintUtilities.colorToString(color3);
        dateAxis1.setTickLabelPaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "pink" + "'", str5.equals("pink"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape2 = null;
        lineAndShapeRenderer0.setSeriesShape(0, shape2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis1.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer6.setSeriesOutlinePaint(4, (java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer6);
        categoryPlot10.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot10.setDomainAxis(categoryAxis14);
        java.awt.Paint paint16 = categoryAxis14.getLabelPaint();
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font2, paint16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font20 = categoryAxis19.getTickLabelFont();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer21 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint24 = ganttRenderer21.getItemOutlinePaint(0, (int) ' ');
        textBlock17.addLine("{0}", font20, paint24);
        org.jfree.chart.text.TextLine textLine26 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = textLine26.calculateDimensions(graphics2D27);
        textBlock17.addLine(textLine26);
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font31, (java.awt.Paint) color32);
        java.awt.Paint paint34 = textFragment33.getPaint();
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date37 = dateAxis36.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis36.setLabelInsets(rectangleInsets42);
        double double44 = rectangleInsets42.getBottom();
        boolean boolean45 = textFragment33.equals((java.lang.Object) double44);
        textLine26.addFragment(textFragment33);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-1.0d) + "'", double44 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer0.setErrorIndicatorPaint((java.awt.Paint) color1);
        java.lang.Object obj3 = statisticalLineAndShapeRenderer0.clone();
        java.awt.Paint paint6 = statisticalLineAndShapeRenderer0.getItemPaint((int) (short) 0, (int) (byte) 10);
        statisticalLineAndShapeRenderer0.setSeriesLinesVisible(0, false);
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Stroke stroke12 = minMaxCategoryRenderer11.getGroupStroke();
        try {
            statisticalLineAndShapeRenderer0.setSeriesStroke((-16711936), stroke12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        java.lang.String str2 = projectInfo0.getName();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.awt.Color color1 = java.awt.Color.WHITE;
        boolean boolean2 = numberTickUnit0.equals((java.lang.Object) color1);
        java.awt.color.ColorSpace colorSpace3 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        float[] floatArray14 = new float[] { 1L, (short) 100, (short) 100, 10 };
        float[] floatArray15 = color9.getColorComponents(floatArray14);
        float[] floatArray16 = color8.getComponents(floatArray14);
        float[] floatArray17 = color7.getRGBColorComponents(floatArray16);
        float[] floatArray18 = java.awt.Color.RGBtoHSB((int) '4', (int) ' ', (int) (byte) 10, floatArray16);
        try {
            float[] floatArray19 = color1.getComponents(colorSpace3, floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat2 = numberAxis3D1.getNumberFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        dateAxis4.setNegativeArrowVisible(false);
        java.awt.Stroke stroke7 = dateAxis4.getAxisLineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis4.getTickUnit();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer9);
        numberAxis3D1.configure();
        numberAxis3D1.setInverted(false);
        org.junit.Assert.assertNull(numberFormat2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = statisticalLineAndShapeRenderer2.getPositiveItemLabelPosition((int) (byte) 1, 7);
        java.awt.Stroke stroke7 = statisticalLineAndShapeRenderer2.getSeriesOutlineStroke(12);
        boolean boolean8 = categoryAxis3D1.equals((java.lang.Object) 12);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 15622431679L, (java.lang.Number) 9999);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat6 = dateAxis3.getDateFormatOverride();
        java.awt.Shape shape7 = dateAxis3.getRightArrow();
        dateAxis3.setAutoTickUnitSelection(true);
        java.awt.Paint paint10 = dateAxis3.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("{0}", font1, paint10);
        java.lang.Object obj12 = labelBlock11.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        long long12 = segmentedTimeline3.toTimelineValue((long) (byte) 0);
        long long14 = segmentedTimeline3.toMillisecond((long) (short) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9400L + "'", long14 == 9400L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer15.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer15);
        categoryPlot19.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        java.awt.Image image27 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.Timeline timeline30 = null;
        dateAxis29.setTimeline(timeline30);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker33.setLabel("TextAnchor.TOP_CENTER");
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D1.drawRangeMarker(graphics2D11, categoryPlot19, (org.jfree.chart.axis.ValueAxis) dateAxis29, (org.jfree.chart.plot.Marker) categoryMarker33, rectangle2D36);
        stackedBarRenderer3D1.setSeriesItemLabelsVisible((int) '#', true);
        stackedBarRenderer3D1.setSeriesVisible((int) (short) 10, (java.lang.Boolean) false);
        double double44 = stackedBarRenderer3D1.getLowerClip();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        java.awt.Paint paint19 = xYPlot16.getDomainCrosshairPaint();
        xYPlot16.clearDomainMarkers(0);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        dateAxis20.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        dateAxis27.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        xYPlot34.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot34.getDomainAxisLocation();
        java.awt.Paint paint37 = xYPlot34.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        int int39 = xYPlot34.getIndexOf(xYItemRenderer38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection42 = null;
        chartRenderingInfo41.setEntityCollection(entityCollection42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = dateAxis47.getTickUnit();
        dateAxis47.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = null;
        dateAxis54.setTickUnit(dateTickUnit55);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis54.getTickUnit();
        dateAxis54.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer60);
        xYPlot61.configureRangeAxes();
        java.awt.Stroke stroke63 = xYPlot61.getRangeZeroBaselineStroke();
        xYPlot61.setRangeCrosshairValue((double) (-3695));
        xYPlot61.setRangeZeroBaselineVisible(true);
        java.awt.geom.Point2D point2D68 = xYPlot61.getQuadrantOrigin();
        xYPlot34.zoomRangeAxes(100.0d, plotRenderingInfo44, point2D68);
        xYPlot16.setQuadrantOrigin(point2D68);
        int int71 = xYPlot16.getDatasetCount();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(dateTickUnit23);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(dateTickUnit50);
        org.junit.Assert.assertNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(point2D68);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.RingPlot ringPlot9 = new org.jfree.chart.plot.RingPlot(pieDataset8);
        ringPlot9.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint12 = ringPlot9.getBackgroundPaint();
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 6, (double) 3, (double) (-1L), (double) 3, paint12);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(1.0E-5d, (double) ' ', (double) (-16711936), (double) 10L, paint12);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        java.lang.String str2 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str2.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        org.jfree.data.gantt.Task task3 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year1);
        java.lang.Object obj4 = null;
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) year1, obj4);
        java.lang.String str6 = year1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer15 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        stackedBarRenderer3D1.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer15);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        stackedBarRenderer3D1.setBaseItemLabelGenerator(categoryItemLabelGenerator17, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer0.setSeriesCreateEntities(8, (java.lang.Boolean) false, true);
        boolean boolean7 = statisticalLineAndShapeRenderer0.getItemShapeVisible(0, 6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer11.setSeriesOutlinePaint(4, (java.awt.Paint) color13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer11);
        categoryPlot15.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21);
        boolean boolean23 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot15.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        int int26 = categoryPlot15.getDomainAxisIndex(categoryAxis25);
        java.awt.Image image27 = categoryPlot15.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot15.getDataset();
        categoryPlot15.setWeight(0);
        statisticalLineAndShapeRenderer0.setPlot(categoryPlot15);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32, 2);
        int int35 = defaultCategoryDataset32.getRowCount();
        org.jfree.data.Range range36 = statisticalLineAndShapeRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(legendItemCollection24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(image27);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(range36);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.configure();
        org.jfree.data.Range range2 = numberAxis3D0.getDefaultAutoRange();
        double double3 = range2.getUpperBound();
        boolean boolean5 = range2.contains(0.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.KeyToGroupMap keyToGroupMap0 = new org.jfree.data.KeyToGroupMap();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        keyToGroupMap0.mapKeyToGroup((java.lang.Comparable) "ERROR : Relative To String", (java.lang.Comparable) year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year2.next();
        java.util.Calendar calendar5 = null;
        try {
            year2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        double double9 = rectangleInsets7.getLeft();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 12.0d + "'", double9 == 12.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        java.lang.Object obj3 = dataPackageResources0.handleGetObject("March");
        org.junit.Assert.assertNotNull(strSet1);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        axisState0.cursorRight((double) 100);
        double double4 = axisState0.getCursor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        statisticalLineAndShapeRenderer16.notifyListeners(rendererChangeEvent20);
        categoryPlot7.setRenderer(3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16, false);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D26.setSeriesPaint((int) (byte) 100, paint28, false);
        double double31 = stackedBarRenderer3D26.getItemMargin();
        stackedBarRenderer3D26.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        categoryPlot7.setRenderer((int) 'a', (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D26, true);
        int int38 = categoryPlot7.getDatasetCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(3, 2, dateFormat2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setNegativeArrowVisible(false);
        java.awt.Stroke stroke20 = dateAxis17.getAxisLineStroke();
        categoryPlot7.setDomainGridlineStroke(stroke20);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot7.getDatasetGroup();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer27.setSeriesOutlinePaint(4, (java.awt.Paint) color29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer27);
        categoryPlot31.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot31.zoomRangeAxes(0.0d, plotRenderingInfo36, point2D37);
        categoryPlot31.configureRangeAxes();
        boolean boolean40 = categoryPlot31.isRangeZoomable();
        double double41 = categoryPlot31.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = null;
        dateAxis44.setTickUnit(dateTickUnit45);
        org.jfree.chart.axis.DateTickUnit dateTickUnit47 = dateAxis44.getTickUnit();
        dateAxis44.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        dateAxis51.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset42, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis51, xYItemRenderer57);
        xYPlot58.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer64 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color66 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer64.setSeriesOutlinePaint(4, (java.awt.Paint) color66);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot(categoryDataset61, categoryAxis62, valueAxis63, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer64);
        categoryPlot68.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        categoryPlot68.zoomRangeAxes(0.0d, plotRenderingInfo73, point2D74);
        boolean boolean76 = categoryPlot68.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection77 = categoryPlot68.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation79 = categoryPlot68.getDomainAxisLocation(10);
        xYPlot58.setRangeAxisLocation((int) (byte) 10, axisLocation79);
        categoryPlot31.setRangeAxisLocation(axisLocation79, false);
        try {
            categoryPlot7.setDomainAxisLocation((-1), axisLocation79, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit47);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(legendItemCollection77);
        org.junit.Assert.assertNotNull(axisLocation79);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setUpperBound(97.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.clear();
        java.lang.Comparable comparable3 = null;
        defaultKeyedValues2D1.removeColumn(comparable3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 100L);
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        java.awt.Paint paint7 = null;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Font font10 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font10, (java.awt.Paint) color11);
        try {
            org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("March", "TextBlockAnchor.BOTTOM_CENTER", "Range[0.0,1.0]", "TextBlockAnchor.BOTTOM_CENTER", shape5, paint7, stroke8, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker1.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.chart.plot.Marker marker5 = markerChangeEvent4.getMarker();
        org.jfree.chart.text.TextAnchor textAnchor6 = marker5.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(marker5);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 100, paint3, false);
        double double6 = stackedBarRenderer3D1.getItemMargin();
        stackedBarRenderer3D1.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint12 = null;
        stackedBarRenderer3D1.setSeriesPaint((int) (byte) 0, paint12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer18.setSeriesOutlinePaint(4, (java.awt.Paint) color20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer18);
        org.jfree.data.general.DatasetGroup datasetGroup23 = categoryPlot22.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D14, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis25, rectangle2D26, (double) (short) 10);
        dateAxis25.centerRange((double) 100.0f);
        java.awt.Paint paint31 = dateAxis25.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 2);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset3, (java.lang.Comparable) 0.0f);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, 0.0d);
        org.jfree.data.Range range10 = rectangleConstraint9.getWidthRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint9.toFixedHeight(2.0d);
        try {
            org.jfree.chart.util.Size2D size2D13 = legendItemBlockContainer5.arrange(graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot7.getRenderer((-3695));
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot7.getDomainAxisLocation(10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer3.getSeriesPaint(4);
        boolean boolean10 = statisticalLineAndShapeRenderer3.getUseOutlinePaint();
        java.lang.Boolean boolean12 = statisticalLineAndShapeRenderer3.getSeriesVisibleInLegend((int) '4');
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeries1.fireSeriesChanged();
        java.lang.Comparable comparable3 = taskSeries1.getKey();
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + "hi!" + "'", comparable3.equals("hi!"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        stackedBarRenderer3D2.setSeriesPaint((int) (byte) 100, paint4, false);
        double double7 = stackedBarRenderer3D2.getItemMargin();
        stackedBarRenderer3D2.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Paint paint13 = null;
        stackedBarRenderer3D2.setSeriesPaint((int) (byte) 0, paint13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer19.setSeriesOutlinePaint(4, (java.awt.Paint) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer19);
        org.jfree.data.general.DatasetGroup datasetGroup24 = categoryPlot23.getDatasetGroup();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        stackedBarRenderer3D2.drawRangeGridline(graphics2D15, categoryPlot23, (org.jfree.chart.axis.ValueAxis) dateAxis26, rectangle2D27, (double) (short) 10);
        java.lang.Class<?> wildcardClass30 = dateAxis26.getClass();
        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AxisLocation.TOP_OR_RIGHT", (java.lang.Class) wildcardClass30);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(datasetGroup24);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNull(obj31);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot16.getRangeAxis();
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            xYPlot16.addDomainMarker(15, marker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis18);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer7 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer7.setSeriesOutlinePaint(4, (java.awt.Paint) color9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer7);
        categoryPlot11.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot11.setDomainAxis(categoryAxis15);
        java.awt.Paint paint17 = categoryAxis15.getLabelPaint();
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font3, paint17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font21 = categoryAxis20.getTickLabelFont();
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer22 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint25 = ganttRenderer22.getItemOutlinePaint(0, (int) ' ');
        textBlock18.addLine("{0}", font21, paint25);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition27 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = categoryLabelPosition27.getLabelAnchor();
        java.lang.String str29 = textBlockAnchor28.toString();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date34 = dateAxis33.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str37 = textAnchor36.toString();
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick40 = new org.jfree.chart.axis.DateTick(date34, "12/31/69", textAnchor36, textAnchor38, 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date43 = dateAxis42.getMaximumDate();
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str46 = textAnchor45.toString();
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.DateTick dateTick49 = new org.jfree.chart.axis.DateTick(date43, "12/31/69", textAnchor45, textAnchor47, 0.0d);
        org.jfree.chart.axis.NumberTick numberTick51 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "hi!", textAnchor38, textAnchor45, (double) (short) 10);
        org.jfree.chart.axis.CategoryTick categoryTick53 = new org.jfree.chart.axis.CategoryTick(comparable0, textBlock18, textBlockAnchor28, textAnchor45, 9359.5d);
        org.jfree.chart.text.TextBlock textBlock54 = categoryTick53.getLabel();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor55 = categoryTick53.getLabelAnchor();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER" + "'", str29.equals("TextBlockAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str37.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str46.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNotNull(textBlock54);
        org.junit.Assert.assertNotNull(textBlockAnchor55);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) 2.0f, (double) 128);
        numberAxis0.setDefaultAutoRange((org.jfree.data.Range) dateRange3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int3 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-3695));
        defaultCategoryDataset0.addValue(0.0d, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 0L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline12 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int13 = segmentedTimeline12.getSegmentsExcluded();
        java.util.List list14 = segmentedTimeline12.getExceptionSegments();
        boolean boolean17 = segmentedTimeline12.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment19 = segmentedTimeline12.getSegment((long) ' ');
        long long20 = segment19.getMillisecond();
        segment19.inc((long) 2958465);
        boolean boolean25 = segment19.contains((long) (short) 10, (long) (-1));
        segment19.moveIndexToStart();
        defaultCategoryDataset0.addValue((double) 9999, (java.lang.Comparable) segment19, (java.lang.Comparable) 31);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(segment19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 32L + "'", long20 == 32L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }
}

