import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) -1);
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font3, (java.awt.Paint) color4);
        categoryMarker1.setLabelPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        java.awt.Stroke stroke4 = defaultDrawingSupplier2.getNextOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke4, rectangleInsets5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = lineBorder6.getInsets();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj1 = defaultCategoryDataset0.clone();
        int int3 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-3695));
        defaultCategoryDataset0.addValue(0.0d, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 0L);
        java.lang.Object obj8 = defaultCategoryDataset0.clone();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        double double10 = range9.getCentralValue();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = stackedBarRenderer3D1.getURLGenerator((int) '#', 0);
        double double12 = stackedBarRenderer3D1.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryURLGenerator11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        java.awt.Paint paint3 = categoryMarker2.getOutlinePaint();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D(pieDataset4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot3D5.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 2, paint3, stroke8);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        boolean boolean12 = textTitle11.getNotify();
        boolean boolean13 = textTitle11.getNotify();
        org.jfree.chart.block.BlockFrame blockFrame14 = textTitle11.getFrame();
        boolean boolean15 = valueMarker10.equals((java.lang.Object) textTitle11);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        statisticalLineAndShapeRenderer16.setBaseShapesFilled(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator23 = null;
        statisticalLineAndShapeRenderer16.setSeriesToolTipGenerator(0, categoryToolTipGenerator23);
        org.jfree.chart.LegendItem legendItem27 = statisticalLineAndShapeRenderer16.getLegendItem((-1), (int) (short) 100);
        boolean boolean28 = textTitle11.equals((java.lang.Object) (-1));
        java.awt.Graphics2D graphics2D29 = null;
        try {
            org.jfree.chart.util.Size2D size2D30 = textTitle11.arrange(graphics2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(blockFrame14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(legendItem27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font14, (java.awt.Paint) color15);
        categoryPlot7.setNoDataMessageFont(font14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        int int19 = categoryPlot7.getDomainAxisIndex(categoryAxis18);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset20.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType25 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        double[][] doubleArray28 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray28);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot30 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset29);
        boolean boolean31 = categoryLabelWidthType25.equals((java.lang.Object) multiplePiePlot30);
        boolean boolean32 = defaultCategoryDataset20.hasListener((java.util.EventListener) multiplePiePlot30);
        org.jfree.chart.JFreeChart jFreeChart33 = multiplePiePlot30.getPieChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis18, jFreeChart33, chartChangeEventType34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelWidthType25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(jFreeChart33);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        double double4 = ringPlot1.getOuterSeparatorExtension();
        java.awt.Paint paint5 = ringPlot1.getLabelShadowPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        java.util.Date date6 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        dateAxis1.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline7);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        int int19 = xYPlot16.indexOf(xYDataset18);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setNegativeArrowVisible(false);
        java.util.Date date24 = dateAxis21.getMinimumDate();
        xYPlot16.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        dateAxis21.setPositiveArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = null;
        dateAxis29.setTickUnit(dateTickUnit30);
        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = dateAxis29.getTickUnit();
        dateAxis29.setAutoTickUnitSelection(false);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer38 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer38.setSeriesOutlinePaint(4, (java.awt.Paint) color40);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer38);
        categoryPlot42.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo47, point2D48);
        categoryPlot42.configureRangeAxes();
        boolean boolean51 = categoryPlot42.isRangeZoomable();
        double double52 = categoryPlot42.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double55 = rectangleInsets53.calculateBottomOutset((double) (short) -1);
        categoryPlot42.setAxisOffset(rectangleInsets53);
        dateAxis29.setLabelInsets(rectangleInsets53);
        org.jfree.chart.axis.TickUnitSource tickUnitSource58 = dateAxis29.getStandardTickUnits();
        dateAxis21.setStandardTickUnits(tickUnitSource58);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(dateTickUnit32);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource58);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        double double4 = ringPlot1.getOuterSeparatorExtension();
        ringPlot1.setShadowXOffset(1.0E-8d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = ringPlot1.getLegendLabelGenerator();
        ringPlot1.setShadowYOffset(0.0d);
        ringPlot1.setMaximumLabelWidth((double) 0L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot20.addDomainMarker(categoryMarker27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot20.getDomainAxisForDataset(2019);
        dateAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        java.awt.Stroke stroke32 = dateAxis9.getTickMarkStroke();
        dateAxis9.setPositiveArrowVisible(true);
        org.jfree.data.Range range35 = dateAxis9.getDefaultAutoRange();
        dateAxis1.setRange(range35);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(categoryAxis30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range35);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        stackedBarRenderer3D1.notifyListeners(rendererChangeEvent7);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = statisticalLineAndShapeRenderer9.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalLineAndShapeRenderer9.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedBarRenderer3D1.getNegativeItemLabelPosition((int) (short) -1, 4);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer18 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = statisticalLineAndShapeRenderer18.getPositiveItemLabelPosition((int) (byte) 1, 7);
        stackedBarRenderer3D1.setBasePositiveItemLabelPosition(itemLabelPosition21, false);
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        piePlot3D25.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke28);
        java.awt.Color color30 = java.awt.Color.darkGray;
        piePlot3D25.setShadowPaint((java.awt.Paint) color30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color36 = java.awt.Color.DARK_GRAY;
        float[] floatArray41 = new float[] { 1L, (short) 100, (short) 100, 10 };
        float[] floatArray42 = color36.getColorComponents(floatArray41);
        float[] floatArray43 = color35.getComponents(floatArray41);
        float[] floatArray44 = color34.getRGBColorComponents(floatArray43);
        float[] floatArray45 = color30.getComponents(colorSpace33, floatArray44);
        boolean boolean46 = itemLabelPosition21.equals((java.lang.Object) floatArray45);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (byte) 1, 7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = statisticalLineAndShapeRenderer0.getSeriesURLGenerator((int) (byte) 100);
        statisticalLineAndShapeRenderer0.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setLowFarOut(false);
        java.util.Iterator iterator3 = outlierListCollection0.iterator();
        org.junit.Assert.assertNotNull(iterator3);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        xYPlot16.clearAnnotations();
        org.jfree.chart.axis.ValueAxis valueAxis19 = xYPlot16.getRangeAxis();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(valueAxis19);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryMarker1.setLabel("TextAnchor.TOP_CENTER");
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) categoryMarker1);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) categoryMarker1);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        java.awt.Color color1 = org.jfree.chart.util.PaintUtilities.stringToColor("{0}");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        java.awt.Stroke stroke4 = defaultDrawingSupplier2.getNextOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color1, stroke4, rectangleInsets5);
        double double7 = rectangleInsets5.getTop();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        java.lang.String str2 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.LEFT" + "'", str2.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot7.setDomainAxis(categoryAxis11);
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font14, (java.awt.Paint) color15);
        categoryPlot7.setNoDataMessageFont(font14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        int int19 = categoryPlot7.getDomainAxisIndex(categoryAxis18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font21 = categoryAxis20.getTickLabelFont();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer25.setSeriesOutlinePaint(4, (java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer25);
        categoryPlot29.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryPlot29.setDomainAxis(categoryAxis33);
        double double35 = categoryAxis33.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis36);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        double double39 = categoryAxis38.getCategoryMargin();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray40 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis20, categoryAxis33, categoryAxis36, categoryAxis38 };
        categoryPlot7.setDomainAxes(categoryAxisArray40);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer42 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        statisticalLineAndShapeRenderer42.setSeriesCreateEntities(8, (java.lang.Boolean) false, true);
        boolean boolean49 = statisticalLineAndShapeRenderer42.getItemShapeVisible(0, 6);
        int int50 = categoryPlot7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer42);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.2d + "'", double35 == 0.2d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.2d + "'", double39 == 0.2d);
        org.junit.Assert.assertNotNull(categoryAxisArray40);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        xYPlot16.setDomainGridlinesVisible(false);
        java.awt.Paint paint21 = xYPlot16.getQuadrantPaint((int) (short) 1);
        org.jfree.chart.plot.Plot plot22 = xYPlot16.getParent();
        int int23 = xYPlot16.getDatasetCount();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot16.setRangeAxes(valueAxisArray24);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(valueAxisArray24);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date2 = dateAxis1.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis1.setLabelInsets(rectangleInsets7);
        double double10 = rectangleInsets7.trimWidth(16.35d);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.350000000000001d + "'", double10 == 4.350000000000001d);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setNegativeArrowVisible(false);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis1.setRangeWithMargins(range4);
        dateAxis1.resizeRange((double) 100);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        java.awt.Image image15 = categoryPlot7.getBackgroundImage();
        java.awt.Paint paint16 = categoryPlot7.getOutlinePaint();
        java.awt.Stroke stroke17 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        dateAxis20.setAutoTickUnitSelection(false);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer29.setSeriesOutlinePaint(4, (java.awt.Paint) color31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer29);
        categoryPlot33.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot33.zoomRangeAxes(0.0d, plotRenderingInfo38, point2D39);
        categoryPlot33.configureRangeAxes();
        boolean boolean42 = categoryPlot33.isRangeZoomable();
        double double43 = categoryPlot33.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double46 = rectangleInsets44.calculateBottomOutset((double) (short) -1);
        categoryPlot33.setAxisOffset(rectangleInsets44);
        dateAxis20.setLabelInsets(rectangleInsets44);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = dateAxis20.getStandardTickUnits();
        org.jfree.data.time.DateRange dateRange53 = new org.jfree.data.time.DateRange((double) 2.0f, (double) 128);
        double double54 = dateRange53.getLength();
        org.jfree.data.Range range55 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint57 = new org.jfree.chart.block.RectangleConstraint(range55, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType58 = rectangleConstraint57.getHeightConstraintType();
        org.jfree.data.Range range60 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType61 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint((double) 31, (org.jfree.data.Range) dateRange53, lengthConstraintType58, (double) (-1), range60, lengthConstraintType61);
        dateAxis20.setRangeWithMargins(range60);
        categoryPlot7.setRangeAxis(2958465, (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(dateTickUnit23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 126.0d + "'", double54 == 126.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType58);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertNotNull(lengthConstraintType61);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setOuterSeparatorExtension(100.0d);
        java.awt.Paint paint4 = ringPlot1.getBackgroundPaint();
        double double5 = ringPlot1.getInteriorGap();
        double double6 = ringPlot1.getInnerSeparatorExtension();
        double double7 = ringPlot1.getSectionDepth();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.25d + "'", double5 == 0.25d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        java.lang.String str3 = size2D2.toString();
        size2D2.height = 3.0d;
        org.jfree.data.gantt.TaskSeries taskSeries7 = new org.jfree.data.gantt.TaskSeries("hi!");
        taskSeries7.fireSeriesChanged();
        taskSeries7.removeAll();
        boolean boolean10 = size2D2.equals((java.lang.Object) taskSeries7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=97.0, height=0.0]" + "'", str3.equals("Size2D[width=97.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setLicenceName("CategoryAnchor.MIDDLE");
        java.lang.String str3 = projectInfo0.getVersion();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.addValue(8.0d, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0f);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray8);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset9);
        boolean boolean11 = categoryLabelWidthType5.equals((java.lang.Object) multiplePiePlot10);
        boolean boolean12 = defaultCategoryDataset0.hasListener((java.util.EventListener) multiplePiePlot10);
        org.jfree.chart.JFreeChart jFreeChart13 = multiplePiePlot10.getPieChart();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double17 = rectangleInsets15.calculateTopOutset((double) (byte) -1);
        org.jfree.chart.util.Size2D size2D20 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        java.lang.String str21 = size2D20.toString();
        size2D20.height = 3.0d;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.geom.Rectangle2D rectangle2D27 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D20, 0.0d, (double) 15, rectangleAnchor26);
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets15.createOutsetRectangle(rectangle2D27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        try {
            jFreeChart13.draw(graphics2D14, rectangle2D28, chartRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jFreeChart13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Size2D[width=97.0, height=0.0]" + "'", str21.equals("Size2D[width=97.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        dateAxis20.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        dateAxis27.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        xYPlot34.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot34.getDomainAxisLocation();
        java.awt.Paint paint37 = xYPlot34.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        int int39 = xYPlot34.getIndexOf(xYItemRenderer38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection42 = null;
        chartRenderingInfo41.setEntityCollection(entityCollection42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = null;
        dateAxis47.setTickUnit(dateTickUnit48);
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = dateAxis47.getTickUnit();
        dateAxis47.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = null;
        dateAxis54.setTickUnit(dateTickUnit55);
        org.jfree.chart.axis.DateTickUnit dateTickUnit57 = dateAxis54.getTickUnit();
        dateAxis54.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer60);
        xYPlot61.configureRangeAxes();
        java.awt.Stroke stroke63 = xYPlot61.getRangeZeroBaselineStroke();
        xYPlot61.setRangeCrosshairValue((double) (-3695));
        xYPlot61.setRangeZeroBaselineVisible(true);
        java.awt.geom.Point2D point2D68 = xYPlot61.getQuadrantOrigin();
        xYPlot34.zoomRangeAxes(100.0d, plotRenderingInfo44, point2D68);
        xYPlot16.setQuadrantOrigin(point2D68);
        xYPlot16.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(dateTickUnit23);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(dateTickUnit50);
        org.junit.Assert.assertNull(dateTickUnit57);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(point2D68);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("TextAnchor.TOP_CENTER", font2, (java.awt.Paint) color3);
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date8 = dateAxis7.getMaximumDate();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (-1), (double) 12, (double) (-1), (double) (byte) 0);
        dateAxis7.setLabelInsets(rectangleInsets13);
        double double15 = rectangleInsets13.getBottom();
        boolean boolean16 = textFragment4.equals((java.lang.Object) double15);
        java.lang.String str17 = textFragment4.getText();
        textLine0.addFragment(textFragment4);
        java.lang.String str19 = textFragment4.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str17.equals("TextAnchor.TOP_CENTER"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str19.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.clearDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = null;
        dateAxis20.setTickUnit(dateTickUnit21);
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = dateAxis20.getTickUnit();
        dateAxis20.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        dateAxis27.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer33);
        xYPlot34.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot34.getDomainAxisLocation();
        xYPlot16.setRangeAxisLocation(axisLocation36, false);
        xYPlot16.clearRangeMarkers(2019);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNull(dateTickUnit23);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Paint paint14 = stackedBarRenderer3D1.getItemPaint(0, (int) (byte) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        stackedBarRenderer3D1.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator16, false);
        java.awt.Paint paint19 = stackedBarRenderer3D1.getWallPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        xYPlot16.setRangeCrosshairValue((-1.0d), true);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation71 = null;
        try {
            boolean boolean72 = xYPlot16.removeAnnotation(xYAnnotation71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D1.setMinimumBarLength((double) (byte) -1);
        boolean boolean6 = stackedBarRenderer3D1.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D1.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = stackedBarRenderer3D1.getBaseToolTipGenerator();
        stackedBarRenderer3D1.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer16.setSeriesOutlinePaint(4, (java.awt.Paint) color18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer16);
        categoryPlot20.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        categoryPlot20.markerChanged(markerChangeEvent24);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit28 = null;
        dateAxis27.setTickUnit(dateTickUnit28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = dateAxis27.getTickUnit();
        double double31 = dateAxis27.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        stackedBarRenderer3D1.drawRangeGridline(graphics2D12, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis27, rectangle2D32, (double) (-1L));
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection39 = null;
        chartRenderingInfo38.setEntityCollection(entityCollection39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        boolean boolean42 = categoryPlot20.render(graphics2D35, rectangle2D36, (-3695), plotRenderingInfo41);
        org.jfree.chart.renderer.RendererState rendererState43 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = plotRenderingInfo41.getOwner();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(dateTickUnit30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chartRenderingInfo44);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Object obj2 = defaultCategoryDataset1.clone();
        int int4 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) (-3695));
        defaultCategoryDataset1.addValue(0.0d, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 0L);
        java.lang.Object obj9 = defaultCategoryDataset1.clone();
        java.util.List list10 = defaultCategoryDataset1.getRowKeys();
        java.util.List list11 = defaultCategoryDataset1.getRowKeys();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit12, dataset13);
        java.lang.String str16 = dateTickUnit12.valueToString((double) (-1.0f));
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        int int19 = year18.getYear();
        org.jfree.data.gantt.Task task20 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        int int23 = year22.getYear();
        org.jfree.data.gantt.Task task24 = new org.jfree.data.gantt.Task("TextAnchor.TOP_CENTER", (org.jfree.data.time.TimePeriod) year22);
        task20.addSubtask(task24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int27 = year26.getYear();
        java.util.Date date28 = year26.getEnd();
        int int30 = year26.compareTo((java.lang.Object) 0.05d);
        task24.setDuration((org.jfree.data.time.TimePeriod) year26);
        java.util.Date date32 = year26.getEnd();
        java.text.DateFormat dateFormat35 = null;
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = new org.jfree.chart.axis.DateTickUnit(2, 0, dateFormat35);
        java.lang.String str38 = dateTickUnit36.valueToString((double) 9999);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        java.util.Date date40 = year39.getStart();
        java.util.TimeZone timeZone41 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Date date42 = dateTickUnit36.rollDate(date40, timeZone41);
        java.util.Date date43 = dateTickUnit12.addToDate(date32, timeZone41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        int int45 = year44.getYear();
        java.util.Date date46 = year44.getEnd();
        org.jfree.chart.JFreeChart jFreeChart47 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date46, jFreeChart47);
        java.util.Date date49 = dateTickUnit12.addToDate(date46);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(100);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths((int) ' ', serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(10, serialDate53);
        java.lang.String str56 = serialDate55.getDescription();
        defaultBoxAndWhiskerCategoryDataset0.add(list11, (java.lang.Comparable) date46, (java.lang.Comparable) serialDate55);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(dateTickUnit12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "12/31/69 3:59 PM" + "'", str16.equals("12/31/69 3:59 PM"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "12/31/69" + "'", str38.equals("12/31/69"));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNull(str56);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceText();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean3 = projectInfo0.equals((java.lang.Object) textAnchor2);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D(pieDataset6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        piePlot3D7.setSectionOutlineStroke((java.lang.Comparable) 9999, stroke10);
        dateAxis1.setAxisLineStroke(stroke10);
        dateAxis1.setAutoRange(true);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        java.awt.Paint paint3 = categoryAxis1.getTickMarkPaint();
        ganttRenderer0.setCompletePaint(paint3);
        java.awt.Paint paint5 = ganttRenderer0.getIncompletePaint();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        ganttRenderer0.setCompletePaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        dateAxis1.setAutoTickUnitSelection(false);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer10.setSeriesOutlinePaint(4, (java.awt.Paint) color12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer10);
        categoryPlot14.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20);
        categoryPlot14.configureRangeAxes();
        boolean boolean23 = categoryPlot14.isRangeZoomable();
        double double24 = categoryPlot14.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateBottomOutset((double) (short) -1);
        categoryPlot14.setAxisOffset(rectangleInsets25);
        dateAxis1.setLabelInsets(rectangleInsets25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = dateAxis1.getStandardTickUnits();
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource30);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot7.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        int int18 = categoryPlot7.getDomainAxisIndex(categoryAxis17);
        java.awt.Image image19 = categoryPlot7.getBackgroundImage();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot7.getDataset();
        categoryPlot7.configureDomainAxes();
        java.awt.Stroke stroke22 = categoryPlot7.getRangeGridlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            boolean boolean24 = categoryPlot7.removeAnnotation(categoryAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = xYPlot16.getDomainAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot16.getDomainAxisLocation();
        xYPlot16.configureDomainAxes();
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        long long5 = segmentedTimeline3.getSegmentsExcludedSize();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder();
        textTitle6.setFrame((org.jfree.chart.block.BlockFrame) blockBorder7);
        boolean boolean9 = segmentedTimeline3.equals((java.lang.Object) textTitle6);
        double double10 = textTitle6.getHeight();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis12.setTickUnit(dateTickUnit13);
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = dateAxis12.getTickUnit();
        dateAxis12.setAutoTickUnitSelection(false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer21.setSeriesOutlinePaint(4, (java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer21);
        categoryPlot25.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot25.zoomRangeAxes(0.0d, plotRenderingInfo30, point2D31);
        categoryPlot25.configureRangeAxes();
        boolean boolean34 = categoryPlot25.isRangeZoomable();
        double double35 = categoryPlot25.getRangeCrosshairValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateBottomOutset((double) (short) -1);
        categoryPlot25.setAxisOffset(rectangleInsets36);
        dateAxis12.setLabelInsets(rectangleInsets36);
        textTitle6.setMargin(rectangleInsets36);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment43 = textTitle42.getHorizontalAlignment();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D45.setMinimumBarLength((double) (byte) -1);
        boolean boolean50 = stackedBarRenderer3D45.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D45.setDrawBarOutline(true);
        double double53 = stackedBarRenderer3D45.getYOffset();
        boolean boolean54 = horizontalAlignment43.equals((java.lang.Object) stackedBarRenderer3D45);
        org.jfree.chart.util.VerticalAlignment verticalAlignment55 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement58 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment43, verticalAlignment55, 0.2d, (double) (-1));
        org.jfree.chart.block.BlockContainer blockContainer59 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement58);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D60 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D60.configure();
        java.text.NumberFormat numberFormat62 = null;
        numberAxis3D60.setNumberFormatOverride(numberFormat62);
        org.jfree.chart.util.Size2D size2D67 = new org.jfree.chart.util.Size2D((double) 'a', (double) (short) 0);
        size2D67.setHeight((double) (byte) 0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D73 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D67, (double) (short) -1, (double) ' ', rectangleAnchor72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        double double75 = numberAxis3D60.valueToJava2D((double) 'a', rectangle2D73, rectangleEdge74);
        blockContainer59.setBounds(rectangle2D73);
        rectangleInsets36.trim(rectangle2D73);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 3100L + "'", long5 == 3100L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(dateTickUnit15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 8.0d + "'", double53 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 9359.5d + "'", double75 == 9359.5d);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 31, (int) (byte) 1, (int) (short) 100);
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list5 = segmentedTimeline3.getExceptionSegments();
        boolean boolean8 = segmentedTimeline3.containsDomainRange((long) (short) 0, (long) 31);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline3.getSegment((long) ' ');
        long long11 = segment10.getMillisecond();
        boolean boolean12 = segment10.inExcludeSegments();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TextAnchor.TOP_CENTER");
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-16711936), 128, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        double double5 = dateAxis1.getAutoRangeMinimumSize();
        java.util.TimeZone timeZone6 = dateAxis1.getTimeZone();
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        ringPlot1.setPieIndex((int) (byte) 1);
        ringPlot1.setOuterSeparatorExtension((double) 12);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        org.jfree.chart.JFreeChart jFreeChart5 = multiplePiePlot4.getPieChart();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener8 = null;
        textTitle6.removeChangeListener(titleChangeListener8);
        jFreeChart5.addSubtitle((org.jfree.chart.title.Title) textTitle6);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = jFreeChart5.getPadding();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(jFreeChart5);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "Other", "RectangleEdge.LEFT");
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        boolean boolean15 = categoryPlot7.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot7.setDataset(categoryDataset16);
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot7.setRangeCrosshairPaint(paint18);
        java.awt.Paint paint20 = categoryPlot7.getDomainGridlinePaint();
        categoryPlot7.setAnchorValue((double) '#');
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        double double25 = categoryAxis24.getCategoryMargin();
        categoryPlot7.setDomainAxis(6, categoryAxis24, false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot7.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot7.getRangeAxisLocation((int) (short) -1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ERROR : Relative To String", "ItemLabelAnchor.INSIDE6", doubleArray2);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset3);
        double double5 = multiplePiePlot4.getLimit();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = multiplePiePlot4.getLegendItems();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean5 = categoryLabelPositions3.equals((java.lang.Object) 1L);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        boolean boolean7 = categoryLabelPositions3.equals((java.lang.Object) year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((java.lang.Comparable) regularTimePeriod8, (java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = dateAxis1.getTickUnit();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer8 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer8.setSeriesOutlinePaint(4, (java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer8);
        categoryPlot12.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        categoryPlot12.markerChanged(markerChangeEvent16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1);
        categoryPlot12.addDomainMarker(categoryMarker19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot12.getDomainAxisForDataset(2019);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int25 = color24.getTransparency();
        categoryPlot12.setRangeGridlinePaint((java.awt.Paint) color24);
        java.awt.color.ColorSpace colorSpace27 = color24.getColorSpace();
        org.junit.Assert.assertNull(dateTickUnit4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(colorSpace27);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("({0}, {1}) = {2}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.setNegativeArrowVisible(false);
        java.text.DateFormat dateFormat6 = dateAxis3.getDateFormatOverride();
        java.awt.Shape shape7 = dateAxis3.getRightArrow();
        dateAxis3.setAutoTickUnitSelection(true);
        java.awt.Paint paint10 = dateAxis3.getTickLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("{0}", font1, paint10);
        double double12 = labelBlock11.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setID("TextAnchor.TOP_CENTER");
        textTitle13.setExpandToFitSpace(false);
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        textTitle13.setBackgroundPaint(paint18);
        labelBlock11.setPaint(paint18);
        java.awt.Font font21 = labelBlock11.getFont();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getHeightConstraintType();
        java.lang.String str4 = lengthConstraintType3.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LengthConstraintType.FIXED" + "'", str4.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot7.markerChanged(markerChangeEvent11);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.Date date16 = dateAxis15.getMaximumDate();
        categoryPlot7.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        try {
            xYPlot0.addDomainMarker(marker1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis11);
        categoryPlot7.axisChanged(axisChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = null;
        dateAxis16.setTickUnit(dateTickUnit17);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = dateAxis16.getTickUnit();
        dateAxis16.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit24 = null;
        dateAxis23.setTickUnit(dateTickUnit24);
        org.jfree.chart.axis.DateTickUnit dateTickUnit26 = dateAxis23.getTickUnit();
        dateAxis23.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer29);
        xYPlot30.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        dateAxis33.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis33.setStandardTickUnits(tickUnitSource36);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D39.setMinimumBarLength((double) (byte) -1);
        boolean boolean44 = stackedBarRenderer3D39.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D39.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator47 = stackedBarRenderer3D39.getBaseToolTipGenerator();
        stackedBarRenderer3D39.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer54 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer54.setSeriesOutlinePaint(4, (java.awt.Paint) color56);
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis53, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer54);
        categoryPlot58.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent62 = null;
        categoryPlot58.markerChanged(markerChangeEvent62);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit66 = null;
        dateAxis65.setTickUnit(dateTickUnit66);
        org.jfree.chart.axis.DateTickUnit dateTickUnit68 = dateAxis65.getTickUnit();
        double double69 = dateAxis65.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        stackedBarRenderer3D39.drawRangeGridline(graphics2D50, categoryPlot58, (org.jfree.chart.axis.ValueAxis) dateAxis65, rectangle2D70, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("");
        dateAxis74.setNegativeArrowVisible(false);
        org.jfree.data.Range range77 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis74.setRangeWithMargins(range77);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray79 = new org.jfree.chart.axis.ValueAxis[] { dateAxis33, dateAxis65, dateAxis74 };
        xYPlot30.setRangeAxes(valueAxisArray79);
        categoryPlot7.setRangeAxes(valueAxisArray79);
        categoryPlot7.clearDomainMarkers((int) (short) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(dateTickUnit19);
        org.junit.Assert.assertNull(dateTickUnit26);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator47);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNull(dateTickUnit68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.0d + "'", double69 == 2.0d);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertNotNull(valueAxisArray79);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer3.setSeriesOutlinePaint(4, (java.awt.Paint) color5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer3);
        categoryPlot7.setAnchorValue((double) 0L, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        categoryPlot7.configureRangeAxes();
        boolean boolean16 = categoryPlot7.isRangeZoomable();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getDomainAxisLocation();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot7.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(500);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-338) + "'", int1 == (-338));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = null;
        dateAxis2.setTickUnit(dateTickUnit3);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = dateAxis2.getTickUnit();
        dateAxis2.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
        dateAxis9.setTickUnit(dateTickUnit10);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = dateAxis9.getTickUnit();
        dateAxis9.setLabelURL("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer15);
        xYPlot16.configureRangeAxes();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        dateAxis19.setStandardTickUnits(tickUnitSource22);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        stackedBarRenderer3D25.setMinimumBarLength((double) (byte) -1);
        boolean boolean30 = stackedBarRenderer3D25.isItemLabelVisible((int) '#', 0);
        stackedBarRenderer3D25.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator33 = stackedBarRenderer3D25.getBaseToolTipGenerator();
        stackedBarRenderer3D25.setRenderAsPercentages(true);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalLineAndShapeRenderer40.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalLineAndShapeRenderer40);
        categoryPlot44.setAnchorValue((double) 0L, false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        categoryPlot44.markerChanged(markerChangeEvent48);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis51.setTickUnit(dateTickUnit52);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = dateAxis51.getTickUnit();
        double double55 = dateAxis51.getAutoRangeMinimumSize();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        stackedBarRenderer3D25.drawRangeGridline(graphics2D36, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis51, rectangle2D56, (double) (-1L));
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        dateAxis60.setNegativeArrowVisible(false);
        org.jfree.data.Range range63 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis60.setRangeWithMargins(range63);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis19, dateAxis51, dateAxis60 };
        xYPlot16.setRangeAxes(valueAxisArray65);
        java.util.List list67 = xYPlot16.getAnnotations();
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle();
        textTitle69.setID("TextAnchor.TOP_CENTER");
        textTitle69.setWidth((-1.0d));
        textTitle69.setExpandToFitSpace(false);
        java.awt.geom.Rectangle2D rectangle2D76 = textTitle69.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection78 = null;
        chartRenderingInfo77.setEntityCollection(entityCollection78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        xYPlot16.drawAnnotations(graphics2D68, rectangle2D76, plotRenderingInfo80);
        org.junit.Assert.assertNull(dateTickUnit5);
        org.junit.Assert.assertNull(dateTickUnit12);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator33);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(dateTickUnit54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.0d + "'", double55 == 2.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertNotNull(rectangle2D76);
    }
}

