import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, 2019);
        int int4 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        java.lang.String str22 = year21.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year21);
        int int25 = year21.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 1560409200000L);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year21.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969" + "'", str22.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        java.lang.Object obj10 = null;
        boolean boolean11 = timePeriodValue9.equals(obj10);
        java.lang.String str12 = timePeriodValue9.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[1969,7]" + "'", str12.equals("TimePeriodValue[1969,7]"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 100);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date6 = simpleTimePeriod5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        boolean boolean9 = year7.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long10 = year7.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 7);
        int int13 = day0.compareTo((java.lang.Object) year7);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        boolean boolean5 = timePeriodValues4.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date11 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str16 = timePeriodFormatException15.toString();
//        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
//        java.lang.Class<?> wildcardClass18 = timePeriodFormatException13.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date29 = simpleTimePeriod28.getEnd();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
//        java.util.Date date32 = year30.getStart();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date32, timeZone34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date11, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day36.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day36, (double) 0);
//        timePeriodValues4.add(timePeriodValue39);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues4.addChangeListener(seriesChangeListener41);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 100);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date6 = simpleTimePeriod5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        boolean boolean9 = year7.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long10 = year7.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (java.lang.Number) 7);
        int int13 = day0.compareTo((java.lang.Object) year7);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues15.fireSeriesChanged();
        int int17 = timePeriodValues15.getItemCount();
        java.lang.String str18 = timePeriodValues15.getDescription();
        timePeriodValues15.setDomainDescription("TimePeriodValue[1969,100.0]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        boolean boolean27 = year25.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long28 = year25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year25.next();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) regularTimePeriod29, (java.lang.Number) 10L);
        boolean boolean32 = day0.equals((java.lang.Object) regularTimePeriod29);
        org.jfree.data.time.SerialDate serialDate33 = day0.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date37 = simpleTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        java.lang.String str39 = year38.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year38.previous();
        long long42 = year38.getFirstMillisecond();
        java.lang.Class<?> wildcardClass43 = year38.getClass();
        java.util.Date date44 = year38.getStart();
        int int45 = day0.compareTo((java.lang.Object) date44);
        java.util.Date date46 = day0.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        java.util.Calendar calendar48 = null;
        try {
            long long49 = year47.getLastMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28799999L + "'", long28 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1969" + "'", str39.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31507200000L) + "'", long42 == (-31507200000L));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        java.util.Date date7 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getSerialIndex();
        long long10 = year8.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1969L + "'", long9 == 1969L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = year4.equals(obj8);
        java.lang.Number number10 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, number10);
        java.lang.Object obj12 = null;
        boolean boolean13 = year4.equals(obj12);
        long long14 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-31507200000L) + "'", long14 == (-31507200000L));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        int int10 = year4.getYear();
        java.util.Date date11 = year4.getStart();
        java.util.Calendar calendar12 = null;
        try {
            year4.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod9);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        int int10 = timePeriodValues8.getMaxEndIndex();
        timePeriodValues8.setDomainDescription("Value");
        timePeriodValues8.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=100.0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        java.lang.Object obj10 = null;
        boolean boolean11 = timePeriodValue9.equals(obj10);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue9.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue9.getPeriod();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertNotNull(timePeriod13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener8);
        java.lang.Object obj10 = timePeriodValues7.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues7);
        java.lang.String str12 = seriesChangeEvent11.toString();
        try {
            int int13 = simpleTimePeriod2.compareTo((java.lang.Object) seriesChangeEvent11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.general.SeriesChangeEvent cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener12);
        java.lang.Class<?> wildcardClass14 = timePeriodValues11.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues11);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setDescription("");
        timePeriodValues1.setNotify(false);
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDescription("13-June-2019");
//        timePeriodValues1.setDescription("Value");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int11 = day9.compareTo((java.lang.Object) 100);
//        java.lang.String str12 = day9.toString();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day9, (double) 7);
//        java.lang.String str15 = timePeriodValues1.getDomainDescription();
//        timePeriodValues1.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener17);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
//        java.lang.String str5 = timePeriodValues1.getDomainDescription();
//        timePeriodValues1.setDescription("13-June-2019");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date11 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        java.lang.String str13 = year12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 8);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int19 = day17.compareTo((java.lang.Object) 5);
//        java.lang.String str20 = day17.toString();
//        long long21 = day17.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str26 = timePeriodFormatException25.toString();
//        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
//        java.lang.Class<?> wildcardClass28 = timePeriodFormatException23.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date32 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date32, timeZone34);
//        boolean boolean36 = day17.equals((java.lang.Object) wildcardClass28);
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date41 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date47 = simpleTimePeriod46.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str52 = timePeriodFormatException51.toString();
//        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException51);
//        java.lang.Class<?> wildcardClass54 = timePeriodFormatException49.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date58 = simpleTimePeriod57.getEnd();
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date58);
//        java.util.TimeZone timeZone60 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date58, timeZone60);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date65 = simpleTimePeriod64.getEnd();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year66.next();
//        java.util.Date date68 = year66.getStart();
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date68, timeZone70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date47, timeZone70);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date41, timeZone70);
//        int int74 = year12.compareTo((java.lang.Object) regularTimePeriod73);
//        int int75 = year12.getYear();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 100 + "'", comparable4.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str52.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1969 + "'", int75 == 1969);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("Value");
        java.lang.String str9 = timePeriodFormatException8.toString();
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) timePeriodFormatException8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        boolean boolean24 = year22.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long25 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year22.next();
        boolean boolean27 = year15.equals((java.lang.Object) year22);
        timePeriodValues1.setKey((java.lang.Comparable) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year15.previous();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.util.Date date0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date4 = simpleTimePeriod3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(date0, date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 8, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Value");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass4 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 100);
        java.lang.Number number12 = timePeriodValue11.getValue();
        java.lang.String str13 = timePeriodValue11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone26);
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        boolean boolean29 = timePeriodValue11.equals((java.lang.Object) wildcardClass20);
        timePeriodValues3.add(timePeriodValue11);
        timePeriodValues1.add(timePeriodValue11);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[1969,100.0]" + "'", str13.equals("TimePeriodValue[1969,100.0]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue9.getPeriod();
        timePeriodValue9.setValue((java.lang.Number) (-1));
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValue9.equals(obj15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year4.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        int int17 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        java.util.Calendar calendar11 = null;
        try {
            year4.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = simpleTimePeriod2.equals(obj5);
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date10 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int13 = day11.compareTo((java.lang.Object) 100);
//        java.lang.String str14 = day11.toString();
//        int int15 = day11.getMonth();
//        java.lang.Class<?> wildcardClass16 = day11.getClass();
//        java.util.Date date17 = day11.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date10, date17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date10, date22);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int28 = day26.compareTo((java.lang.Object) 5);
//        java.lang.String str29 = day26.toString();
//        long long30 = day26.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str35 = timePeriodFormatException34.toString();
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
//        java.lang.Class<?> wildcardClass37 = timePeriodFormatException32.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date41 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone43);
//        boolean boolean45 = day26.equals((java.lang.Object) wildcardClass37);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
//        timePeriodValues48.addChangeListener(seriesChangeListener49);
//        int int51 = timePeriodValues48.getMinStartIndex();
//        java.lang.Comparable comparable52 = timePeriodValues48.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = timePeriodValues48.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date59 = simpleTimePeriod58.getEnd();
//        timePeriodValues48.setKey((java.lang.Comparable) simpleTimePeriod58);
//        java.util.Date date61 = simpleTimePeriod58.getEnd();
//        java.util.TimeZone timeZone62 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date61, timeZone62);
//        int int64 = day26.compareTo((java.lang.Object) date61);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date10, date61);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560409200000L + "'", long30 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable52 + "' != '" + (short) 100 + "'", comparable52.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues55);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int8 = timePeriodValues7.getMinEndIndex();
        boolean boolean9 = year4.equals((java.lang.Object) timePeriodValues7);
        java.lang.String str10 = timePeriodValues7.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        boolean boolean17 = year15.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 7);
        java.lang.Number number21 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year15, number21);
        java.lang.String str23 = timePeriodValues7.getRangeDescription();
        timePeriodValues7.setNotify(false);
        java.lang.Object obj26 = timePeriodValues7.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent(obj26);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date8 = simpleTimePeriod7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date34, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date13, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date8, timeZone36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date3, timeZone36);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date3);
        long long42 = year41.getSerialIndex();
        java.lang.Object obj43 = null;
        int int44 = year41.compareTo(obj43);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1969L + "'", long42 == 1969L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        int int5 = day4.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        java.util.Date date4 = day0.getEnd();
//        long long5 = day0.getSerialIndex();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        int int2 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.lang.Class<?> wildcardClass4 = simpleTimePeriod2.getClass();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        int int6 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: Value");
        int int9 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        java.lang.Object obj11 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException5.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date24, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date3, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = day29.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue9.getPeriod();
        timePeriodValue9.setValue((java.lang.Number) (-1));
        java.lang.Number number15 = timePeriodValue9.getValue();
        java.lang.Object obj16 = timePeriodValue9.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1) + "'", number15.equals((-1)));
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int8 = timePeriodValues7.getMinEndIndex();
        boolean boolean9 = year4.equals((java.lang.Object) timePeriodValues7);
        java.lang.String str10 = timePeriodValues7.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues7.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[1969,100.0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str20 = timePeriodFormatException19.toString();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.String str23 = timePeriodFormatException19.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues6.addChangeListener(seriesChangeListener7);
//        int int9 = timePeriodValues6.getMinStartIndex();
//        java.lang.Comparable comparable10 = timePeriodValues6.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        timePeriodValues6.setKey((java.lang.Comparable) simpleTimePeriod16);
//        boolean boolean19 = timePeriodValues6.isEmpty();
//        int int20 = timePeriodValues6.getMinMiddleIndex();
//        int int21 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        int int22 = timePeriodValues6.getItemCount();
//        int int23 = timePeriodValues6.getMaxEndIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 100 + "'", comparable10.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, number4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day3, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ", "org.jfree.data.time.TimePeriodFormatException: 7-April-2019");
        java.lang.Comparable comparable9 = timePeriodValues8.getKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(comparable9);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date7 = simpleTimePeriod6.getEnd();
//        long long8 = simpleTimePeriod6.getEndMillis();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = simpleTimePeriod6.equals(obj9);
//        java.util.Date date11 = simpleTimePeriod6.getStart();
//        boolean boolean13 = simpleTimePeriod6.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date14 = simpleTimePeriod6.getStart();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int17 = day15.compareTo((java.lang.Object) 100);
//        java.lang.String str18 = day15.toString();
//        int int19 = day15.getMonth();
//        java.lang.Class<?> wildcardClass20 = day15.getClass();
//        java.util.Date date21 = day15.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date14, date21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date3, date21);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(date21);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues8.addChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timePeriodValues8.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues8);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        int int14 = year4.compareTo((java.lang.Object) seriesChangeEvent12);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 6);
        java.util.Calendar calendar17 = null;
        try {
            year4.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date6 = simpleTimePeriod5.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date6, date11);
        java.util.Date date13 = simpleTimePeriod12.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues15.getMinStartIndex();
        java.lang.Comparable comparable19 = timePeriodValues15.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = timePeriodValues15.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        timePeriodValues15.setKey((java.lang.Comparable) simpleTimePeriod25);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str33 = timePeriodFormatException32.toString();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.Class<?> wildcardClass35 = timePeriodFormatException30.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date39 = simpleTimePeriod38.getEnd();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone41);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date46 = simpleTimePeriod45.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.next();
        java.util.Date date49 = year47.getStart();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date49, timeZone51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date28, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date13, timeZone51);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (short) 100 + "'", comparable19.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(regularTimePeriod54);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        int int8 = year4.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        boolean boolean8 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[1969,7]");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = year4.equals(obj8);
        java.lang.Number number10 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, number10);
        java.lang.Object obj12 = timePeriodValue11.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        java.lang.String str6 = year4.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.lang.Class<?> wildcardClass4 = simpleTimePeriod2.getClass();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        int int14 = timePeriodValues1.getMinEndIndex();
        java.lang.Comparable comparable15 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        timePeriodValues1.setKey((java.lang.Comparable) 0L);
        boolean boolean20 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(comparable15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,2.8799999E7]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 100 + "'", comparable6.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinStartIndex();
//        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date12 = simpleTimePeriod11.getEnd();
//        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
//        boolean boolean14 = timePeriodValues1.isEmpty();
//        int int15 = timePeriodValues1.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int20 = day18.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day18.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 6);
//        long long24 = day18.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day18.previous();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues8);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("13-June-2019");
        boolean boolean8 = timePeriodValues1.equals((java.lang.Object) 4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        boolean boolean15 = year13.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long16 = year13.getLastMillisecond();
        java.lang.Object obj17 = null;
        boolean boolean18 = year13.equals(obj17);
        java.lang.Number number19 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, number19);
        java.lang.String str21 = year13.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener24);
        java.lang.Object obj26 = timePeriodValues23.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues23);
        int int28 = timePeriodValues23.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener29);
        int int31 = year13.compareTo((java.lang.Object) seriesChangeListener29);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year13, (double) 9);
        boolean boolean34 = timePeriodValues1.isEmpty();
        int int35 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969" + "'", str21.equals("1969"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, 2019);
        int int4 = day3.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        long long6 = day3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1554620400000L + "'", long6 == 1554620400000L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        java.lang.String str3 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date7 = simpleTimePeriod6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str17 = timePeriodFormatException16.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException14.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date23 = simpleTimePeriod22.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date30 = simpleTimePeriod29.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.next();
        java.util.Date date33 = year31.getStart();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date33, timeZone35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date12, timeZone35);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date7, timeZone35);
        boolean boolean39 = timePeriodValues1.equals((java.lang.Object) timeZone35);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener40);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str31 = timePeriodFormatException30.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException28.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date37 = simpleTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date44 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.util.Date date47 = year45.getStart();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date47, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date26, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date19, timeZone49);
        boolean boolean53 = simpleTimePeriod2.equals((java.lang.Object) day52);
        java.util.Date date54 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues57.fireSeriesChanged();
        int int59 = timePeriodValues57.getItemCount();
        java.lang.String str60 = timePeriodValues57.getDescription();
        int int61 = timePeriodValues57.getMinStartIndex();
        int int62 = timePeriodValues57.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = timePeriodValues57.createCopy(0, 1969);
        boolean boolean66 = simpleTimePeriod2.equals((java.lang.Object) 1969);
        java.util.Date date67 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(date67);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 1969);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[1969,100.0]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException5.toString();
        java.lang.String str9 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str20 = timePeriodFormatException19.toString();
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=100.0]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) seriesException27);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        long long7 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        long long8 = year4.getSerialIndex();
        long long9 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        java.lang.Object obj4 = timePeriodValues1.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
//        int int6 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str11 = timePeriodFormatException10.toString();
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
//        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date20 = simpleTimePeriod19.getEnd();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        java.lang.String str22 = year21.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year21);
//        int int25 = year21.getYear();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) 1560409200000L);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 1969L);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod30, (java.lang.Number) 10.0f);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        int int35 = day33.compareTo((java.lang.Object) 100);
//        java.lang.String str36 = day33.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day33.next();
//        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod37);
//        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]");
//        try {
//            java.lang.Object obj41 = timePeriodValues1.clone();
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969" + "'", str22.equals("1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        java.util.Date date6 = year4.getEnd();
        int int7 = year4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
//        long long6 = day5.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        int int9 = timePeriodValues8.getMaxMiddleIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date13 = simpleTimePeriod12.getEnd();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
//        java.lang.Object obj16 = seriesChangeEvent15.getSource();
//        boolean boolean17 = timePeriodValues8.equals(obj16);
//        boolean boolean18 = day5.equals(obj16);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560452399999L + "'", long6 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', (int) 'a', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMaxMiddleIndex();
        int int11 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str9 = timePeriodFormatException8.toString();
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException6.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = day0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
//        timePeriodValues22.addChangeListener(seriesChangeListener23);
//        int int25 = timePeriodValues22.getMinStartIndex();
//        java.lang.Comparable comparable26 = timePeriodValues22.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = timePeriodValues22.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date33 = simpleTimePeriod32.getEnd();
//        timePeriodValues22.setKey((java.lang.Comparable) simpleTimePeriod32);
//        java.util.Date date35 = simpleTimePeriod32.getEnd();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date35, timeZone36);
//        int int38 = day0.compareTo((java.lang.Object) date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timePeriodValues40.addChangeListener(seriesChangeListener41);
//        int int43 = timePeriodValues40.getMinStartIndex();
//        java.lang.Comparable comparable44 = timePeriodValues40.getKey();
//        int int45 = timePeriodValues40.getMinStartIndex();
//        timePeriodValues40.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: Value");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date51 = simpleTimePeriod50.getEnd();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
//        boolean boolean53 = timePeriodValues40.equals((java.lang.Object) date51);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date35, date51);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date35);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (short) 100 + "'", comparable26.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + (short) 100 + "'", comparable44.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        timePeriodValues1.setRangeDescription("Value");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        int int8 = timePeriodValues6.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener11);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) timePeriodValues6);
        try {
            org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues6.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener9);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDescription("13-June-2019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 8);
        int int17 = timePeriodValues1.getItemCount();
        try {
            timePeriodValues1.update((int) (short) -1, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 100 + "'", comparable4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.setNotify(true);
        java.lang.String str5 = timePeriodValues1.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.String str7 = seriesChangeEvent5.toString();
        java.lang.Object obj8 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
//        long long7 = year4.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = timePeriodValue9.equals(obj10);
//        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue9.getPeriod();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timePeriodValues14.addChangeListener(seriesChangeListener15);
//        int int17 = timePeriodValues14.getMinStartIndex();
//        timePeriodValues14.setDescription("13-June-2019");
//        boolean boolean21 = timePeriodValues14.equals((java.lang.Object) 4);
//        boolean boolean22 = timePeriodValue9.equals((java.lang.Object) boolean21);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date26 = simpleTimePeriod25.getEnd();
//        long long27 = simpleTimePeriod25.getEndMillis();
//        java.lang.Object obj28 = null;
//        boolean boolean29 = simpleTimePeriod25.equals(obj28);
//        java.util.Date date30 = simpleTimePeriod25.getStart();
//        boolean boolean32 = simpleTimePeriod25.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date33 = simpleTimePeriod25.getStart();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        int int36 = day34.compareTo((java.lang.Object) 100);
//        java.lang.String str37 = day34.toString();
//        int int38 = day34.getMonth();
//        java.lang.Class<?> wildcardClass39 = day34.getClass();
//        java.util.Date date40 = day34.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date33, date40);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date45 = simpleTimePeriod44.getEnd();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date33, date45);
//        boolean boolean49 = timePeriodValue9.equals((java.lang.Object) date33);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue9);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(timePeriod12);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 100L + "'", long27 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException5.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date24, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date3, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
        java.lang.String str30 = day28.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "31-December-1969" + "'", str30.equals("31-December-1969"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Value");
        java.lang.Object obj12 = null;
        boolean boolean13 = timePeriodValue9.equals(obj12);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) ' ');
//        int int9 = day0.getYear();
//        java.util.Calendar calendar10 = null;
//        try {
//            day0.peg(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date3 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        boolean boolean8 = timePeriodValues7.getNotify();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int11 = day9.compareTo((java.lang.Object) 100);
//        java.lang.String str12 = day9.toString();
//        timePeriodValues7.setKey((java.lang.Comparable) day9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues7.removeChangeListener(seriesChangeListener14);
//        boolean boolean16 = year4.equals((java.lang.Object) seriesChangeListener14);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) (byte) 10);
        timePeriodValue9.setValue((java.lang.Number) 6);
        timePeriodValue9.setValue((java.lang.Number) 100.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        boolean boolean22 = year20.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long23 = year20.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 7);
        boolean boolean27 = timePeriodValue25.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.TimePeriod timePeriod28 = timePeriodValue25.getPeriod();
        timePeriodValue25.setValue((java.lang.Number) (-1));
        org.jfree.data.time.TimePeriod timePeriod31 = timePeriodValue25.getPeriod();
        boolean boolean32 = timePeriodValue9.equals((java.lang.Object) timePeriodValue25);
        java.lang.Object obj33 = timePeriodValue9.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-31507200000L) + "'", long23 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timePeriod28);
        org.junit.Assert.assertNotNull(timePeriod31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        long long8 = year4.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            year4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-15739200001L) + "'", long8 == (-15739200001L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.setRangeDescription("TimePeriodValue[13-June-2019,2.8799999E7]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (short) 100);
        java.lang.Number number7 = timePeriodValue6.getValue();
        java.lang.String str8 = timePeriodValue6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone21);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        boolean boolean24 = timePeriodValue6.equals((java.lang.Object) wildcardClass15);
        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[1969,100.0]" + "'", str8.equals("TimePeriodValue[1969,100.0]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timePeriod25);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 6);
//        long long6 = day0.getLastMillisecond();
//        int int7 = day0.getMonth();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getLastMillisecond();
//        long long5 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        int int12 = year10.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener15);
        java.lang.Object obj17 = timePeriodValues14.clone();
        timePeriodValues14.delete((int) 'a', 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        boolean boolean27 = year25.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long28 = year25.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 7);
        boolean boolean32 = timePeriodValue30.equals((java.lang.Object) (byte) 10);
        timePeriodValue30.setValue((java.lang.Number) 6);
        timePeriodValue30.setValue((java.lang.Number) 100.0d);
        timePeriodValues14.add(timePeriodValue30);
        java.lang.String str38 = timePeriodValues14.getRangeDescription();
        int int39 = year10.compareTo((java.lang.Object) str38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year10.next();
        boolean boolean41 = simpleTimePeriod2.equals((java.lang.Object) year10);
        long long42 = year10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31507200000L) + "'", long28 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Value" + "'", str38.equals("Value"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException1.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 1577865599999L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        timePeriodValues1.setKey((java.lang.Comparable) (short) -1);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues1.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        long long7 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date15 = simpleTimePeriod14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str25 = timePeriodFormatException24.toString();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException22.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date38 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date41, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date20, timeZone43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date15, timeZone43);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date10, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.next();
        boolean boolean49 = simpleTimePeriod2.equals((java.lang.Object) year47);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timePeriodValues1.getNotify();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int5 = day3.compareTo((java.lang.Object) 100);
//        java.lang.String str6 = day3.toString();
//        timePeriodValues1.setKey((java.lang.Comparable) day3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener8);
//        java.lang.String str10 = timePeriodValues1.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(str10);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = simpleTimePeriod2.equals(obj5);
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date10 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int13 = day11.compareTo((java.lang.Object) 100);
//        java.lang.String str14 = day11.toString();
//        int int15 = day11.getMonth();
//        java.lang.Class<?> wildcardClass16 = day11.getClass();
//        java.util.Date date17 = day11.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date10, date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day19);
//        java.lang.String str21 = seriesChangeEvent20.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod4 = timePeriodValues1.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        int int17 = timePeriodValues1.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        boolean boolean14 = year12.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 7);
        boolean boolean19 = timePeriodValue17.equals((java.lang.Object) (byte) 10);
        timePeriodValue17.setValue((java.lang.Number) 6);
        timePeriodValue17.setValue((java.lang.Number) 100.0d);
        timePeriodValues1.add(timePeriodValue17);
        java.lang.String str25 = timePeriodValues1.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date29 = simpleTimePeriod28.getEnd();
        long long30 = simpleTimePeriod28.getEndMillis();
        java.lang.Object obj31 = null;
        boolean boolean32 = simpleTimePeriod28.equals(obj31);
        java.util.Date date33 = simpleTimePeriod28.getStart();
        boolean boolean34 = timePeriodValues1.equals((java.lang.Object) simpleTimePeriod28);
        int int35 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Value" + "'", str25.equals("Value"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
//        timePeriodValues1.setDomainDescription("Value");
//        java.lang.String str6 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int11 = day9.compareTo((java.lang.Object) 5);
//        java.lang.String str12 = day9.toString();
//        java.util.Date date13 = day9.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        long long19 = year18.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        int int22 = timePeriodValues21.getMinEndIndex();
//        boolean boolean23 = year18.equals((java.lang.Object) timePeriodValues21);
//        java.lang.String str24 = timePeriodValues21.getRangeDescription();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date28 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        java.lang.String str30 = year29.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year29.next();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year29);
//        boolean boolean33 = timePeriodValues21.equals((java.lang.Object) seriesChangeEvent32);
//        java.lang.String str34 = seriesChangeEvent32.toString();
//        java.lang.String str35 = seriesChangeEvent32.toString();
//        java.lang.String str36 = seriesChangeEvent32.toString();
//        boolean boolean37 = day9.equals((java.lang.Object) seriesChangeEvent32);
//        java.lang.Number number38 = null;
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day9, number38);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1969L + "'", long19 == 1969L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1969" + "'", str30.equals("1969"));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str34.equals("org.jfree.data.general.SeriesChangeEvent[source=1969]"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str35.equals("org.jfree.data.general.SeriesChangeEvent[source=1969]"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str36.equals("org.jfree.data.general.SeriesChangeEvent[source=1969]"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) ' ');
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 3);
//        int int11 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        int int17 = timePeriodValues1.getMaxMiddleIndex();
        try {
            timePeriodValues1.delete(7, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        int int14 = timePeriodValues1.getMinEndIndex();
        int int15 = timePeriodValues1.getMinMiddleIndex();
        int int16 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        timePeriodValues1.delete(13, 2);
        timePeriodValues1.setNotify(true);
        int int22 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setDescription("13-June-2019");
//        timePeriodValues1.setDescription("Value");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int11 = day9.compareTo((java.lang.Object) 100);
//        java.lang.String str12 = day9.toString();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day9, (double) 7);
//        java.lang.String str15 = timePeriodValues1.getDomainDescription();
//        try {
//            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues1.getTimePeriod(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        long long8 = year4.getSerialIndex();
        long long9 = year4.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        int int13 = timePeriodValues11.getMaxEndIndex();
        int int14 = timePeriodValues11.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener15);
        boolean boolean17 = year4.equals((java.lang.Object) seriesChangeListener15);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        boolean boolean4 = day0.equals((java.lang.Object) 10L);
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = day0.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate6);
//        int int9 = day8.getDayOfMonth();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day8.getFirstMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 13 + "'", int9 == 13);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) (short) 100);
        boolean boolean15 = timePeriodValue13.equals((java.lang.Object) 28799999L);
        java.lang.Number number16 = timePeriodValue13.getValue();
        java.lang.Number number17 = timePeriodValue13.getValue();
        timePeriodValues1.add(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 100.0d + "'", number16.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str31 = timePeriodFormatException30.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException28.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date37 = simpleTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date44 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.util.Date date47 = year45.getStart();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date47, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date26, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date19, timeZone49);
        boolean boolean53 = simpleTimePeriod2.equals((java.lang.Object) day52);
        java.util.Date date54 = simpleTimePeriod2.getStart();
        long long55 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date59 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException61 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str64 = timePeriodFormatException63.toString();
        timePeriodFormatException61.addSuppressed((java.lang.Throwable) timePeriodFormatException63);
        java.lang.Class<?> wildcardClass66 = timePeriodFormatException61.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date70 = simpleTimePeriod69.getEnd();
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date70);
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date70, timeZone72);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date77 = simpleTimePeriod76.getEnd();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year78.next();
        java.util.Date date80 = year78.getStart();
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date80);
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date80, timeZone82);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date59, timeZone82);
        int int85 = simpleTimePeriod2.compareTo((java.lang.Object) day84);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str64.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean3 = timePeriodValues1.isEmpty();
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        long long8 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 32L);
        java.util.Calendar calendar12 = null;
        try {
            year4.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        long long2 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.lang.Object obj5 = null;
        boolean boolean6 = simpleTimePeriod2.equals(obj5);
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str31 = timePeriodFormatException30.toString();
        timePeriodFormatException28.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException28.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date37 = simpleTimePeriod36.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date44 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        java.util.Date date47 = year45.getStart();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date47, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date26, timeZone49);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date19, timeZone49);
        boolean boolean53 = simpleTimePeriod2.equals((java.lang.Object) day52);
        java.util.Calendar calendar54 = null;
        try {
            long long55 = day52.getFirstMillisecond(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues6.addChangeListener(seriesChangeListener7);
//        int int9 = timePeriodValues6.getMinStartIndex();
//        java.lang.Comparable comparable10 = timePeriodValues6.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        timePeriodValues6.setKey((java.lang.Comparable) simpleTimePeriod16);
//        boolean boolean19 = timePeriodValues6.isEmpty();
//        int int20 = timePeriodValues6.getMinMiddleIndex();
//        int int21 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        int int22 = timePeriodValues6.getItemCount();
//        java.lang.Class<?> wildcardClass23 = timePeriodValues6.getClass();
//        try {
//            java.lang.Number number25 = timePeriodValues6.getValue(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 100 + "'", comparable10.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, 2019);
        int int4 = day3.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 8);
        long long7 = day3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1554620400000L + "'", long7 == 1554620400000L);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getMiddleMillisecond();
//        java.lang.String str4 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = year4.equals(obj8);
        long long10 = year4.getMiddleMillisecond();
        java.util.Date date11 = year4.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-15739200001L) + "'", long10 == (-15739200001L));
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 1.0d);
        java.lang.String str6 = timePeriodValue5.toString();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        java.lang.String str10 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year4.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        boolean boolean5 = timePeriodValues4.getNotify();
        java.lang.Comparable comparable6 = timePeriodValues4.getKey();
        timePeriodValues4.fireSeriesChanged();
        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 100 + "'", comparable6.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        int int5 = day4.getMonth();
        long long6 = day4.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day4.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("13-June-2019");
        boolean boolean8 = timePeriodValues1.equals((java.lang.Object) 4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        boolean boolean15 = year13.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long16 = year13.getLastMillisecond();
        java.lang.Object obj17 = null;
        boolean boolean18 = year13.equals(obj17);
        java.lang.Number number19 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, number19);
        java.lang.String str21 = year13.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener24);
        java.lang.Object obj26 = timePeriodValues23.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues23);
        int int28 = timePeriodValues23.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener29);
        int int31 = year13.compareTo((java.lang.Object) seriesChangeListener29);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year13, (double) 9);
        boolean boolean34 = timePeriodValues1.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod36 = timePeriodValues1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969" + "'", str21.equals("1969"));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException3.toString();
        java.lang.String str7 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str21 = timePeriodFormatException11.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException11.getSuppressed();
        java.lang.String str24 = timePeriodFormatException11.toString();
        java.lang.String str25 = timePeriodFormatException11.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getFirstMillisecond();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        java.util.Date date10 = year4.getStart();
        java.util.Calendar calendar11 = null;
        try {
            year4.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        boolean boolean14 = timePeriodValues1.isEmpty();
        int int15 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDescription("1969");
        boolean boolean18 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 1969L);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        int int5 = day4.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int5, "1969", "");
        boolean boolean9 = timePeriodValues8.getNotify();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.Object obj7 = seriesChangeEvent5.getSource();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date10, date15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date20 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str25 = timePeriodFormatException24.toString();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException22.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date38 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date41, timeZone43);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date20, timeZone43);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date15, timeZone43);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date3, timeZone43);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.lang.Object obj7 = null;
        int int8 = year4.compareTo(obj7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        timePeriodValues1.setNotify(true);
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) 4);
        int int12 = timePeriodValues1.getItemCount();
        timePeriodValues1.setRangeDescription("TimePeriodValue[1969,7]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        int int17 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        boolean boolean24 = year22.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long25 = year22.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 7);
        boolean boolean29 = timePeriodValue27.equals((java.lang.Object) (byte) 10);
        timePeriodValue27.setValue((java.lang.Number) 6);
        timePeriodValue27.setValue((java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue27.getPeriod();
        timePeriodValues1.add(timePeriodValue27);
        timePeriodValue27.setValue((java.lang.Number) 10.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31507200000L) + "'", long25 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timePeriod34);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        int int14 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, 2019);
        int int4 = day3.getMonth();
        java.lang.String str5 = day3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7-April-2019" + "'", str5.equals("7-April-2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date8 = simpleTimePeriod7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date34, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date13, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date8, timeZone36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date3, timeZone36);
        long long41 = year40.getFirstMillisecond();
        long long42 = year40.getFirstMillisecond();
        java.util.Calendar calendar43 = null;
        try {
            long long44 = year40.getMiddleMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-31507200000L) + "'", long41 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-31507200000L) + "'", long42 == (-31507200000L));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        java.lang.String str10 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date8 = simpleTimePeriod7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date34, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date13, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date8, timeZone36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date3, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year40.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod41, "", "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=1969]");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        boolean boolean14 = timePeriodValues1.isEmpty();
        int int15 = timePeriodValues1.getMinMiddleIndex();
        int int16 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        boolean boolean14 = timePeriodValues1.isEmpty();
        int int15 = timePeriodValues1.getMinMiddleIndex();
        int int16 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("7-April-2019");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1969]");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) seriesException18);
        java.lang.String str20 = seriesException18.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str20.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=1969]"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, 2019);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        long long5 = day0.getMiddleMillisecond();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) ' ');
//        timePeriodValue8.setValue((java.lang.Number) (-1L));
//        java.lang.String str11 = timePeriodValue8.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[13-June-2019,-1]" + "'", str11.equals("TimePeriodValue[13-June-2019,-1]"));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues16.addChangeListener(seriesChangeListener17);
        java.lang.Object obj19 = timePeriodValues16.clone();
        timePeriodValues16.delete((int) 'a', 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        boolean boolean29 = year27.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long30 = year27.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 7);
        boolean boolean34 = timePeriodValue32.equals((java.lang.Object) (byte) 10);
        timePeriodValue32.setValue((java.lang.Number) 6);
        timePeriodValue32.setValue((java.lang.Number) 100.0d);
        timePeriodValues16.add(timePeriodValue32);
        boolean boolean40 = simpleTimePeriod11.equals((java.lang.Object) timePeriodValues16);
        long long41 = simpleTimePeriod11.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        long long45 = simpleTimePeriod44.getStartMillis();
        boolean boolean46 = simpleTimePeriod11.equals((java.lang.Object) simpleTimePeriod44);
        java.util.Date date47 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        java.util.Date date49 = year48.getEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-31507200000L) + "'", long30 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 32L + "'", long41 == 32L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException5.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date24, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date3, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date3);
        long long30 = day29.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28799999L + "'", long30 == 28799999L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("13-June-2019");
        boolean boolean8 = timePeriodValues1.equals((java.lang.Object) 4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int8 = timePeriodValues7.getMinEndIndex();
        boolean boolean9 = year4.equals((java.lang.Object) timePeriodValues7);
        java.lang.String str10 = timePeriodValues7.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        boolean boolean17 = year15.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 7);
        java.lang.Number number21 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year15, number21);
        java.lang.String str23 = timePeriodValues7.getRangeDescription();
        timePeriodValues7.setNotify(false);
        java.lang.String str26 = timePeriodValues7.getDescription();
        java.lang.String str27 = timePeriodValues7.getDescription();
        java.lang.Comparable comparable28 = timePeriodValues7.getKey();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (short) 100 + "'", comparable28.equals((short) 100));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.previous();
        long long14 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year11, (double) 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28799999L + "'", long14 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 6);
//        long long6 = day0.getLastMillisecond();
//        java.util.Date date7 = day0.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date11 = simpleTimePeriod10.getEnd();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues16.addChangeListener(seriesChangeListener17);
//        java.lang.Object obj19 = timePeriodValues16.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues16);
//        java.lang.Object obj21 = seriesChangeEvent20.getSource();
//        int int22 = year12.compareTo((java.lang.Object) seriesChangeEvent20);
//        boolean boolean23 = day0.equals((java.lang.Object) year12);
//        long long24 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-31507200000L));
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year4.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str9 = timePeriodFormatException8.toString();
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException6.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str27 = timePeriodFormatException26.toString();
//        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
//        java.lang.Class<?> wildcardClass29 = timePeriodFormatException24.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date33 = simpleTimePeriod32.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date33, timeZone35);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date40 = simpleTimePeriod39.getEnd();
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.next();
//        java.util.Date date43 = year41.getStart();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date43, timeZone45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date22, timeZone45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date15, timeZone45);
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date4, timeZone45);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) ' ', 5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 100 + "'", comparable6.equals((short) 100));
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        boolean boolean11 = timePeriodValue9.equals((java.lang.Object) (byte) 10);
        java.lang.String str12 = timePeriodValue9.toString();
        java.lang.Number number13 = timePeriodValue9.getValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[1969,7]" + "'", str12.equals("TimePeriodValue[1969,7]"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 7 + "'", number13.equals(7));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        long long7 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int8 = timePeriodValues7.getMinEndIndex();
        boolean boolean9 = year4.equals((java.lang.Object) timePeriodValues7);
        java.lang.String str10 = timePeriodValues7.getRangeDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year15);
        boolean boolean19 = timePeriodValues7.equals((java.lang.Object) seriesChangeEvent18);
        java.lang.String str20 = seriesChangeEvent18.toString();
        java.lang.String str21 = seriesChangeEvent18.toString();
        java.lang.Object obj22 = seriesChangeEvent18.getSource();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=1969]"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str21.equals("org.jfree.data.general.SeriesChangeEvent[source=1969]"));
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesChangeEvent[source=1969]");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Class<?> wildcardClass10 = timePeriodFormatException5.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date14, timeZone16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year22.next();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date24, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date3, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date3);
        java.util.Date date30 = day29.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-15739200001L));
        java.lang.Object obj11 = timePeriodValue10.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        long long8 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.next();
        int int10 = year4.getYear();
        long long11 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-31507200000L));
        long long12 = year4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        boolean boolean14 = year12.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 7);
        boolean boolean19 = timePeriodValue17.equals((java.lang.Object) (byte) 10);
        timePeriodValue17.setValue((java.lang.Number) 6);
        timePeriodValue17.setValue((java.lang.Number) 100.0d);
        timePeriodValues1.add(timePeriodValue17);
        timePeriodValues1.setDescription("TimePeriodValue[13-June-2019,2.8799999E7]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date9 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date9);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date3, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str4 = timePeriodFormatException3.toString();
//        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
//        java.lang.Class<?> wildcardClass6 = timePeriodFormatException1.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date10 = simpleTimePeriod9.getEnd();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone12);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        java.util.Date date20 = year18.getStart();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date20, timeZone22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date28 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        long long32 = simpleTimePeriod31.getEndMillis();
//        long long33 = simpleTimePeriod31.getEndMillis();
//        java.util.Date date34 = simpleTimePeriod31.getEnd();
//        java.util.Date date35 = simpleTimePeriod31.getEnd();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        int int39 = day37.compareTo((java.lang.Object) 5);
//        java.lang.String str40 = day37.toString();
//        long long41 = day37.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException45 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str46 = timePeriodFormatException45.toString();
//        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException45);
//        java.lang.Class<?> wildcardClass48 = timePeriodFormatException43.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date52 = simpleTimePeriod51.getEnd();
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone54);
//        boolean boolean56 = day37.equals((java.lang.Object) wildcardClass48);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date61 = simpleTimePeriod60.getEnd();
//        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date61);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent63 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date61);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date67 = simpleTimePeriod66.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException69 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException71 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str72 = timePeriodFormatException71.toString();
//        timePeriodFormatException69.addSuppressed((java.lang.Throwable) timePeriodFormatException71);
//        java.lang.Class<?> wildcardClass74 = timePeriodFormatException69.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date78 = simpleTimePeriod77.getEnd();
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date78);
//        java.util.TimeZone timeZone80 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date78, timeZone80);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date85 = simpleTimePeriod84.getEnd();
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = year86.next();
//        java.util.Date date88 = year86.getStart();
//        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date88);
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date88, timeZone90);
//        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date67, timeZone90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date61, timeZone90);
//        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date35, timeZone90);
//        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date28, timeZone90);
//        java.util.TimeZone timeZone96 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date28, timeZone96);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 32L + "'", long32 == 32L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 32L + "'", long33 == 32L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str46.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str72.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(date85);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNull(regularTimePeriod91);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNull(regularTimePeriod97);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        boolean boolean14 = timePeriodValues1.isEmpty();
        int int15 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (short) 100);
        java.lang.Number number7 = timePeriodValue6.getValue();
        java.lang.String str8 = timePeriodValue6.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone21);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        boolean boolean24 = timePeriodValue6.equals((java.lang.Object) wildcardClass15);
        java.lang.Object obj25 = timePeriodValue6.clone();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0d + "'", number7.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[1969,100.0]" + "'", str8.equals("TimePeriodValue[1969,100.0]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[1969,100.0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[1969,100.0]");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException17.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str24 = timePeriodFormatException23.toString();
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str30 = timePeriodFormatException29.toString();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException23.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("7-April-2019");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1969]");
        timePeriodFormatException35.addSuppressed((java.lang.Throwable) seriesException38);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year4.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        java.util.Calendar calendar6 = null;
//        try {
//            year5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod9);
        timePeriodValues11.setDomainDescription("Time");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 1L);
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDescription("13-June-2019");
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int11 = day9.compareTo((java.lang.Object) 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        java.lang.String str17 = year16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        int int19 = day9.compareTo((java.lang.Object) regularTimePeriod18);
        timePeriodValues1.setKey((java.lang.Comparable) int19);
        int int21 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 100 + "'", comparable4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969" + "'", str17.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str15 = timePeriodFormatException12.toString();
        java.lang.String str16 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        int int31 = year4.compareTo((java.lang.Object) timePeriodFormatException12);
        java.lang.String str32 = timePeriodFormatException12.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
//        timePeriodValues2.addChangeListener(seriesChangeListener3);
//        int int5 = timePeriodValues2.getMinStartIndex();
//        java.lang.Comparable comparable6 = timePeriodValues2.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues2.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date13 = simpleTimePeriod12.getEnd();
//        timePeriodValues2.setKey((java.lang.Comparable) simpleTimePeriod12);
//        java.util.Date date15 = simpleTimePeriod12.getEnd();
//        java.util.TimeZone timeZone16 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date22 = simpleTimePeriod21.getEnd();
//        long long23 = simpleTimePeriod21.getEndMillis();
//        java.lang.Object obj24 = null;
//        boolean boolean25 = simpleTimePeriod21.equals(obj24);
//        java.util.Date date26 = simpleTimePeriod21.getStart();
//        boolean boolean28 = simpleTimePeriod21.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date29 = simpleTimePeriod21.getStart();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        int int32 = day30.compareTo((java.lang.Object) 100);
//        java.lang.String str33 = day30.toString();
//        int int34 = day30.getMonth();
//        java.lang.Class<?> wildcardClass35 = day30.getClass();
//        java.util.Date date36 = day30.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date29, date36);
//        boolean boolean38 = day18.equals((java.lang.Object) date29);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 100 + "'", comparable6.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 100L + "'", long23 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = simpleTimePeriod2.equals(obj5);
//        java.util.Date date7 = simpleTimePeriod2.getStart();
//        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date10 = simpleTimePeriod2.getStart();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int13 = day11.compareTo((java.lang.Object) 100);
//        java.lang.String str14 = day11.toString();
//        int int15 = day11.getMonth();
//        java.lang.Class<?> wildcardClass16 = day11.getClass();
//        java.util.Date date17 = day11.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date10, date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date23 = simpleTimePeriod22.getStart();
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date28 = simpleTimePeriod27.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str33 = timePeriodFormatException32.toString();
//        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        java.lang.Class<?> wildcardClass35 = timePeriodFormatException30.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date39 = simpleTimePeriod38.getEnd();
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone41);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date46 = simpleTimePeriod45.getEnd();
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year47.next();
//        java.util.Date date49 = year47.getStart();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date49, timeZone51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date28, timeZone51);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date23, timeZone51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date17, timeZone51);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getFirstMillisecond();
        java.lang.Class<?> wildcardClass9 = year4.getClass();
        java.util.Date date10 = year4.getStart();
        long long11 = year4.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-31507200000L) + "'", long8 == (-31507200000L));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        timePeriodValues1.setRangeDescription("TimePeriodValue[1969,-1.5739200001E10]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) (short) 100);
        java.lang.Number number21 = timePeriodValue20.getValue();
        java.lang.Object obj22 = timePeriodValue20.clone();
        java.lang.Object obj23 = timePeriodValue20.clone();
        timePeriodValues1.add(timePeriodValue20);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 100.0d + "'", number21.equals(100.0d));
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        java.lang.Object obj11 = null;
        int int12 = year10.compareTo(obj11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year10.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        int int14 = timePeriodValues1.getMinEndIndex();
        java.lang.Comparable comparable15 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        timePeriodValues1.setKey((java.lang.Comparable) 0L);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue21 = timePeriodValues1.getDataItem((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(comparable15);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        java.lang.String str9 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year4.previous();
        long long11 = year4.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year4.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        timePeriodValues1.setNotify(true);
        boolean boolean7 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        timePeriodValues1.setDescription("13-June-2019");
        timePeriodValues1.delete(1, (-1));
        timePeriodValues1.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + (short) 100 + "'", comparable4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        boolean boolean14 = year12.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 7);
        boolean boolean19 = timePeriodValue17.equals((java.lang.Object) (byte) 10);
        timePeriodValue17.setValue((java.lang.Number) 6);
        timePeriodValue17.setValue((java.lang.Number) 100.0d);
        timePeriodValues1.add(timePeriodValue17);
        java.lang.Comparable comparable25 = timePeriodValues1.getKey();
        int int26 = timePeriodValues1.getMinMiddleIndex();
        boolean boolean27 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        boolean boolean37 = day32.equals((java.lang.Object) ' ');
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day32, (java.lang.Number) 100);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (short) 100 + "'", comparable25.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) (-15739200001L));
        java.lang.String str11 = timePeriodValue10.toString();
        java.lang.Number number12 = timePeriodValue10.getValue();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener15);
        java.lang.Object obj17 = timePeriodValues14.clone();
        timePeriodValues14.delete((int) 'a', 5);
        timePeriodValues14.setNotify(true);
        boolean boolean24 = timePeriodValues14.equals((java.lang.Object) 4);
        int int25 = timePeriodValues14.getItemCount();
        timePeriodValues14.setDomainDescription("TimePeriodValue[1969,100.0]");
        boolean boolean28 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[1969,-1.5739200001E10]" + "'", str11.equals("TimePeriodValue[1969,-1.5739200001E10]"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.5739200001E10d) + "'", number12.equals((-1.5739200001E10d)));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        java.lang.String str5 = year4.toString();
        long long6 = year4.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-15739200001L) + "'", long6 == (-15739200001L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException1.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        boolean boolean2 = timePeriodValues1.getNotify();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int5 = day3.compareTo((java.lang.Object) 100);
//        java.lang.String str6 = day3.toString();
//        timePeriodValues1.setKey((java.lang.Comparable) day3);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues1.removeChangeListener(seriesChangeListener8);
//        int int10 = timePeriodValues1.getMaxMiddleIndex();
//        java.lang.String str11 = timePeriodValues1.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        int int10 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDescription("Value");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 100 + "'", comparable9.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues6.addChangeListener(seriesChangeListener7);
//        int int9 = timePeriodValues6.getMinStartIndex();
//        java.lang.Comparable comparable10 = timePeriodValues6.getKey();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues6.createCopy((int) (short) 100, (int) (byte) 0);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date17 = simpleTimePeriod16.getEnd();
//        timePeriodValues6.setKey((java.lang.Comparable) simpleTimePeriod16);
//        boolean boolean19 = timePeriodValues6.isEmpty();
//        int int20 = timePeriodValues6.getMinMiddleIndex();
//        int int21 = day0.compareTo((java.lang.Object) timePeriodValues6);
//        int int22 = timePeriodValues6.getItemCount();
//        timePeriodValues6.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (short) 100 + "'", comparable10.equals((short) 100));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        timePeriodValues1.fireSeriesChanged();
//        int int3 = timePeriodValues1.getItemCount();
//        java.lang.String str4 = timePeriodValues1.getDescription();
//        int int5 = timePeriodValues1.getMinStartIndex();
//        int int6 = timePeriodValues1.getMinEndIndex();
//        int int7 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int10 = day8.compareTo((java.lang.Object) 100);
//        java.lang.String str11 = day8.toString();
//        int int12 = day8.getMonth();
//        java.lang.Class<?> wildcardClass13 = day8.getClass();
//        java.util.Date date14 = day8.getEnd();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day8, 1.0d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int2 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 100.0d);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.Object obj6 = seriesChangeEvent4.getSource();
        java.lang.String str7 = seriesChangeEvent4.toString();
        java.lang.String str8 = seriesChangeEvent4.toString();
        java.lang.Object obj9 = seriesChangeEvent4.getSource();
        boolean boolean10 = timePeriodValues1.equals((java.lang.Object) seriesChangeEvent4);
        java.lang.String str11 = seriesChangeEvent4.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100.0]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=100.0]"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 100.0d + "'", obj6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100.0]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=100.0]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100.0]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=100.0]"));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + 100.0d + "'", obj9.equals(100.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100.0]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=100.0]"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        timePeriodValues1.setRangeDescription("Value");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate2, "org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]", "TimePeriodValue[1969,-1.5739200001E10]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        java.lang.String str8 = timePeriodValue7.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[13-June-2019,0.0]" + "'", str8.equals("TimePeriodValue[13-June-2019,0.0]"));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        boolean boolean8 = year4.equals((java.lang.Object) (byte) 0);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMinMiddleIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        try {
            timePeriodValues1.update((int) (byte) 1, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        java.util.Date date0 = null;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
//        java.util.Date date4 = simpleTimePeriod3.getEnd();
//        long long5 = simpleTimePeriod3.getEndMillis();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = simpleTimePeriod3.equals(obj6);
//        java.util.Date date8 = simpleTimePeriod3.getStart();
//        boolean boolean10 = simpleTimePeriod3.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
//        java.util.Date date11 = simpleTimePeriod3.getStart();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int14 = day12.compareTo((java.lang.Object) 100);
//        java.lang.String str15 = day12.toString();
//        int int16 = day12.getMonth();
//        java.lang.Class<?> wildcardClass17 = day12.getClass();
//        java.util.Date date18 = day12.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date11, date18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date0, date18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues1.createCopy((int) (short) 100, (int) (byte) 0);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date12 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        boolean boolean14 = timePeriodValues1.isEmpty();
        int int15 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (short) 100 + "'", comparable5.equals((short) 100));
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, 100L);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException6.getSuppressed();
        try {
            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodFormatException6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodFormatException cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        timePeriodValues1.setDomainDescription("TimePeriodValue[1969,100.0]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        boolean boolean13 = year11.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long14 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year11.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) 10L);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod15, (java.lang.Number) (-15739200001L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28799999L + "'", long14 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=100.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 3, (long) 31);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener2);
//        int int4 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setNotify(true);
//        timePeriodValues1.setDescription("13-June-2019");
//        int int9 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        int int12 = day10.compareTo((java.lang.Object) 5);
//        java.lang.String str13 = day10.toString();
//        long long14 = day10.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str19 = timePeriodFormatException18.toString();
//        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.Class<?> wildcardClass21 = timePeriodFormatException16.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date25 = simpleTimePeriod24.getEnd();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone27);
//        boolean boolean29 = day10.equals((java.lang.Object) wildcardClass21);
//        int int31 = day10.compareTo((java.lang.Object) (-15739200001L));
//        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (-15739200001L));
//        java.lang.Number number34 = timePeriodValue33.getValue();
//        timePeriodValues1.add(timePeriodValue33);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        int int37 = day36.getYear();
//        org.jfree.data.time.SerialDate serialDate38 = day36.getSerialDate();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate38);
//        long long41 = day40.getSerialIndex();
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day40, (java.lang.Number) 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-15739200001L) + "'", number34.equals((-15739200001L)));
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43629L + "'", long41 == 43629L);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[7-April-2019,8]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        int int5 = day4.getMonth();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, number6);
        java.lang.Number number8 = timePeriodValue7.getValue();
        java.lang.Number number9 = timePeriodValue7.getValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(number9);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        java.util.Date date4 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, 0.0d);
//        java.lang.Object obj8 = timePeriodValue7.clone();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(obj8);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.lang.Comparable comparable3 = timePeriodValues1.getKey();
        timePeriodValues1.fireSeriesChanged();
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (short) 100 + "'", comparable3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = year4.equals(obj8);
        long long10 = year4.getMiddleMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        boolean boolean17 = year15.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long18 = year15.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (java.lang.Number) 7);
        int int21 = year15.getYear();
        int int22 = year4.compareTo((java.lang.Object) int21);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-15739200001L) + "'", long10 == (-15739200001L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 6);
//        long long6 = day0.getLastMillisecond();
//        java.util.Date date7 = day0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        int int9 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560495599999L + "'", long6 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        long long11 = simpleTimePeriod10.getStartMillis();
        long long12 = simpleTimePeriod10.getEndMillis();
        java.lang.Object obj13 = null;
        boolean boolean14 = simpleTimePeriod10.equals(obj13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date18 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        boolean boolean21 = year19.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long22 = year19.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year19, (java.lang.Number) 7);
        boolean boolean26 = timePeriodValue24.equals((java.lang.Object) (byte) 10);
        org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValue24.getPeriod();
        int int28 = simpleTimePeriod10.compareTo((java.lang.Object) timePeriod27);
        timePeriodValues1.add(timePeriod27, (java.lang.Number) 3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-31507200000L) + "'", long22 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        boolean boolean2 = timePeriodValues1.getNotify();
        java.lang.Comparable comparable3 = timePeriodValues1.getKey();
        timePeriodValues1.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + (short) 100 + "'", comparable3.equals((short) 100));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues4.addChangeListener(seriesChangeListener5);
        java.lang.Object obj7 = timePeriodValues4.clone();
        int int8 = day0.compareTo(obj7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("13-June-2019");
        boolean boolean8 = timePeriodValues1.equals((java.lang.Object) 4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        try {
            timePeriodValues1.update((int) '#', (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 6);
//        long long6 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("13-June-2019");
        boolean boolean8 = timePeriodValues1.equals((java.lang.Object) 4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues1.getItemCount();
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener16);
        java.lang.Object obj18 = timePeriodValues15.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues15);
        int int20 = timePeriodValues15.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str25 = timePeriodFormatException24.toString();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Class<?> wildcardClass27 = timePeriodFormatException22.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class28);
        boolean boolean30 = timePeriodValues15.equals((java.lang.Object) class28);
        boolean boolean31 = timePeriodValues1.equals((java.lang.Object) timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDomainDescription("hi!");
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        int int10 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date14 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        java.lang.String str16 = year15.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year15);
        java.lang.String str19 = seriesChangeEvent18.toString();
        boolean boolean20 = timePeriodValues1.equals((java.lang.Object) seriesChangeEvent18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (short) 100 + "'", comparable9.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1969]" + "'", str19.equals("org.jfree.data.general.SeriesChangeEvent[source=1969]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 5);
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str9 = timePeriodFormatException8.toString();
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Class<?> wildcardClass11 = timePeriodFormatException6.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date15 = simpleTimePeriod14.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone17);
//        boolean boolean19 = day0.equals((java.lang.Object) wildcardClass11);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date24 = simpleTimePeriod23.getEnd();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date24);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date30 = simpleTimePeriod29.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str35 = timePeriodFormatException34.toString();
//        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
//        java.lang.Class<?> wildcardClass37 = timePeriodFormatException32.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date41 = simpleTimePeriod40.getEnd();
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date41, timeZone43);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date48 = simpleTimePeriod47.getEnd();
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year49.next();
//        java.util.Date date51 = year49.getStart();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date51, timeZone53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date30, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date24, timeZone53);
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(class57);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        timePeriodValues1.delete(13, 2);
        timePeriodValues1.setDomainDescription("TimePeriodValue[1969,7]");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getLastMillisecond();
        java.lang.Object obj8 = null;
        boolean boolean9 = year4.equals(obj8);
        java.lang.Number number10 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, number10);
        java.lang.Object obj12 = null;
        boolean boolean13 = year4.equals(obj12);
        int int14 = year4.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Value");
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 6);
//        long long6 = day0.getFirstMillisecond();
//        java.util.Date date7 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        long long9 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560452399999L + "'", long9 == 1560452399999L);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        timePeriodValues1.fireSeriesChanged();
        int int3 = timePeriodValues1.getItemCount();
        java.lang.String str4 = timePeriodValues1.getDescription();
        int int5 = timePeriodValues1.getMinStartIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, 1969);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: TimePeriodValue[1969,100.0]");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int8 = timePeriodValues7.getMinEndIndex();
        boolean boolean9 = year4.equals((java.lang.Object) timePeriodValues7);
        timePeriodValues7.setDescription("");
        int int12 = timePeriodValues7.getMaxMiddleIndex();
        java.lang.String str13 = timePeriodValues7.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        timePeriodValues1.delete((int) 'a', 5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date11 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        boolean boolean14 = year12.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long15 = year12.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 7);
        boolean boolean19 = timePeriodValue17.equals((java.lang.Object) (byte) 10);
        timePeriodValue17.setValue((java.lang.Number) 6);
        timePeriodValue17.setValue((java.lang.Number) 100.0d);
        timePeriodValues1.add(timePeriodValue17);
        java.lang.Object obj25 = timePeriodValue17.clone();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date3 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
//        java.util.Date date6 = year4.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues8.addChangeListener(seriesChangeListener9);
//        java.lang.Object obj11 = timePeriodValues8.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues8);
//        java.lang.Object obj13 = seriesChangeEvent12.getSource();
//        int int14 = year4.compareTo((java.lang.Object) seriesChangeEvent12);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int17 = day15.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (double) 6);
//        long long21 = day15.getLastMillisecond();
//        java.util.Date date22 = day15.getStart();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date26 = simpleTimePeriod25.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        java.util.Date date29 = year27.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timePeriodValues31.addChangeListener(seriesChangeListener32);
//        java.lang.Object obj34 = timePeriodValues31.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues31);
//        java.lang.Object obj36 = seriesChangeEvent35.getSource();
//        int int37 = year27.compareTo((java.lang.Object) seriesChangeEvent35);
//        boolean boolean38 = day15.equals((java.lang.Object) year27);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        int int41 = day39.compareTo((java.lang.Object) 100);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
//        java.util.Date date45 = simpleTimePeriod44.getEnd();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        boolean boolean48 = year46.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
//        long long49 = year46.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) 7);
//        int int52 = day39.compareTo((java.lang.Object) year46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int52);
//        int int54 = year27.compareTo((java.lang.Object) int52);
//        boolean boolean55 = year4.equals((java.lang.Object) int52);
//        long long56 = year4.getSerialIndex();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560495599999L + "'", long21 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-31507200000L) + "'", long49 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1969L + "'", long56 == 1969L);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int2 = day0.compareTo((java.lang.Object) 100);
//        long long3 = day0.getLastMillisecond();
//        long long4 = day0.getSerialIndex();
//        long long5 = day0.getMiddleMillisecond();
//        long long6 = day0.getSerialIndex();
//        long long7 = day0.getFirstMillisecond();
//        java.lang.String str8 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560452399999L + "'", long5 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560409200000L + "'", long7 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Class<?> wildcardClass13 = timePeriodFormatException8.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        boolean boolean16 = timePeriodValues1.equals((java.lang.Object) class14);
        int int17 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date21 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        boolean boolean24 = year22.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long25 = year22.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (java.lang.Number) 7);
        boolean boolean29 = timePeriodValue27.equals((java.lang.Object) (byte) 10);
        timePeriodValue27.setValue((java.lang.Number) 6);
        timePeriodValue27.setValue((java.lang.Number) (byte) 0);
        org.jfree.data.time.TimePeriod timePeriod34 = timePeriodValue27.getPeriod();
        timePeriodValues1.add(timePeriodValue27);
        int int36 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31507200000L) + "'", long25 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timePeriod34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        int int8 = timePeriodValues7.getMinEndIndex();
        boolean boolean9 = year4.equals((java.lang.Object) timePeriodValues7);
        timePeriodValues7.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date8 = simpleTimePeriod7.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date13 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date24 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date31 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        java.util.Date date34 = year32.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date34, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date13, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date8, timeZone36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date3, timeZone36);
        long long41 = year40.getFirstMillisecond();
        java.util.Calendar calendar42 = null;
        try {
            long long43 = year40.getLastMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-31507200000L) + "'", long41 == (-31507200000L));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time");
        int int2 = timePeriodValues1.getMinStartIndex();
        try {
            timePeriodValues1.update(10, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int2 = day0.compareTo((java.lang.Object) 5);
        boolean boolean4 = day0.equals((java.lang.Object) 10L);
        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 10);
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        java.lang.String str3 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(0L, 100L);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        long long9 = simpleTimePeriod7.getEndMillis();
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod7.equals(obj10);
        java.util.Date date12 = simpleTimePeriod7.getEnd();
        int int13 = simpleTimePeriod2.compareTo((java.lang.Object) simpleTimePeriod7);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues15.getMinStartIndex();
        timePeriodValues15.setDescription("13-June-2019");
        boolean boolean22 = timePeriodValues15.equals((java.lang.Object) 4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues15.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date28 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (double) (short) 100);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date35 = simpleTimePeriod34.getEnd();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        boolean boolean38 = year36.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long39 = year36.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year36.previous();
        boolean boolean41 = timePeriodValue31.equals((java.lang.Object) year36);
        java.util.Date date42 = year36.getEnd();
        timePeriodValues15.setKey((java.lang.Comparable) date42);
        try {
            int int44 = simpleTimePeriod7.compareTo((java.lang.Object) date42);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 28799999L + "'", long39 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date10 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date10, timeZone12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str22 = timePeriodFormatException21.toString();
        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Class<?> wildcardClass24 = timePeriodFormatException19.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date28 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date35 = simpleTimePeriod34.getEnd();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
        java.util.Date date38 = year36.getStart();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date38, timeZone40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date17, timeZone40);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date10, timeZone40);
        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
        java.lang.Class<?> wildcardClass45 = serialDate44.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        boolean boolean6 = year4.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: ");
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) 7);
        int int10 = year4.getYear();
        java.util.Date date11 = year4.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date15 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date20 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str30 = timePeriodFormatException29.toString();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.Class<?> wildcardClass32 = timePeriodFormatException27.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date36 = simpleTimePeriod35.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date43 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
        java.util.Date date46 = year44.getStart();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date46, timeZone48);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date25, timeZone48);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date20, timeZone48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date15, timeZone48);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date11, timeZone48);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str30.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date19 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) ' ');
        java.util.Date date26 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date29, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date8, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date3, timeZone31);
        org.jfree.data.time.SerialDate serialDate35 = day34.getSerialDate();
        long long36 = day34.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 25568L + "'", long36 == 25568L);
    }
}

