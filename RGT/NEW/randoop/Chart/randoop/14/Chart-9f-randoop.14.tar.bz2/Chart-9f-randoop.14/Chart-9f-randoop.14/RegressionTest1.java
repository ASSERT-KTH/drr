import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        int int5 = timeSeries1.getItemCount();
        boolean boolean6 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        long long13 = day12.getLastMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries1.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        int int7 = day2.getYear();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
        long long7 = fixedMillisecond4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        java.util.Date date65 = spreadsheetDate63.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        int int68 = spreadsheetDate67.getMonth();
        boolean boolean69 = spreadsheetDate63.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str72 = serialDate71.getDescription();
        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate67.getEndOfCurrentMonth(serialDate71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date76 = fixedMillisecond75.getStart();
        java.lang.Class<?> wildcardClass77 = fixedMillisecond75.getClass();
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate71, (java.lang.Class) wildcardClass77);
        boolean boolean79 = spreadsheetDate40.isOnOrBefore(serialDate71);
        try {
            org.jfree.data.time.SerialDate serialDate81 = serialDate71.getFollowingDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Class<?> wildcardClass7 = regularTimePeriod6.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.lang.String str2 = month0.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries15.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        long long21 = day20.getLastMillisecond();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day20);
        timeSeries15.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries6.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (-1.0d));
        int int32 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass37 = fixedMillisecond36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond27, "Last", "Last", (java.lang.Class) wildcardClass37);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208441600001L) + "'", long21 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        int int4 = timeSeries1.getItemCount();
        java.lang.String str5 = timeSeries1.getDescription();
        timeSeries1.setRangeDescription("October");
        timeSeries1.setMaximumItemCount(4);
        boolean boolean10 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        long long27 = day26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (double) 10);
        java.util.Calendar calendar30 = null;
        try {
            day26.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 7L + "'", long27 == 7L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-25566));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-25566) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        try {
            timeSeries1.setMaximumItemCount((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("December 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        timeSeries1.clear();
        timeSeries1.setMaximumItemAge((long) 9999);
        try {
            java.lang.Number number17 = timeSeries1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate30 = serialDate20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        serialDate30.setDescription("1969");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(2);
        java.lang.String str2 = serialDate1.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1-January-1900" + "'", str2.equals("1-January-1900"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        java.lang.String str8 = month4.toString();
        java.util.Calendar calendar9 = null;
        try {
            month4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int6 = spreadsheetDate5.getMonth();
//        java.util.Date date7 = spreadsheetDate5.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int10 = spreadsheetDate9.getMonth();
//        boolean boolean11 = spreadsheetDate5.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int14 = spreadsheetDate13.getMonth();
//        java.util.Date date15 = spreadsheetDate13.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int18 = spreadsheetDate17.getMonth();
//        boolean boolean19 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        boolean boolean20 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date23 = fixedMillisecond22.getStart();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day24.next();
//        boolean boolean26 = spreadsheetDate5.equals((java.lang.Object) regularTimePeriod25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate5);
//        boolean boolean28 = day0.equals((java.lang.Object) 3);
//        int int29 = day0.getDayOfMonth();
//        int int30 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month17.next();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries25.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
        long long31 = day30.getLastMillisecond();
        timeSeries25.delete((org.jfree.data.time.RegularTimePeriod) day30);
        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
        java.lang.String str34 = day30.toString();
        boolean boolean35 = month17.equals((java.lang.Object) day30);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2208441600001L) + "'", long31 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "6-January-1900" + "'", str34.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        java.util.Date date4 = day2.getStart();
        java.util.Calendar calendar5 = null;
        try {
            day2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Last");
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 0);
        boolean boolean3 = fixedMillisecond1.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = serialDate6.getEndOfCurrentMonth(serialDate19);
        boolean boolean21 = year3.equals((java.lang.Object) serialDate20);
        java.util.Date date22 = year3.getEnd();
        java.util.TimeZone timeZone23 = null;
        try {
            org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22, timeZone23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2, 0, (-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("1-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        java.util.Date date7 = regularTimePeriod6.getStart();
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod6);
        long long9 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getMiddleMillisecond(calendar10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, 12, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0d));
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        timeSeries1.setKey((java.lang.Comparable) "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        java.lang.Class class19 = timeSeries1.getTimePeriodClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize(class19);
        java.util.Date date21 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date24 = fixedMillisecond23.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass27 = fixedMillisecond26.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date35, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date32, timeZone37);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date24, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone37);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod41);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        int int3 = month0.compareTo((java.lang.Object) true);
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getMonth();
        java.util.Date date12 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean16 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int18 = spreadsheetDate10.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        boolean boolean16 = spreadsheetDate6.isOnOrBefore(serialDate11);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek((int) (byte) 1);
        int int22 = spreadsheetDate6.compare(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        java.util.Date date26 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.getMonth();
        boolean boolean30 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-6) + "'", int22 == (-6));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        long long28 = year27.getSerialIndex();
        long long29 = year27.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year27, (double) 25568L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar35 = null;
        fixedMillisecond34.peg(calendar35);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1969L + "'", long28 == 1969L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1969L + "'", long29 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        spreadsheetDate17.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.String str20 = seriesException19.toString();
        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond23.getClass();
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) false);
        boolean boolean27 = timeSeries10.equals((java.lang.Object) false);
        timeSeries10.setKey((java.lang.Comparable) 7L);
        boolean boolean30 = day2.equals((java.lang.Object) 7L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        java.lang.Class<?> wildcardClass34 = fixedMillisecond32.getClass();
        long long35 = fixedMillisecond32.getLastMillisecond();
        boolean boolean36 = day2.equals((java.lang.Object) fixedMillisecond32);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = day2.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        long long13 = day12.getLastMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            timeSeries7.setMaximumItemCount((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list8 = timeSeries7.getItems();
        boolean boolean9 = year3.equals((java.lang.Object) timeSeries7);
        long long10 = year3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        java.util.Date date65 = spreadsheetDate63.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        int int68 = spreadsheetDate67.getMonth();
        boolean boolean69 = spreadsheetDate63.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str72 = serialDate71.getDescription();
        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate67.getEndOfCurrentMonth(serialDate71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date76 = fixedMillisecond75.getStart();
        java.lang.Class<?> wildcardClass77 = fixedMillisecond75.getClass();
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate71, (java.lang.Class) wildcardClass77);
        boolean boolean79 = spreadsheetDate40.isOnOrBefore(serialDate71);
        int int80 = spreadsheetDate40.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(2);
        int int84 = spreadsheetDate83.getMonth();
        java.util.Date date85 = spreadsheetDate83.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate87 = new org.jfree.data.time.SpreadsheetDate(2);
        int int88 = spreadsheetDate87.getMonth();
        boolean boolean89 = spreadsheetDate83.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate87);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str92 = serialDate91.getDescription();
        org.jfree.data.time.SerialDate serialDate93 = spreadsheetDate87.getEndOfCurrentMonth(serialDate91);
        org.jfree.data.time.SerialDate serialDate94 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate87);
        boolean boolean95 = spreadsheetDate40.isOnOrAfter(serialDate94);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 2 + "'", int80 == 2);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNull(str92);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        try {
            timeSeries1.add(regularTimePeriod6, (java.lang.Number) 1.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        try {
            timeSeries2.delete((-572), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -572");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.lang.String str3 = fixedMillisecond1.toString();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.util.Date date0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        int int8 = month5.compareTo((java.lang.Object) "");
        int int9 = month5.getYearValue();
        org.jfree.data.time.Year year10 = month5.getYear();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        java.lang.Comparable comparable16 = timeSeries13.getKey();
        java.lang.String str17 = timeSeries13.getDomainDescription();
        int int18 = timeSeries13.getItemCount();
        boolean boolean19 = timeSeries13.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date22 = fixedMillisecond21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        long long24 = year23.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries26.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        long long32 = day31.getLastMillisecond();
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day31);
        int int34 = year23.compareTo((java.lang.Object) day31);
        timeSeries13.setKey((java.lang.Comparable) int34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) (-1.0d));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.lang.Class class43 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date46 = fixedMillisecond45.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date49 = fixedMillisecond48.getTime();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date49, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date46, timeZone51);
        int int54 = year10.compareTo((java.lang.Object) timeZone51);
        try {
            org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date0, timeZone51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + '4' + "'", comparable16.equals('4'));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2208441600001L) + "'", long32 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        timeSeries1.removeAgedItems((-1L), false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        try {
            org.jfree.data.time.SerialDate serialDate63 = spreadsheetDate40.getPreviousDayOfWeek((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date8 = fixedMillisecond7.getStart();
        java.lang.Class<?> wildcardClass9 = fixedMillisecond7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-459));
        long long13 = fixedMillisecond7.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) "7-January-1900");
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int17 = spreadsheetDate9.toSerial();
        int int18 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date8 = fixedMillisecond7.getStart();
        java.lang.Class<?> wildcardClass9 = fixedMillisecond7.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-459));
        java.lang.String str13 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        java.util.Date date65 = spreadsheetDate63.toDate();
        int int66 = spreadsheetDate63.getMonth();
        boolean boolean67 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
        int int68 = spreadsheetDate63.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 2 + "'", int68 == 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        java.lang.String str34 = timeSeries33.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries36.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        long long42 = day41.getLastMillisecond();
        timeSeries36.delete((org.jfree.data.time.RegularTimePeriod) day41);
        org.jfree.data.general.SeriesException seriesException45 = new org.jfree.data.general.SeriesException("");
        java.lang.String str46 = seriesException45.toString();
        boolean boolean47 = timeSeries36.equals((java.lang.Object) seriesException45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date50 = fixedMillisecond49.getStart();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date50);
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("");
        int int55 = month52.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) month52);
        try {
            timeSeries33.add((org.jfree.data.time.RegularTimePeriod) month52, (double) 9999, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Last" + "'", str34.equals("Last"));
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208441600001L) + "'", long42 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str46.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem56);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        long long14 = timeSeries13.getMaximumItemAge();
        timeSeries13.setKey((java.lang.Comparable) "June 2019");
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        java.lang.Comparable comparable11 = timeSeries8.getKey();
        java.lang.String str12 = timeSeries8.getDomainDescription();
        int int13 = timeSeries8.getItemCount();
        boolean boolean14 = timeSeries8.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries21.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        long long27 = day26.getLastMillisecond();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day26);
        int int29 = year18.compareTo((java.lang.Object) day26);
        timeSeries8.setKey((java.lang.Comparable) int29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1.0d));
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        long long40 = fixedMillisecond32.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + '4' + "'", comparable11.equals('4'));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208441600001L) + "'", long27 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15);
        java.lang.Number number19 = timeSeriesDataItem15.getValue();
        java.lang.Number number20 = timeSeriesDataItem15.getValue();
        java.lang.Number number21 = timeSeriesDataItem15.getValue();
        boolean boolean23 = timeSeriesDataItem15.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1 + "'", number19.equals(1));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1 + "'", number20.equals(1));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1 + "'", number21.equals(1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        boolean boolean16 = spreadsheetDate6.isOnOrBefore(serialDate11);
        java.util.Date date17 = spreadsheetDate6.toDate();
        try {
            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-572), (org.jfree.data.time.SerialDate) spreadsheetDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate17 = null;
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        org.jfree.data.time.SerialDate serialDate24 = serialDate21.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate21);
        java.lang.String str26 = serialDate25.getDescription();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(0, serialDate25);
        try {
            boolean boolean29 = spreadsheetDate1.isInRange(serialDate17, serialDate27, (-461));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        timeSeries1.removeAgedItems(false);
        int int24 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        int int39 = spreadsheetDate18.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = timeSeries9.isEmpty();
        java.lang.String str13 = timeSeries9.getDomainDescription();
        java.util.Collection collection14 = timeSeries9.getTimePeriods();
        java.lang.String str15 = timeSeries9.getDomainDescription();
        timeSeries9.removeAgedItems((-31507200000L), false);
        java.lang.Class class19 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, "hi!", "January", class19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date4);
        java.lang.String str22 = month21.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "January 1900" + "'", str22.equals("January 1900"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.previous();
        try {
            timeSeries20.add(regularTimePeriod33, (java.lang.Number) 1560191377402L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1969L + "'", long32 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-572), 2019, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191401813L + "'", long3 == 1560191401813L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond22.getMiddleMillisecond(calendar28);
        long long30 = fixedMillisecond22.getFirstMillisecond();
        long long31 = fixedMillisecond22.getFirstMillisecond();
        java.util.Calendar calendar32 = null;
        fixedMillisecond22.peg(calendar32);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        int int39 = spreadsheetDate18.getYYYY();
        int int40 = spreadsheetDate18.toSerial();
        int int41 = spreadsheetDate18.getMonth();
        int int42 = spreadsheetDate18.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = timeSeries29.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        java.lang.String str11 = day6.toString();
        long long12 = day6.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6-January-1900" + "'", str11.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 7L + "'", long12 == 7L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December 1969");
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod7, (java.lang.Number) 1);
        long long10 = regularTimePeriod7.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getMonth();
        java.util.Date date5 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getMonth();
        boolean boolean9 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate12);
        boolean boolean17 = spreadsheetDate7.isOnOrBefore(serialDate12);
        java.util.Date date18 = spreadsheetDate7.toDate();
        int int19 = spreadsheetDate7.getYYYY();
        int int20 = spreadsheetDate1.compareTo((java.lang.Object) spreadsheetDate7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate5.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        java.util.Date date24 = spreadsheetDate22.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        boolean boolean28 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        java.util.Date date32 = spreadsheetDate30.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(2);
        int int35 = spreadsheetDate34.getMonth();
        boolean boolean36 = spreadsheetDate30.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean37 = spreadsheetDate22.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        int int40 = spreadsheetDate39.getMonth();
        java.util.Date date41 = spreadsheetDate39.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2);
        int int44 = spreadsheetDate43.getMonth();
        boolean boolean45 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getMonth();
        java.util.Date date49 = spreadsheetDate47.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getMonth();
        boolean boolean53 = spreadsheetDate47.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean54 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        boolean boolean59 = spreadsheetDate30.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate39, serialDate56, (int) ' ');
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(serialDate61);
        org.jfree.data.time.SerialDate serialDate64 = serialDate61.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries66.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(serialDate70);
        long long72 = day71.getLastMillisecond();
        timeSeries66.delete((org.jfree.data.time.RegularTimePeriod) day71);
        org.jfree.data.time.SerialDate serialDate74 = day71.getSerialDate();
        org.jfree.data.time.SerialDate serialDate75 = serialDate61.getEndOfCurrentMonth(serialDate74);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(2);
        int int78 = spreadsheetDate77.getMonth();
        java.util.Date date79 = spreadsheetDate77.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(2);
        int int82 = spreadsheetDate81.getMonth();
        boolean boolean83 = spreadsheetDate77.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean85 = spreadsheetDate39.isInRange(serialDate75, (org.jfree.data.time.SerialDate) spreadsheetDate81, 2019);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(2);
        int int89 = spreadsheetDate88.getMonth();
        java.util.Date date90 = spreadsheetDate88.toDate();
        java.util.Date date91 = spreadsheetDate88.toDate();
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean93 = spreadsheetDate81.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean94 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate81);
        try {
            org.jfree.data.time.SerialDate serialDate96 = spreadsheetDate81.getPreviousDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-2208441600001L) + "'", long72 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        timeSeries1.delete(regularTimePeriod26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month28.previous();
        int int31 = month28.compareTo((java.lang.Object) true);
        long long32 = month28.getFirstMillisecond();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) (-2649600000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1559372400000L + "'", long32 == 1559372400000L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date6 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date6, timeZone19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date2, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getYearValue();
        org.jfree.data.time.Year year32 = month30.getYear();
        boolean boolean33 = timeSeriesDataItem29.equals((java.lang.Object) year32);
        boolean boolean34 = year23.equals((java.lang.Object) boolean33);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year23.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date10, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date2, timeZone15);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date2, timeZone19);
        int int21 = month20.getYearValue();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond2.getLastMillisecond(calendar3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond2, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getYearValue();
        org.jfree.data.time.Year year9 = month7.getYear();
        boolean boolean10 = timeSeriesDataItem6.equals((java.lang.Object) year9);
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(0, year9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (-435));
        java.lang.Object obj8 = null;
        int int9 = fixedMillisecond1.compareTo(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        try {
            timeSeries2.add(regularTimePeriod9, (java.lang.Number) (-1L), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int49 = spreadsheetDate17.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getMonth();
        java.util.Date date53 = spreadsheetDate51.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(2);
        int int56 = spreadsheetDate55.getMonth();
        boolean boolean57 = spreadsheetDate51.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(2);
        int int60 = spreadsheetDate59.getMonth();
        java.util.Date date61 = spreadsheetDate59.toDate();
        boolean boolean62 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate59);
        int int63 = spreadsheetDate51.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2 + "'", int63 == 2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        int int39 = spreadsheetDate18.getYYYY();
        int int40 = spreadsheetDate18.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        java.util.Date date44 = spreadsheetDate42.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        int int47 = spreadsheetDate46.getMonth();
        boolean boolean48 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        try {
            org.jfree.data.time.SerialDate serialDate51 = spreadsheetDate18.getNearestDayOfWeek(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.addAndOrUpdate(timeSeries23);
        java.lang.String str27 = timeSeries23.getRangeDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        java.util.Calendar calendar6 = null;
        try {
            month3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2649600000L) + "'", long4 == (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        int int21 = timeSeries1.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener22);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647);
        java.lang.String str7 = month3.toString();
        org.jfree.data.time.Year year8 = month3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2649600000L) + "'", long4 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertNotNull(year8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.String str20 = seriesException19.toString();
        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond23.getClass();
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) false);
        boolean boolean27 = timeSeries10.equals((java.lang.Object) false);
        timeSeries10.setKey((java.lang.Comparable) 7L);
        boolean boolean30 = day2.equals((java.lang.Object) 7L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        java.lang.Class<?> wildcardClass34 = fixedMillisecond32.getClass();
        long long35 = fixedMillisecond32.getLastMillisecond();
        boolean boolean36 = day2.equals((java.lang.Object) fixedMillisecond32);
        java.lang.String str37 = day2.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "6-January-1900" + "'", str37.equals("6-January-1900"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate28.getEndOfCurrentMonth(serialDate41);
        boolean boolean43 = year25.equals((java.lang.Object) serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) 7);
        int int47 = day44.getYear();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setRangeDescription("Time");
        java.lang.String str11 = timeSeries1.getDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries8.removeChangeListener(seriesChangeListener22);
        timeSeries8.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        timeSeries1.clear();
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        int int15 = timeSeries1.getMaximumItemCount();
        int int16 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        int int8 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        org.jfree.data.time.Year year8 = month6.getYear();
        boolean boolean9 = timeSeriesDataItem5.equals((java.lang.Object) year8);
        timeSeriesDataItem5.setValue((java.lang.Number) 3);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        long long10 = month4.getFirstMillisecond();
        long long11 = month4.getFirstMillisecond();
        java.lang.Class<?> wildcardClass12 = month4.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2649600000L) + "'", long10 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2649600000L) + "'", long11 == (-2649600000L));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries23.setRangeDescription("Time");
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        long long35 = fixedMillisecond34.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        try {
            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 30, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        long long2 = fixedMillisecond1.getLastMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str10 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date14 = fixedMillisecond13.getStart();
        java.lang.Class<?> wildcardClass15 = fixedMillisecond13.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass15);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        java.util.Date date65 = spreadsheetDate63.toDate();
        int int66 = spreadsheetDate63.getMonth();
        boolean boolean67 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.util.Date date68 = spreadsheetDate63.toDate();
        int int69 = spreadsheetDate63.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1900 + "'", int69 == 1900);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        boolean boolean45 = timeSeries33.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date48 = fixedMillisecond47.getStart();
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries52.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        long long58 = day57.getLastMillisecond();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.addAndOrUpdate(timeSeries33);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(serialDate64);
        long long66 = day65.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = day65.next();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        java.lang.String str69 = year68.toString();
        long long70 = year68.getLastMillisecond();
        int int71 = year68.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year68.previous();
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries1.createCopy(regularTimePeriod67, (org.jfree.data.time.RegularTimePeriod) year68);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208441600001L) + "'", long58 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-2208441600001L) + "'", long66 == (-2208441600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "2019" + "'", str69.equals("2019"));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2019 + "'", int71 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(timeSeries73);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, (int) (byte) 10, 9999);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = null;
        try {
            timeSeries1.add(timeSeriesDataItem3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("October");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = month13.compareTo((java.lang.Object) "");
        int int17 = month13.getYearValue();
        org.jfree.data.time.Year year18 = month13.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 1);
        int int25 = month13.compareTo((java.lang.Object) timeSeriesDataItem24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (org.jfree.data.time.RegularTimePeriod) month13);
        timeSeries26.setNotify(false);
        int int29 = timeSeries26.getItemCount();
        try {
            timeSeries26.delete((-572), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -572");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        boolean boolean45 = timeSeries33.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date48 = fixedMillisecond47.getStart();
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries52.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        long long58 = day57.getLastMillisecond();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.addAndOrUpdate(timeSeries33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond64.next();
        java.util.Calendar calendar67 = null;
        fixedMillisecond64.peg(calendar67);
        try {
            timeSeries62.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (double) (-451), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208441600001L) + "'", long58 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-572));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getMonth();
        java.util.Date date12 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean16 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.Object obj18 = null;
        boolean boolean19 = spreadsheetDate2.equals(obj18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        java.util.Date date8 = spreadsheetDate6.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getMonth();
        boolean boolean12 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str15 = serialDate14.getDescription();
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate10.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        boolean boolean18 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        int int21 = spreadsheetDate20.getMonth();
        java.util.Date date22 = spreadsheetDate20.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        boolean boolean26 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
        org.jfree.data.time.SerialDate serialDate32 = serialDate29.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate29);
        boolean boolean34 = spreadsheetDate24.isOnOrBefore(serialDate29);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getFollowingDayOfWeek((int) (byte) 1);
        int int40 = spreadsheetDate24.compare(serialDate39);
        java.lang.String str41 = serialDate39.getDescription();
        boolean boolean42 = spreadsheetDate10.isOn(serialDate39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-6) + "'", int40 == (-6));
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        long long5 = day3.getFirstMillisecond();
        int int6 = day3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-57600000L) + "'", long5 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-451), 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate28.getEndOfCurrentMonth(serialDate41);
        boolean boolean43 = year25.equals((java.lang.Object) serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) 7);
        long long47 = day44.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2206368000000L) + "'", long47 == (-2206368000000L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries13.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond29.next();
        long long32 = fixedMillisecond29.getLastMillisecond();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.previous();
        java.util.Date date35 = regularTimePeriod34.getStart();
        int int36 = fixedMillisecond29.compareTo((java.lang.Object) regularTimePeriod34);
        long long37 = fixedMillisecond29.getFirstMillisecond();
        int int38 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        long long39 = timeSeries13.getMaximumItemAge();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.removeAgedItems(false);
//        boolean boolean4 = timeSeries1.isEmpty();
//        java.lang.String str5 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries7.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
//        long long13 = day12.getLastMillisecond();
//        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
//        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int20 = spreadsheetDate19.getMonth();
//        java.lang.String str21 = spreadsheetDate19.getDescription();
//        boolean boolean22 = day16.equals((java.lang.Object) str21);
//        org.jfree.data.time.SerialDate serialDate23 = day16.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date11 = fixedMillisecond10.getStart();
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass13 = fixedMillisecond12.getClass();
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date18 = fixedMillisecond17.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date21 = fixedMillisecond20.getTime();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date21, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date18, timeZone23);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date10, timeZone23);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone23);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date3, timeZone23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        java.lang.String str7 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((-31507200000L), false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        int int37 = month34.compareTo((java.lang.Object) "");
        int int38 = month34.getYearValue();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int38, class39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries40);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond15.getFirstMillisecond(calendar42);
        long long44 = fixedMillisecond15.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 10L + "'", long44 == 10L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        timeSeries1.setMaximumItemCount(0);
        java.lang.String str8 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        java.lang.String str30 = timeSeries29.getDescription();
        java.lang.String str31 = timeSeries29.getDomainDescription();
        java.lang.String str32 = timeSeries29.getDomainDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone5);
        int int7 = month6.getYearValue();
        long long8 = month6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.jfree.data.time.Year year4 = month0.getYear();
        int int6 = year4.compareTo((java.lang.Object) 10L);
        java.util.Calendar calendar7 = null;
        try {
            year4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        int int4 = timeSeries1.getItemCount();
        java.lang.String str5 = timeSeries1.getDescription();
        timeSeries1.setDescription("7-January-1900");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        int int3 = month0.compareTo((java.lang.Object) true);
        java.util.Date date4 = month0.getStart();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.lang.String str4 = spreadsheetDate2.getDescription();
        int int5 = spreadsheetDate2.getDayOfWeek();
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = month13.compareTo((java.lang.Object) "");
        int int17 = month13.getYearValue();
        org.jfree.data.time.Year year18 = month13.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 1);
        int int25 = month13.compareTo((java.lang.Object) timeSeriesDataItem24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (org.jfree.data.time.RegularTimePeriod) month13);
        long long27 = month13.getLastMillisecond();
        long long28 = month13.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28799999L + "'", long27 == 28799999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 23640L + "'", long28 == 23640L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date10, timeZone15);
        try {
            org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries(comparable0, "SerialDate.weekInMonthToString(): invalid code.", "hi!", class7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        long long4 = day2.getSerialIndex();
        int int5 = day2.getMonth();
        int int6 = day2.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        int int6 = year3.getYear();
        java.util.Calendar calendar7 = null;
        try {
            year3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        int int6 = year3.getYear();
        long long7 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1969L + "'", long7 == 1969L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str11 = serialDate10.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int14 = spreadsheetDate6.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate18.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate60, 2019);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        int int68 = spreadsheetDate67.getMonth();
        java.util.Date date69 = spreadsheetDate67.toDate();
        java.util.Date date70 = spreadsheetDate67.toDate();
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean72 = spreadsheetDate60.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        try {
            org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate60.getPreviousDayOfWeek((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.util.Date date8 = spreadsheetDate5.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date19, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date11, timeZone24);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date11, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date8, timeZone28);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        java.util.Collection collection36 = timeSeries31.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(collection36);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date36 = fixedMillisecond35.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        long long38 = year37.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.previous();
        int int40 = year37.getYear();
        long long41 = year37.getLastMillisecond();
        long long42 = year37.getLastMillisecond();
        java.lang.Number number43 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) year37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date46 = fixedMillisecond45.getStart();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46);
        org.jfree.data.general.SeriesException seriesException50 = new org.jfree.data.general.SeriesException("");
        int int51 = month48.compareTo((java.lang.Object) "");
        int int52 = month48.getYearValue();
        org.jfree.data.time.Year year53 = month48.getYear();
        java.util.Date date54 = year53.getStart();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date54);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date54);
        int int57 = year37.compareTo((java.lang.Object) date54);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1969L + "'", long38 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1969 + "'", int40 == 1969);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1969 + "'", int52 == 1969);
        org.junit.Assert.assertNotNull(year53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries33.createCopy((int) (short) 0, (int) (short) 100);
        try {
            timeSeries36.setMaximumItemAge((long) (-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        int int9 = timeSeriesDataItem5.compareTo((java.lang.Object) serialDate7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        long long22 = month17.getFirstMillisecond();
        org.jfree.data.time.Year year23 = month17.getYear();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2649600000L) + "'", long22 == (-2649600000L));
        org.junit.Assert.assertNotNull(year23);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        int int16 = spreadsheetDate5.toSerial();
        int int17 = spreadsheetDate5.getMonth();
        java.lang.Class<?> wildcardClass18 = spreadsheetDate5.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(true);
        int int5 = timeSeries1.getMaximumItemCount();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        long long11 = month10.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 2147483647);
        try {
            timeSeries1.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2649600000L) + "'", long11 == (-2649600000L));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
//        long long10 = day6.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) (short) 0);
        java.util.Date date7 = fixedMillisecond4.getTime();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate2, "Last", "", class12);
        long long14 = timeSeries13.getMaximumItemAge();
        long long15 = timeSeries13.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.removeChangeListener(seriesChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date20 = fixedMillisecond19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getSerialIndex();
        long long23 = year21.getSerialIndex();
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year21, number24);
        try {
            timeSeries13.add(timeSeriesDataItem25, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1969L + "'", long22 == 1969L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1969L + "'", long23 == 1969L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        org.jfree.data.time.Year year8 = month6.getYear();
        boolean boolean9 = timeSeriesDataItem5.equals((java.lang.Object) year8);
        java.lang.Number number10 = null;
        timeSeriesDataItem5.setValue(number10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        int int8 = month5.compareTo((java.lang.Object) "");
        int int9 = month5.getYearValue();
        org.jfree.data.time.Year year10 = month5.getYear();
        java.lang.String str11 = year10.toString();
        int int12 = year10.getYear();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(6, year10);
        long long14 = month13.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-18464400000L) + "'", long14 == (-18464400000L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str3 = serialDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(3, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        try {
            timeSeries20.update(7, (java.lang.Number) (-2206368000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        long long37 = day36.getLastMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
        java.lang.String str40 = day36.toString();
        int int41 = day36.getDayOfMonth();
        long long42 = day36.getFirstMillisecond();
        int int43 = day36.getDayOfMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day36, (double) 7, false);
        int int47 = day36.getYear();
        java.util.Calendar calendar48 = null;
        try {
            long long49 = day36.getMiddleMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208441600001L) + "'", long37 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "6-January-1900" + "'", str40.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208528000000L) + "'", long42 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.SerialDate serialDate24 = spreadsheetDate17.getEndOfCurrentMonth(serialDate22);
        int int25 = spreadsheetDate17.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        long long27 = day26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (double) 10);
        java.util.List list30 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 7L + "'", long27 == 7L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        java.util.Date date39 = spreadsheetDate9.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries2.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        long long8 = day7.getLastMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) day7);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        timeSeries11.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries2.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) (-1.0d));
        int int28 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass33 = fixedMillisecond32.getClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond23, "Last", "Last", (java.lang.Class) wildcardClass33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date37 = fixedMillisecond36.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        long long39 = year38.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries46.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate50);
        long long52 = day51.getLastMillisecond();
        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) day51);
        org.jfree.data.time.SerialDate serialDate54 = day51.getSerialDate();
        org.jfree.data.time.SerialDate serialDate55 = serialDate41.getEndOfCurrentMonth(serialDate54);
        boolean boolean56 = year38.equals((java.lang.Object) serialDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(2);
        int int60 = spreadsheetDate59.getMonth();
        java.util.Date date61 = spreadsheetDate59.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        boolean boolean65 = spreadsheetDate59.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str68 = serialDate67.getDescription();
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate63.getEndOfCurrentMonth(serialDate67);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate63);
        org.jfree.data.time.SerialDate serialDate71 = serialDate55.getEndOfCurrentMonth(serialDate70);
        int int72 = fixedMillisecond23.compareTo((java.lang.Object) serialDate55);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears(3, serialDate55);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208441600001L) + "'", long8 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1969L + "'", long39 == 1969L);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2208441600001L) + "'", long52 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(serialDate73);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries2.removeAgedItems(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries2.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        java.util.List list13 = timeSeries1.getItems();
        try {
            java.lang.Number number15 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        timeSeries8.setKey((java.lang.Comparable) (-2649600000L));
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        java.util.Date date27 = spreadsheetDate25.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getMonth();
        boolean boolean31 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str34 = serialDate33.getDescription();
        org.jfree.data.time.SerialDate serialDate35 = spreadsheetDate29.getEndOfCurrentMonth(serialDate33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date38 = fixedMillisecond37.getStart();
        java.lang.Class<?> wildcardClass39 = fixedMillisecond37.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate33, (java.lang.Class) wildcardClass39);
        java.util.Collection collection41 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(collection41);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond4.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        long long9 = day8.getLastMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("");
        java.lang.String str13 = seriesException12.toString();
        boolean boolean14 = timeSeries3.equals((java.lang.Object) seriesException12);
        java.lang.String str15 = seriesException12.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException12);
        java.lang.String str17 = seriesException12.toString();
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2208441600001L) + "'", long9 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str13.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str15.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("January");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        timeSeries8.setRangeDescription("6-January-1900");
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        long long27 = day26.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
        long long31 = day30.getSerialIndex();
        int int32 = day26.compareTo((java.lang.Object) long31);
        java.lang.Number number33 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day26);
        java.util.Calendar calendar34 = null;
        try {
            day26.peg(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 7L + "'", long27 == 7L);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 7L + "'", long31 == 7L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(number33);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries2.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries2.getRangeDescription();
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries9 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(class8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond5);
        long long7 = fixedMillisecond5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        int int37 = month34.compareTo((java.lang.Object) "");
        int int38 = month34.getYearValue();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int38, class39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries40);
        timeSeries40.setRangeDescription("Last");
        long long44 = timeSeries40.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeries40.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 9223372036854775807L + "'", long44 == 9223372036854775807L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list8 = timeSeries7.getItems();
        boolean boolean9 = year3.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        long long14 = year13.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        int int16 = timeSeries7.getIndex(regularTimePeriod15);
        timeSeries7.setRangeDescription("hi!");
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1969L + "'", long14 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries33.createCopy((int) (short) 0, (int) (short) 100);
        timeSeries36.setNotify(false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(timeSeries36);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond5);
        long long7 = fixedMillisecond5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries10.removeChangeListener(seriesChangeListener26);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191410366L + "'", long24 == 1560191410366L);
//        org.junit.Assert.assertNull(number25);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, number6);
        int int8 = year3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        boolean boolean22 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass34 = fixedMillisecond33.getClass();
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate25, "Last", "", class35);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean22, class35);
        int int38 = timeSeries37.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(true);
        int int5 = timeSeries1.getMaximumItemCount();
        java.lang.String str6 = timeSeries1.getDescription();
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) month0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate8.getMonth();
        java.util.Date date10 = spreadsheetDate8.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(2);
        int int13 = spreadsheetDate12.getMonth();
        boolean boolean14 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate17);
        boolean boolean22 = spreadsheetDate12.isOnOrBefore(serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        boolean boolean26 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate27 = serialDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        try {
            org.jfree.data.time.SerialDate serialDate29 = serialDate27.getPreviousDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        boolean boolean45 = timeSeries33.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date48 = fixedMillisecond47.getStart();
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries52.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        long long58 = day57.getLastMillisecond();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.addAndOrUpdate(timeSeries33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getLastMillisecond(calendar65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean69 = fixedMillisecond64.equals((java.lang.Object) fixedMillisecond68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond68.previous();
        long long71 = fixedMillisecond68.getFirstMillisecond();
        long long72 = fixedMillisecond68.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date75 = fixedMillisecond74.getStart();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date75);
        org.jfree.data.general.SeriesException seriesException79 = new org.jfree.data.general.SeriesException("");
        int int80 = month77.compareTo((java.lang.Object) "");
        int int81 = month77.getYearValue();
        org.jfree.data.time.Year year82 = month77.getYear();
        java.lang.String str83 = month77.toString();
        java.util.Date date84 = month77.getStart();
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, (org.jfree.data.time.RegularTimePeriod) month77);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208441600001L) + "'", long58 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 100L + "'", long71 == 100L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1969 + "'", int81 == 1969);
        org.junit.Assert.assertNotNull(year82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "December 1969" + "'", str83.equals("December 1969"));
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeSeries85);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        java.lang.String str33 = seriesException32.toString();
        boolean boolean34 = timeSeries23.equals((java.lang.Object) seriesException32);
        boolean boolean35 = timeSeries23.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date38 = fixedMillisecond37.getStart();
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond37.getLastMillisecond(calendar39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries42.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        long long48 = day47.getLastMillisecond();
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day47);
        timeSeries23.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries55.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(serialDate59);
        long long61 = day60.getLastMillisecond();
        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) day60);
        org.jfree.data.general.SeriesException seriesException64 = new org.jfree.data.general.SeriesException("");
        java.lang.String str65 = seriesException64.toString();
        boolean boolean66 = timeSeries55.equals((java.lang.Object) seriesException64);
        boolean boolean67 = timeSeries55.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date70 = fixedMillisecond69.getStart();
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond69.getLastMillisecond(calendar71);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries74.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(serialDate78);
        long long80 = day79.getLastMillisecond();
        timeSeries74.delete((org.jfree.data.time.RegularTimePeriod) day79);
        org.jfree.data.time.SerialDate serialDate82 = day79.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (org.jfree.data.time.RegularTimePeriod) day79);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries23.addAndOrUpdate(timeSeries55);
        timeSeries84.clear();
        java.util.Collection collection86 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries84);
        long long87 = timeSeries84.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries84.getDataItem(regularTimePeriod88);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str33.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-2208441600001L) + "'", long48 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-2208441600001L) + "'", long61 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str65.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-2208441600001L) + "'", long80 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(collection86);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 9223372036854775807L + "'", long87 == 9223372036854775807L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean28 = fixedMillisecond23.equals((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.previous();
        int int30 = timeSeries1.getIndex(regularTimePeriod29);
        java.lang.String str31 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2208528000000L) + "'", long10 == (-2208528000000L));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeriesDataItem11.getPeriod();
        boolean boolean13 = timeSeries1.equals((java.lang.Object) timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        timeSeries10.removeAgedItems(true);
//        java.util.Collection collection28 = timeSeries10.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries10.createCopy(0, 2019);
//        timeSeries10.setDomainDescription("");
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191414449L + "'", long24 == 1560191414449L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(timeSeries31);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        timeSeries10.removeAgedItems(true);
//        java.util.Collection collection28 = timeSeries10.getTimePeriods();
//        timeSeries10.setDescription("6-January-1900");
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191414516L + "'", long24 == 1560191414516L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(collection28);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        int int8 = timeSeriesDataItem5.compareTo((java.lang.Object) 1560191341622L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        int int12 = day6.getDayOfMonth();
        long long13 = day6.getSerialIndex();
        java.lang.Class<?> wildcardClass14 = day6.getClass();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 7L + "'", long13 == 7L);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str20 = seriesException19.toString();
//        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date24 = fixedMillisecond23.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
//        int int29 = month26.compareTo((java.lang.Object) "");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
//        long long31 = month26.getFirstMillisecond();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        long long34 = day32.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int38 = spreadsheetDate37.getMonth();
//        java.util.Date date39 = spreadsheetDate37.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int42 = spreadsheetDate41.getMonth();
//        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int46 = spreadsheetDate45.getMonth();
//        java.util.Date date47 = spreadsheetDate45.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int50 = spreadsheetDate49.getMonth();
//        boolean boolean51 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean52 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date55 = fixedMillisecond54.getStart();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.next();
//        boolean boolean58 = spreadsheetDate37.equals((java.lang.Object) regularTimePeriod57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate37);
//        boolean boolean60 = day32.equals((java.lang.Object) 3);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) day32);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = timeSeries61.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2649600000L) + "'", long31 == (-2649600000L));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(timeSeries61);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        timeSeries8.setKey((java.lang.Comparable) (-2649600000L));
        timeSeries8.clear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        boolean boolean14 = timeSeries13.isEmpty();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setMaximumItemCount(7);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries23.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries14.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) (-1.0d));
        int int40 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass45 = fixedMillisecond44.getClass();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, "Last", "Last", (java.lang.Class) wildcardClass45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date49 = fixedMillisecond48.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        long long51 = year50.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries58.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate62);
        long long64 = day63.getLastMillisecond();
        timeSeries58.delete((org.jfree.data.time.RegularTimePeriod) day63);
        org.jfree.data.time.SerialDate serialDate66 = day63.getSerialDate();
        org.jfree.data.time.SerialDate serialDate67 = serialDate53.getEndOfCurrentMonth(serialDate66);
        boolean boolean68 = year50.equals((java.lang.Object) serialDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(2);
        int int72 = spreadsheetDate71.getMonth();
        java.util.Date date73 = spreadsheetDate71.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(2);
        int int76 = spreadsheetDate75.getMonth();
        boolean boolean77 = spreadsheetDate71.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str80 = serialDate79.getDescription();
        org.jfree.data.time.SerialDate serialDate81 = spreadsheetDate75.getEndOfCurrentMonth(serialDate79);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate83 = serialDate67.getEndOfCurrentMonth(serialDate82);
        int int84 = fixedMillisecond35.compareTo((java.lang.Object) serialDate67);
        boolean boolean85 = timeSeries10.equals((java.lang.Object) fixedMillisecond35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond87 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date88 = fixedMillisecond87.getStart();
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date88);
        long long90 = year89.getSerialIndex();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year89, 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1969L + "'", long51 == 1969L);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2208441600001L) + "'", long64 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1969L + "'", long90 == 1969L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) (short) 0);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond4);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getSerialIndex();
        long long26 = year24.getSerialIndex();
        boolean boolean28 = year24.equals((java.lang.Object) (-2649600000L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 1560236399999L);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year24.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1969L + "'", long25 == 1969L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate1.getMonth();
        int int9 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setDescription("org.jfree.data.general.SeriesException: ");
        timeSeries10.setKey((java.lang.Comparable) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries16.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        long long22 = day21.getLastMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        java.lang.String str26 = seriesException25.toString();
        boolean boolean27 = timeSeries16.equals((java.lang.Object) seriesException25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("");
        int int35 = month32.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month32.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month32.next();
        java.lang.Number number39 = timeSeries10.getValue(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208441600001L) + "'", long22 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str26.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNull(number39);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        long long3 = month2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        long long5 = day3.getFirstMillisecond();
        java.lang.Class<?> wildcardClass6 = day3.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-57600000L) + "'", long5 == (-57600000L));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        java.util.Date date4 = day2.getStart();
        long long5 = day2.getSerialIndex();
        int int6 = day2.getMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 7L + "'", long5 == 7L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        int int11 = timeSeries1.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getLastMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        boolean boolean24 = timeSeries13.equals((java.lang.Object) seriesException22);
        boolean boolean25 = timeSeries13.getNotify();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.addAndOrUpdate(timeSeries13);
        try {
            java.lang.Number number28 = timeSeries1.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2208441600001L) + "'", long19 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4', (-451), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        int int16 = spreadsheetDate5.toSerial();
        int int17 = spreadsheetDate5.getMonth();
        int int18 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        boolean boolean22 = spreadsheetDate5.isOn(serialDate20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month17.next();
        int int24 = month17.getMonth();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month17.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = serialDate6.getEndOfCurrentMonth(serialDate19);
        boolean boolean21 = year3.equals((java.lang.Object) serialDate20);
        java.util.Date date22 = year3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year3.previous();
        long long24 = year3.getFirstMillisecond();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year3.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31507200000L) + "'", long24 == (-31507200000L));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        int int7 = timeSeries1.getMaximumItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            timeSeries1.add(timeSeriesDataItem9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) (-1.0d));
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) timeSeriesDataItem7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem7.getPeriod();
        java.lang.Number number10 = null;
        timeSeriesDataItem7.setValue(number10);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.next();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries10.addChangeListener(seriesChangeListener26);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191415655L + "'", long24 == 1560191415655L);
//        org.junit.Assert.assertNull(number25);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        long long6 = year3.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-31507200000L) + "'", long6 == (-31507200000L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.lang.String str10 = year9.toString();
        int int11 = year9.getYear();
        java.lang.String str12 = year9.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2019);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate16, "Last", "", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        long long29 = timeSeries27.getMaximumItemAge();
        boolean boolean30 = timeSeries1.equals((java.lang.Object) timeSeries27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("");
        int int38 = month35.compareTo((java.lang.Object) "");
        java.lang.String str39 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries41.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
        long long47 = day46.getLastMillisecond();
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries50.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getLastMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) day55);
        timeSeries50.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries41.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        int int67 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass72 = fixedMillisecond71.getClass();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond62, "Last", "Last", (java.lang.Class) wildcardClass72);
        boolean boolean74 = month35.equals((java.lang.Object) timeSeries73);
        java.util.Collection collection75 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(2);
        int int78 = spreadsheetDate77.getMonth();
        java.util.Date date79 = spreadsheetDate77.toDate();
        int int80 = spreadsheetDate77.getMonth();
        boolean boolean81 = timeSeries73.equals((java.lang.Object) int80);
        timeSeries73.fireSeriesChanged();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "December 1969" + "'", str39.equals("December 1969"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2208441600001L) + "'", long47 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2208441600001L) + "'", long56 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 10L + "'", long64 == 10L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(collection75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getLastMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        int int3 = month2.getYearValue();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        int int8 = day6.getYear();
        int int9 = day6.getMonth();
        org.jfree.data.time.SerialDate serialDate10 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        int int12 = month2.compareTo((java.lang.Object) day6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, number6);
        long long8 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.String str20 = seriesException19.toString();
        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond23.getClass();
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) false);
        boolean boolean27 = timeSeries10.equals((java.lang.Object) false);
        timeSeries10.setKey((java.lang.Comparable) 7L);
        boolean boolean30 = day2.equals((java.lang.Object) 7L);
        org.jfree.data.time.SerialDate serialDate31 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date10, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date2, timeZone15);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date2, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year21.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-458), (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        java.lang.Class<?> wildcardClass5 = month3.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.lang.String str10 = year9.toString();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries12.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        long long18 = day17.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day17);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        boolean boolean23 = timeSeries12.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26);
        org.jfree.data.general.SeriesException seriesException30 = new org.jfree.data.general.SeriesException("");
        int int31 = month28.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month28.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month28.next();
        boolean boolean35 = year9.equals((java.lang.Object) month28);
        java.lang.String str36 = year9.toString();
        java.lang.Object obj37 = null;
        boolean boolean38 = year9.equals(obj37);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2208441600001L) + "'", long18 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1969" + "'", str36.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(8, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "August" + "'", str2.equals("August"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int49 = spreadsheetDate17.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
        org.jfree.data.time.SerialDate serialDate55 = serialDate52.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2);
        int int59 = spreadsheetDate58.getMonth();
        java.util.Date date60 = spreadsheetDate58.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(2);
        int int63 = spreadsheetDate62.getMonth();
        boolean boolean64 = spreadsheetDate58.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(serialDate67);
        org.jfree.data.time.SerialDate serialDate70 = serialDate67.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate67);
        boolean boolean72 = spreadsheetDate62.isOnOrBefore(serialDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(2);
        int int75 = spreadsheetDate74.getMonth();
        boolean boolean76 = spreadsheetDate62.isOn((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.SerialDate serialDate77 = serialDate52.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate62);
        boolean boolean78 = spreadsheetDate17.isOnOrBefore(serialDate52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate4);
        java.lang.String str9 = serialDate4.getDescription();
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getEndOfCurrentMonth(serialDate4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        boolean boolean6 = year3.equals((java.lang.Object) 1560191339344L);
        long long7 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        timeSeries1.setRangeDescription("Time");
//        timeSeries1.removeAgedItems(2019L, true);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        long long16 = day14.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int20 = spreadsheetDate19.getMonth();
//        java.util.Date date21 = spreadsheetDate19.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int24 = spreadsheetDate23.getMonth();
//        boolean boolean25 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int28 = spreadsheetDate27.getMonth();
//        java.util.Date date29 = spreadsheetDate27.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int32 = spreadsheetDate31.getMonth();
//        boolean boolean33 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        boolean boolean34 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date37 = fixedMillisecond36.getStart();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day38.next();
//        boolean boolean40 = spreadsheetDate19.equals((java.lang.Object) regularTimePeriod39);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate19);
//        boolean boolean42 = day14.equals((java.lang.Object) 3);
//        java.lang.String str43 = day14.toString();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries45.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
//        long long51 = day50.getLastMillisecond();
//        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
//        java.lang.String str54 = day50.toString();
//        int int55 = day50.getDayOfMonth();
//        long long56 = day50.getFirstMillisecond();
//        java.util.Date date57 = day50.getStart();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond(date57);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "10-June-2019" + "'", str43.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "6-January-1900" + "'", str54.equals("6-January-1900"));
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2208528000000L) + "'", long56 == (-2208528000000L));
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeSeries60);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.lang.String str10 = month4.toString();
        java.util.Date date11 = month4.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "December 1969" + "'", str10.equals("December 1969"));
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(true);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        java.util.Date date26 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.getMonth();
        boolean boolean30 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str33 = serialDate32.getDescription();
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate28.getEndOfCurrentMonth(serialDate32);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        org.jfree.data.time.SerialDate serialDate49 = serialDate46.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate46);
        boolean boolean51 = spreadsheetDate41.isOnOrBefore(serialDate46);
        boolean boolean52 = spreadsheetDate28.isOn(serialDate46);
        boolean boolean53 = spreadsheetDate5.isAfter(serialDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str65 = serialDate64.getDescription();
        org.jfree.data.time.SerialDate serialDate66 = spreadsheetDate60.getEndOfCurrentMonth(serialDate64);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate60);
        int int68 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date71 = fixedMillisecond70.getTime();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date75 = fixedMillisecond74.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass78 = fixedMillisecond77.getClass();
        java.lang.Class class79 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass78);
        java.lang.Class class80 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass78);
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date83 = fixedMillisecond82.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond85 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date86 = fixedMillisecond85.getTime();
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.createInstance(date86);
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month89 = new org.jfree.data.time.Month(date86, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date83, timeZone88);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date75, timeZone88);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month93 = new org.jfree.data.time.Month(date75, timeZone92);
        org.jfree.data.time.Day day94 = new org.jfree.data.time.Day(date71, timeZone92);
        org.jfree.data.time.SerialDate serialDate95 = day94.getSerialDate();
        boolean boolean96 = spreadsheetDate60.isOnOrBefore(serialDate95);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(class79);
        org.junit.Assert.assertNotNull(class80);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNotNull(serialDate95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((-5));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        int int2 = month0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.previous();
        int int8 = day2.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day2.previous();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setRangeDescription("Time");
        timeSeries1.setMaximumItemCount(9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem5.getPeriod();
        java.lang.Object obj10 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        int int6 = year3.compareTo((java.lang.Object) (short) 10);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date22 = fixedMillisecond21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        org.jfree.data.general.SeriesException seriesException26 = new org.jfree.data.general.SeriesException("");
        int int27 = month24.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month24.next();
        java.lang.Class<?> wildcardClass30 = regularTimePeriod29.getClass();
        int int31 = year3.compareTo((java.lang.Object) wildcardClass30);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        long long13 = day12.getLastMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        java.lang.String str17 = seriesException16.toString();
        boolean boolean18 = timeSeries7.equals((java.lang.Object) seriesException16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date21 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        int int26 = month23.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month23.next();
        java.lang.Class<?> wildcardClass29 = regularTimePeriod28.getClass();
        int int30 = fixedMillisecond1.compareTo((java.lang.Object) wildcardClass29);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 6);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191419288L + "'", long1 == 1560191419288L);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        long long6 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        long long6 = year3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries16.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        long long22 = day21.getLastMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        java.lang.String str26 = seriesException25.toString();
        boolean boolean27 = timeSeries16.equals((java.lang.Object) seriesException25);
        java.lang.String str28 = seriesException25.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException25);
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str31 = timePeriodFormatException14.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208441600001L) + "'", long22 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str26.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str28.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int2 = month0.getYearValue();
        int int3 = month0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries13.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date30 = fixedMillisecond29.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("");
        int int35 = month32.compareTo((java.lang.Object) "");
        int int36 = month32.getYearValue();
        org.jfree.data.time.Year year37 = month32.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 1);
        int int44 = month32.compareTo((java.lang.Object) timeSeriesDataItem43);
        try {
            timeSeries13.add(timeSeriesDataItem43, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(year37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 10L + "'", long41 == 10L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries13.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(12, (int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        long long36 = fixedMillisecond32.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 10L + "'", long36 == 10L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setDescription("org.jfree.data.general.SeriesException: ");
        int int13 = timeSeries10.getMaximumItemCount();
        java.lang.Object obj14 = timeSeries10.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date17, timeZone20);
        int int22 = month21.getYearValue();
        java.lang.String str23 = month21.toString();
        try {
            timeSeries10.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 1560191361412L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "December 1969" + "'", str23.equals("December 1969"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        long long8 = day7.getSerialIndex();
        int int9 = day3.compareTo((java.lang.Object) long8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass12 = fixedMillisecond11.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int9, class13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        int int22 = month19.compareTo((java.lang.Object) "");
        int int23 = month19.getYearValue();
        org.jfree.data.time.Year year24 = month19.getYear();
        java.lang.String str25 = year24.toString();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) year24);
        try {
            org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(2958465, year24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7L + "'", long4 == 7L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7L + "'", long8 == 7L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate6, "Last", "", class16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date20 = fixedMillisecond19.getTime();
        boolean boolean21 = timeSeries17.equals((java.lang.Object) fixedMillisecond19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
//        java.lang.String str20 = seriesException19.toString();
//        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date24 = fixedMillisecond23.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
//        int int29 = month26.compareTo((java.lang.Object) "");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
//        long long31 = month26.getFirstMillisecond();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.lang.String str33 = day32.toString();
//        long long34 = day32.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int38 = spreadsheetDate37.getMonth();
//        java.util.Date date39 = spreadsheetDate37.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int42 = spreadsheetDate41.getMonth();
//        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int46 = spreadsheetDate45.getMonth();
//        java.util.Date date47 = spreadsheetDate45.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int50 = spreadsheetDate49.getMonth();
//        boolean boolean51 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
//        boolean boolean52 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date55 = fixedMillisecond54.getStart();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.next();
//        boolean boolean58 = spreadsheetDate37.equals((java.lang.Object) regularTimePeriod57);
//        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate37);
//        boolean boolean60 = day32.equals((java.lang.Object) 3);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month26, (org.jfree.data.time.RegularTimePeriod) day32);
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timeSeries61.removePropertyChangeListener(propertyChangeListener62);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2649600000L) + "'", long31 == (-2649600000L));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(timeSeries61);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        java.util.Date date39 = spreadsheetDate9.toDate();
        java.util.Date date40 = spreadsheetDate9.toDate();
        java.lang.String str41 = spreadsheetDate9.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        java.util.Date date46 = spreadsheetDate44.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        boolean boolean50 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str53 = serialDate52.getDescription();
        org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate48.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean56 = spreadsheetDate9.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries58.removeAgedItems(false);
        boolean boolean61 = timeSeries58.isEmpty();
        java.lang.String str62 = timeSeries58.getDomainDescription();
        java.lang.String str63 = timeSeries58.getDescription();
        java.lang.Class class64 = timeSeries58.getTimePeriodClass();
        boolean boolean65 = spreadsheetDate9.equals((java.lang.Object) class64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Time" + "'", str62.equals("Time"));
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-459), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -459");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        int int2 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem8.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) 1);
        timeSeries1.delete(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        java.util.Date date16 = spreadsheetDate5.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        java.util.Date date37 = spreadsheetDate35.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
        int int40 = spreadsheetDate39.getMonth();
        boolean boolean41 = spreadsheetDate35.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2);
        int int44 = spreadsheetDate43.getMonth();
        java.util.Date date45 = spreadsheetDate43.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getMonth();
        boolean boolean49 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean50 = spreadsheetDate35.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate52);
        boolean boolean55 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, serialDate52, (int) ' ');
        java.util.Date date56 = spreadsheetDate26.toDate();
        java.util.Date date57 = spreadsheetDate26.toDate();
        java.lang.String str58 = spreadsheetDate26.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2);
        int int62 = spreadsheetDate61.getMonth();
        java.util.Date date63 = spreadsheetDate61.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(2);
        int int66 = spreadsheetDate65.getMonth();
        boolean boolean67 = spreadsheetDate61.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str70 = serialDate69.getDescription();
        org.jfree.data.time.SerialDate serialDate71 = spreadsheetDate65.getEndOfCurrentMonth(serialDate69);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean73 = spreadsheetDate26.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean74 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(2);
        int int77 = spreadsheetDate76.getMonth();
        java.util.Date date78 = spreadsheetDate76.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(2);
        int int81 = spreadsheetDate80.getMonth();
        boolean boolean82 = spreadsheetDate76.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str85 = serialDate84.getDescription();
        org.jfree.data.time.SerialDate serialDate86 = spreadsheetDate80.getEndOfCurrentMonth(serialDate84);
        boolean boolean87 = spreadsheetDate65.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate80);
        java.lang.String str88 = spreadsheetDate80.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNull(str88);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        int int4 = month3.getMonth();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        java.lang.String str16 = seriesException15.toString();
        boolean boolean17 = timeSeries6.equals((java.lang.Object) seriesException15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date20 = fixedMillisecond19.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        int int25 = month22.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month22.next();
        java.lang.Class<?> wildcardClass28 = regularTimePeriod27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int4, (java.lang.Class) wildcardClass28);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str16.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        boolean boolean16 = spreadsheetDate6.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        boolean boolean20 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        java.util.Date date24 = spreadsheetDate22.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        boolean boolean28 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate31);
        boolean boolean36 = spreadsheetDate26.isOnOrBefore(serialDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        int int39 = spreadsheetDate38.getMonth();
        java.util.Date date40 = spreadsheetDate38.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        boolean boolean44 = spreadsheetDate38.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str47 = serialDate46.getDescription();
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate42.getEndOfCurrentMonth(serialDate46);
        boolean boolean49 = spreadsheetDate18.isInRange(serialDate31, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(serialDate50);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean28 = fixedMillisecond23.equals((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.previous();
        int int30 = timeSeries1.getIndex(regularTimePeriod29);
        java.lang.Object obj31 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("1-January-1970");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getYearValue();
        long long23 = month21.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.getDataItem(regularTimePeriod24);
        timeSeries1.setMaximumItemCount(2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.lang.String str10 = year9.toString();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries12.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        long long18 = day17.getLastMillisecond();
        timeSeries12.delete((org.jfree.data.time.RegularTimePeriod) day17);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("");
        java.lang.String str22 = seriesException21.toString();
        boolean boolean23 = timeSeries12.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26);
        org.jfree.data.general.SeriesException seriesException30 = new org.jfree.data.general.SeriesException("");
        int int31 = month28.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month28.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month28.next();
        boolean boolean35 = year9.equals((java.lang.Object) month28);
        java.lang.String str36 = year9.toString();
        long long37 = year9.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2208441600001L) + "'", long18 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str22.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "1969" + "'", str36.equals("1969"));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1969L + "'", long37 == 1969L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getMonth();
        java.util.Date date5 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getMonth();
        boolean boolean9 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate12);
        boolean boolean17 = spreadsheetDate7.isOnOrBefore(serialDate12);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        org.jfree.data.time.SerialDate serialDate22 = serialDate19.getFollowingDayOfWeek((int) (byte) 1);
        int int23 = spreadsheetDate7.compare(serialDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        java.util.Date date27 = spreadsheetDate25.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(2);
        int int30 = spreadsheetDate29.getMonth();
        boolean boolean31 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(2);
        int int34 = spreadsheetDate33.getMonth();
        java.util.Date date35 = spreadsheetDate33.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        boolean boolean39 = spreadsheetDate33.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean40 = spreadsheetDate25.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        java.util.Date date44 = spreadsheetDate42.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        int int47 = spreadsheetDate46.getMonth();
        boolean boolean48 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getMonth();
        java.util.Date date52 = spreadsheetDate50.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        int int55 = spreadsheetDate54.getMonth();
        boolean boolean56 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean57 = spreadsheetDate42.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(serialDate59);
        boolean boolean62 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, serialDate59, (int) ' ');
        boolean boolean63 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date66 = fixedMillisecond65.getTime();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
        int int68 = spreadsheetDate7.compare(serialDate67);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate67);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, serialDate69);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-6) + "'", int23 == (-6));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-25566) + "'", int68 == (-25566));
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str10 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date14 = fixedMillisecond13.getStart();
        java.lang.Class<?> wildcardClass15 = fixedMillisecond13.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate9);
        long long18 = day17.getSerialIndex();
        java.lang.Class<?> wildcardClass19 = day17.getClass();
        java.util.Calendar calendar20 = null;
        try {
            day17.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 7L + "'", long18 == 7L);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        long long3 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        boolean boolean21 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        timeSeries10.removeAgedItems(true);
//        java.util.Collection collection28 = timeSeries10.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries10.createCopy(0, 2019);
//        int int32 = timeSeries10.getMaximumItemCount();
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191423119L + "'", long24 == 1560191423119L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(collection28);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.lang.Comparable comparable3 = timeSeries2.getKey();
        java.lang.Object obj4 = timeSeries2.clone();
        org.junit.Assert.assertNotNull(comparable3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        org.jfree.data.time.Year year8 = month6.getYear();
        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getLastMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        boolean boolean24 = timeSeries13.equals((java.lang.Object) seriesException22);
        java.lang.String str25 = seriesException22.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) seriesException22);
        int int27 = month6.compareTo((java.lang.Object) seriesException22);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries29.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
        long long35 = day34.getLastMillisecond();
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day34);
        org.jfree.data.general.SeriesException seriesException38 = new org.jfree.data.general.SeriesException("");
        java.lang.String str39 = seriesException38.toString();
        boolean boolean40 = timeSeries29.equals((java.lang.Object) seriesException38);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException42 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries44.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(serialDate48);
        long long50 = day49.getLastMillisecond();
        timeSeries44.delete((org.jfree.data.time.RegularTimePeriod) day49);
        org.jfree.data.general.SeriesException seriesException53 = new org.jfree.data.general.SeriesException("");
        java.lang.String str54 = seriesException53.toString();
        boolean boolean55 = timeSeries44.equals((java.lang.Object) seriesException53);
        java.lang.String str56 = seriesException53.toString();
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) seriesException53);
        seriesException38.addSuppressed((java.lang.Throwable) timePeriodFormatException42);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException60 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray61 = timePeriodFormatException60.getSuppressed();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries63.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(serialDate67);
        long long69 = day68.getLastMillisecond();
        timeSeries63.delete((org.jfree.data.time.RegularTimePeriod) day68);
        org.jfree.data.general.SeriesException seriesException72 = new org.jfree.data.general.SeriesException("");
        java.lang.String str73 = seriesException72.toString();
        boolean boolean74 = timeSeries63.equals((java.lang.Object) seriesException72);
        timePeriodFormatException60.addSuppressed((java.lang.Throwable) seriesException72);
        timePeriodFormatException42.addSuppressed((java.lang.Throwable) seriesException72);
        seriesException22.addSuppressed((java.lang.Throwable) seriesException72);
        org.jfree.data.general.SeriesException seriesException79 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray80 = seriesException79.getSuppressed();
        seriesException72.addSuppressed((java.lang.Throwable) seriesException79);
        java.lang.Throwable[] throwableArray82 = seriesException72.getSuppressed();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2208441600001L) + "'", long19 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str25.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2208441600001L) + "'", long35 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str39.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-2208441600001L) + "'", long50 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str54.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str56.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-2208441600001L) + "'", long69 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str73.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(throwableArray80);
        org.junit.Assert.assertNotNull(throwableArray82);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        int int39 = spreadsheetDate9.getMonth();
        try {
            org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate9.getPreviousDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.removeAgedItems(false);
        int int6 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getLastMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
        int int21 = year10.compareTo((java.lang.Object) day18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, 0.0d);
        timeSeries1.add(timeSeriesDataItem23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries1.getTimePeriod(0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2208441600001L) + "'", long19 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        java.lang.String str8 = month4.toString();
        long long9 = month4.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 23640L + "'", long9 == 23640L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, (-25566), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate16, "Last", "", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        long long29 = timeSeries27.getMaximumItemAge();
        boolean boolean30 = timeSeries1.equals((java.lang.Object) timeSeries27);
        java.util.Collection collection31 = timeSeries1.getTimePeriods();
        timeSeries1.setMaximumItemCount(2147483647);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(collection31);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getMonth();
        java.util.Date date52 = spreadsheetDate50.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        int int55 = spreadsheetDate54.getMonth();
        boolean boolean56 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
        java.lang.Object obj58 = null;
        try {
            int int59 = spreadsheetDate50.compareTo(obj58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate57);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.String str20 = seriesException19.toString();
        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond23.getClass();
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) false);
        boolean boolean27 = timeSeries10.equals((java.lang.Object) false);
        timeSeries10.setKey((java.lang.Comparable) 7L);
        boolean boolean30 = day2.equals((java.lang.Object) 7L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        java.lang.Class<?> wildcardClass34 = fixedMillisecond32.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        int int36 = day2.compareTo((java.lang.Object) fixedMillisecond32);
        java.util.Calendar calendar37 = null;
        fixedMillisecond32.peg(calendar37);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list22 = timeSeries21.getItems();
        boolean boolean23 = spreadsheetDate5.equals((java.lang.Object) list22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        try {
            timeSeries1.update((-5), (java.lang.Number) 1560191414516L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        java.lang.String str11 = day6.toString();
        int int12 = day6.getDayOfMonth();
        int int13 = day6.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6-January-1900" + "'", str11.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.removeChangeListener(seriesChangeListener4);
        timeSeries1.setMaximumItemCount(0);
        java.lang.Object obj8 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate18.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate60, 2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date67 = fixedMillisecond66.getTime();
        java.lang.Class<?> wildcardClass68 = fixedMillisecond66.getClass();
        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean64, (java.lang.Class) wildcardClass68);
        java.beans.PropertyChangeListener propertyChangeListener70 = null;
        timeSeries69.addPropertyChangeListener(propertyChangeListener70);
        timeSeries69.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-25566));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        java.util.Date date39 = spreadsheetDate9.toDate();
        int int40 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        java.util.Date date44 = spreadsheetDate42.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        int int47 = spreadsheetDate46.getMonth();
        boolean boolean48 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate51);
        boolean boolean56 = spreadsheetDate46.isOnOrBefore(serialDate51);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(2);
        int int59 = spreadsheetDate58.getMonth();
        boolean boolean60 = spreadsheetDate46.isOn((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(2);
        int int63 = spreadsheetDate62.getMonth();
        java.util.Date date64 = spreadsheetDate62.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(2);
        int int67 = spreadsheetDate66.getMonth();
        boolean boolean68 = spreadsheetDate62.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate66);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(serialDate71);
        org.jfree.data.time.SerialDate serialDate74 = serialDate71.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate71);
        boolean boolean76 = spreadsheetDate66.isOnOrBefore(serialDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(2);
        int int79 = spreadsheetDate78.getMonth();
        java.util.Date date80 = spreadsheetDate78.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        int int83 = spreadsheetDate82.getMonth();
        boolean boolean84 = spreadsheetDate78.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
        org.jfree.data.time.SerialDate serialDate86 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str87 = serialDate86.getDescription();
        org.jfree.data.time.SerialDate serialDate88 = spreadsheetDate82.getEndOfCurrentMonth(serialDate86);
        boolean boolean89 = spreadsheetDate58.isInRange(serialDate71, (org.jfree.data.time.SerialDate) spreadsheetDate82);
        java.util.Date date90 = spreadsheetDate58.toDate();
        org.jfree.data.time.SerialDate serialDate91 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(serialDate86);
        org.junit.Assert.assertNull(str87);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(serialDate91);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date49 = spreadsheetDate41.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.lang.String str4 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getMonth();
        java.util.Date date9 = spreadsheetDate7.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(2);
        int int12 = spreadsheetDate11.getMonth();
        boolean boolean13 = spreadsheetDate7.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        boolean boolean21 = spreadsheetDate11.isOnOrBefore(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        boolean boolean25 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        java.util.Date date29 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        boolean boolean33 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate36);
        boolean boolean41 = spreadsheetDate31.isOnOrBefore(serialDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2);
        int int44 = spreadsheetDate43.getMonth();
        java.util.Date date45 = spreadsheetDate43.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
        int int48 = spreadsheetDate47.getMonth();
        boolean boolean49 = spreadsheetDate43.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str52 = serialDate51.getDescription();
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate47.getEndOfCurrentMonth(serialDate51);
        boolean boolean54 = spreadsheetDate23.isInRange(serialDate36, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int55 = spreadsheetDate23.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        int int58 = spreadsheetDate57.getMonth();
        java.util.Date date59 = spreadsheetDate57.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2);
        int int62 = spreadsheetDate61.getMonth();
        boolean boolean63 = spreadsheetDate57.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(2);
        int int66 = spreadsheetDate65.getMonth();
        java.util.Date date67 = spreadsheetDate65.toDate();
        boolean boolean68 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate57, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate65);
        int int70 = spreadsheetDate1.compare(serialDate69);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-31) + "'", int70 == (-31));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560191410366L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.lang.String str4 = spreadsheetDate1.getDescription();
        java.lang.Class<?> wildcardClass5 = spreadsheetDate1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Object obj7 = null;
        boolean boolean8 = timeSeriesDataItem5.equals(obj7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        java.lang.Comparable comparable13 = timeSeries10.getKey();
        java.lang.String str14 = timeSeries10.getDomainDescription();
        int int15 = timeSeries10.getItemCount();
        boolean boolean16 = timeSeries10.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        int int31 = year20.compareTo((java.lang.Object) day28);
        timeSeries10.setKey((java.lang.Comparable) int31);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
        long long36 = day35.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries40.removeAgedItems(false);
        boolean boolean43 = timeSeries40.isEmpty();
        java.lang.String str44 = timeSeries40.getDomainDescription();
        java.util.Collection collection45 = timeSeries40.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries47.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        long long53 = day52.getLastMillisecond();
        timeSeries47.delete((org.jfree.data.time.RegularTimePeriod) day52);
        org.jfree.data.general.SeriesException seriesException56 = new org.jfree.data.general.SeriesException("");
        java.lang.String str57 = seriesException56.toString();
        boolean boolean58 = timeSeries47.equals((java.lang.Object) seriesException56);
        boolean boolean59 = timeSeries47.getNotify();
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries40.addAndOrUpdate(timeSeries47);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries10.addAndOrUpdate(timeSeries60);
        timeSeries10.update((int) (byte) 0, (java.lang.Number) (-2208484800001L));
        int int65 = timeSeriesDataItem5.compareTo((java.lang.Object) timeSeries10);
        java.lang.Number number66 = timeSeriesDataItem5.getValue();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2019);
        java.lang.String str69 = seriesChangeEvent68.toString();
        java.lang.String str70 = seriesChangeEvent68.toString();
        boolean boolean71 = timeSeriesDataItem5.equals((java.lang.Object) str70);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + '4' + "'", comparable13.equals('4'));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28799999L + "'", long21 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 7L + "'", long36 == 7L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Time" + "'", str44.equals("Time"));
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-2208441600001L) + "'", long53 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str57.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + (-1.0d) + "'", number66.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str69.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str70.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) false);
        java.util.Date date5 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getMiddleMillisecond(calendar6);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date20 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate21 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate62);
        org.jfree.data.time.SerialDate serialDate65 = serialDate62.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries67.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(serialDate71);
        long long73 = day72.getLastMillisecond();
        timeSeries67.delete((org.jfree.data.time.RegularTimePeriod) day72);
        org.jfree.data.time.SerialDate serialDate75 = day72.getSerialDate();
        org.jfree.data.time.SerialDate serialDate76 = serialDate62.getEndOfCurrentMonth(serialDate75);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(2);
        int int79 = spreadsheetDate78.getMonth();
        java.util.Date date80 = spreadsheetDate78.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        int int83 = spreadsheetDate82.getMonth();
        boolean boolean84 = spreadsheetDate78.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
        boolean boolean86 = spreadsheetDate40.isInRange(serialDate76, (org.jfree.data.time.SerialDate) spreadsheetDate82, 2019);
        try {
            boolean boolean88 = spreadsheetDate5.isInRange(serialDate21, (org.jfree.data.time.SerialDate) spreadsheetDate82, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-2208441600001L) + "'", long73 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("December 1969");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond22.getMiddleMillisecond(calendar28);
        long long30 = fixedMillisecond22.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        boolean boolean6 = year3.equals((java.lang.Object) 1560191339344L);
        int int7 = year3.getYear();
        java.lang.String str8 = year3.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year3.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.addAndOrUpdate(timeSeries23);
        timeSeries23.setDomainDescription("Last");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        long long5 = year3.getSerialIndex();
        long long6 = year3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date23 = fixedMillisecond22.getStart();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getLastMillisecond(calendar24);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries27.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        long long33 = day32.getLastMillisecond();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries8.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) day32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date39 = fixedMillisecond38.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date39);
        org.jfree.data.general.SeriesException seriesException43 = new org.jfree.data.general.SeriesException("");
        int int44 = month41.compareTo((java.lang.Object) "");
        int int45 = month41.getYearValue();
        java.lang.Class class46 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int45, class46);
        int int48 = fixedMillisecond22.compareTo((java.lang.Object) timeSeries47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date51 = fixedMillisecond50.getStart();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 10L);
        boolean boolean56 = year3.equals((java.lang.Object) timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-2208441600001L) + "'", long33 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        java.lang.String str33 = seriesException32.toString();
        boolean boolean34 = timeSeries23.equals((java.lang.Object) seriesException32);
        boolean boolean35 = timeSeries23.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date38 = fixedMillisecond37.getStart();
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond37.getLastMillisecond(calendar39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries42.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        long long48 = day47.getLastMillisecond();
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day47);
        timeSeries23.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries55.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(serialDate59);
        long long61 = day60.getLastMillisecond();
        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) day60);
        org.jfree.data.general.SeriesException seriesException64 = new org.jfree.data.general.SeriesException("");
        java.lang.String str65 = seriesException64.toString();
        boolean boolean66 = timeSeries55.equals((java.lang.Object) seriesException64);
        boolean boolean67 = timeSeries55.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date70 = fixedMillisecond69.getStart();
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond69.getLastMillisecond(calendar71);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries74.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(serialDate78);
        long long80 = day79.getLastMillisecond();
        timeSeries74.delete((org.jfree.data.time.RegularTimePeriod) day79);
        org.jfree.data.time.SerialDate serialDate82 = day79.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (org.jfree.data.time.RegularTimePeriod) day79);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries23.addAndOrUpdate(timeSeries55);
        timeSeries84.clear();
        java.util.Collection collection86 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries84);
        long long87 = timeSeries84.getMaximumItemAge();
        int int88 = timeSeries84.getMaximumItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str33.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-2208441600001L) + "'", long48 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-2208441600001L) + "'", long61 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str65.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-2208441600001L) + "'", long80 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(collection86);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 9223372036854775807L + "'", long87 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2147483647 + "'", int88 == 2147483647);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        long long11 = day6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.previous();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2208528000000L) + "'", long11 == (-2208528000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        int int6 = year3.compareTo((java.lang.Object) 1900);
        long long7 = year3.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, (double) 1560191414516L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1969L + "'", long7 == 1969L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        long long4 = fixedMillisecond1.getLastMillisecond();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.lang.String str6 = timeSeries1.getDescription();
        java.lang.Class class7 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(class7);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.String str9 = timeSeries1.getDescription();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertNull(str9);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        java.lang.String str34 = timeSeries33.getDomainDescription();
        java.lang.Comparable comparable35 = timeSeries33.getKey();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Last" + "'", str34.equals("Last"));
        org.junit.Assert.assertNotNull(comparable35);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        java.util.List list13 = timeSeries1.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries1.addChangeListener(seriesChangeListener14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond17.getLastMillisecond(calendar18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem21.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem21.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod23, (java.lang.Number) 1);
        try {
            timeSeries1.add(timeSeriesDataItem25, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries2.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        int int12 = month9.compareTo((java.lang.Object) "");
        java.lang.String str13 = month9.toString();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries15.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        long long21 = day20.getLastMillisecond();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries24.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        long long30 = day29.getLastMillisecond();
        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day29);
        timeSeries24.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries15.addAndOrUpdate(timeSeries24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond36.getLastMillisecond(calendar37);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) (-1.0d));
        int int41 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass46 = fixedMillisecond45.getClass();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond36, "Last", "Last", (java.lang.Class) wildcardClass46);
        boolean boolean48 = month9.equals((java.lang.Object) timeSeries47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month9.previous();
        java.lang.Number number50 = timeSeries2.getValue(regularTimePeriod49);
        try {
            timeSeries2.setMaximumItemCount((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "December 1969" + "'", str13.equals("December 1969"));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208441600001L) + "'", long21 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2208441600001L) + "'", long30 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNull(number50);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        int int18 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries10.removeChangeListener(seriesChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.lang.String str10 = year9.toString();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        org.jfree.data.time.Year year8 = month6.getYear();
        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getLastMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        boolean boolean24 = timeSeries13.equals((java.lang.Object) seriesException22);
        java.lang.String str25 = seriesException22.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) seriesException22);
        int int27 = month6.compareTo((java.lang.Object) seriesException22);
        java.lang.String str28 = month6.toString();
        long long29 = month6.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        boolean boolean32 = month6.equals((java.lang.Object) fixedMillisecond31);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2208441600001L) + "'", long19 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str25.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "June 2019" + "'", str28.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        long long9 = day6.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        java.util.List list13 = timeSeries1.getItems();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        int int17 = day16.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 100L);
        int int20 = day16.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Last");
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(2);
        int int51 = spreadsheetDate50.getMonth();
        java.util.Date date52 = spreadsheetDate50.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(2);
        int int55 = spreadsheetDate54.getMonth();
        boolean boolean56 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SerialDate serialDate57 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate50);
        int int58 = spreadsheetDate50.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        long long14 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date17);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date17, timeZone20);
        int int22 = month21.getYearValue();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month21, (double) 1L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str10 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        int int18 = day16.getYear();
        int int19 = day16.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.previous();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries22.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        long long28 = day27.getLastMillisecond();
        timeSeries22.delete((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        long long37 = day36.getLastMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day36);
        timeSeries31.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries22.addAndOrUpdate(timeSeries31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getLastMillisecond(calendar44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) (-1.0d));
        int int48 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass53 = fixedMillisecond52.getClass();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond43, "Last", "Last", (java.lang.Class) wildcardClass53);
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod20, (java.lang.Class) wildcardClass53);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, "", "7-January-1900", (java.lang.Class) wildcardClass53);
        timeSeries56.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-2208441600001L) + "'", long28 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208441600001L) + "'", long37 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass53);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setNotify(true);
        int int5 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        long long13 = day12.getLastMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
        org.jfree.data.general.SeriesException seriesException16 = new org.jfree.data.general.SeriesException("");
        java.lang.String str17 = seriesException16.toString();
        boolean boolean18 = timeSeries7.equals((java.lang.Object) seriesException16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date21 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        int int26 = month23.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month23);
        java.lang.Class class28 = timeSeries7.getTimePeriodClass();
        java.util.Collection collection29 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str17.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(collection29);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date6 = fixedMillisecond5.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass9 = fixedMillisecond8.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date17, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone19);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date6, timeZone19);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date6, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date2, timeZone23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date28 = fixedMillisecond27.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date28);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        int int33 = month30.compareTo((java.lang.Object) "");
        int int34 = month30.getYearValue();
        org.jfree.data.time.Year year35 = month30.getYear();
        java.util.Date date36 = year35.getStart();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries38.setRangeDescription("");
        java.lang.Comparable comparable41 = timeSeries38.getKey();
        java.lang.String str42 = timeSeries38.getDomainDescription();
        int int43 = timeSeries38.getItemCount();
        boolean boolean44 = timeSeries38.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date47 = fixedMillisecond46.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        long long49 = year48.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries51.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
        long long57 = day56.getLastMillisecond();
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) day56);
        int int59 = year48.compareTo((java.lang.Object) day56);
        timeSeries38.setKey((java.lang.Comparable) int59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        java.lang.Class class68 = timeSeries38.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date71 = fixedMillisecond70.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date74 = fixedMillisecond73.getTime();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date74, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date71, timeZone76);
        int int79 = year35.compareTo((java.lang.Object) timeZone76);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date2, timeZone76);
        long long81 = year80.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
        org.junit.Assert.assertNotNull(year35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + comparable41 + "' != '" + '4' + "'", comparable41.equals('4'));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 28799999L + "'", long49 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-2208441600001L) + "'", long57 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 10L + "'", long64 == 10L);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-31507200000L) + "'", long81 == (-31507200000L));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        int int6 = year3.getYear();
        long long7 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year3.next();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries8.addChangeListener(seriesChangeListener22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setDescription("org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getLastMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        int int18 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries10.removeChangeListener(seriesChangeListener19);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries10.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(12, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str18 = serialDate17.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate13.getEndOfCurrentMonth(serialDate17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date22 = fixedMillisecond21.getStart();
        java.lang.Class<?> wildcardClass23 = fixedMillisecond21.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate17, (java.lang.Class) wildcardClass23);
        java.lang.Class<?> wildcardClass25 = timeSeries24.getClass();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, (java.lang.Class) wildcardClass25);
        long long27 = timeSeries26.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getMonth();
        java.util.Date date9 = spreadsheetDate7.toDate();
        int int10 = year5.compareTo((java.lang.Object) spreadsheetDate7);
        int int11 = spreadsheetDate7.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.next();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        int int2 = month0.getMonth();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        timeSeries1.setKey((java.lang.Comparable) 4);
        java.lang.String str16 = timeSeries1.getDescription();
        timeSeries1.removeAgedItems(0L, true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Tuesday" + "'", str1.equals("Tuesday"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str10 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date14 = fixedMillisecond13.getStart();
        java.lang.Class<?> wildcardClass15 = fixedMillisecond13.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate9, (java.lang.Class) wildcardClass15);
        java.lang.String str17 = serialDate9.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6-January-1900" + "'", str17.equals("6-January-1900"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) boolean18);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        java.lang.String str33 = seriesException32.toString();
        boolean boolean34 = timeSeries23.equals((java.lang.Object) seriesException32);
        boolean boolean35 = timeSeries23.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date38 = fixedMillisecond37.getStart();
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond37.getLastMillisecond(calendar39);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries42.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(serialDate46);
        long long48 = day47.getLastMillisecond();
        timeSeries42.delete((org.jfree.data.time.RegularTimePeriod) day47);
        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (org.jfree.data.time.RegularTimePeriod) day47);
        timeSeries23.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries55.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(serialDate59);
        long long61 = day60.getLastMillisecond();
        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) day60);
        org.jfree.data.general.SeriesException seriesException64 = new org.jfree.data.general.SeriesException("");
        java.lang.String str65 = seriesException64.toString();
        boolean boolean66 = timeSeries55.equals((java.lang.Object) seriesException64);
        boolean boolean67 = timeSeries55.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date70 = fixedMillisecond69.getStart();
        java.util.Calendar calendar71 = null;
        long long72 = fixedMillisecond69.getLastMillisecond(calendar71);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries74.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(serialDate78);
        long long80 = day79.getLastMillisecond();
        timeSeries74.delete((org.jfree.data.time.RegularTimePeriod) day79);
        org.jfree.data.time.SerialDate serialDate82 = day79.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (org.jfree.data.time.RegularTimePeriod) day79);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries23.addAndOrUpdate(timeSeries55);
        timeSeries84.clear();
        java.util.Collection collection86 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries84);
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year();
        java.lang.String str88 = year87.toString();
        long long89 = year87.getLastMillisecond();
        int int90 = year87.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = year87.previous();
        try {
            timeSeries84.add(regularTimePeriod91, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str33.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-2208441600001L) + "'", long48 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-2208441600001L) + "'", long61 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str65.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-2208441600001L) + "'", long80 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertNotNull(collection86);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "2019" + "'", str88.equals("2019"));
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 2019 + "'", int90 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        long long4 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getFirstMillisecond(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.util.Date date8 = spreadsheetDate5.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date22 = fixedMillisecond21.getTime();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date19, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date11, timeZone24);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date11, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date8, timeZone28);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date8);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date47 = fixedMillisecond46.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date47);
        org.jfree.data.general.SeriesException seriesException51 = new org.jfree.data.general.SeriesException("");
        int int52 = month49.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) month49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month49.next();
        try {
            timeSeries31.add(regularTimePeriod54, (java.lang.Number) (-31));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = serialDate6.getEndOfCurrentMonth(serialDate19);
        boolean boolean21 = year3.equals((java.lang.Object) serialDate20);
        java.util.Date date22 = year3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        int int27 = fixedMillisecond24.compareTo((java.lang.Object) false);
        java.util.Date date28 = fixedMillisecond24.getEnd();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date22, timeZone29);
        int int32 = month31.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener22);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.getDataItem(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-6));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries1.getRangeDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            int int23 = timeSeries1.getIndex(regularTimePeriod22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setMaximumItemCount(7);
        java.lang.Object obj13 = timeSeries10.clone();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries15.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        long long21 = day20.getLastMillisecond();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) day20);
        org.jfree.data.general.SeriesException seriesException24 = new org.jfree.data.general.SeriesException("");
        java.lang.String str25 = seriesException24.toString();
        boolean boolean26 = timeSeries15.equals((java.lang.Object) seriesException24);
        boolean boolean27 = timeSeries15.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date30 = fixedMillisecond29.getStart();
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond29.getLastMillisecond(calendar31);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries34.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
        long long40 = day39.getLastMillisecond();
        timeSeries34.delete((org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.SerialDate serialDate42 = day39.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) day39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (double) 31);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208441600001L) + "'", long21 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str25.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-2208441600001L) + "'", long40 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.util.Date date26 = fixedMillisecond21.getStart();
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191429348L + "'", long24 == 1560191429348L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(date26);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener11);
        timeSeries1.clear();
        timeSeries1.setMaximumItemAge((long) 9999);
        timeSeries1.setRangeDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        timeSeries1.setMaximumItemCount(0);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + '4' + "'", comparable8.equals('4'));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries13.addChangeListener(seriesChangeListener26);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries29.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate33);
        long long35 = day34.getLastMillisecond();
        timeSeries29.delete((org.jfree.data.time.RegularTimePeriod) day34);
        org.jfree.data.time.SerialDate serialDate37 = day34.getSerialDate();
        int int38 = day34.getDayOfMonth();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries40.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
        long long46 = day45.getLastMillisecond();
        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) day45);
        org.jfree.data.general.SeriesException seriesException49 = new org.jfree.data.general.SeriesException("");
        java.lang.String str50 = seriesException49.toString();
        boolean boolean51 = timeSeries40.equals((java.lang.Object) seriesException49);
        java.util.List list52 = timeSeries40.getItems();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        int int56 = day55.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (double) 100L);
        java.lang.String str59 = day55.toString();
        long long60 = day55.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate61 = day55.getSerialDate();
        int int62 = day34.compareTo((java.lang.Object) day55);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day55, (double) 1560191361412L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Millisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-2208441600001L) + "'", long35 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-2208441600001L) + "'", long46 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str50.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "6-January-1900" + "'", str59.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-2208441600001L) + "'", long60 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        int int8 = month5.compareTo((java.lang.Object) "");
        int int9 = month5.getYearValue();
        org.jfree.data.time.Year year10 = month5.getYear();
        java.util.Date date11 = year10.getStart();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        java.lang.Comparable comparable16 = timeSeries13.getKey();
        java.lang.String str17 = timeSeries13.getDomainDescription();
        int int18 = timeSeries13.getItemCount();
        boolean boolean19 = timeSeries13.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date22 = fixedMillisecond21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        long long24 = year23.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries26.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        long long32 = day31.getLastMillisecond();
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) day31);
        int int34 = year23.compareTo((java.lang.Object) day31);
        timeSeries13.setKey((java.lang.Comparable) int34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) (-1.0d));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
        java.lang.Class class43 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date46 = fixedMillisecond45.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date49 = fixedMillisecond48.getTime();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date49, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date46, timeZone51);
        int int54 = year10.compareTo((java.lang.Object) timeZone51);
        try {
            org.jfree.data.time.Month month55 = new org.jfree.data.time.Month((-25566), year10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + '4' + "'", comparable16.equals('4'));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2208441600001L) + "'", long32 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertNotNull(class43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        long long3 = fixedMillisecond0.getSerialIndex();
//        long long4 = fixedMillisecond0.getMiddleMillisecond();
//        long long5 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560191429512L + "'", long2 == 1560191429512L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191429512L + "'", long3 == 1560191429512L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560191429512L + "'", long4 == 1560191429512L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191429512L + "'", long5 == 1560191429512L);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-6));
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        java.util.Collection collection22 = timeSeries1.getTimePeriods();
        boolean boolean23 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate18);
        boolean boolean23 = spreadsheetDate13.isOnOrBefore(serialDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears(3, serialDate28);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560191423119L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        try {
            timeSeries1.delete(regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.lang.String str4 = spreadsheetDate1.getDescription();
        int int5 = spreadsheetDate1.getYYYY();
        int int6 = spreadsheetDate1.toSerial();
        int int7 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        java.lang.String str16 = serialDate15.getDescription();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(0, serialDate15);
        boolean boolean18 = spreadsheetDate1.isBefore(serialDate15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        java.util.Date date39 = spreadsheetDate9.toDate();
        java.util.Date date40 = spreadsheetDate9.toDate();
        java.lang.String str41 = spreadsheetDate9.getDescription();
        int int42 = spreadsheetDate9.toSerial();
        int int43 = spreadsheetDate9.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate5.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        java.util.Date date24 = spreadsheetDate22.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        boolean boolean28 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate31);
        boolean boolean36 = spreadsheetDate26.isOnOrBefore(serialDate31);
        int int37 = spreadsheetDate26.toSerial();
        int int38 = spreadsheetDate26.getMonth();
        int int39 = spreadsheetDate26.getYYYY();
        boolean boolean40 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        java.util.Date date44 = spreadsheetDate42.toDate();
        int int45 = spreadsheetDate42.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass48 = fixedMillisecond47.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        boolean boolean50 = spreadsheetDate42.equals((java.lang.Object) class49);
        int int51 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        int int54 = spreadsheetDate53.getMonth();
        java.util.Date date55 = spreadsheetDate53.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        int int58 = spreadsheetDate57.getMonth();
        boolean boolean59 = spreadsheetDate53.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2);
        int int62 = spreadsheetDate61.getMonth();
        java.util.Date date63 = spreadsheetDate61.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(2);
        int int66 = spreadsheetDate65.getMonth();
        boolean boolean67 = spreadsheetDate61.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate65);
        boolean boolean68 = spreadsheetDate53.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate61);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(2);
        int int71 = spreadsheetDate70.getMonth();
        java.util.Date date72 = spreadsheetDate70.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(2);
        int int75 = spreadsheetDate74.getMonth();
        boolean boolean76 = spreadsheetDate70.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate74);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(2);
        int int79 = spreadsheetDate78.getMonth();
        java.util.Date date80 = spreadsheetDate78.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        int int83 = spreadsheetDate82.getMonth();
        boolean boolean84 = spreadsheetDate78.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate82);
        boolean boolean85 = spreadsheetDate70.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate78);
        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day(serialDate87);
        boolean boolean90 = spreadsheetDate61.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate70, serialDate87, (int) ' ');
        int int91 = spreadsheetDate70.getYYYY();
        int int92 = spreadsheetDate70.toSerial();
        int int93 = spreadsheetDate70.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate94 = spreadsheetDate42.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate70);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1900 + "'", int91 == 1900);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2 + "'", int92 == 2);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 2 + "'", int93 == 2);
        org.junit.Assert.assertNotNull(serialDate94);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        long long24 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries26.setRangeDescription("");
        java.lang.Comparable comparable29 = timeSeries26.getKey();
        java.lang.String str30 = timeSeries26.getDomainDescription();
        int int31 = timeSeries26.getItemCount();
        boolean boolean32 = timeSeries26.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date35 = fixedMillisecond34.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        long long37 = year36.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries39.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate43);
        long long45 = day44.getLastMillisecond();
        timeSeries39.delete((org.jfree.data.time.RegularTimePeriod) day44);
        int int47 = year36.compareTo((java.lang.Object) day44);
        timeSeries26.setKey((java.lang.Comparable) int47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) (-1.0d));
        timeSeries26.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        java.lang.Class class56 = timeSeries26.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date59 = fixedMillisecond58.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date62 = fixedMillisecond61.getTime();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date62, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date59, timeZone64);
        timeSeries1.add(regularTimePeriod66, (double) (byte) 0);
        boolean boolean69 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + '4' + "'", comparable29.equals('4'));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 28799999L + "'", long37 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-2208441600001L) + "'", long45 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertNotNull(class56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Number number23 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        timeSeries1.setDomainDescription("October");
        timeSeries1.removeAgedItems(1560191361412L, false);
        java.util.List list29 = timeSeries1.getItems();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener30);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        java.lang.String str34 = timeSeries33.getDomainDescription();
        timeSeries33.removeAgedItems(true);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Last" + "'", str34.equals("Last"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries13);
        java.lang.String str15 = timeSeries13.getDomainDescription();
        try {
            timeSeries13.setMaximumItemAge((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        java.util.Date date65 = spreadsheetDate63.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        int int68 = spreadsheetDate67.getMonth();
        boolean boolean69 = spreadsheetDate63.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str72 = serialDate71.getDescription();
        org.jfree.data.time.SerialDate serialDate73 = spreadsheetDate67.getEndOfCurrentMonth(serialDate71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date76 = fixedMillisecond75.getStart();
        java.lang.Class<?> wildcardClass77 = fixedMillisecond75.getClass();
        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate71, (java.lang.Class) wildcardClass77);
        boolean boolean79 = spreadsheetDate40.isOnOrBefore(serialDate71);
        int int80 = spreadsheetDate40.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(2);
        int int83 = spreadsheetDate82.getMonth();
        java.util.Date date84 = spreadsheetDate82.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate86 = new org.jfree.data.time.SpreadsheetDate(2);
        int int87 = spreadsheetDate86.getMonth();
        boolean boolean88 = spreadsheetDate82.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate86);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str91 = serialDate90.getDescription();
        org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate86.getEndOfCurrentMonth(serialDate90);
        boolean boolean93 = spreadsheetDate40.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate86);
        int int94 = spreadsheetDate86.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1900 + "'", int80 == 1900);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNull(str91);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy(30, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) (byte) 0);
        java.lang.Number number9 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) 0 + "'", number9.equals((byte) 0));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        int int14 = year3.compareTo((java.lang.Object) day11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, 0.0d);
        int int17 = day11.getDayOfMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        try {
            timeSeries1.delete((-6), (-572));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries2.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries2.getRangeDescription();
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        java.lang.String str9 = timeSeries2.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        int int5 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries16.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        long long22 = day21.getLastMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        java.lang.String str26 = seriesException25.toString();
        boolean boolean27 = timeSeries16.equals((java.lang.Object) seriesException25);
        java.lang.String str28 = seriesException25.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException25);
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries35.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        long long41 = day40.getLastMillisecond();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        boolean boolean46 = timeSeries35.equals((java.lang.Object) seriesException44);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) seriesException44);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException44);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries50.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getLastMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) day55);
        org.jfree.data.general.SeriesException seriesException59 = new org.jfree.data.general.SeriesException("");
        java.lang.String str60 = seriesException59.toString();
        boolean boolean61 = timeSeries50.equals((java.lang.Object) seriesException59);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries65.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(serialDate69);
        long long71 = day70.getLastMillisecond();
        timeSeries65.delete((org.jfree.data.time.RegularTimePeriod) day70);
        org.jfree.data.general.SeriesException seriesException74 = new org.jfree.data.general.SeriesException("");
        java.lang.String str75 = seriesException74.toString();
        boolean boolean76 = timeSeries65.equals((java.lang.Object) seriesException74);
        java.lang.String str77 = seriesException74.toString();
        timePeriodFormatException63.addSuppressed((java.lang.Throwable) seriesException74);
        seriesException59.addSuppressed((java.lang.Throwable) timePeriodFormatException63);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException81 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray82 = timePeriodFormatException81.getSuppressed();
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries84.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate88 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(serialDate88);
        long long90 = day89.getLastMillisecond();
        timeSeries84.delete((org.jfree.data.time.RegularTimePeriod) day89);
        org.jfree.data.general.SeriesException seriesException93 = new org.jfree.data.general.SeriesException("");
        java.lang.String str94 = seriesException93.toString();
        boolean boolean95 = timeSeries84.equals((java.lang.Object) seriesException93);
        timePeriodFormatException81.addSuppressed((java.lang.Throwable) seriesException93);
        timePeriodFormatException63.addSuppressed((java.lang.Throwable) seriesException93);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException63);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208441600001L) + "'", long22 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str26.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str28.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2208441600001L) + "'", long41 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2208441600001L) + "'", long56 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str60.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-2208441600001L) + "'", long71 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str75.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str77.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray82);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + (-2208441600001L) + "'", long90 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str94.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date7, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date2, timeZone10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date19 = fixedMillisecond18.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass22 = fixedMillisecond21.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date27 = fixedMillisecond26.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date30, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date27, timeZone32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date19, timeZone32);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date15, timeZone32);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date2, timeZone32);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.String str3 = fixedMillisecond1.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date49 = spreadsheetDate17.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(date49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        java.lang.String str8 = month4.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries19.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        long long25 = day24.getLastMillisecond();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day24);
        timeSeries19.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries10.addAndOrUpdate(timeSeries19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-1.0d));
        int int36 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass41 = fixedMillisecond40.getClass();
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond31, "Last", "Last", (java.lang.Class) wildcardClass41);
        boolean boolean43 = month4.equals((java.lang.Object) timeSeries42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month4.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 2019);
        java.lang.String str47 = seriesChangeEvent46.toString();
        java.lang.String str48 = seriesChangeEvent46.toString();
        java.lang.Object obj49 = seriesChangeEvent46.getSource();
        java.lang.Object obj50 = seriesChangeEvent46.getSource();
        java.lang.Object obj51 = seriesChangeEvent46.getSource();
        int int52 = month4.compareTo(obj51);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2208441600001L) + "'", long25 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str47.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str48.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + obj49 + "' != '" + 2019 + "'", obj49.equals(2019));
        org.junit.Assert.assertTrue("'" + obj50 + "' != '" + 2019 + "'", obj50.equals(2019));
        org.junit.Assert.assertTrue("'" + obj51 + "' != '" + 2019 + "'", obj51.equals(2019));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }
}

