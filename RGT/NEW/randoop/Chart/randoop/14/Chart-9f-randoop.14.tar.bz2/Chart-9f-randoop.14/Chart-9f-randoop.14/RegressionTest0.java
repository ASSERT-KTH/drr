import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 1);
        try {
            timeSeries1.add(timeSeriesDataItem9, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries3 = null;
        try {
            java.util.Collection collection4 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        try {
            timeSeries1.update((int) (byte) -1, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        try {
            java.lang.Number number6 = timeSeries1.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0d));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1.0d) + "'", obj2.equals((-1.0d)));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        try {
            org.jfree.data.time.SerialDate serialDate4 = serialDate1.getFollowingDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) (-1.0d));
        try {
            timeSeries1.add(timeSeriesDataItem9, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.TimeZone timeZone3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date4 = fixedMillisecond3.getStart();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getLastMillisecond(calendar5);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) (-1), false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date7 = fixedMillisecond6.getStart();
        java.lang.Class<?> wildcardClass8 = fixedMillisecond6.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.next();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) -1, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Third" + "'", str1.equals("Third"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date7 = fixedMillisecond6.getStart();
        java.lang.Class<?> wildcardClass8 = fixedMillisecond6.getClass();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getLastMillisecond(calendar6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 1);
        try {
            timeSeries1.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getFollowingDayOfWeek((int) (byte) 1);
        java.lang.String str5 = serialDate4.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7-January-1900" + "'", str5.equals("7-January-1900"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        try {
            timeSeries1.update(0, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        try {
            int int4 = spreadsheetDate1.compareTo((java.lang.Object) "Third");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        long long13 = day12.getLastMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
        int int15 = year4.compareTo((java.lang.Object) day12);
        try {
            org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(0, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("6-January-1900");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.util.Calendar calendar10 = null;
        try {
            month4.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getNearestDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getFollowingDayOfWeek((int) (byte) 1);
        java.lang.String str5 = serialDate4.getDescription();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getFollowingDayOfWeek((int) (byte) 1);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            month0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2958465, (org.jfree.data.time.SerialDate) spreadsheetDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 2);
        java.lang.Number number9 = null;
        timeSeriesDataItem5.setValue(number9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 9999, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.util.Calendar calendar17 = null;
        try {
            month4.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.lang.String str28 = fixedMillisecond22.toString();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str28.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getFirstMillisecond();
        java.lang.String str13 = day6.toString();
        int int14 = day6.getMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208528000000L) + "'", long12 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "6-January-1900" + "'", str13.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("1-January-1970");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        boolean boolean21 = timeSeries1.getNotify();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) 5, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2147483647, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2147483647");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        int int21 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        java.lang.String str5 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Time");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        java.lang.Class<?> wildcardClass4 = fixedMillisecond2.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries(comparable0, (java.lang.Class) wildcardClass4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        try {
            java.lang.Number number5 = timeSeries1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.util.Calendar calendar26 = null;
        try {
            year23.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getFirstMillisecond();
        java.lang.String str13 = day6.toString();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day6.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208528000000L) + "'", long12 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "6-January-1900" + "'", str13.equals("6-January-1900"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        java.util.Calendar calendar8 = null;
        try {
            month4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        long long10 = year9.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = timeSeries1.createCopy((int) 'a', (-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getLastMillisecond(calendar30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 1);
        try {
            timeSeries20.add(timeSeriesDataItem33, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate3);
        java.lang.String str8 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(0, serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate7.getPreviousDayOfWeek((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate1.getEndOfCurrentMonth(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate15.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        int int39 = spreadsheetDate9.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond22.getMiddleMillisecond(calendar28);
        long long30 = fixedMillisecond22.getFirstMillisecond();
        long long31 = fixedMillisecond22.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getFollowingDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getFirstMillisecond();
        java.lang.String str13 = day6.toString();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day6.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208528000000L) + "'", long12 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "6-January-1900" + "'", str13.equals("6-January-1900"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str10 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate5.getPreviousDayOfWeek(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, (-6));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-6), 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str10 = serialDate9.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate5.getEndOfCurrentMonth(serialDate9);
        serialDate9.setDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries13.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.next();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond0.previous();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560191348838L + "'", long3 == 1560191348838L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date9, timeZone12);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1969");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        java.util.List list8 = timeSeries1.getItems();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            day2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener4);
        long long6 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) ' ', 0, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        int int2 = timeSeries1.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getLastMillisecond(calendar5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) (-1.0d));
        try {
            timeSeries1.add(timeSeriesDataItem8, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-6));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-461) + "'", int1 == (-461));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.lang.String str5 = day3.toString();
        long long6 = day3.getSerialIndex();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "31-December-1969" + "'", str5.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 25568L + "'", long6 == 25568L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        java.lang.String str11 = day6.toString();
        int int12 = day6.getYear();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6-January-1900" + "'", str11.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year23.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        boolean boolean7 = year3.equals((java.lang.Object) (-2649600000L));
        java.lang.String str8 = year3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        java.lang.String str7 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems((-31507200000L), false);
        java.lang.Object obj11 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(true);
        java.lang.String str6 = timeSeries1.getDescription();
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "August -1" + "'", str3.equals("August -1"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        long long22 = month17.getFirstMillisecond();
        int int23 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month17.previous();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2649600000L) + "'", long22 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        int int14 = year3.compareTo((java.lang.Object) day11);
        int int15 = day11.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        boolean boolean45 = timeSeries33.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date48 = fixedMillisecond47.getStart();
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries52.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        long long58 = day57.getLastMillisecond();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.addAndOrUpdate(timeSeries33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = null;
        try {
            timeSeries62.add(timeSeriesDataItem63, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208441600001L) + "'", long58 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries62);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        int int10 = year9.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.lang.String str4 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        long long9 = month4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month4.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2649600000L) + "'", long9 == (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        try {
//            java.lang.Number number27 = timeSeries10.getValue((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191353930L + "'", long24 == 1560191353930L);
//        org.junit.Assert.assertNull(number25);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getMonth();
        java.util.Date date5 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getMonth();
        boolean boolean9 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str12 = serialDate11.getDescription();
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate7.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(2);
        int int17 = spreadsheetDate16.getMonth();
        java.util.Date date18 = spreadsheetDate16.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        int int21 = spreadsheetDate20.getMonth();
        boolean boolean22 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate25.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate25);
        boolean boolean30 = spreadsheetDate20.isOnOrBefore(serialDate25);
        boolean boolean31 = spreadsheetDate7.isOn(serialDate25);
        try {
            org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 10, serialDate25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond15.getMiddleMillisecond(calendar30);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        int int2 = timeSeries1.getItemCount();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getFollowingDayOfWeek((int) (byte) 1);
        timeSeries1.setKey((java.lang.Comparable) (byte) 1);
        timeSeries1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-25566));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month17.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate18.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate60, 2019);
        java.lang.Object obj65 = null;
        try {
            int int66 = spreadsheetDate60.compareTo(obj65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        long long10 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries1.addChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getLastMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
        timeSeries13.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener23);
        boolean boolean25 = timeSeries1.equals((java.lang.Object) timeSeries13);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2208441600001L) + "'", long19 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10, 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        boolean boolean45 = timeSeries33.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date48 = fixedMillisecond47.getStart();
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries52.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        long long58 = day57.getLastMillisecond();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.addAndOrUpdate(timeSeries33);
        try {
            timeSeries33.delete((int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208441600001L) + "'", long58 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries62);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208571200001L) + "'", long7 == (-2208571200001L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) (-25566));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        java.lang.Comparable comparable9 = timeSeries6.getKey();
        java.lang.String str10 = timeSeries6.getDomainDescription();
        int int11 = timeSeries6.getItemCount();
        boolean boolean12 = timeSeries6.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries19.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate23);
        long long25 = day24.getLastMillisecond();
        timeSeries19.delete((org.jfree.data.time.RegularTimePeriod) day24);
        int int27 = year16.compareTo((java.lang.Object) day24);
        timeSeries6.setKey((java.lang.Comparable) int27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (-1.0d));
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond30.next();
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + '4' + "'", comparable9.equals('4'));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28799999L + "'", long17 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-2208441600001L) + "'", long25 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month17.next();
        long long24 = month17.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = month17.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-458));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -458");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.lang.String str3 = spreadsheetDate1.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate1.getPreviousDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        long long6 = year4.getSerialIndex();
        boolean boolean8 = year4.equals((java.lang.Object) (-2649600000L));
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 100, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        timeSeriesDataItem5.setValue((java.lang.Number) (-31507200000L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getLastMillisecond(calendar4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem7.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem7);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(31, (int) (byte) 0, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        int int37 = month34.compareTo((java.lang.Object) "");
        int int38 = month34.getYearValue();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int38, class39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date44 = fixedMillisecond43.getStart();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (java.lang.Number) 10L);
        java.util.Collection collection49 = timeSeries40.getTimePeriods();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(collection49);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1969);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("October");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        int int37 = month34.compareTo((java.lang.Object) "");
        int int38 = month34.getYearValue();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int38, class39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries40);
        try {
            timeSeries40.removeAgedItems((long) 1900, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate1);
        java.util.Calendar calendar6 = null;
        try {
            day5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries1.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        boolean boolean11 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriods();
        try {
            java.lang.Number number16 = timeSeries1.getValue(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list8 = timeSeries7.getItems();
        boolean boolean9 = year3.equals((java.lang.Object) timeSeries7);
        try {
            timeSeries7.setMaximumItemCount((-6));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setKey((java.lang.Comparable) 2);
        timeSeries1.setDescription("31-December-1969");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        try {
            timeSeries13.setMaximumItemAge((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("August -1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        java.util.List list13 = timeSeries1.getItems();
        try {
            timeSeries1.update(9999, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate18.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate60, 2019);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        int int68 = spreadsheetDate67.getMonth();
        java.util.Date date69 = spreadsheetDate67.toDate();
        java.util.Date date70 = spreadsheetDate67.toDate();
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean72 = spreadsheetDate60.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int73 = spreadsheetDate67.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2 + "'", int73 == 2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date24 = fixedMillisecond23.getStart();
        java.lang.Class<?> wildcardClass25 = fixedMillisecond23.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.next();
        boolean boolean28 = fixedMillisecond23.equals((java.lang.Object) "7-January-1900");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond23.previous();
        try {
            timeSeries20.add(regularTimePeriod29, (double) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-1), 1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        int int4 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        long long37 = day36.getLastMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
        java.lang.String str40 = day36.toString();
        int int41 = day36.getDayOfMonth();
        long long42 = day36.getFirstMillisecond();
        int int43 = day36.getDayOfMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day36, (double) 7, false);
        try {
            java.lang.Number number48 = timeSeries1.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208441600001L) + "'", long37 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "6-January-1900" + "'", str40.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208528000000L) + "'", long42 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date6 = fixedMillisecond5.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date6, timeZone8);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate18.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate60, 2019);
        org.jfree.data.time.SerialDate serialDate65 = null;
        try {
            boolean boolean66 = spreadsheetDate60.isOn(serialDate65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (-6));
        boolean boolean5 = month2.equals((java.lang.Object) fixedMillisecond4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries18.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        java.util.Calendar calendar30 = null;
        try {
            day25.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str11 = serialDate10.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries15.removeAgedItems(false);
        boolean boolean18 = timeSeries15.isEmpty();
        java.lang.String str19 = timeSeries15.getDomainDescription();
        java.util.Collection collection20 = timeSeries15.getTimePeriods();
        java.lang.String str21 = timeSeries15.getDomainDescription();
        try {
            int int22 = spreadsheetDate6.compareTo((java.lang.Object) timeSeries15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setDescription("org.jfree.data.general.SeriesException: ");
        timeSeries10.setKey((java.lang.Comparable) (short) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            timeSeries10.add(regularTimePeriod15, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        long long5 = year3.getSerialIndex();
        long long6 = year3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year3.previous();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-458), 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = month13.compareTo((java.lang.Object) "");
        int int17 = month13.getYearValue();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int17, class18);
        timeSeries19.setMaximumItemCount(7);
        boolean boolean22 = timeSeriesDataItem5.equals((java.lang.Object) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int62 = spreadsheetDate40.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.String str17 = month4.toString();
        long long18 = month4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-2649600000L) + "'", long18 == (-2649600000L));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond3.next();
        java.util.Calendar calendar6 = null;
        fixedMillisecond3.peg(calendar6);
        try {
            timeSeries1.setKey((java.lang.Comparable) calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener2);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
        int int29 = month26.compareTo((java.lang.Object) "");
        java.lang.String str30 = month26.toString();
        try {
            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month26, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "December 1969" + "'", str30.equals("December 1969"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list2 = timeSeries1.getItems();
        timeSeries1.setDescription("10-June-2019");
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem5.getPeriod();
        timeSeriesDataItem5.setValue((java.lang.Number) (-1.0d));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        boolean boolean11 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriods();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate(regularTimePeriod15, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(collection14);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        boolean boolean27 = fixedMillisecond21.equals((java.lang.Object) 1L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond21.getLastMillisecond(calendar28);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191361412L + "'", long24 == 1560191361412L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560191361412L + "'", long29 == 1560191361412L);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list8 = timeSeries7.getItems();
        boolean boolean9 = year3.equals((java.lang.Object) timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date12 = fixedMillisecond11.getStart();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        long long14 = year13.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        int int16 = timeSeries7.getIndex(regularTimePeriod15);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1969L + "'", long14 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.String str1 = year0.toString();
        java.util.Calendar calendar2 = null;
        try {
            year0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "2019" + "'", str1.equals("2019"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        java.lang.Class class22 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date25 = fixedMillisecond24.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        timeSeries1.delete(regularTimePeriod26);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = timeSeries1.getTimePeriod(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, (-461));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int2 = month0.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        try {
            timeSeries1.delete(2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.String str2 = year1.toString();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((-459), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1969, (-461));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date2);
        java.util.Date date5 = fixedMillisecond4.getTime();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0d));
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond25.next();
        java.util.Date date32 = fixedMillisecond25.getEnd();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-2208571200001L));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        timeSeries8.setKey((java.lang.Comparable) (-2649600000L));
        int int24 = timeSeries8.getMaximumItemCount();
        try {
            java.lang.Number number26 = timeSeries8.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = serialDate6.getEndOfCurrentMonth(serialDate19);
        boolean boolean21 = year3.equals((java.lang.Object) serialDate20);
        java.util.Date date22 = year3.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        long long9 = month4.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month4.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2649600000L) + "'", long9 == (-2649600000L));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Number number23 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
//        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        long long36 = day34.getLastMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int40 = spreadsheetDate39.getMonth();
//        java.util.Date date41 = spreadsheetDate39.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int44 = spreadsheetDate43.getMonth();
//        boolean boolean45 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int48 = spreadsheetDate47.getMonth();
//        java.util.Date date49 = spreadsheetDate47.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int52 = spreadsheetDate51.getMonth();
//        boolean boolean53 = spreadsheetDate47.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        boolean boolean54 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.util.Date date57 = fixedMillisecond56.getStart();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day58.next();
//        boolean boolean60 = spreadsheetDate39.equals((java.lang.Object) regularTimePeriod59);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, (org.jfree.data.time.SerialDate) spreadsheetDate39);
//        boolean boolean62 = day34.equals((java.lang.Object) 3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries33.getDataItem((org.jfree.data.time.RegularTimePeriod) day34);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560236399999L + "'", long36 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str5 = serialDate4.getDescription();
        int int6 = month2.compareTo((java.lang.Object) serialDate4);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1969);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        int int14 = year3.compareTo((java.lang.Object) day11);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day11.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        int int4 = timeSeries1.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.getDataItem(regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2);
        int int4 = spreadsheetDate3.getMonth();
        java.util.Date date5 = spreadsheetDate3.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(2);
        int int8 = spreadsheetDate7.getMonth();
        boolean boolean9 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str12 = serialDate11.getDescription();
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate7.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        try {
            org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((-461), serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647);
        java.util.Calendar calendar7 = null;
        try {
            month3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2649600000L) + "'", long4 == (-2649600000L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        int int4 = day2.compareTo((java.lang.Object) 100.0d);
        java.lang.String str5 = day2.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "6-January-1900" + "'", str5.equals("6-January-1900"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        java.lang.Number number7 = timeSeriesDataItem5.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        org.jfree.data.time.SerialDate serialDate6 = day2.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.previous();
        long long8 = day2.getLastMillisecond();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2208441600001L) + "'", long8 == (-2208441600001L));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        timeSeries8.setRangeDescription("6-January-1900");
        timeSeries8.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15);
        java.lang.Object obj19 = timeSeries18.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        java.lang.String str5 = spreadsheetDate2.getDescription();
        int int6 = spreadsheetDate2.getYYYY();
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = serialDate40.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.time.SerialDate serialDate53 = day50.getSerialDate();
        org.jfree.data.time.SerialDate serialDate54 = serialDate40.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(2);
        int int57 = spreadsheetDate56.getMonth();
        java.util.Date date58 = spreadsheetDate56.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(2);
        int int61 = spreadsheetDate60.getMonth();
        boolean boolean62 = spreadsheetDate56.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean64 = spreadsheetDate18.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate60, 2019);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(2);
        int int68 = spreadsheetDate67.getMonth();
        java.util.Date date69 = spreadsheetDate67.toDate();
        java.util.Date date70 = spreadsheetDate67.toDate();
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean72 = spreadsheetDate60.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date75 = fixedMillisecond74.getStart();
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date75);
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month(date75);
        try {
            int int78 = spreadsheetDate67.compareTo((java.lang.Object) date75);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(date75);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month4.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = timeSeries9.isEmpty();
        java.lang.String str13 = timeSeries9.getDomainDescription();
        java.util.Collection collection14 = timeSeries9.getTimePeriods();
        java.lang.String str15 = timeSeries9.getDomainDescription();
        timeSeries9.removeAgedItems((-31507200000L), false);
        java.lang.Class class19 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, "hi!", "January", class19);
        try {
            timeSeries20.update((-461), (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(7, (-6));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj2 = timeSeries1.clone();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = serialDate6.getEndOfCurrentMonth(serialDate19);
        boolean boolean21 = year3.equals((java.lang.Object) serialDate20);
        java.lang.String str22 = year3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969" + "'", str22.equals("1969"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem15.getPeriod();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        boolean boolean7 = timeSeries1.equals((java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.previous();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getSerialIndex();
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((-459), year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond28.getLastMillisecond(calendar29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeriesDataItem32.getPeriod();
        try {
            timeSeries23.add(timeSeriesDataItem32);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (-1.0d));
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        timeSeriesDataItem11.setValue((java.lang.Number) (byte) 0);
        try {
            timeSeries1.add(timeSeriesDataItem11, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0d) + "'", number12.equals((-1.0d)));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getMonth();
        java.util.Date date12 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean16 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
        int int20 = spreadsheetDate19.getMonth();
        java.util.Date date21 = spreadsheetDate19.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        boolean boolean25 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        java.util.Date date29 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        boolean boolean33 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean39 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate36, (int) ' ');
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        org.jfree.data.time.SerialDate serialDate44 = serialDate41.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries46.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(serialDate50);
        long long52 = day51.getLastMillisecond();
        timeSeries46.delete((org.jfree.data.time.RegularTimePeriod) day51);
        org.jfree.data.time.SerialDate serialDate54 = day51.getSerialDate();
        org.jfree.data.time.SerialDate serialDate55 = serialDate41.getEndOfCurrentMonth(serialDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate(2);
        int int58 = spreadsheetDate57.getMonth();
        java.util.Date date59 = spreadsheetDate57.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(2);
        int int62 = spreadsheetDate61.getMonth();
        boolean boolean63 = spreadsheetDate57.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean65 = spreadsheetDate19.isInRange(serialDate55, (org.jfree.data.time.SerialDate) spreadsheetDate61, 2019);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(2);
        int int69 = spreadsheetDate68.getMonth();
        java.util.Date date70 = spreadsheetDate68.toDate();
        java.util.Date date71 = spreadsheetDate68.toDate();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate68);
        boolean boolean73 = spreadsheetDate61.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addDays(9, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int75 = spreadsheetDate61.getYYYY();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-2208441600001L) + "'", long52 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1900 + "'", int75 == 1900);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        int int16 = spreadsheetDate5.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate18 = spreadsheetDate5.getNearestDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.lang.Object obj2 = null;
        boolean boolean3 = timeSeries1.equals(obj2);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = timeSeries1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        int int32 = timeSeries1.getMaximumItemCount();
        timeSeries1.setRangeDescription("Last");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(2);
        int int5 = spreadsheetDate4.getMonth();
        java.util.Date date6 = spreadsheetDate4.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(2);
        int int9 = spreadsheetDate8.getMonth();
        boolean boolean10 = spreadsheetDate4.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str13 = serialDate12.getDescription();
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate8.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        java.util.Date date19 = spreadsheetDate17.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        boolean boolean23 = spreadsheetDate17.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = serialDate26.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate26);
        boolean boolean31 = spreadsheetDate21.isOnOrBefore(serialDate26);
        boolean boolean32 = spreadsheetDate8.isOn(serialDate26);
        int int33 = spreadsheetDate1.compare(serialDate26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-5) + "'", int33 == (-5));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.List list6 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        java.lang.Comparable comparable11 = timeSeries8.getKey();
        java.lang.String str12 = timeSeries8.getDomainDescription();
        int int13 = timeSeries8.getItemCount();
        boolean boolean14 = timeSeries8.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date17 = fixedMillisecond16.getStart();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries21.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        long long27 = day26.getLastMillisecond();
        timeSeries21.delete((org.jfree.data.time.RegularTimePeriod) day26);
        int int29 = year18.compareTo((java.lang.Object) day26);
        timeSeries8.setKey((java.lang.Comparable) int29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) (-1.0d));
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.getDataItem(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + '4' + "'", comparable11.equals('4'));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-2208441600001L) + "'", long27 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate2, "Last", "", class12);
        long long14 = timeSeries13.getMaximumItemAge();
        long long15 = timeSeries13.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries13.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem5.getPeriod();
        java.lang.String str7 = regularTimePeriod6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        java.util.Date date4 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = timeSeries9.isEmpty();
        java.lang.String str13 = timeSeries9.getDomainDescription();
        java.util.Collection collection14 = timeSeries9.getTimePeriods();
        java.lang.String str15 = timeSeries9.getDomainDescription();
        timeSeries9.removeAgedItems((-31507200000L), false);
        java.lang.Class class19 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date4, "hi!", "January", class19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries20.removePropertyChangeListener(propertyChangeListener21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list9 = timeSeries8.getItems();
        int int10 = fixedMillisecond5.compareTo((java.lang.Object) list9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate18);
        boolean boolean23 = spreadsheetDate13.isOnOrBefore(serialDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        try {
            org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-5), serialDate28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate28);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) false);
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        try {
            timeSeries20.update((int) (short) 100, (java.lang.Number) 1560191341622L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        boolean boolean16 = spreadsheetDate6.isOnOrBefore(serialDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        boolean boolean20 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        java.util.Date date24 = spreadsheetDate22.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        boolean boolean28 = spreadsheetDate22.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
        org.jfree.data.time.SerialDate serialDate34 = serialDate31.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate31);
        boolean boolean36 = spreadsheetDate26.isOnOrBefore(serialDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(2);
        int int39 = spreadsheetDate38.getMonth();
        java.util.Date date40 = spreadsheetDate38.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        boolean boolean44 = spreadsheetDate38.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str47 = serialDate46.getDescription();
        org.jfree.data.time.SerialDate serialDate48 = spreadsheetDate42.getEndOfCurrentMonth(serialDate46);
        boolean boolean49 = spreadsheetDate18.isInRange(serialDate31, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        int int50 = spreadsheetDate18.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, (org.jfree.data.time.SerialDate) spreadsheetDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month17.next();
        long long24 = month17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-2649600000L) + "'", long24 == (-2649600000L));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        int int21 = timeSeries1.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeriesDataItem29.getPeriod();
        try {
            timeSeries1.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-451) + "'", int1 == (-451));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.util.Date date49 = spreadsheetDate17.toDate();
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        long long53 = day52.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
        long long57 = day56.getSerialIndex();
        int int58 = day52.compareTo((java.lang.Object) long57);
        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass61 = fixedMillisecond60.getClass();
        java.lang.Class class62 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass61);
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int58, class62);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent64 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries63);
        boolean boolean65 = spreadsheetDate17.equals((java.lang.Object) timeSeries63);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 7L + "'", long53 == 7L);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 7L + "'", long57 == 7L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int17 = spreadsheetDate9.toSerial();
        org.jfree.data.time.SerialDate serialDate18 = null;
        try {
            boolean boolean19 = spreadsheetDate9.isAfter(serialDate18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1969, (-461), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        long long22 = month17.getFirstMillisecond();
        int int24 = month17.compareTo((java.lang.Object) 1969L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2649600000L) + "'", long22 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.lang.String str4 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(3, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
//        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.next();
//        long long5 = fixedMillisecond3.getFirstMillisecond();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond3);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560191373955L + "'", long5 == 1560191373955L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        boolean boolean22 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.util.Calendar calendar24 = null;
        try {
            day23.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        org.jfree.data.general.SeriesException seriesException20 = new org.jfree.data.general.SeriesException("");
        int int21 = month18.compareTo((java.lang.Object) "");
        int int22 = month18.getYearValue();
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries13.addChangeListener(seriesChangeListener26);
        int int28 = timeSeries13.getItemCount();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        timeSeries1.setNotify(false);
        boolean boolean11 = timeSeries1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.removeChangeListener(seriesChangeListener12);
        java.util.Collection collection14 = timeSeries1.getTimePeriods();
        timeSeries1.setNotify(true);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        java.lang.Class class19 = timeSeries1.getTimePeriodClass();
        timeSeries1.setMaximumItemAge((long) (short) 10);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass5 = fixedMillisecond4.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date13, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date10, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date2, timeZone15);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date2, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(timeZone19);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(2);
        int int21 = spreadsheetDate20.getMonth();
        java.util.Date date22 = spreadsheetDate20.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        boolean boolean26 = spreadsheetDate20.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(serialDate29);
        org.jfree.data.time.SerialDate serialDate32 = serialDate29.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate29);
        boolean boolean34 = spreadsheetDate24.isOnOrBefore(serialDate29);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = serialDate36.getFollowingDayOfWeek((int) (byte) 1);
        int int40 = spreadsheetDate24.compare(serialDate39);
        java.lang.String str41 = serialDate39.getDescription();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears(11, serialDate39);
        boolean boolean43 = timeSeriesDataItem15.equals((java.lang.Object) 11);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-6) + "'", int40 == (-6));
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        int int4 = timeSeries1.getItemCount();
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries7.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        long long13 = day12.getLastMillisecond();
        timeSeries7.delete((org.jfree.data.time.RegularTimePeriod) day12);
        java.util.Collection collection15 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date18 = fixedMillisecond17.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        long long20 = year19.getLastMillisecond();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year19, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208441600001L) + "'", long13 == (-2208441600001L));
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28799999L + "'", long20 == 28799999L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-461));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-572) + "'", int1 == (-572));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener14);
        int int16 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        long long10 = month4.getFirstMillisecond();
        long long11 = month4.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month4.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2649600000L) + "'", long10 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-2649600000L) + "'", long11 == (-2649600000L));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate16, "Last", "", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        long long29 = timeSeries27.getMaximumItemAge();
        boolean boolean30 = timeSeries1.equals((java.lang.Object) timeSeries27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("");
        int int38 = month35.compareTo((java.lang.Object) "");
        java.lang.String str39 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries41.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
        long long47 = day46.getLastMillisecond();
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries50.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getLastMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) day55);
        timeSeries50.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries41.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        int int67 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass72 = fixedMillisecond71.getClass();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond62, "Last", "Last", (java.lang.Class) wildcardClass72);
        boolean boolean74 = month35.equals((java.lang.Object) timeSeries73);
        java.util.Collection collection75 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries73);
        int int76 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "December 1969" + "'", str39.equals("December 1969"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2208441600001L) + "'", long47 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2208441600001L) + "'", long56 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 10L + "'", long64 == 10L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(collection75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2147483647 + "'", int76 == 2147483647);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.SerialDate serialDate4 = serialDate1.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries6.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        long long12 = day11.getLastMillisecond();
        timeSeries6.delete((org.jfree.data.time.RegularTimePeriod) day11);
        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = serialDate1.getEndOfCurrentMonth(serialDate14);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate1.getFollowingDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208441600001L) + "'", long12 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) fixedMillisecond5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        java.lang.String str8 = fixedMillisecond5.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str8.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        long long3 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62083209600001L) + "'", long3 == (-62083209600001L));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        java.util.List list13 = timeSeries1.getItems();
        java.lang.String str14 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 10, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October" + "'", str2.equals("October"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries1.setMaximumItemCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        timeSeries1.setKey((java.lang.Comparable) 2);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        try {
            timeSeries1.update(5, (java.lang.Number) 1560191361412L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        int int2 = timeSeries1.getItemCount();
        try {
            timeSeries1.update((int) (byte) 100, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.lang.Object obj2 = null;
        boolean boolean3 = timeSeries1.equals(obj2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(8, (int) (byte) -1);
        int int7 = month6.getYearValue();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month6, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        timeSeries20.removeAgedItems((long) 2, false);
        try {
            timeSeries20.delete(31, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        timeSeries1.setDescription("");
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.general.SeriesException seriesException42 = new org.jfree.data.general.SeriesException("");
        java.lang.String str43 = seriesException42.toString();
        boolean boolean44 = timeSeries33.equals((java.lang.Object) seriesException42);
        boolean boolean45 = timeSeries33.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date48 = fixedMillisecond47.getStart();
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond47.getLastMillisecond(calendar49);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries52.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        long long58 = day57.getLastMillisecond();
        timeSeries52.delete((org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) day57);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.addAndOrUpdate(timeSeries33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date65 = fixedMillisecond64.getStart();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date65);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date65, timeZone68);
        int int70 = month69.getYearValue();
        try {
            timeSeries62.add((org.jfree.data.time.RegularTimePeriod) month69, (java.lang.Number) 1560191339344L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str43.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-2208441600001L) + "'", long58 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1969 + "'", int70 == 1969);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar4 = null;
        try {
            year3.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar26 = null;
        fixedMillisecond25.peg(calendar26);
        long long28 = fixedMillisecond25.getLastMillisecond();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond25.getMiddleMillisecond(calendar29);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0f), true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        org.jfree.data.time.Year year8 = month6.getYear();
        boolean boolean9 = timeSeriesDataItem5.equals((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem5.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate17 = serialDate10.getFollowingDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        int int4 = day2.compareTo((java.lang.Object) 100.0d);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        java.lang.Number number23 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) month22);
        timeSeries1.setDomainDescription("October");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries1.removeChangeListener(seriesChangeListener26);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.util.List list8 = timeSeries7.getItems();
        boolean boolean9 = year3.equals((java.lang.Object) timeSeries7);
        int int10 = year3.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        long long37 = day36.getLastMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
        java.lang.String str40 = day36.toString();
        int int41 = day36.getDayOfMonth();
        long long42 = day36.getFirstMillisecond();
        int int43 = day36.getDayOfMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day36, (double) 7, false);
        int int47 = day36.getYear();
        java.util.Calendar calendar48 = null;
        try {
            day36.peg(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208441600001L) + "'", long37 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "6-January-1900" + "'", str40.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208528000000L) + "'", long42 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date11 = fixedMillisecond10.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("");
        int int16 = month13.compareTo((java.lang.Object) "");
        int int17 = month13.getYearValue();
        org.jfree.data.time.Year year18 = month13.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getLastMillisecond(calendar21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 1);
        int int25 = month13.compareTo((java.lang.Object) timeSeriesDataItem24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (org.jfree.data.time.RegularTimePeriod) month13);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener27);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int62 = spreadsheetDate40.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        int int6 = year3.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) "7-January-1900");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        long long8 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-451));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        long long27 = day26.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day26, (double) 10);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries31.removeAgedItems(false);
        boolean boolean34 = timeSeries31.isEmpty();
        java.lang.String str35 = timeSeries31.getDomainDescription();
        java.util.Collection collection36 = timeSeries31.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries38.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate42);
        long long44 = day43.getLastMillisecond();
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.general.SeriesException seriesException47 = new org.jfree.data.general.SeriesException("");
        java.lang.String str48 = seriesException47.toString();
        boolean boolean49 = timeSeries38.equals((java.lang.Object) seriesException47);
        boolean boolean50 = timeSeries38.getNotify();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries31.addAndOrUpdate(timeSeries38);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries1.addAndOrUpdate(timeSeries51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date55 = fixedMillisecond54.getStart();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
        org.jfree.data.general.SeriesException seriesException59 = new org.jfree.data.general.SeriesException("");
        int int60 = month57.compareTo((java.lang.Object) "");
        int int61 = month57.getYearValue();
        org.jfree.data.time.Year year62 = month57.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getLastMillisecond(calendar65);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (java.lang.Number) 1);
        int int69 = month57.compareTo((java.lang.Object) timeSeriesDataItem68);
        java.lang.Object obj70 = timeSeriesDataItem68.clone();
        try {
            timeSeries51.add(timeSeriesDataItem68, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 7L + "'", long27 == 7L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-2208441600001L) + "'", long44 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str48.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1969 + "'", int61 == 1969);
        org.junit.Assert.assertNotNull(year62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(obj70);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        org.jfree.data.general.SeriesException seriesException27 = new org.jfree.data.general.SeriesException("");
        int int28 = month25.compareTo((java.lang.Object) "");
        int int29 = month25.getYearValue();
        org.jfree.data.time.Year year30 = month25.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond32.getLastMillisecond(calendar33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1);
        int int37 = month25.compareTo((java.lang.Object) timeSeriesDataItem36);
        java.lang.Number number38 = timeSeriesDataItem36.getValue();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem36);
        java.lang.Number number40 = timeSeriesDataItem36.getValue();
        java.lang.Number number41 = timeSeriesDataItem36.getValue();
        try {
            timeSeries10.add(timeSeriesDataItem36, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
        org.junit.Assert.assertNotNull(year30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 10L + "'", long34 == 10L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1 + "'", number38.equals(1));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 1 + "'", number40.equals(1));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1 + "'", number41.equals(1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-458));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        java.util.Date date7 = regularTimePeriod6.getStart();
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod6);
        long long9 = fixedMillisecond1.getFirstMillisecond();
        long long10 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate13 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day6.previous();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208528000000L) + "'", long12 == (-2208528000000L));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getSerialIndex();
        int int8 = day2.compareTo((java.lang.Object) long7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        java.lang.String str20 = seriesException19.toString();
        boolean boolean21 = timeSeries10.equals((java.lang.Object) seriesException19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass24 = fixedMillisecond23.getClass();
        int int26 = fixedMillisecond23.compareTo((java.lang.Object) false);
        boolean boolean27 = timeSeries10.equals((java.lang.Object) false);
        timeSeries10.setKey((java.lang.Comparable) 7L);
        boolean boolean30 = day2.equals((java.lang.Object) 7L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        java.lang.Class<?> wildcardClass34 = fixedMillisecond32.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond32.next();
        int int36 = day2.compareTo((java.lang.Object) fixedMillisecond32);
        long long37 = fixedMillisecond32.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7L + "'", long7 == 7L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str20.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        timeSeries2.setDomainDescription("");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        java.lang.String str8 = month4.toString();
        java.util.Date date9 = month4.getEnd();
        org.jfree.data.time.Year year10 = month4.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.Object obj3 = timeSeries2.clone();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) year4);
        boolean boolean7 = year4.equals((java.lang.Object) 1560191339344L);
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(0, year4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(2);
        int int64 = spreadsheetDate63.getMonth();
        java.util.Date date65 = spreadsheetDate63.toDate();
        int int66 = spreadsheetDate63.getMonth();
        boolean boolean67 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate63);
        java.util.Date date68 = spreadsheetDate63.toDate();
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance(date68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(serialDate69);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        boolean boolean16 = spreadsheetDate6.isOnOrBefore(serialDate11);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek((int) (byte) 1);
        int int22 = spreadsheetDate6.compare(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        java.util.Date date26 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.getMonth();
        boolean boolean30 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        int int33 = spreadsheetDate32.getMonth();
        java.util.Date date34 = spreadsheetDate32.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2);
        int int37 = spreadsheetDate36.getMonth();
        boolean boolean38 = spreadsheetDate32.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        java.util.Date date43 = spreadsheetDate41.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        int int46 = spreadsheetDate45.getMonth();
        boolean boolean47 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        int int50 = spreadsheetDate49.getMonth();
        java.util.Date date51 = spreadsheetDate49.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        int int54 = spreadsheetDate53.getMonth();
        boolean boolean55 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate58);
        boolean boolean61 = spreadsheetDate32.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, serialDate58, (int) ' ');
        boolean boolean62 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date65 = fixedMillisecond64.getTime();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        int int67 = spreadsheetDate6.compare(serialDate66);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate66);
        java.lang.String str69 = serialDate66.getDescription();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-6) + "'", int22 == (-6));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-25566) + "'", int67 == (-25566));
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNull(str69);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate16, "Last", "", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        long long29 = timeSeries27.getMaximumItemAge();
        boolean boolean30 = timeSeries1.equals((java.lang.Object) timeSeries27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("");
        int int38 = month35.compareTo((java.lang.Object) "");
        java.lang.String str39 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries41.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
        long long47 = day46.getLastMillisecond();
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries50.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getLastMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) day55);
        timeSeries50.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries41.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        int int67 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass72 = fixedMillisecond71.getClass();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond62, "Last", "Last", (java.lang.Class) wildcardClass72);
        boolean boolean74 = month35.equals((java.lang.Object) timeSeries73);
        java.util.Collection collection75 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries73);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(serialDate77);
        long long79 = day78.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = day78.next();
        int int81 = timeSeries73.getIndex((org.jfree.data.time.RegularTimePeriod) day78);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "December 1969" + "'", str39.equals("December 1969"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2208441600001L) + "'", long47 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2208441600001L) + "'", long56 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 10L + "'", long64 == 10L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(collection75);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-2208441600001L) + "'", long79 == (-2208441600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        java.util.List list13 = timeSeries1.getItems();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        int int17 = day16.getDayOfMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 100L);
        java.lang.String str20 = day16.toString();
        long long21 = day16.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate22 = day16.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "6-January-1900" + "'", str20.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-2208441600001L) + "'", long21 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        java.lang.Class class19 = timeSeries1.getTimePeriodClass();
        timeSeries1.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries1.createCopy(0, 0);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        java.util.Date date10 = year9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        int int12 = year9.getYear();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        int int4 = spreadsheetDate1.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass7 = fixedMillisecond6.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        boolean boolean9 = spreadsheetDate1.equals((java.lang.Object) class8);
        try {
            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate1.getPreviousDayOfWeek((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries16.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        long long22 = day21.getLastMillisecond();
        timeSeries16.delete((org.jfree.data.time.RegularTimePeriod) day21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        java.lang.String str26 = seriesException25.toString();
        boolean boolean27 = timeSeries16.equals((java.lang.Object) seriesException25);
        java.lang.String str28 = seriesException25.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException25);
        seriesException10.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException32.getSuppressed();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries35.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        long long41 = day40.getLastMillisecond();
        timeSeries35.delete((org.jfree.data.time.RegularTimePeriod) day40);
        org.jfree.data.general.SeriesException seriesException44 = new org.jfree.data.general.SeriesException("");
        java.lang.String str45 = seriesException44.toString();
        boolean boolean46 = timeSeries35.equals((java.lang.Object) seriesException44);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) seriesException44);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException44);
        java.lang.Throwable[] throwableArray49 = timePeriodFormatException14.getSuppressed();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2208441600001L) + "'", long22 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str26.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str28.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-2208441600001L) + "'", long41 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str45.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        java.lang.String str11 = day6.toString();
        long long12 = day6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6-January-1900" + "'", str11.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208528000000L) + "'", long12 == (-2208528000000L));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries2.removeAgedItems(false);
        java.lang.Number number6 = null;
        try {
            timeSeries2.update(4, number6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        java.lang.Class class19 = timeSeries1.getTimePeriodClass();
        java.lang.String str20 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem35.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = timeSeriesDataItem35.getPeriod();
        boolean boolean38 = timeSeries29.equals((java.lang.Object) regularTimePeriod37);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener2);
        timeSeries1.setMaximumItemAge(1L);
        java.lang.Class class6 = timeSeries1.getTimePeriodClass();
        java.lang.Object obj7 = null;
        boolean boolean8 = timeSeries1.equals(obj7);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("January");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1.0d));
        java.lang.Number number6 = timeSeriesDataItem5.getValue();
        timeSeriesDataItem5.setValue((java.lang.Number) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeriesDataItem5.getPeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.next();
        boolean boolean15 = timeSeriesDataItem5.equals((java.lang.Object) regularTimePeriod14);
        java.lang.Object obj16 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0d) + "'", number6.equals((-1.0d)));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate16, "Last", "", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        long long29 = timeSeries27.getMaximumItemAge();
        boolean boolean30 = timeSeries1.equals((java.lang.Object) timeSeries27);
        java.util.Collection collection31 = timeSeries1.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond33.next();
        try {
            timeSeries1.add(regularTimePeriod36, (double) (-31507200000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1-January-1970");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        java.lang.String str5 = regularTimePeriod4.toString();
        java.lang.Class<?> wildcardClass6 = regularTimePeriod4.getClass();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1-January-1970" + "'", str5.equals("1-January-1970"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate28.getEndOfCurrentMonth(serialDate41);
        boolean boolean43 = year25.equals((java.lang.Object) serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) 7);
        java.util.Calendar calendar47 = null;
        try {
            day44.peg(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        java.util.Date date39 = spreadsheetDate9.toDate();
        java.util.Date date40 = spreadsheetDate9.toDate();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        java.util.Date date44 = fixedMillisecond43.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass47 = fixedMillisecond46.getClass();
        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date52 = fixedMillisecond51.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date55 = fixedMillisecond54.getTime();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month(date55, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date52, timeZone57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date44, timeZone57);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date44, timeZone61);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(date40, timeZone61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(class48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(timeZone61);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 100);
        long long2 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        int int6 = month3.getMonth();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2649600000L) + "'", long4 == (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(2);
        int int11 = spreadsheetDate10.getMonth();
        java.util.Date date12 = spreadsheetDate10.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(2);
        int int15 = spreadsheetDate14.getMonth();
        boolean boolean16 = spreadsheetDate10.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean17 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2);
        int int20 = spreadsheetDate19.getMonth();
        java.util.Date date21 = spreadsheetDate19.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        boolean boolean25 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        java.util.Date date29 = spreadsheetDate27.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        boolean boolean33 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        boolean boolean39 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate36, (int) ' ');
        java.util.Date date40 = spreadsheetDate10.toDate();
        java.util.Date date41 = spreadsheetDate10.toDate();
        java.lang.String str42 = spreadsheetDate10.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        int int46 = spreadsheetDate45.getMonth();
        java.util.Date date47 = spreadsheetDate45.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        int int50 = spreadsheetDate49.getMonth();
        boolean boolean51 = spreadsheetDate45.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str54 = serialDate53.getDescription();
        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate49.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean57 = spreadsheetDate10.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        try {
            org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, (org.jfree.data.time.SerialDate) spreadsheetDate49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        int int21 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date24 = fixedMillisecond23.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate28.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries33.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        long long39 = day38.getLastMillisecond();
        timeSeries33.delete((org.jfree.data.time.RegularTimePeriod) day38);
        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
        org.jfree.data.time.SerialDate serialDate42 = serialDate28.getEndOfCurrentMonth(serialDate41);
        boolean boolean43 = year25.equals((java.lang.Object) serialDate42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate42);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) 7);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (double) 10.0f);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-2208441600001L) + "'", long39 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        int int37 = month34.compareTo((java.lang.Object) "");
        int int38 = month34.getYearValue();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int38, class39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries40);
        timeSeries40.setRangeDescription("Last");
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date46 = fixedMillisecond45.getStart();
        java.lang.Class<?> wildcardClass47 = fixedMillisecond45.getClass();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, (java.lang.Number) 1560191341622L);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries1.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        long long7 = day6.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries10.setRangeDescription("");
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        long long16 = day15.getLastMillisecond();
//        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        timeSeries10.setRangeDescription("Time");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond21.getMiddleMillisecond(calendar23);
//        java.lang.Number number25 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond21.getLastMillisecond(calendar26);
//        long long28 = fixedMillisecond21.getFirstMillisecond();
//        long long29 = fixedMillisecond21.getSerialIndex();
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560191389035L + "'", long24 == 1560191389035L);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560191389035L + "'", long27 == 1560191389035L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560191389035L + "'", long28 == 1560191389035L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560191389035L + "'", long29 == 1560191389035L);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 7L + "'", long10 == 7L);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int2 = spreadsheetDate1.getMonth();
//        java.util.Date date3 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int6 = spreadsheetDate5.getMonth();
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
//        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int18 = spreadsheetDate17.getMonth();
//        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int22 = spreadsheetDate21.getMonth();
//        java.util.Date date23 = spreadsheetDate21.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int26 = spreadsheetDate25.getMonth();
//        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
//        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
//        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
//        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int38 = spreadsheetDate37.getMonth();
//        java.util.Date date39 = spreadsheetDate37.toDate();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
//        int int42 = spreadsheetDate41.getMonth();
//        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
//        java.lang.String str46 = serialDate45.getDescription();
//        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
//        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
//        timeSeries50.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timeSeries50.removePropertyChangeListener(propertyChangeListener53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) day55);
//        boolean boolean58 = spreadsheetDate17.equals((java.lang.Object) day55);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        int int6 = timeSeries1.getItemCount();
        boolean boolean7 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date10 = fixedMillisecond9.getStart();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        int int22 = year11.compareTo((java.lang.Object) day19);
        timeSeries1.setKey((java.lang.Comparable) int22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0d));
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        java.lang.Class class31 = timeSeries1.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertNotNull(class31);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        long long30 = day25.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-2208484800001L) + "'", long30 == (-2208484800001L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries31.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        long long37 = day36.getLastMillisecond();
        timeSeries31.delete((org.jfree.data.time.RegularTimePeriod) day36);
        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
        java.lang.String str40 = day36.toString();
        int int41 = day36.getDayOfMonth();
        long long42 = day36.getFirstMillisecond();
        int int43 = day36.getDayOfMonth();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day36, (double) 7, false);
        long long47 = day36.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-2208441600001L) + "'", long37 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "6-January-1900" + "'", str40.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-2208528000000L) + "'", long42 == (-2208528000000L));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2208484800001L) + "'", long47 == (-2208484800001L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date7 = fixedMillisecond6.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("");
        int int12 = month9.compareTo((java.lang.Object) "");
        int int13 = month9.getYearValue();
        org.jfree.data.time.Year year14 = month9.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 1);
        int int21 = month9.compareTo((java.lang.Object) timeSeriesDataItem20);
        try {
            timeSeries1.add(timeSeriesDataItem20);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) 2147483647);
        java.lang.String str7 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.previous();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2649600000L) + "'", long4 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 1969" + "'", str7.equals("December 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.addAndOrUpdate(timeSeries23);
        timeSeries26.setRangeDescription("December 1969");
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate17.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        long long8 = month4.getSerialIndex();
        java.util.Date date9 = month4.getStart();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 23640L + "'", long8 == 23640L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        java.lang.Class<?> wildcardClass3 = fixedMillisecond1.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.next();
        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) "7-January-1900");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        java.lang.String str11 = day6.toString();
        int int12 = day6.getDayOfMonth();
        long long13 = day6.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day6.next();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day6.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "6-January-1900" + "'", str11.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2208484800001L) + "'", long13 == (-2208484800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        int int3 = day2.getMonth();
        int int4 = day2.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries23.removePropertyChangeListener(propertyChangeListener24);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries20.addAndOrUpdate(timeSeries23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries23.addChangeListener(seriesChangeListener27);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(timeSeries26);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        java.lang.String str10 = day6.toString();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getFirstMillisecond();
        java.util.Date date13 = day6.getStart();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        int int15 = day14.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6-January-1900" + "'", str10.equals("6-January-1900"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-2208528000000L) + "'", long12 == (-2208528000000L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.next();
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.previous();
        java.util.Date date7 = regularTimePeriod6.getStart();
        int int8 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod6);
        long long9 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond1.getFirstMillisecond(calendar10);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(true);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        org.jfree.data.time.Year year8 = month6.getYear();
        int int9 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: org.jfree.data.general.SeriesException: ");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries13.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        long long19 = day18.getLastMillisecond();
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) day18);
        org.jfree.data.general.SeriesException seriesException22 = new org.jfree.data.general.SeriesException("");
        java.lang.String str23 = seriesException22.toString();
        boolean boolean24 = timeSeries13.equals((java.lang.Object) seriesException22);
        java.lang.String str25 = seriesException22.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) seriesException22);
        int int27 = month6.compareTo((java.lang.Object) seriesException22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        java.util.Date date32 = spreadsheetDate30.toDate();
        java.util.Date date33 = spreadsheetDate30.toDate();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        int int35 = month6.compareTo((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2208441600001L) + "'", long19 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str23.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str25.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-6));
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-6L) + "'", long3 == (-6L));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, number6);
        java.lang.Object obj8 = timeSeriesDataItem7.clone();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1969L + "'", long5 == 1969L);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        java.lang.Comparable comparable4 = timeSeries1.getKey();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass8 = fixedMillisecond7.getClass();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            int int11 = timeSeries1.getIndex(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '4' + "'", comparable4.equals('4'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 28799999L + "'", long4 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate11.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate11);
        boolean boolean16 = spreadsheetDate6.isOnOrBefore(serialDate11);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getFollowingDayOfWeek((int) (byte) 1);
        int int22 = spreadsheetDate6.compare(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(2);
        int int25 = spreadsheetDate24.getMonth();
        java.util.Date date26 = spreadsheetDate24.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(2);
        int int29 = spreadsheetDate28.getMonth();
        boolean boolean30 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(2);
        int int33 = spreadsheetDate32.getMonth();
        java.util.Date date34 = spreadsheetDate32.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(2);
        int int37 = spreadsheetDate36.getMonth();
        boolean boolean38 = spreadsheetDate32.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate36);
        boolean boolean39 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        java.util.Date date43 = spreadsheetDate41.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(2);
        int int46 = spreadsheetDate45.getMonth();
        boolean boolean47 = spreadsheetDate41.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(2);
        int int50 = spreadsheetDate49.getMonth();
        java.util.Date date51 = spreadsheetDate49.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(2);
        int int54 = spreadsheetDate53.getMonth();
        boolean boolean55 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean56 = spreadsheetDate41.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate58);
        boolean boolean61 = spreadsheetDate32.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate41, serialDate58, (int) ' ');
        boolean boolean62 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(2);
        int int65 = spreadsheetDate64.getMonth();
        java.util.Date date66 = spreadsheetDate64.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(2);
        int int69 = spreadsheetDate68.getMonth();
        boolean boolean70 = spreadsheetDate64.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str73 = serialDate72.getDescription();
        org.jfree.data.time.SerialDate serialDate74 = spreadsheetDate68.getEndOfCurrentMonth(serialDate72);
        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date77 = fixedMillisecond76.getStart();
        java.lang.Class<?> wildcardClass78 = fixedMillisecond76.getClass();
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate72, (java.lang.Class) wildcardClass78);
        boolean boolean80 = spreadsheetDate41.isOnOrBefore(serialDate72);
        int int81 = spreadsheetDate41.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate84 = new org.jfree.data.time.SpreadsheetDate(2);
        int int85 = spreadsheetDate84.getMonth();
        java.util.Date date86 = spreadsheetDate84.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(2);
        int int89 = spreadsheetDate88.getMonth();
        boolean boolean90 = spreadsheetDate84.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        org.jfree.data.time.SerialDate serialDate92 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str93 = serialDate92.getDescription();
        org.jfree.data.time.SerialDate serialDate94 = spreadsheetDate88.getEndOfCurrentMonth(serialDate92);
        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean96 = spreadsheetDate41.isOnOrAfter(serialDate95);
        org.jfree.data.time.SerialDate serialDate97 = org.jfree.data.time.SerialDate.addDays(8, serialDate95);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-6) + "'", int22 == (-6));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2 + "'", int81 == 2);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertNotNull(serialDate95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(serialDate97);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(2);
        int int18 = spreadsheetDate17.getMonth();
        boolean boolean19 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(2);
        int int22 = spreadsheetDate21.getMonth();
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(2);
        int int26 = spreadsheetDate25.getMonth();
        boolean boolean27 = spreadsheetDate21.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(serialDate30);
        org.jfree.data.time.SerialDate serialDate33 = serialDate30.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate30);
        boolean boolean35 = spreadsheetDate25.isOnOrBefore(serialDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(2);
        int int38 = spreadsheetDate37.getMonth();
        java.util.Date date39 = spreadsheetDate37.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(2);
        int int42 = spreadsheetDate41.getMonth();
        boolean boolean43 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str46 = serialDate45.getDescription();
        org.jfree.data.time.SerialDate serialDate47 = spreadsheetDate41.getEndOfCurrentMonth(serialDate45);
        boolean boolean48 = spreadsheetDate17.isInRange(serialDate30, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int49 = spreadsheetDate17.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(2);
        int int52 = spreadsheetDate51.getMonth();
        java.util.Date date53 = spreadsheetDate51.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(2);
        int int56 = spreadsheetDate55.getMonth();
        boolean boolean57 = spreadsheetDate51.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate(2);
        int int60 = spreadsheetDate59.getMonth();
        java.util.Date date61 = spreadsheetDate59.toDate();
        boolean boolean62 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate51, (org.jfree.data.time.SerialDate) spreadsheetDate59);
        try {
            org.jfree.data.time.SerialDate serialDate64 = spreadsheetDate17.getNearestDayOfWeek((-461));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        timeSeries8.setKey((java.lang.Comparable) (-2649600000L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date26 = fixedMillisecond25.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26);
        org.jfree.data.general.SeriesException seriesException30 = new org.jfree.data.general.SeriesException("");
        int int31 = month28.compareTo((java.lang.Object) "");
        int int32 = month28.getYearValue();
        org.jfree.data.time.Year year33 = month28.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 1);
        int int40 = month28.compareTo((java.lang.Object) timeSeriesDataItem39);
        try {
            timeSeries8.update((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1969 + "'", int32 == 1969);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9, (-459));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        long long4 = year3.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate6.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries11.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        long long17 = day16.getLastMillisecond();
        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
        org.jfree.data.time.SerialDate serialDate20 = serialDate6.getEndOfCurrentMonth(serialDate19);
        boolean boolean21 = year3.equals((java.lang.Object) serialDate20);
        java.util.Date date22 = year3.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year3.previous();
        long long24 = year3.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date27 = fixedMillisecond26.getTime();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date27);
        boolean boolean30 = year3.equals((java.lang.Object) date27);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2208441600001L) + "'", long17 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31507200000L) + "'", long24 == (-31507200000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        timeSeries1.clear();
        timeSeries1.setMaximumItemCount(0);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        timeSeries1.removeAgedItems((-2208571200001L), false);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) -1, (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date16 = fixedMillisecond15.getStart();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries20.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        long long26 = day25.getLastMillisecond();
        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) day25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date32 = fixedMillisecond31.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32);
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("");
        int int37 = month34.compareTo((java.lang.Object) "");
        int int38 = month34.getYearValue();
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int38, class39);
        int int41 = fixedMillisecond15.compareTo((java.lang.Object) timeSeries40);
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond15.getFirstMillisecond(calendar42);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries45.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(serialDate49);
        long long51 = day50.getLastMillisecond();
        timeSeries45.delete((org.jfree.data.time.RegularTimePeriod) day50);
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("");
        java.lang.String str55 = seriesException54.toString();
        boolean boolean56 = timeSeries45.equals((java.lang.Object) seriesException54);
        boolean boolean57 = timeSeries45.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date60 = fixedMillisecond59.getStart();
        java.util.Calendar calendar61 = null;
        long long62 = fixedMillisecond59.getLastMillisecond(calendar61);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries64.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(serialDate68);
        long long70 = day69.getLastMillisecond();
        timeSeries64.delete((org.jfree.data.time.RegularTimePeriod) day69);
        org.jfree.data.time.SerialDate serialDate72 = day69.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) day69);
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date76 = fixedMillisecond75.getStart();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
        org.jfree.data.general.SeriesException seriesException80 = new org.jfree.data.general.SeriesException("");
        int int81 = month78.compareTo((java.lang.Object) "");
        int int82 = month78.getYearValue();
        java.lang.Class class83 = null;
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int82, class83);
        int int85 = fixedMillisecond59.compareTo((java.lang.Object) timeSeries84);
        boolean boolean86 = fixedMillisecond15.equals((java.lang.Object) fixedMillisecond59);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208441600001L) + "'", long26 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1969 + "'", int38 == 1969);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-2208441600001L) + "'", long51 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str55.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-2208441600001L) + "'", long70 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1969 + "'", int82 == 1969);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date3 = fixedMillisecond2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        int int8 = month5.compareTo((java.lang.Object) "");
        int int9 = month5.getYearValue();
        org.jfree.data.time.Year year10 = month5.getYear();
        java.lang.String str11 = year10.toString();
        try {
            org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(0, year10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate10);
        boolean boolean15 = spreadsheetDate5.isOnOrBefore(serialDate10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = serialDate17.getFollowingDayOfWeek((int) (byte) 1);
        int int21 = spreadsheetDate5.compare(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(2);
        int int24 = spreadsheetDate23.getMonth();
        java.util.Date date25 = spreadsheetDate23.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(2);
        int int28 = spreadsheetDate27.getMonth();
        boolean boolean29 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(2);
        int int32 = spreadsheetDate31.getMonth();
        java.util.Date date33 = spreadsheetDate31.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(2);
        int int36 = spreadsheetDate35.getMonth();
        boolean boolean37 = spreadsheetDate31.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        boolean boolean38 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(2);
        int int41 = spreadsheetDate40.getMonth();
        java.util.Date date42 = spreadsheetDate40.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(2);
        int int45 = spreadsheetDate44.getMonth();
        boolean boolean46 = spreadsheetDate40.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(2);
        int int49 = spreadsheetDate48.getMonth();
        java.util.Date date50 = spreadsheetDate48.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(2);
        int int53 = spreadsheetDate52.getMonth();
        boolean boolean54 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean55 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean60 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, serialDate57, (int) ' ');
        boolean boolean61 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int62 = spreadsheetDate40.getDayOfWeek();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-6) + "'", int21 == (-6));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, class9);
        timeSeries10.setMaximumItemCount(7);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        long long20 = day19.getLastMillisecond();
        timeSeries14.delete((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries23.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate27);
        long long29 = day28.getLastMillisecond();
        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) day28);
        timeSeries23.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries14.addAndOrUpdate(timeSeries23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) (-1.0d));
        int int40 = timeSeries33.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass45 = fixedMillisecond44.getClass();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond35, "Last", "Last", (java.lang.Class) wildcardClass45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date49 = fixedMillisecond48.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        long long51 = year50.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate53);
        org.jfree.data.time.SerialDate serialDate56 = serialDate53.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries58.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(serialDate62);
        long long64 = day63.getLastMillisecond();
        timeSeries58.delete((org.jfree.data.time.RegularTimePeriod) day63);
        org.jfree.data.time.SerialDate serialDate66 = day63.getSerialDate();
        org.jfree.data.time.SerialDate serialDate67 = serialDate53.getEndOfCurrentMonth(serialDate66);
        boolean boolean68 = year50.equals((java.lang.Object) serialDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(2);
        int int72 = spreadsheetDate71.getMonth();
        java.util.Date date73 = spreadsheetDate71.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(2);
        int int76 = spreadsheetDate75.getMonth();
        boolean boolean77 = spreadsheetDate71.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str80 = serialDate79.getDescription();
        org.jfree.data.time.SerialDate serialDate81 = spreadsheetDate75.getEndOfCurrentMonth(serialDate79);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate83 = serialDate67.getEndOfCurrentMonth(serialDate82);
        int int84 = fixedMillisecond35.compareTo((java.lang.Object) serialDate67);
        boolean boolean85 = timeSeries10.equals((java.lang.Object) fixedMillisecond35);
        long long86 = fixedMillisecond35.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-2208441600001L) + "'", long20 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-2208441600001L) + "'", long29 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1969L + "'", long51 == 1969L);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-2208441600001L) + "'", long64 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 10L + "'", long86 == 10L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2, 100, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries10.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        long long16 = day15.getLastMillisecond();
        timeSeries10.delete((org.jfree.data.time.RegularTimePeriod) day15);
        timeSeries10.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) (-1.0d));
        int int27 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass32 = fixedMillisecond31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond22, "Last", "Last", (java.lang.Class) wildcardClass32);
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-2208441600001L) + "'", long16 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(class34);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths((-572), (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass15 = fixedMillisecond14.getClass();
        int int17 = fixedMillisecond14.compareTo((java.lang.Object) false);
        boolean boolean18 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setKey((java.lang.Comparable) 7L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date23 = fixedMillisecond22.getStart();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getSerialIndex();
        long long26 = year24.getSerialIndex();
        boolean boolean28 = year24.equals((java.lang.Object) (-2649600000L));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 1560236399999L);
        try {
            timeSeries1.update((-435), (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1969L + "'", long25 == 1969L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1969L + "'", long26 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2);
        int int3 = spreadsheetDate2.getMonth();
        java.util.Date date4 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(2);
        int int7 = spreadsheetDate6.getMonth();
        boolean boolean8 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str11 = serialDate10.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = spreadsheetDate6.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(2, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate14 = null;
        try {
            boolean boolean15 = spreadsheetDate6.isOnOrAfter(serialDate14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date19 = fixedMillisecond18.getStart();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.next();
        boolean boolean22 = spreadsheetDate1.equals((java.lang.Object) regularTimePeriod21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("January");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        boolean boolean13 = timeSeries1.getNotify();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate16.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass25 = fixedMillisecond24.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate16, "Last", "", class26);
        long long28 = timeSeries27.getMaximumItemAge();
        long long29 = timeSeries27.getMaximumItemAge();
        boolean boolean30 = timeSeries1.equals((java.lang.Object) timeSeries27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date33 = fixedMillisecond32.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("");
        int int38 = month35.compareTo((java.lang.Object) "");
        java.lang.String str39 = month35.toString();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries41.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
        long long47 = day46.getLastMillisecond();
        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) day46);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries50.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        long long56 = day55.getLastMillisecond();
        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) day55);
        timeSeries50.setRangeDescription("Time");
        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries41.addAndOrUpdate(timeSeries50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar63 = null;
        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (java.lang.Number) (-1.0d));
        int int67 = timeSeries60.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass72 = fixedMillisecond71.getClass();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond62, "Last", "Last", (java.lang.Class) wildcardClass72);
        boolean boolean74 = month35.equals((java.lang.Object) timeSeries73);
        java.util.Collection collection75 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries73);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(2);
        int int78 = spreadsheetDate77.getMonth();
        java.util.Date date79 = spreadsheetDate77.toDate();
        int int80 = spreadsheetDate77.getMonth();
        boolean boolean81 = timeSeries73.equals((java.lang.Object) int80);
        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        java.lang.Object obj84 = null;
        boolean boolean85 = timeSeries83.equals(obj84);
        java.util.Collection collection86 = timeSeries73.getTimePeriodsUniqueToOtherSeries(timeSeries83);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 9223372036854775807L + "'", long28 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "December 1969" + "'", str39.equals("December 1969"));
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-2208441600001L) + "'", long47 == (-2208441600001L));
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-2208441600001L) + "'", long56 == (-2208441600001L));
        org.junit.Assert.assertNotNull(timeSeries60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 10L + "'", long64 == 10L);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(collection75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(collection86);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2);
        int int2 = spreadsheetDate1.getMonth();
        java.util.Date date3 = spreadsheetDate1.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(2);
        int int6 = spreadsheetDate5.getMonth();
        boolean boolean7 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(2);
        int int10 = spreadsheetDate9.getMonth();
        java.util.Date date11 = spreadsheetDate9.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(2);
        int int14 = spreadsheetDate13.getMonth();
        boolean boolean15 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean16 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(2);
        int int19 = spreadsheetDate18.getMonth();
        java.util.Date date20 = spreadsheetDate18.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(2);
        int int23 = spreadsheetDate22.getMonth();
        boolean boolean24 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(2);
        int int27 = spreadsheetDate26.getMonth();
        java.util.Date date28 = spreadsheetDate26.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(2);
        int int31 = spreadsheetDate30.getMonth();
        boolean boolean32 = spreadsheetDate26.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate30);
        boolean boolean33 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean38 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate35, (int) ' ');
        int int39 = spreadsheetDate18.getYYYY();
        int int40 = spreadsheetDate18.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(2);
        int int43 = spreadsheetDate42.getMonth();
        java.util.Date date44 = spreadsheetDate42.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(2);
        int int47 = spreadsheetDate46.getMonth();
        boolean boolean48 = spreadsheetDate42.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean49 = spreadsheetDate18.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.util.Date date50 = spreadsheetDate46.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate2.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(4, serialDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.lang.Class<?> wildcardClass11 = fixedMillisecond10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate2, "Last", "", class12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries13.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        java.lang.String str2 = serialDate1.getDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) serialDate1);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("");
        int int7 = month4.compareTo((java.lang.Object) "");
        int int8 = month4.getYearValue();
        org.jfree.data.time.Year year9 = month4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 1);
        int int16 = month4.compareTo((java.lang.Object) timeSeriesDataItem15);
        java.lang.Number number17 = timeSeriesDataItem15.getValue();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date21 = fixedMillisecond20.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("");
        int int26 = month23.compareTo((java.lang.Object) "");
        java.lang.String str27 = month23.toString();
        java.util.Date date28 = month23.getEnd();
        long long29 = month23.getLastMillisecond();
        try {
            timeSeries18.add((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1 + "'", number17.equals(1));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "December 1969" + "'", str27.equals("December 1969"));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28799999L + "'", long29 == 28799999L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        long long7 = day6.getLastMillisecond();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day6);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("");
        java.lang.String str11 = seriesException10.toString();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) seriesException10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date15 = fixedMillisecond14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.general.SeriesException seriesException19 = new org.jfree.data.general.SeriesException("");
        int int20 = month17.compareTo((java.lang.Object) "");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.next();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = month17.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208441600001L) + "'", long7 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str11.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(serialDate1);
        long long3 = day2.getLastMillisecond();
        int int4 = day2.getYear();
        int int5 = day2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date8 = fixedMillisecond7.getTime();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.previous();
        boolean boolean12 = day2.equals((java.lang.Object) regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2208441600001L) + "'", long3 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2649600000L) + "'", long10 == (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries1.removeAgedItems(false);
        boolean boolean4 = timeSeries1.isEmpty();
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.util.Collection collection6 = timeSeries1.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4');
        timeSeries8.setRangeDescription("");
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(7);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
        long long14 = day13.getLastMillisecond();
        timeSeries8.delete((org.jfree.data.time.RegularTimePeriod) day13);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        java.lang.String str18 = seriesException17.toString();
        boolean boolean19 = timeSeries8.equals((java.lang.Object) seriesException17);
        boolean boolean20 = timeSeries8.getNotify();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries8.removeChangeListener(seriesChangeListener22);
        int int24 = timeSeries8.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2208441600001L) + "'", long14 == (-2208441600001L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str18.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560191396123L + "'", long1 == 1560191396123L);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d));
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Calendar calendar5 = null;
        fixedMillisecond4.peg(calendar5);
        int int7 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 10);
        java.util.Date date2 = fixedMillisecond1.getTime();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        long long4 = month3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.previous();
        java.lang.String str6 = month3.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2649600000L) + "'", long4 == (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "December 1969" + "'", str6.equals("December 1969"));
    }
}

