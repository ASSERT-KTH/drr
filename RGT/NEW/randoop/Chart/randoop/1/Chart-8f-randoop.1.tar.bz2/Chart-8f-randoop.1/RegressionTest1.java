import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getWeek();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str7 = timePeriodFormatException6.toString();
        java.lang.String str8 = timePeriodFormatException6.toString();
        int int9 = week2.compareTo((java.lang.Object) str8);
        java.lang.Object obj10 = null;
        boolean boolean11 = week2.equals(obj10);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = week4.getEnd();
        java.lang.Object obj20 = new java.lang.Object();
        java.lang.Class<?> wildcardClass21 = obj20.getClass();
        int int22 = week4.compareTo(obj20);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week4.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        long long10 = week9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.next();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        long long16 = week15.getFirstMillisecond();
        java.util.Date date17 = week15.getEnd();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date17, timeZone20);
        boolean boolean23 = week9.equals((java.lang.Object) date17);
        int int24 = week9.getWeek();
        boolean boolean25 = week2.equals((java.lang.Object) int24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61782451200000L) + "'", long10 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61782451200000L) + "'", long16 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        int int7 = week2.getWeek();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
//        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod12);
//        java.util.Date date14 = week2.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
//        try {
//            org.jfree.data.time.Year year16 = week15.getYear();
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 52");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        long long5 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = regularTimePeriod6.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61782451200000L) + "'", long5 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.lang.String str3 = week2.toString();
        java.lang.String str4 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week -1, 0" + "'", str3.equals("Week -1, 0"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week -1, 0" + "'", str4.equals("Week -1, 0"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str22 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        int int8 = week7.getWeek();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        boolean boolean11 = week8.equals((java.lang.Object) 7);
        boolean boolean13 = week8.equals((java.lang.Object) '4');
        long long14 = week8.getSerialIndex();
        java.util.Date date15 = week8.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(12, 12);
        long long20 = week19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
        java.util.Date date22 = week19.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date22, timeZone25);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date15, timeZone25);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date15, timeZone29);
        boolean boolean31 = week2.equals((java.lang.Object) week30);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.lang.String str3 = week2.toString();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date8, timeZone11);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date8, timeZone14);
        java.lang.Class<?> wildcardClass16 = date8.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(12, 12);
        long long20 = week19.getFirstMillisecond();
        java.util.Date date21 = week19.getEnd();
        java.lang.Class class22 = null;
        java.util.Date date23 = null;
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date23, timeZone24);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date21, timeZone24);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date21, timeZone27);
        java.lang.Class<?> wildcardClass29 = date21.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(6, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.previous();
        java.lang.Class<?> wildcardClass34 = regularTimePeriod33.getClass();
        java.lang.Class class35 = null;
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(12, 12);
        long long39 = week38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week38.next();
        java.util.Date date41 = week38.getEnd();
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date41, timeZone44);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.previous();
        java.lang.Class<?> wildcardClass51 = week49.getClass();
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
        java.lang.Class class53 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass51);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date57 = week56.getStart();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date57);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week61.next();
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(12, 12);
        long long66 = week65.getFirstMillisecond();
        java.util.Date date67 = week65.getEnd();
        java.lang.Class class68 = null;
        java.util.Date date69 = null;
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date69, timeZone70);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date67, timeZone70);
        java.lang.Class<?> wildcardClass73 = timeZone70.getClass();
        int int74 = week61.compareTo((java.lang.Object) timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date57, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date41, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone70);
        boolean boolean78 = week2.equals((java.lang.Object) date21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 52" + "'", str3.equals("Week 0, 52"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61782451200000L) + "'", long39 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertNotNull(class52);
        org.junit.Assert.assertNotNull(class53);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61782451200000L) + "'", long66 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.util.Date date6 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        long long19 = week14.getSerialIndex();
        long long20 = week14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week14.previous();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = regularTimePeriod21.getMiddleMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 648L + "'", long19 == 648L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        java.lang.String str28 = timePeriodFormatException26.toString();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        int int30 = week4.compareTo((java.lang.Object) timePeriodFormatException20);
        java.lang.String str31 = timePeriodFormatException20.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (-1));
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        java.lang.String str15 = timePeriodFormatException13.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.String str17 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 52");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date34, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone55);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        java.lang.Class<?> wildcardClass64 = week62.getClass();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        boolean boolean70 = week67.equals((java.lang.Object) 7);
        boolean boolean72 = week67.equals((java.lang.Object) '4');
        long long73 = week67.getSerialIndex();
        java.util.Date date74 = week67.getEnd();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date74);
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date74, timeZone78);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
        java.util.Date date82 = null;
        java.lang.Class class83 = null;
        java.util.Date date84 = null;
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date84, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone85);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date17, timeZone85);
        java.lang.Class<?> wildcardClass89 = date17.getClass();
        java.util.TimeZone timeZone90 = null;
        try {
            org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date17, timeZone90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 648L + "'", long73 == 648L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(wildcardClass89);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, (int) (short) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        java.lang.Class<?> wildcardClass18 = date17.getClass();
        int int19 = week2.compareTo((java.lang.Object) date17);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(12, 12);
        long long30 = week29.getFirstMillisecond();
        java.util.Date date31 = week29.getEnd();
        java.util.Date date32 = week29.getEnd();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week37.previous();
        java.lang.Class<?> wildcardClass39 = week37.getClass();
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass39);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date45 = week44.getStart();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date45);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.next();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        long long54 = week53.getFirstMillisecond();
        java.util.Date date55 = week53.getEnd();
        java.lang.Class class56 = null;
        java.util.Date date57 = null;
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone58);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date55, timeZone58);
        java.lang.Class<?> wildcardClass61 = timeZone58.getClass();
        int int62 = week49.compareTo((java.lang.Object) timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date45, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date32, timeZone58);
        java.util.Locale locale65 = null;
        try {
            org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date17, timeZone58, locale65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-61782451200000L) + "'", long30 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61782451200000L) + "'", long54 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        java.lang.Class<?> wildcardClass4 = week2.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
//        long long8 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        java.util.Date date10 = regularTimePeriod9.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
//        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
//        java.lang.Class<?> wildcardClass18 = week16.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
//        java.util.Date date24 = week23.getStart();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
//        long long33 = week32.getFirstMillisecond();
//        java.util.Date date34 = week32.getEnd();
//        java.lang.Class class35 = null;
//        java.util.Date date36 = null;
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34, timeZone37);
//        java.lang.Class<?> wildcardClass40 = timeZone37.getClass();
//        int int41 = week28.compareTo((java.lang.Object) timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone37);
//        java.util.TimeZone timeZone43 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date24, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        int int47 = week46.getWeek();
//        java.util.Date date48 = week46.getEnd();
//        org.jfree.data.time.Year year49 = week46.getYear();
//        java.util.Date date50 = year49.getEnd();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.next();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(12, 12);
//        long long58 = week57.getFirstMillisecond();
//        java.util.Date date59 = week57.getEnd();
//        java.lang.Class class60 = null;
//        java.util.Date date61 = null;
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date59, timeZone62);
//        java.lang.Class<?> wildcardClass65 = timeZone62.getClass();
//        int int66 = week53.compareTo((java.lang.Object) timeZone62);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date50, timeZone62);
//        java.util.Locale locale68 = null;
//        try {
//            org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date24, timeZone62, locale68);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 24 + "'", int47 == 24);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61782451200000L) + "'", long58 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(wildcardClass65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = week22.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.lang.String str5 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 10, 0" + "'", str5.equals("Week 10, 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        java.util.Calendar calendar8 = null;
        try {
            week2.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        java.util.Date date5 = year4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (short) -1, year4);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year4.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (short) -1);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        long long14 = week2.getLastMillisecond();
        java.util.Date date15 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61781846400001L) + "'", long14 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        int int6 = week2.compareTo((java.lang.Object) (short) 0);
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62167708800000L) + "'", long5 == (-62167708800000L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.lang.Class<?> wildcardClass12 = date4.getClass();
        java.lang.Class<?> wildcardClass13 = date4.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        int int7 = week2.getWeek();
        java.lang.String str8 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 12, 12" + "'", str8.equals("Week 12, 12"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 7);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(7, year4);
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.lang.Class<?> wildcardClass12 = date4.getClass();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = week17.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        boolean boolean25 = week22.equals((java.lang.Object) 7);
        boolean boolean27 = week22.equals((java.lang.Object) '4');
        long long28 = week22.getSerialIndex();
        java.util.Date date29 = week22.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date29, timeZone33);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        java.util.Date date41 = week39.getEnd();
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date41, timeZone44);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date50 = week49.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        java.lang.Class<?> wildcardClass56 = week54.getClass();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        long long60 = week59.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week59.next();
        java.util.Date date62 = regularTimePeriod61.getStart();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date62, timeZone63);
        boolean boolean65 = week51.equals((java.lang.Object) wildcardClass56);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(12, 12);
        long long69 = week68.getFirstMillisecond();
        java.util.Date date70 = week68.getEnd();
        java.util.Date date71 = week68.getStart();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(12, 12);
        long long75 = week74.getFirstMillisecond();
        java.util.Date date76 = week74.getEnd();
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date71, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date41, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone79);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date4, timeZone79);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 648L + "'", long28 == 648L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61782451200000L) + "'", long60 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61782451200000L) + "'", long69 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-61782451200000L) + "'", long75 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61781544000001L) + "'", long7 == (-61781544000001L));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = week2.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62161963200001L) + "'", long3 == (-62161963200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62161660800001L) + "'", long4 == (-62161660800001L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, 35);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException10.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str22 = timePeriodFormatException21.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException21.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.String str26 = timePeriodFormatException21.toString();
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException21.getSuppressed();
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException21.getSuppressed();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException12.getSuppressed();
        boolean boolean22 = week2.equals((java.lang.Object) timePeriodFormatException12);
        long long23 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 648L + "'", long23 == 648L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = week2.getEnd();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week2.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.previous();
        boolean boolean27 = week24.equals((java.lang.Object) 7);
        boolean boolean29 = week24.equals((java.lang.Object) '4');
        long long30 = week24.getSerialIndex();
        java.util.Date date31 = week24.getEnd();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        long long33 = week32.getLastMillisecond();
        java.util.Date date34 = week32.getEnd();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date34, timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 648L + "'", long30 == 648L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61781846400001L) + "'", long33 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, 0);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        long long13 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 1, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone18);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        long long25 = week24.getFirstMillisecond();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date26, timeZone29);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date35 = week34.getStart();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        long long45 = week44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week44.next();
        java.util.Date date47 = regularTimePeriod46.getStart();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        boolean boolean50 = week36.equals((java.lang.Object) wildcardClass41);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        long long54 = week53.getFirstMillisecond();
        java.util.Date date55 = week53.getEnd();
        java.util.Date date56 = week53.getStart();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        long long60 = week59.getFirstMillisecond();
        java.util.Date date61 = week59.getEnd();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date56, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date26, timeZone64);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date26);
        java.lang.String str70 = week69.toString();
        try {
            org.jfree.data.time.Year year71 = week69.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61782451200000L) + "'", long25 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61782451200000L) + "'", long45 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61782451200000L) + "'", long54 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61782451200000L) + "'", long60 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 12, 12" + "'", str70.equals("Week 12, 12"));
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(10, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1545551999999L + "'", long8 == 1545551999999L);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = week17.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        boolean boolean25 = week22.equals((java.lang.Object) 7);
        boolean boolean27 = week22.equals((java.lang.Object) '4');
        long long28 = week22.getSerialIndex();
        java.util.Date date29 = week22.getEnd();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date29);
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date29, timeZone33);
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        java.util.Date date41 = week39.getEnd();
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date41, timeZone44);
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date50 = week49.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        java.lang.Class<?> wildcardClass56 = week54.getClass();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        long long60 = week59.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week59.next();
        java.util.Date date62 = regularTimePeriod61.getStart();
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date62, timeZone63);
        boolean boolean65 = week51.equals((java.lang.Object) wildcardClass56);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(12, 12);
        long long69 = week68.getFirstMillisecond();
        java.util.Date date70 = week68.getEnd();
        java.util.Date date71 = week68.getStart();
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(12, 12);
        long long75 = week74.getFirstMillisecond();
        java.util.Date date76 = week74.getEnd();
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date76, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date71, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date41, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone79);
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date14);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 648L + "'", long28 == 648L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61782451200000L) + "'", long60 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61782451200000L) + "'", long69 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-61782451200000L) + "'", long75 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        long long19 = week14.getSerialIndex();
        long long20 = week14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week14.previous();
        java.lang.String str22 = week14.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 648L + "'", long19 == 648L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 12, 12" + "'", str22.equals("Week 12, 12"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        java.lang.Class<?> wildcardClass18 = week16.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date24 = week23.getStart();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        java.util.Date date34 = week32.getEnd();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34, timeZone37);
        java.lang.Class<?> wildcardClass40 = timeZone37.getClass();
        int int41 = week28.compareTo((java.lang.Object) timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone37);
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date24, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date24);
        try {
            org.jfree.data.time.Year year46 = week45.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        int int7 = week2.getWeek();
//        int int8 = week2.getWeek();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        java.util.Date date14 = week12.getEnd();
//        org.jfree.data.time.Year year15 = week12.getYear();
//        java.util.Date date16 = year15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) -1, year15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', year15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(2019, year15);
//        int int20 = week2.compareTo((java.lang.Object) 2019);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = week2.getMiddleMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        java.util.Date date10 = week8.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
        boolean boolean16 = week2.equals((java.lang.Object) date10);
        int int17 = week2.getWeek();
        int int19 = week2.compareTo((java.lang.Object) (byte) 100);
        int int20 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.lang.String str7 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 12, 12" + "'", str7.equals("Week 12, 12"));
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        long long5 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 1, year5);
//        long long8 = week7.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = week7.getLastMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546459199999L + "'", long8 == 1546459199999L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        int int11 = week2.getYearValue();
        long long12 = week2.getLastMillisecond();
        long long13 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61781846400001L) + "'", long12 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(6, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, year5);
//        java.lang.String str8 = week7.toString();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 12, 2019" + "'", str8.equals("Week 12, 2019"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        long long26 = week25.getFirstMillisecond();
        java.util.Date date27 = week25.getEnd();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        java.lang.Class<?> wildcardClass33 = timeZone30.getClass();
        int int34 = week21.compareTo((java.lang.Object) timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date17, timeZone30);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date6, timeZone30);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date6, timeZone55);
        java.util.Date date59 = week58.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61782451200000L) + "'", long26 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date59);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.util.Date date18 = week10.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-60527793600001L) + "'", long6 == (-60527793600001L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62199158400001L) + "'", long4 == (-62199158400001L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        java.util.Date date3 = week2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week10.previous();
        int int19 = week10.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 100, year5);
//        java.util.Date date8 = week7.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
//        java.util.Date date14 = week11.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week11.next();
//        try {
//            int int16 = week7.compareTo((java.lang.Object) week11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
        int int7 = week6.getWeek();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week6.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        long long18 = week17.getFirstMillisecond();
        java.util.Date date19 = week17.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        boolean boolean30 = week27.equals((java.lang.Object) 7);
        boolean boolean32 = week27.equals((java.lang.Object) '4');
        long long33 = week27.getSerialIndex();
        java.util.Date date34 = week27.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date34, timeZone38);
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        long long45 = week44.getFirstMillisecond();
        java.util.Date date46 = week44.getEnd();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date55 = week54.getStart();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        java.lang.Class<?> wildcardClass61 = week59.getClass();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(12, 12);
        long long65 = week64.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week64.next();
        java.util.Date date67 = regularTimePeriod66.getStart();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date67, timeZone68);
        boolean boolean70 = week56.equals((java.lang.Object) wildcardClass61);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(12, 12);
        long long74 = week73.getFirstMillisecond();
        java.util.Date date75 = week73.getEnd();
        java.util.Date date76 = week73.getStart();
        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(12, 12);
        long long80 = week79.getFirstMillisecond();
        java.util.Date date81 = week79.getEnd();
        java.lang.Class class82 = null;
        java.util.Date date83 = null;
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date83, timeZone84);
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date81, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date76, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date46, timeZone84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date19, timeZone84);
        java.lang.Class class90 = org.jfree.data.time.RegularTimePeriod.downsize(class13);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61782451200000L) + "'", long18 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 648L + "'", long33 == 648L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61782451200000L) + "'", long45 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-61782451200000L) + "'", long65 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61782451200000L) + "'", long74 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-61782451200000L) + "'", long80 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(class90);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        boolean boolean8 = week5.equals((java.lang.Object) 7);
        boolean boolean10 = week5.equals((java.lang.Object) '4');
        long long11 = week5.getSerialIndex();
        java.util.Date date12 = week5.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week5.next();
        java.util.Date date14 = week5.getStart();
        try {
            int int15 = week2.compareTo((java.lang.Object) week5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 648L + "'", long11 == 648L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.lang.String str7 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 12, 12" + "'", str7.equals("Week 12, 12"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        long long13 = week11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.previous();
        java.util.Date date15 = week11.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782148800001L) + "'", long13 == (-61782148800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        java.lang.Class<?> wildcardClass7 = week5.getClass();
        int int9 = week5.compareTo((java.lang.Object) "Week 12, 12");
        int int10 = week2.compareTo((java.lang.Object) int9);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.next();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        boolean boolean20 = week17.equals((java.lang.Object) 7);
        boolean boolean22 = week17.equals((java.lang.Object) '4');
        long long23 = week17.getSerialIndex();
        java.util.Date date24 = week17.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        long long26 = week25.getLastMillisecond();
        int int27 = week25.getYearValue();
        java.lang.String str28 = week25.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week25.previous();
        boolean boolean30 = week13.equals((java.lang.Object) week25);
        int int31 = week25.getYearValue();
        int int32 = week25.getYearValue();
        int int33 = week2.compareTo((java.lang.Object) int32);
        java.util.Calendar calendar34 = null;
        try {
            long long35 = week2.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 648L + "'", long23 == 648L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61781846400001L) + "'", long26 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 12, 12" + "'", str28.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 12 + "'", int32 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str16 = timePeriodFormatException15.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException15.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str24 = timePeriodFormatException15.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: Week 12, 12");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        java.lang.Class<?> wildcardClass10 = week8.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        long long16 = week15.getFirstMillisecond();
        java.util.Date date17 = week15.getEnd();
        java.util.Date date18 = week15.getEnd();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date31 = week30.getStart();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        java.util.Date date41 = week39.getEnd();
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date41, timeZone44);
        java.lang.Class<?> wildcardClass47 = timeZone44.getClass();
        int int48 = week35.compareTo((java.lang.Object) timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date18, timeZone44);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date5, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
        java.util.Date date53 = regularTimePeriod52.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61782451200000L) + "'", long16 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        int int13 = week12.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (short) 10);
        long long3 = week2.getLastMillisecond();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61848374400001L) + "'", long3 == (-61848374400001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.util.Date date27 = week22.getEnd();
        java.lang.Class<?> wildcardClass28 = week22.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date9 = week8.getEnd();
        java.lang.Class<?> wildcardClass10 = week8.getClass();
        int int11 = week2.compareTo((java.lang.Object) wildcardClass10);
        try {
            org.jfree.data.time.Year year12 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62167104000001L) + "'", long5 == (-62167104000001L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = null;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (byte) 1, year9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(7, year9);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, year9);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (short) 10, year9);
//        long long16 = week15.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107017L + "'", long16 == 107017L);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        long long10 = week9.getFirstMillisecond();
        java.util.Date date11 = week9.getEnd();
        java.util.Date date12 = week9.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12, timeZone13);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = week17.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date25 = week24.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.next();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
        long long34 = week33.getFirstMillisecond();
        java.util.Date date35 = week33.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date35, timeZone38);
        java.lang.Class<?> wildcardClass41 = timeZone38.getClass();
        int int42 = week29.compareTo((java.lang.Object) timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date25, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone38);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(12, 12);
        long long48 = week47.getFirstMillisecond();
        java.util.Date date49 = week47.getEnd();
        java.lang.Class class50 = null;
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone52);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date49, timeZone52);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date49, timeZone55);
        java.util.Date date57 = week56.getStart();
        java.util.Date date58 = week56.getEnd();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date62 = week61.getStart();
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date62);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week66.previous();
        java.lang.Class<?> wildcardClass68 = week66.getClass();
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(12, 12);
        long long72 = week71.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week71.next();
        java.util.Date date74 = regularTimePeriod73.getStart();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date74, timeZone75);
        boolean boolean77 = week63.equals((java.lang.Object) wildcardClass68);
        java.util.Date date78 = week63.getEnd();
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(12, 12);
        long long82 = week81.getFirstMillisecond();
        java.util.Date date83 = week81.getEnd();
        java.util.Date date84 = week81.getEnd();
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date84, timeZone85);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date78, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date58, timeZone85);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61782451200000L) + "'", long10 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61782451200000L) + "'", long34 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61782451200000L) + "'", long48 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-61782451200000L) + "'", long72 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-61782451200000L) + "'", long82 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod88);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        int int7 = week2.getWeek();
        long long8 = week2.getFirstMillisecond();
        long long9 = week2.getSerialIndex();
        int int10 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 648L + "'", long9 == 648L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        java.util.Date date7 = regularTimePeriod5.getStart();
        java.lang.Class class8 = null;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = week11.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        boolean boolean19 = week16.equals((java.lang.Object) 7);
        boolean boolean21 = week16.equals((java.lang.Object) '4');
        long long22 = week16.getSerialIndex();
        java.util.Date date23 = week16.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone27);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
        long long34 = week33.getFirstMillisecond();
        java.util.Date date35 = week33.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date35, timeZone38);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date44 = week43.getStart();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        java.lang.Class<?> wildcardClass50 = week48.getClass();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        long long54 = week53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week53.next();
        java.util.Date date56 = regularTimePeriod55.getStart();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date56, timeZone57);
        boolean boolean59 = week45.equals((java.lang.Object) wildcardClass50);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        long long63 = week62.getFirstMillisecond();
        java.util.Date date64 = week62.getEnd();
        java.util.Date date65 = week62.getStart();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(12, 12);
        long long69 = week68.getFirstMillisecond();
        java.util.Date date70 = week68.getEnd();
        java.lang.Class class71 = null;
        java.util.Date date72 = null;
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date72, timeZone73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date70, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date65, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date35, timeZone73);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date35);
        java.lang.Class class79 = null;
        java.util.Date date80 = null;
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class79, date80, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date35, timeZone81);
        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date7, timeZone81);
        try {
            org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date0, timeZone81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 648L + "'", long22 == 648L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61782451200000L) + "'", long34 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61782451200000L) + "'", long54 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61782451200000L) + "'", long63 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61782451200000L) + "'", long69 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNull(regularTimePeriod83);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        java.util.Date date10 = week8.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
        boolean boolean16 = week2.equals((java.lang.Object) date10);
        int int17 = week2.getWeek();
        long long18 = week2.getSerialIndex();
        long long19 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 648L + "'", long18 == 648L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        int int11 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.Date date6 = regularTimePeriod4.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        boolean boolean10 = week2.equals((java.lang.Object) week8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week8.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass7 = throwableArray6.getClass();
        java.lang.Class<?> wildcardClass8 = throwableArray6.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = week4.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        java.util.Date date24 = week22.getEnd();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date19, timeZone26);
        java.util.Date date29 = week28.getEnd();
        try {
            org.jfree.data.time.Year year30 = week28.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week9.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        long long6 = week2.getSerialIndex();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        long long11 = week9.getMiddleMillisecond();
        boolean boolean12 = week2.equals((java.lang.Object) long11);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 648L + "'", long6 == 648L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62167406400001L) + "'", long11 == (-62167406400001L));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (short) -1);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) -1, 9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date8, timeZone11);
        java.lang.Class<?> wildcardClass14 = timeZone11.getClass();
        int int15 = week2.compareTo((java.lang.Object) timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
        java.util.Date date17 = week2.getEnd();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week2.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getMiddleMillisecond();
        java.lang.String str9 = week2.toString();
        java.util.Date date10 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782148800001L) + "'", long8 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 12, 12" + "'", str9.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 10, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int6 = week2.compareTo((java.lang.Object) "Week 12, 12");
        long long7 = week2.getSerialIndex();
        java.util.Date date8 = week2.getStart();
        int int9 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 648L + "'", long7 == 648L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        java.lang.Class<?> wildcardClass18 = week16.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date24 = week23.getStart();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        java.util.Date date34 = week32.getEnd();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34, timeZone37);
        java.lang.Class<?> wildcardClass40 = timeZone37.getClass();
        int int41 = week28.compareTo((java.lang.Object) timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone37);
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date24, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date24);
        long long46 = week45.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 648L + "'", long46 == 648L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        java.util.Date date13 = week11.getEnd();
        java.lang.Class<?> wildcardClass14 = week11.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        long long12 = week11.getFirstMillisecond();
        java.util.Date date13 = week11.getEnd();
        java.util.Date date14 = week11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date7, timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61782451200000L) + "'", long12 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(10, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(5, year6);
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (short) 1, year9);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        java.lang.Class<?> wildcardClass11 = week2.getClass();
        long long12 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61782451200000L) + "'", long12 == (-61782451200000L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        java.util.Date date6 = week3.getEnd();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date6);
        long long13 = week12.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        long long14 = week2.getSerialIndex();
        java.util.Date date15 = week2.getStart();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        long long18 = week15.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        int int7 = week2.getWeek();
//        int int8 = week2.getWeek();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        int int13 = week12.getWeek();
//        java.util.Date date14 = week12.getEnd();
//        org.jfree.data.time.Year year15 = week12.getYear();
//        java.util.Date date16 = year15.getEnd();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week((int) (short) -1, year15);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week((int) '#', year15);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(2019, year15);
//        int int20 = week2.compareTo((java.lang.Object) 2019);
//        long long21 = week2.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61782148800001L) + "'", long21 == (-61782148800001L));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException12.getSuppressed();
        boolean boolean22 = week2.equals((java.lang.Object) timePeriodFormatException12);
        java.util.Date date23 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.String str4 = week2.toString();
        java.lang.String str5 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 0" + "'", str4.equals("Week 1, 0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 1, 0" + "'", str5.equals("Week 1, 0"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize(class14);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
        long long19 = week18.getFirstMillisecond();
        java.util.Date date20 = week18.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        boolean boolean31 = week28.equals((java.lang.Object) 7);
        boolean boolean33 = week28.equals((java.lang.Object) '4');
        long long34 = week28.getSerialIndex();
        java.util.Date date35 = week28.getEnd();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date35, timeZone39);
        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        long long46 = week45.getFirstMillisecond();
        java.util.Date date47 = week45.getEnd();
        java.lang.Class class48 = null;
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date47, timeZone50);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date56 = week55.getStart();
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date56);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = week60.previous();
        java.lang.Class<?> wildcardClass62 = week60.getClass();
        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(12, 12);
        long long66 = week65.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = week65.next();
        java.util.Date date68 = regularTimePeriod67.getStart();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date68, timeZone69);
        boolean boolean71 = week57.equals((java.lang.Object) wildcardClass62);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(12, 12);
        long long75 = week74.getFirstMillisecond();
        java.util.Date date76 = week74.getEnd();
        java.util.Date date77 = week74.getStart();
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(12, 12);
        long long81 = week80.getFirstMillisecond();
        java.util.Date date82 = week80.getEnd();
        java.lang.Class class83 = null;
        java.util.Date date84 = null;
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date84, timeZone85);
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date82, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date77, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date47, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone85);
        try {
            org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date0, timeZone85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61782451200000L) + "'", long19 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 648L + "'", long34 == 648L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(class42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-61782451200000L) + "'", long66 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-61782451200000L) + "'", long75 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61782451200000L) + "'", long81 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNull(regularTimePeriod90);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 0");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getSerialIndex();
        long long6 = week4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 257L + "'", long5 == 257L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62014089600001L) + "'", long6 == (-62014089600001L));
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = week5.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1545854399999L + "'", long6 == 1545854399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.lang.String str18 = week15.toString();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = week15.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 1, 0" + "'", str18.equals("Week 1, 0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.lang.Class<?> wildcardClass12 = date4.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62161660800001L) + "'", long5 == (-62161660800001L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        java.lang.Class<?> wildcardClass18 = week16.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date24 = week23.getStart();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        java.util.Date date34 = week32.getEnd();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34, timeZone37);
        java.lang.Class<?> wildcardClass40 = timeZone37.getClass();
        int int41 = week28.compareTo((java.lang.Object) timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone37);
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date24, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date24);
        long long46 = week45.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) ' ');
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week10.previous();
        int int19 = week10.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        java.lang.String str14 = timePeriodFormatException11.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str17 = timePeriodFormatException16.toString();
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        boolean boolean9 = week6.equals((java.lang.Object) 7);
        boolean boolean11 = week6.equals((java.lang.Object) '4');
        long long12 = week6.getSerialIndex();
        java.util.Date date13 = week6.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        long long15 = week14.getLastMillisecond();
        int int16 = week14.getYearValue();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.previous();
        boolean boolean19 = week2.equals((java.lang.Object) week14);
        int int20 = week14.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str23 = timePeriodFormatException22.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException22.getSuppressed();
        java.lang.Class<?> wildcardClass28 = throwableArray27.getClass();
        int int29 = week14.compareTo((java.lang.Object) throwableArray27);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 648L + "'", long12 == 648L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61781846400001L) + "'", long15 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 12, 12" + "'", str17.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
//        boolean boolean10 = week7.equals((java.lang.Object) 7);
//        boolean boolean12 = week7.equals((java.lang.Object) '4');
//        long long13 = week7.getSerialIndex();
//        java.util.Date date14 = week7.getEnd();
//        int int15 = week7.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str20 = timePeriodFormatException19.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException19.getSuppressed();
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
//        java.lang.Throwable[] throwableArray26 = timePeriodFormatException17.getSuppressed();
//        boolean boolean27 = week7.equals((java.lang.Object) timePeriodFormatException17);
//        int int28 = week0.compareTo((java.lang.Object) boolean27);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertNotNull(throwableArray26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        int int11 = week2.getYearValue();
        long long12 = week2.getLastMillisecond();
        java.lang.String str13 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61781846400001L) + "'", long12 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.util.Calendar calendar18 = null;
        try {
            week15.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        int int7 = week2.getWeek();
        long long8 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year9 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int7 = week6.getWeek();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(24, year9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (byte) 1, year9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(7, year9);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (short) 0, year9);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) -1, year9);
//        java.util.Date date16 = week15.getStart();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(100, year6);
//        java.util.Date date9 = year6.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 1, year6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date9);
//    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        java.util.Date date5 = year4.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        long long14 = week13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        java.util.Date date16 = week13.getEnd();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9, timeZone19);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date9, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week24.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
        java.lang.String str14 = timePeriodFormatException11.toString();
        java.lang.String str15 = timePeriodFormatException11.toString();
        int int16 = week2.compareTo((java.lang.Object) timePeriodFormatException11);
        long long17 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61781846400001L) + "'", long17 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date34, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone55);
        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.util.Date date61 = null;
        java.util.TimeZone timeZone62 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date61, timeZone62);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertNull(regularTimePeriod63);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.String str11 = timePeriodFormatException9.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str17 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str27 = timePeriodFormatException26.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 5);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        boolean boolean8 = week5.equals((java.lang.Object) 7);
        boolean boolean10 = week5.equals((java.lang.Object) '4');
        long long11 = week5.getSerialIndex();
        java.util.Date date12 = week5.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        long long14 = week13.getLastMillisecond();
        int int15 = week13.getYearValue();
        java.lang.String str16 = week13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week13.previous();
        boolean boolean18 = week2.equals((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 648L + "'", long11 == 648L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61781846400001L) + "'", long14 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 12, 12" + "'", str16.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        java.util.Date date9 = week7.getEnd();
        java.util.Date date10 = week7.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date3, timeZone11);
        long long14 = week13.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 54L + "'", long14 == 54L);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.lang.Object obj3 = null;
//        int int4 = week0.compareTo(obj3);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date10 = week9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        long long18 = week17.getFirstMillisecond();
        java.util.Date date19 = week17.getEnd();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date19, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone22);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61782451200000L) + "'", long18 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        int int6 = week5.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        java.util.Date date7 = week5.getEnd();
        java.util.Date date8 = week5.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(6, (int) (short) 10);
        java.util.Date date12 = week11.getStart();
        try {
            int int13 = week5.compareTo((java.lang.Object) week11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        int int13 = week10.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week10.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str19 = timePeriodFormatException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        boolean boolean24 = week10.equals((java.lang.Object) timePeriodFormatException21);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException20.getSuppressed();
        java.lang.String str22 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 0");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(1, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(35, year5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (byte) 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date9 = week8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        long long13 = week12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2755L + "'", long13 == 2755L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        java.util.Date date6 = week3.getEnd();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.util.Date date5 = null;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        boolean boolean11 = week8.equals((java.lang.Object) 7);
        boolean boolean13 = week8.equals((java.lang.Object) '4');
        long long14 = week8.getSerialIndex();
        java.util.Date date15 = week8.getEnd();
        int int16 = week8.getWeek();
        boolean boolean18 = week8.equals((java.lang.Object) 10.0f);
        int int19 = week8.getWeek();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        java.util.Date date24 = week22.getEnd();
        int int25 = week8.compareTo((java.lang.Object) date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week8.previous();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        boolean boolean34 = week31.equals((java.lang.Object) 7);
        boolean boolean36 = week31.equals((java.lang.Object) '4');
        long long37 = week31.getSerialIndex();
        java.util.Date date38 = week31.getEnd();
        int int39 = week31.getWeek();
        boolean boolean41 = week31.equals((java.lang.Object) 10.0f);
        java.lang.String str42 = week31.toString();
        java.util.Date date43 = week31.getStart();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.next();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(12, 12);
        long long51 = week50.getFirstMillisecond();
        java.util.Date date52 = week50.getEnd();
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date52, timeZone55);
        java.lang.Class<?> wildcardClass58 = timeZone55.getClass();
        int int59 = week46.compareTo((java.lang.Object) timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date43, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date5, timeZone55);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 648L + "'", long37 == 648L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 12, 12" + "'", str42.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-61782451200000L) + "'", long51 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        int int13 = week10.getYearValue();
        long long14 = week10.getSerialIndex();
        java.lang.Class<?> wildcardClass15 = week10.getClass();
        long long16 = week10.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 648L + "'", long16 == 648L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getLastMillisecond();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 97, 3" + "'", str4.equals("Week 97, 3"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62014089600001L) + "'", long5 == (-62014089600001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str24 = timePeriodFormatException23.toString();
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException23.getSuppressed();
        java.lang.String str26 = timePeriodFormatException23.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.Throwable[] throwableArray28 = timePeriodFormatException14.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str24.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getSerialIndex();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2756L + "'", long4 == 2756L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        boolean boolean9 = week6.equals((java.lang.Object) 7);
        boolean boolean11 = week6.equals((java.lang.Object) '4');
        long long12 = week6.getSerialIndex();
        java.util.Date date13 = week6.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        long long15 = week14.getLastMillisecond();
        int int16 = week14.getYearValue();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.previous();
        boolean boolean19 = week2.equals((java.lang.Object) week14);
        int int20 = week14.getYearValue();
        int int21 = week14.getYearValue();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = week14.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 648L + "'", long12 == 648L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61781846400001L) + "'", long15 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 12, 12" + "'", str17.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        int int3 = week2.getYearValue();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        java.lang.String str8 = timePeriodFormatException6.toString();
        boolean boolean9 = week2.equals((java.lang.Object) timePeriodFormatException6);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        boolean boolean15 = week12.equals((java.lang.Object) 7);
        boolean boolean17 = week12.equals((java.lang.Object) '4');
        long long18 = week12.getSerialIndex();
        java.util.Date date19 = week12.getEnd();
        int int20 = week12.getYearValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str25 = timePeriodFormatException24.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException24.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException22.getSuppressed();
        boolean boolean32 = week12.equals((java.lang.Object) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str35 = timePeriodFormatException34.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException34.addSuppressed((java.lang.Throwable) timePeriodFormatException37);
        java.lang.Throwable[] throwableArray39 = timePeriodFormatException34.getSuppressed();
        java.lang.String str40 = timePeriodFormatException34.toString();
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException34.getSuppressed();
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException34.getSuppressed();
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 0" + "'", str4.equals("Week 1, 0"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 648L + "'", long18 == 648L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str40.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray42);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date4 = week3.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        java.lang.Class<?> wildcardClass10 = week8.getClass();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        long long14 = week13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        java.util.Date date16 = regularTimePeriod15.getStart();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date16, timeZone17);
        boolean boolean19 = week5.equals((java.lang.Object) wildcardClass10);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        java.util.Date date24 = week22.getEnd();
        java.util.Date date25 = week22.getStart();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        long long29 = week28.getFirstMillisecond();
        java.util.Date date30 = week28.getEnd();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date30, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date25, timeZone33);
        java.util.Locale locale37 = null;
        try {
            org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date0, timeZone33, locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61782451200000L) + "'", long29 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        boolean boolean17 = week14.equals((java.lang.Object) 7);
        boolean boolean19 = week14.equals((java.lang.Object) '4');
        long long20 = week14.getSerialIndex();
        java.util.Date date21 = week14.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date21, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        java.util.Date date32 = regularTimePeriod31.getStart();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = week35.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = week40.getClass();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        long long46 = week45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week45.next();
        java.util.Date date48 = regularTimePeriod47.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
        java.lang.Class<?> wildcardClass55 = week53.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.previous();
        boolean boolean61 = week58.equals((java.lang.Object) 7);
        boolean boolean63 = week58.equals((java.lang.Object) '4');
        long long64 = week58.getSerialIndex();
        java.util.Date date65 = week58.getEnd();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date65, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date48, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date32, timeZone69);
        try {
            int int74 = week2.compareTo((java.lang.Object) regularTimePeriod73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 648L + "'", long20 == 648L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 648L + "'", long64 == 648L);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        boolean boolean2 = week0.equals((java.lang.Object) '#');
//        java.lang.String str3 = week0.toString();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
//        long long8 = week7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        java.util.Date date10 = week7.getStart();
//        java.util.Date date11 = week7.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
//        boolean boolean17 = week14.equals((java.lang.Object) 7);
//        boolean boolean19 = week14.equals((java.lang.Object) '4');
//        long long20 = week14.getSerialIndex();
//        java.util.Date date21 = week14.getStart();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
//        long long26 = week25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week25.next();
//        java.util.Date date28 = week25.getEnd();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date28, timeZone31);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date21, timeZone31);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date11, timeZone31);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
//        java.lang.Class<?> wildcardClass40 = week38.getClass();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(12, 12);
//        long long44 = week43.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week43.next();
//        java.util.Date date46 = regularTimePeriod45.getStart();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone47);
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        java.util.Date date50 = null;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        int int54 = week53.getWeek();
//        java.util.Date date55 = week53.getEnd();
//        org.jfree.data.time.Year year56 = week53.getYear();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(0, year56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(100, year56);
//        java.util.Date date59 = year56.getStart();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
//        java.util.Date date63 = week62.getEnd();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
//        long long68 = week67.getFirstMillisecond();
//        java.util.Date date69 = week67.getEnd();
//        java.util.Date date70 = week67.getEnd();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date70, timeZone71);
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date63, timeZone71);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date59, timeZone71);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone71);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date11, timeZone71);
//        java.util.Locale locale77 = null;
//        try {
//            org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date4, timeZone71, locale77);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 648L + "'", long20 == 648L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61782451200000L) + "'", long26 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61782451200000L) + "'", long44 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 24 + "'", int54 == 24);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61782451200000L) + "'", long68 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        int int7 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 12, 12" + "'", str6.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date14 = week13.getStart();
        long long15 = week13.getSerialIndex();
        java.lang.String str16 = week13.toString();
        int int17 = week13.getYearValue();
        long long18 = week13.getSerialIndex();
        try {
            int int19 = week2.compareTo((java.lang.Object) week13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2756L + "'", long15 == 2756L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 0, 52" + "'", str16.equals("Week 0, 52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2756L + "'", long18 == 2756L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) 'a');
        long long3 = week2.getLastMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.util.Date date9 = week6.getEnd();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
        boolean boolean12 = week2.equals((java.lang.Object) week11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59105001600001L) + "'", long3 == (-59105001600001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, 53);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = week4.getEnd();
        java.lang.Object obj20 = new java.lang.Object();
        java.lang.Class<?> wildcardClass21 = obj20.getClass();
        int int22 = week4.compareTo(obj20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str25 = timePeriodFormatException24.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str31 = timePeriodFormatException30.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException33);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str37 = timePeriodFormatException36.toString();
        java.lang.String str38 = timePeriodFormatException36.toString();
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException43 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str44 = timePeriodFormatException43.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException46 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException46);
        java.lang.Throwable[] throwableArray48 = timePeriodFormatException43.getSuppressed();
        timePeriodFormatException41.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        timePeriodFormatException30.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        java.lang.Throwable[] throwableArray51 = timePeriodFormatException43.getSuppressed();
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        boolean boolean57 = week54.equals((java.lang.Object) 7);
        boolean boolean59 = week54.equals((java.lang.Object) '4');
        long long60 = week54.getSerialIndex();
        java.util.Date date61 = week54.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException63 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str64 = timePeriodFormatException63.toString();
        java.lang.Throwable[] throwableArray65 = timePeriodFormatException63.getSuppressed();
        java.lang.String str66 = timePeriodFormatException63.toString();
        java.lang.String str67 = timePeriodFormatException63.toString();
        int int68 = week54.compareTo((java.lang.Object) timePeriodFormatException63);
        timePeriodFormatException43.addSuppressed((java.lang.Throwable) timePeriodFormatException63);
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException43);
        boolean boolean71 = week4.equals((java.lang.Object) timePeriodFormatException27);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str31.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str44.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 648L + "'", long60 == 648L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str64.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str66.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str67.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) week5);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
        int int11 = week10.getWeek();
        java.lang.String str12 = week10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.next();
        long long14 = week10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week10.next();
        boolean boolean16 = week2.equals((java.lang.Object) week10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 12, 12" + "'", str12.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61781846400001L) + "'", long14 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) 'a');
        long long3 = week2.getLastMillisecond();
        java.lang.Object obj4 = null;
        int int5 = week2.compareTo(obj4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59105001600001L) + "'", long3 == (-59105001600001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 12, 2019");
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        java.lang.Class<?> wildcardClass18 = regularTimePeriod17.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date22 = week21.getStart();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        java.lang.Class<?> wildcardClass33 = week31.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(12, 12);
        long long37 = week36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
        java.util.Date date39 = regularTimePeriod38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        java.lang.Class<?> wildcardClass46 = week44.getClass();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = week49.previous();
        boolean boolean52 = week49.equals((java.lang.Object) 7);
        boolean boolean54 = week49.equals((java.lang.Object) '4');
        long long55 = week49.getSerialIndex();
        java.util.Date date56 = week49.getEnd();
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date56);
        java.lang.Class class58 = null;
        java.util.Date date59 = null;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date59, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date56, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date39, timeZone60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date22, timeZone60);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        java.lang.Class<?> wildcardClass69 = week67.getClass();
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.previous();
        boolean boolean75 = week72.equals((java.lang.Object) 7);
        boolean boolean77 = week72.equals((java.lang.Object) '4');
        long long78 = week72.getSerialIndex();
        java.util.Date date79 = week72.getEnd();
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date79);
        java.lang.Class class81 = null;
        java.util.Date date82 = null;
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date79, timeZone83);
        java.lang.Class class86 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass69);
        java.util.Date date87 = null;
        java.lang.Class class88 = null;
        java.util.Date date89 = null;
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class88, date89, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class86, date87, timeZone90);
        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date22, timeZone90);
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date3, timeZone90);
        org.jfree.data.time.Week week95 = new org.jfree.data.time.Week(date3);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61782451200000L) + "'", long37 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 648L + "'", long55 == 648L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 648L + "'", long78 == 648L);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(class86);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNull(regularTimePeriod92);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.util.Date date27 = week22.getEnd();
        boolean boolean29 = week22.equals((java.lang.Object) (-62162265600000L));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week22.next();
        java.util.Date date31 = regularTimePeriod30.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, 7);
        long long3 = week2.getMiddleMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61946654400001L) + "'", long3 == (-61946654400001L));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Date date7 = week6.getEnd();
        long long8 = week6.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61781846400001L) + "'", long8 == (-61781846400001L));
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(10, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (short) 1, year6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((-1), year4);
//        int int6 = week5.getWeek();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
//        long long10 = week9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
//        boolean boolean13 = week5.equals((java.lang.Object) regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61782451200000L) + "'", long10 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        long long2 = week0.getFirstMillisecond();
//        long long3 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560063600000L + "'", long2 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone18);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date24 = week23.getEnd();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
        java.util.Date date35 = regularTimePeriod34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        java.util.Date date38 = null;
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.next();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        long long46 = week45.getFirstMillisecond();
        java.util.Date date47 = week45.getEnd();
        java.lang.Class class48 = null;
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date47, timeZone50);
        java.lang.Class<?> wildcardClass53 = timeZone50.getClass();
        int int54 = week41.compareTo((java.lang.Object) timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date38, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date24, timeZone50);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date24);
        java.util.Calendar calendar58 = null;
        try {
            week57.peg(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, 12);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        boolean boolean11 = week8.equals((java.lang.Object) 7);
        boolean boolean13 = week8.equals((java.lang.Object) '4');
        long long14 = week8.getSerialIndex();
        java.util.Date date15 = week8.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date15, timeZone19);
        java.util.Locale locale22 = null;
        try {
            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date0, timeZone19, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, (int) (short) 0);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62161056000001L) + "'", long3 == (-62161056000001L));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        int int6 = week4.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
//        long long8 = week7.getFirstMillisecond();
//        java.util.Date date9 = week7.getEnd();
//        java.lang.Class class10 = null;
//        java.util.Date date11 = null;
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone15);
//        java.lang.Class<?> wildcardClass17 = date9.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
//        java.lang.Class<?> wildcardClass22 = week20.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
//        java.util.Date date28 = week27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(12, 12);
//        long long37 = week36.getFirstMillisecond();
//        java.util.Date date38 = week36.getEnd();
//        java.lang.Class class39 = null;
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date38, timeZone41);
//        java.lang.Class<?> wildcardClass44 = timeZone41.getClass();
//        int int45 = week32.compareTo((java.lang.Object) timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone41);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        int int55 = week54.getWeek();
//        java.util.Date date56 = week54.getEnd();
//        org.jfree.data.time.Year year57 = week54.getYear();
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(0, year57);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(24, year57);
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week((int) (byte) 1, year57);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(7, year57);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week((int) (short) 0, year57);
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week((int) (short) 10, year57);
//        java.util.Date date64 = year57.getEnd();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
//        boolean boolean70 = week67.equals((java.lang.Object) 7);
//        boolean boolean72 = week67.equals((java.lang.Object) '4');
//        long long73 = week67.getSerialIndex();
//        java.util.Date date74 = week67.getStart();
//        java.lang.Class class75 = null;
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(12, 12);
//        long long79 = week78.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = week78.next();
//        java.util.Date date81 = week78.getEnd();
//        java.lang.Class class82 = null;
//        java.util.Date date83 = null;
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date83, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date81, timeZone84);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date74, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date64, timeZone84);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61782451200000L) + "'", long37 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 24 + "'", int55 == 24);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 648L + "'", long73 == 648L);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-61782451200000L) + "'", long79 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, 100);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (-1));
        int int3 = week2.getWeek();
        java.util.Date date4 = week2.getStart();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        long long13 = week11.getMiddleMillisecond();
        int int14 = week11.getWeek();
        try {
            org.jfree.data.time.Year year15 = week11.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782148800001L) + "'", long13 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        java.lang.Object obj8 = null;
        int int9 = week7.compareTo(obj8);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        java.lang.Class<?> wildcardClass14 = week12.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        boolean boolean20 = week17.equals((java.lang.Object) 7);
        boolean boolean22 = week17.equals((java.lang.Object) '4');
        long long23 = week17.getSerialIndex();
        java.util.Date date24 = week17.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date24, timeZone28);
        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.util.Date date32 = null;
        java.lang.Class class33 = null;
        java.util.Date date34 = null;
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone35);
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize(class31);
        boolean boolean39 = week7.equals((java.lang.Object) class31);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 648L + "'", long23 == 648L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        long long14 = week13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        java.util.Date date16 = week13.getEnd();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9, timeZone19);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date9, timeZone23);
        int int25 = week24.getWeek();
        long long26 = week24.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61781846400001L) + "'", long26 == (-61781846400001L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        long long9 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        int int8 = week7.getWeek();
        int int9 = week7.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.previous();
        try {
            int int11 = week2.compareTo((java.lang.Object) regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        int int6 = week2.compareTo((java.lang.Object) 10);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        long long12 = week9.getMiddleMillisecond();
        long long13 = week9.getMiddleMillisecond();
        int int14 = week2.compareTo((java.lang.Object) long13);
        java.util.Date date15 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61782148800001L) + "'", long12 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782148800001L) + "'", long13 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Date date4 = week0.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str22 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException26.getSuppressed();
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getLastMillisecond();
        java.util.Date date6 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2756L + "'", long4 == 2756L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526886400001L) + "'", long5 == (-60526886400001L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
        int int7 = week4.getYearValue();
        long long8 = week4.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        java.util.Date date4 = week2.getEnd();
//        java.util.Date date5 = week2.getEnd();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        int int7 = week2.getWeek();
//        long long8 = week2.getFirstMillisecond();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int10 = week9.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.previous();
//        boolean boolean13 = week2.equals((java.lang.Object) regularTimePeriod12);
//        java.util.Date date14 = week2.getStart();
//        int int15 = week2.getWeek();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
//        boolean boolean5 = week2.equals((java.lang.Object) 7);
//        boolean boolean7 = week2.equals((java.lang.Object) '4');
//        long long8 = week2.getSerialIndex();
//        java.util.Date date9 = week2.getEnd();
//        java.util.Date date10 = week2.getEnd();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        int int12 = week11.getWeek();
//        java.util.Date date13 = week11.getEnd();
//        org.jfree.data.time.Year year14 = week11.getYear();
//        java.util.Date date15 = year14.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
//        long long23 = week22.getFirstMillisecond();
//        java.util.Date date24 = week22.getEnd();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date24, timeZone27);
//        java.lang.Class<?> wildcardClass30 = timeZone27.getClass();
//        int int31 = week18.compareTo((java.lang.Object) timeZone27);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date15, timeZone27);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date10, timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(12, 12);
        long long20 = week19.getFirstMillisecond();
        java.util.Date date21 = week19.getEnd();
        long long22 = week19.getFirstMillisecond();
        boolean boolean23 = week16.equals((java.lang.Object) week19);
        long long24 = week19.getSerialIndex();
        long long25 = week19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week19.previous();
        boolean boolean27 = week4.equals((java.lang.Object) week19);
        long long28 = week19.getSerialIndex();
        java.lang.Class<?> wildcardClass29 = week19.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61782451200000L) + "'", long22 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 648L + "'", long24 == 648L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61782451200000L) + "'", long25 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 648L + "'", long28 == 648L);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        long long14 = week10.getFirstMillisecond();
        boolean boolean16 = week10.equals((java.lang.Object) 107006L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        java.util.Date date4 = week2.getEnd();
//        java.lang.Class class5 = null;
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
//        java.lang.Class<?> wildcardClass12 = date4.getClass();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        int int14 = week13.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week13.previous();
//        java.lang.Class<?> wildcardClass17 = week13.getClass();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
//        long long21 = week20.getFirstMillisecond();
//        java.util.Date date22 = week20.getEnd();
//        java.lang.Class class23 = null;
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date22, timeZone25);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date22, timeZone28);
//        java.lang.Class<?> wildcardClass30 = date22.getClass();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
//        java.lang.Class<?> wildcardClass35 = week33.getClass();
//        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        java.lang.Class class37 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
//        java.util.Date date41 = week40.getStart();
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date41);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
//        long long50 = week49.getFirstMillisecond();
//        java.util.Date date51 = week49.getEnd();
//        java.lang.Class class52 = null;
//        java.util.Date date53 = null;
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date51, timeZone54);
//        java.lang.Class<?> wildcardClass57 = timeZone54.getClass();
//        int int58 = week45.compareTo((java.lang.Object) timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date41, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone54);
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date4, timeZone54);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61782451200000L) + "'", long21 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(class36);
//        org.junit.Assert.assertNotNull(class37);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61782451200000L) + "'", long50 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
        long long8 = week5.getSerialIndex();
        long long9 = week5.getFirstMillisecond();
        long long10 = week5.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 648L + "'", long10 == 648L);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year4);
//        long long6 = year4.getMiddleMillisecond();
//        java.util.Date date7 = year4.getEnd();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10, timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 0, 52");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.lang.Class<?> wildcardClass27 = week25.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        long long31 = week30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week30.next();
        java.util.Date date33 = regularTimePeriod32.getStart();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date33, timeZone34);
        boolean boolean36 = week22.equals((java.lang.Object) wildcardClass27);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        java.util.Date date41 = week39.getEnd();
        java.util.Date date42 = week39.getStart();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        long long46 = week45.getFirstMillisecond();
        java.util.Date date47 = week45.getEnd();
        java.lang.Class class48 = null;
        java.util.Date date49 = null;
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date49, timeZone50);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date47, timeZone50);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date42, timeZone50);
        int int54 = week15.compareTo((java.lang.Object) timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61782451200000L) + "'", long31 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }
}

