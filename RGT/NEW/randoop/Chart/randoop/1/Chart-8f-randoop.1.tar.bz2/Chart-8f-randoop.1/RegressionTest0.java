import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(4, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone18);
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale22 = null;
        try {
            org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date14, timeZone21, locale22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timeZone21);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) 'a');
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        java.lang.Class<?> wildcardClass14 = week12.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        boolean boolean20 = week17.equals((java.lang.Object) 7);
        boolean boolean22 = week17.equals((java.lang.Object) '4');
        long long23 = week17.getSerialIndex();
        java.util.Date date24 = week17.getEnd();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date24, timeZone28);
        java.util.Locale locale31 = null;
        try {
            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date9, timeZone28, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 648L + "'", long23 == 648L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782753600001L) + "'", long6 == (-61782753600001L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
        boolean boolean11 = week2.equals((java.lang.Object) regularTimePeriod10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week2.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        try {
            org.jfree.data.time.Year year11 = week10.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            week10.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 12, 12" + "'", str6.equals("Week 12, 12"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        int int7 = week2.getWeek();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        long long10 = week9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 648L + "'", long10 == 648L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        java.util.Calendar calendar8 = null;
        try {
            week7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.util.Calendar calendar13 = null;
        try {
            week2.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        java.util.Date date17 = week14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9, timeZone18, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        java.util.Date date5 = week3.getEnd();
        java.util.Date date6 = week3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date6, timeZone7);
        try {
            org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date0, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        int int6 = week2.compareTo((java.lang.Object) false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        java.util.Locale locale9 = null;
        try {
            org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date3, timeZone7, locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date34, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone55);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        java.lang.Class<?> wildcardClass64 = week62.getClass();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        boolean boolean70 = week67.equals((java.lang.Object) 7);
        boolean boolean72 = week67.equals((java.lang.Object) '4');
        long long73 = week67.getSerialIndex();
        java.util.Date date74 = week67.getEnd();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date74);
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date74, timeZone78);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
        java.util.Date date82 = null;
        java.lang.Class class83 = null;
        java.util.Date date84 = null;
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date84, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone85);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date17, timeZone85);
        java.util.TimeZone timeZone89 = null;
        try {
            org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date17, timeZone89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 648L + "'", long73 == 648L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNull(regularTimePeriod87);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week7.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        long long10 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 648L + "'", long10 == 648L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getWeek();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week11.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.next();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        long long14 = week13.getFirstMillisecond();
        java.util.Date date15 = week13.getEnd();
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date15, timeZone18);
        java.lang.Class<?> wildcardClass21 = timeZone18.getClass();
        int int22 = week9.compareTo((java.lang.Object) timeZone18);
        java.util.Locale locale23 = null;
        try {
            org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date6, timeZone18, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61781846400001L) + "'", long4 == (-61781846400001L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61781846400001L) + "'", long4 == (-61781846400001L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 648L + "'", long5 == 648L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        try {
            org.jfree.data.time.Year year20 = week4.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getFirstMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date10, timeZone15, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        boolean boolean5 = week2.equals((java.lang.Object) (byte) -1);
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62162265600000L) + "'", long3 == (-62162265600000L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        try {
            org.jfree.data.time.Year year19 = week4.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        boolean boolean4 = week0.equals((java.lang.Object) 53);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = throwableArray6.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.previous();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        int int8 = week7.getWeek();
        int int9 = week7.getYearValue();
        try {
            int int10 = week2.compareTo((java.lang.Object) week7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        java.util.Date date14 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.next();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        long long22 = week21.getFirstMillisecond();
        java.util.Date date23 = week21.getEnd();
        java.lang.Class class24 = null;
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date23, timeZone26);
        java.lang.Class<?> wildcardClass29 = timeZone26.getClass();
        int int30 = week17.compareTo((java.lang.Object) timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date14, timeZone26);
        try {
            org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date0, timeZone26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61782451200000L) + "'", long22 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.lang.String str11 = week10.toString();
        java.util.Calendar calendar12 = null;
        try {
            week10.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 12, 12" + "'", str11.equals("Week 12, 12"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone18);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        long long29 = week28.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.next();
        java.util.Date date31 = regularTimePeriod30.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date31, timeZone32);
        java.util.Locale locale34 = null;
        try {
            org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date14, timeZone32, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-61782451200000L) + "'", long29 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        try {
            int int9 = week2.compareTo((java.lang.Object) regularTimePeriod8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable throwable4 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Locale locale6 = null;
        try {
            org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date3, timeZone5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        int int27 = week4.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 12 + "'", int27 == 12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        long long3 = week2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62162265600000L) + "'", long3 == (-62162265600000L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date8, timeZone11);
        java.lang.Class<?> wildcardClass14 = timeZone11.getClass();
        int int15 = week2.compareTo((java.lang.Object) timeZone11);
        java.util.Calendar calendar16 = null;
        try {
            week2.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 97, 3" + "'", str4.equals("Week 97, 3"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62014392000001L) + "'", long5 == (-62014392000001L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 5);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date8, timeZone11);
        java.lang.Class<?> wildcardClass14 = timeZone11.getClass();
        int int15 = week2.compareTo((java.lang.Object) timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = regularTimePeriod16.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        java.lang.Class<?> wildcardClass18 = week16.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        long long22 = week21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week21.next();
        java.util.Date date24 = regularTimePeriod23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date24, timeZone25);
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date31 = week30.getStart();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = week35.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = week40.getClass();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        long long46 = week45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week45.next();
        java.util.Date date48 = regularTimePeriod47.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
        java.lang.Class<?> wildcardClass55 = week53.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.previous();
        boolean boolean61 = week58.equals((java.lang.Object) 7);
        boolean boolean63 = week58.equals((java.lang.Object) '4');
        long long64 = week58.getSerialIndex();
        java.util.Date date65 = week58.getEnd();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date65, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date48, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date31, timeZone69);
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(12, 12);
        long long77 = week76.getFirstMillisecond();
        java.util.Date date78 = week76.getEnd();
        java.util.Date date79 = week76.getEnd();
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date79, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date31, timeZone80);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61782451200000L) + "'", long22 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 648L + "'", long64 == 648L);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-61782451200000L) + "'", long77 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = week0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        java.util.Date date7 = week5.getEnd();
        java.util.Date date8 = week5.getStart();
        try {
            int int9 = week2.compareTo((java.lang.Object) week5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        int int3 = week2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        long long6 = week5.getLastMillisecond();
        try {
            org.jfree.data.time.Year year7 = week5.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        int int4 = week2.compareTo((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        int int20 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = regularTimePeriod5.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 648L + "'", long7 == 648L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            week0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Date date6 = week2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date34, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone55);
        java.lang.Class class60 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        java.lang.Class class61 = org.jfree.data.time.RegularTimePeriod.downsize(class60);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(class60);
        org.junit.Assert.assertNotNull(class61);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.next();
        java.util.Date date12 = regularTimePeriod11.getStart();
        long long13 = regularTimePeriod11.getMiddleMillisecond();
        try {
            int int14 = week2.compareTo((java.lang.Object) regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61781544000001L) + "'", long13 == (-61781544000001L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.util.Calendar calendar7 = null;
        try {
            week2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (-1));
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        try {
            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date0, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 12, 12");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        long long5 = week2.getMiddleMillisecond();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61782148800001L) + "'", long5 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = null;
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        long long28 = week27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week27.next();
        java.util.Date date30 = regularTimePeriod29.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date19, timeZone31);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-61782451200000L) + "'", long28 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(12, 12);
        long long5 = week4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        java.util.Date date7 = week4.getEnd();
        java.lang.Class class8 = null;
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date7, timeZone10);
        try {
            org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date0, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61782451200000L) + "'", long5 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.util.Date date27 = week22.getEnd();
        long long28 = week22.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62161660800001L) + "'", long28 == (-62161660800001L));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        long long3 = week2.getMiddleMillisecond();
        long long4 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62161963200001L) + "'", long3 == (-62161963200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable11 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        int int13 = week10.getYearValue();
        int int14 = week10.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        long long11 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = week4.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        java.util.Date date24 = week22.getEnd();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date19, timeZone26);
        java.lang.Class<?> wildcardClass29 = date19.getClass();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.lang.String str4 = week2.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 1, 0" + "'", str4.equals("Week 1, 0"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getSerialIndex();
        long long5 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2756L + "'", long4 == 2756L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60527188800001L) + "'", long5 == (-60527188800001L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        long long4 = week2.getFirstMillisecond();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
//        java.lang.Class<?> wildcardClass7 = week5.getClass();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
//        boolean boolean13 = week10.equals((java.lang.Object) 7);
//        boolean boolean15 = week10.equals((java.lang.Object) '4');
//        long long16 = week10.getSerialIndex();
//        java.util.Date date17 = week10.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        java.lang.Class class19 = null;
//        java.util.Date date20 = null;
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date17, timeZone21);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
//        long long28 = week27.getFirstMillisecond();
//        java.util.Date date29 = week27.getEnd();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date29, timeZone32);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(12, 12);
//        java.util.Date date38 = week37.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date38);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week42.previous();
//        java.lang.Class<?> wildcardClass44 = week42.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(12, 12);
//        long long48 = week47.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week47.next();
//        java.util.Date date50 = regularTimePeriod49.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date50, timeZone51);
//        boolean boolean53 = week39.equals((java.lang.Object) wildcardClass44);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(12, 12);
//        long long57 = week56.getFirstMillisecond();
//        java.util.Date date58 = week56.getEnd();
//        java.util.Date date59 = week56.getStart();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
//        long long63 = week62.getFirstMillisecond();
//        java.util.Date date64 = week62.getEnd();
//        java.lang.Class class65 = null;
//        java.util.Date date66 = null;
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date64, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date59, timeZone67);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date29, timeZone67);
//        java.util.Locale locale72 = null;
//        try {
//            org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date2, timeZone67, locale72);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 648L + "'", long16 == 648L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-61782451200000L) + "'", long28 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-61782451200000L) + "'", long48 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-61782451200000L) + "'", long57 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61782451200000L) + "'", long63 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62162265600000L) + "'", long3 == (-62162265600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getLastMillisecond();
        long long5 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62161660800001L) + "'", long4 == (-62161660800001L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
        long long19 = week18.getFirstMillisecond();
        java.util.Date date20 = week18.getEnd();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone23);
        java.lang.Class<?> wildcardClass26 = timeZone23.getClass();
        int int27 = week14.compareTo((java.lang.Object) timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone23);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week31.previous();
        java.lang.Class<?> wildcardClass33 = week31.getClass();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(12, 12);
        long long37 = week36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
        java.util.Date date39 = regularTimePeriod38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date39, timeZone40);
        java.util.Date date42 = null;
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.next();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        long long50 = week49.getFirstMillisecond();
        java.util.Date date51 = week49.getEnd();
        java.lang.Class class52 = null;
        java.util.Date date53 = null;
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date53, timeZone54);
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date51, timeZone54);
        java.lang.Class<?> wildcardClass57 = timeZone54.getClass();
        int int58 = week45.compareTo((java.lang.Object) timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date42, timeZone54);
        java.util.Locale locale60 = null;
        try {
            org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date10, timeZone54, locale60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61782451200000L) + "'", long19 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61782451200000L) + "'", long37 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-61782451200000L) + "'", long50 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNull(regularTimePeriod59);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = week4.getEnd();
        java.util.TimeZone timeZone20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        java.lang.String str11 = week2.toString();
        try {
            org.jfree.data.time.Year year12 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 12, 12" + "'", str11.equals("Week 12, 12"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date18 = week17.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
        java.util.Date date35 = regularTimePeriod34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = week40.getClass();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
        boolean boolean48 = week45.equals((java.lang.Object) 7);
        boolean boolean50 = week45.equals((java.lang.Object) '4');
        long long51 = week45.getSerialIndex();
        java.util.Date date52 = week45.getEnd();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date52, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date35, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone56);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = week63.previous();
        java.lang.Class<?> wildcardClass65 = week63.getClass();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = week68.previous();
        boolean boolean71 = week68.equals((java.lang.Object) 7);
        boolean boolean73 = week68.equals((java.lang.Object) '4');
        long long74 = week68.getSerialIndex();
        java.util.Date date75 = week68.getEnd();
        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date75);
        java.lang.Class class77 = null;
        java.util.Date date78 = null;
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date78, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date75, timeZone79);
        java.lang.Class class82 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass65);
        java.util.Date date83 = null;
        java.lang.Class class84 = null;
        java.util.Date date85 = null;
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class84, date85, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date83, timeZone86);
        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date18, timeZone86);
        java.util.Locale locale90 = null;
        try {
            org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date0, timeZone86, locale90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 648L + "'", long51 == 648L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 648L + "'", long74 == 648L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(class82);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod88);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int9 = week8.getYearValue();
        long long10 = week8.getSerialIndex();
        try {
            int int11 = week2.compareTo((java.lang.Object) week8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        int int15 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = week10.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        try {
            org.jfree.data.time.Year year19 = week14.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        long long12 = week11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        java.lang.Class<?> wildcardClass17 = regularTimePeriod16.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date21 = week20.getStart();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        java.lang.Class<?> wildcardClass27 = week25.getClass();
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.lang.Class<?> wildcardClass32 = week30.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        long long36 = week35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = week35.next();
        java.util.Date date38 = regularTimePeriod37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date38, timeZone39);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week43.previous();
        java.lang.Class<?> wildcardClass45 = week43.getClass();
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        boolean boolean51 = week48.equals((java.lang.Object) 7);
        boolean boolean53 = week48.equals((java.lang.Object) '4');
        long long54 = week48.getSerialIndex();
        java.util.Date date55 = week48.getEnd();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date55);
        java.lang.Class class57 = null;
        java.util.Date date58 = null;
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date58, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date55, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date38, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone59);
        java.util.Locale locale64 = null;
        try {
            org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date3, timeZone59, locale64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61782451200000L) + "'", long12 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61782451200000L) + "'", long36 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 648L + "'", long54 == 648L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        try {
            org.jfree.data.time.Year year8 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.String str7 = timePeriodFormatException4.toString();
        java.lang.String str8 = timePeriodFormatException4.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week2.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        boolean boolean28 = week25.equals((java.lang.Object) 7);
        boolean boolean30 = week25.equals((java.lang.Object) '4');
        long long31 = week25.getSerialIndex();
        java.util.Date date32 = week25.getEnd();
        int int33 = week25.getWeek();
        boolean boolean35 = week25.equals((java.lang.Object) 10.0f);
        java.lang.String str36 = week25.toString();
        java.util.Date date37 = week25.getStart();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        long long45 = week44.getFirstMillisecond();
        java.util.Date date46 = week44.getEnd();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
        java.lang.Class<?> wildcardClass52 = timeZone49.getClass();
        int int53 = week40.compareTo((java.lang.Object) timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date37, timeZone49);
        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(12, 12);
        long long58 = week57.getFirstMillisecond();
        java.util.Date date59 = week57.getEnd();
        java.util.Date date60 = week57.getEnd();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date60, timeZone61);
        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date60);
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date60, timeZone64);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 648L + "'", long31 == 648L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 12, 12" + "'", str36.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61782451200000L) + "'", long45 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-61782451200000L) + "'", long58 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod65);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        boolean boolean5 = week2.equals((java.lang.Object) (byte) -1);
        long long6 = week2.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62162265600000L) + "'", long6 == (-62162265600000L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, (int) (short) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, 24);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
        java.util.Date date35 = regularTimePeriod34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = week40.getClass();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
        boolean boolean48 = week45.equals((java.lang.Object) 7);
        boolean boolean50 = week45.equals((java.lang.Object) '4');
        long long51 = week45.getSerialIndex();
        java.util.Date date52 = week45.getEnd();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date52, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date35, timeZone56);
        java.util.Locale locale60 = null;
        try {
            org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date18, timeZone56, locale60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 648L + "'", long51 == 648L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week11.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date16 = week15.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        java.lang.Class<?> wildcardClass22 = week20.getClass();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        long long26 = week25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week25.next();
        java.util.Date date28 = regularTimePeriod27.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date28, timeZone29);
        boolean boolean31 = week17.equals((java.lang.Object) wildcardClass22);
        java.util.Date date32 = week17.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = week35.getClass();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        long long41 = week40.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week40.next();
        java.util.Date date43 = regularTimePeriod42.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date43, timeZone44);
        java.lang.Class<?> wildcardClass46 = regularTimePeriod45.getClass();
        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date50 = week49.getStart();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week54.previous();
        java.lang.Class<?> wildcardClass56 = week54.getClass();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week59.previous();
        java.lang.Class<?> wildcardClass61 = week59.getClass();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(12, 12);
        long long65 = week64.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = week64.next();
        java.util.Date date67 = regularTimePeriod66.getStart();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date67, timeZone68);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = week72.previous();
        java.lang.Class<?> wildcardClass74 = week72.getClass();
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = week77.previous();
        boolean boolean80 = week77.equals((java.lang.Object) 7);
        boolean boolean82 = week77.equals((java.lang.Object) '4');
        long long83 = week77.getSerialIndex();
        java.util.Date date84 = week77.getEnd();
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date84);
        java.lang.Class class86 = null;
        java.util.Date date87 = null;
        java.util.TimeZone timeZone88 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class86, date87, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass74, date84, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date67, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date50, timeZone88);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date32, timeZone88);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61782451200000L) + "'", long26 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61782451200000L) + "'", long41 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-61782451200000L) + "'", long65 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 648L + "'", long83 == 648L);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone88);
        org.junit.Assert.assertNull(regularTimePeriod89);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        java.util.Date date14 = week12.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date14, timeZone17);
        java.lang.Class<?> wildcardClass20 = timeZone17.getClass();
        int int21 = week8.compareTo((java.lang.Object) timeZone17);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date3, timeZone17);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(9, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone18);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        long long25 = week24.getFirstMillisecond();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date26, timeZone29);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date35 = week34.getStart();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        long long45 = week44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week44.next();
        java.util.Date date47 = regularTimePeriod46.getStart();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        boolean boolean50 = week36.equals((java.lang.Object) wildcardClass41);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        long long54 = week53.getFirstMillisecond();
        java.util.Date date55 = week53.getEnd();
        java.util.Date date56 = week53.getStart();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        long long60 = week59.getFirstMillisecond();
        java.util.Date date61 = week59.getEnd();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date56, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date26, timeZone64);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(12, 12);
        long long72 = week71.getFirstMillisecond();
        java.lang.Class<?> wildcardClass73 = week71.getClass();
        java.lang.Class class74 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass73);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date78 = week77.getStart();
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date78, timeZone79);
        java.util.Locale locale81 = null;
        try {
            org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date26, timeZone79, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61782451200000L) + "'", long25 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61782451200000L) + "'", long45 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61782451200000L) + "'", long54 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61782451200000L) + "'", long60 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-61782451200000L) + "'", long72 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(class74);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        boolean boolean10 = week2.equals((java.lang.Object) week8);
        int int11 = week8.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        long long18 = week17.getFirstMillisecond();
        java.lang.Class<?> wildcardClass19 = week17.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date24 = week23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date24, timeZone25);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        java.lang.Class<?> wildcardClass31 = week29.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        boolean boolean37 = week34.equals((java.lang.Object) 7);
        boolean boolean39 = week34.equals((java.lang.Object) '4');
        long long40 = week34.getSerialIndex();
        java.util.Date date41 = week34.getEnd();
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date41);
        java.lang.Class class43 = null;
        java.util.Date date44 = null;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date44, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date41, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date24, timeZone45);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61782451200000L) + "'", long18 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 648L + "'", long40 == 648L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        java.util.Date date7 = regularTimePeriod4.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week5.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        long long7 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date10 = week9.getStart();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.next();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
        long long19 = week18.getFirstMillisecond();
        java.util.Date date20 = week18.getEnd();
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date20, timeZone23);
        java.lang.Class<?> wildcardClass26 = timeZone23.getClass();
        int int27 = week14.compareTo((java.lang.Object) timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date10, timeZone23);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        java.lang.Class<?> wildcardClass33 = week31.getClass();
        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(12, 12);
        long long39 = week38.getFirstMillisecond();
        java.util.Date date40 = week38.getEnd();
        java.util.Date date41 = week38.getEnd();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
        java.lang.Class<?> wildcardClass48 = week46.getClass();
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass48);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date54 = week53.getStart();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date54);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.next();
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        long long63 = week62.getFirstMillisecond();
        java.util.Date date64 = week62.getEnd();
        java.lang.Class class65 = null;
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date64, timeZone67);
        java.lang.Class<?> wildcardClass70 = timeZone67.getClass();
        int int71 = week58.compareTo((java.lang.Object) timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date54, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date41, timeZone67);
        java.util.Locale locale74 = null;
        try {
            org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date10, timeZone67, locale74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61782451200000L) + "'", long19 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61782451200000L) + "'", long39 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertNotNull(class50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61782451200000L) + "'", long63 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNull(regularTimePeriod73);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.Calendar calendar10 = null;
        try {
            week9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        long long14 = week2.getLastMillisecond();
        long long15 = week2.getFirstMillisecond();
        long long16 = week2.getFirstMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week2.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61781846400001L) + "'", long14 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61782451200000L) + "'", long16 == (-61782451200000L));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.String str22 = timePeriodFormatException14.toString();
        java.lang.Throwable throwable23 = null;
        try {
            timePeriodFormatException14.addSuppressed(throwable23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int6 = week2.compareTo((java.lang.Object) "Week 12, 12");
        long long7 = week2.getSerialIndex();
        java.util.Date date8 = week2.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 648L + "'", long7 == 648L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 97, 3");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(7, (-1));
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        boolean boolean15 = week12.equals((java.lang.Object) 7);
        boolean boolean17 = week12.equals((java.lang.Object) '4');
        long long18 = week12.getSerialIndex();
        java.util.Date date19 = week12.getEnd();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
        java.lang.Class class21 = null;
        java.util.Date date22 = null;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date19, timeZone23);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        java.util.Date date30 = regularTimePeriod29.getStart();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        java.lang.Class<?> wildcardClass35 = week33.getClass();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week38.previous();
        java.lang.Class<?> wildcardClass40 = week38.getClass();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(12, 12);
        long long44 = week43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week43.next();
        java.util.Date date46 = regularTimePeriod45.getStart();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone47);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week51.previous();
        java.lang.Class<?> wildcardClass53 = week51.getClass();
        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week56.previous();
        boolean boolean59 = week56.equals((java.lang.Object) 7);
        boolean boolean61 = week56.equals((java.lang.Object) '4');
        long long62 = week56.getSerialIndex();
        java.util.Date date63 = week56.getEnd();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
        java.lang.Class class65 = null;
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date63, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date46, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date30, timeZone67);
        java.util.Locale locale72 = null;
        try {
            org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date3, timeZone67, locale72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 648L + "'", long18 == 648L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-61782451200000L) + "'", long44 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 648L + "'", long62 == 648L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int6 = week2.compareTo((java.lang.Object) "Week 12, 12");
        long long7 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        java.util.Calendar calendar7 = null;
        try {
            week6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            week4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            week2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        java.util.Date date6 = week4.getEnd();
//        org.jfree.data.time.Year year7 = week4.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(24, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 1, year7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(10, year7);
//        long long12 = week11.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1551600000000L + "'", long12 == 1551600000000L);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = timeZone12.getClass();
        int int16 = week3.compareTo((java.lang.Object) timeZone12);
        try {
            org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date0, timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) 'a');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        java.util.Date date7 = regularTimePeriod4.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str11 = timePeriodFormatException7.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        boolean boolean17 = week14.equals((java.lang.Object) 7);
        boolean boolean19 = week14.equals((java.lang.Object) '4');
        long long20 = week14.getSerialIndex();
        java.util.Date date21 = week14.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date21, timeZone25);
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        java.util.Date date33 = week31.getEnd();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date33, timeZone36);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date42 = week41.getStart();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week46.previous();
        java.lang.Class<?> wildcardClass48 = week46.getClass();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(12, 12);
        long long52 = week51.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week51.next();
        java.util.Date date54 = regularTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date54, timeZone55);
        boolean boolean57 = week43.equals((java.lang.Object) wildcardClass48);
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(12, 12);
        long long61 = week60.getFirstMillisecond();
        java.util.Date date62 = week60.getEnd();
        java.util.Date date63 = week60.getStart();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(12, 12);
        long long67 = week66.getFirstMillisecond();
        java.util.Date date68 = week66.getEnd();
        java.lang.Class class69 = null;
        java.util.Date date70 = null;
        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date70, timeZone71);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date68, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date63, timeZone71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date33, timeZone71);
        int int76 = week2.compareTo((java.lang.Object) class28);
        java.lang.Class class77 = org.jfree.data.time.RegularTimePeriod.downsize(class28);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 648L + "'", long20 == 648L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61782451200000L) + "'", long52 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-61782451200000L) + "'", long61 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-61782451200000L) + "'", long67 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(class77);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        long long14 = week13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        java.util.Date date16 = week13.getEnd();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9, timeZone19);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class6);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        java.util.Date date6 = week3.getEnd();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone9);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        java.lang.Class<?> wildcardClass16 = week14.getClass();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week19.previous();
        boolean boolean22 = week19.equals((java.lang.Object) 7);
        boolean boolean24 = week19.equals((java.lang.Object) '4');
        long long25 = week19.getSerialIndex();
        java.util.Date date26 = week19.getEnd();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date26, timeZone30);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.util.Date date34 = null;
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date34, timeZone37);
        java.util.Locale locale40 = null;
        try {
            org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date6, timeZone37, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 648L + "'", long25 == 648L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        int int7 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((-1), year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, year5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week7.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (short) -1);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException8.getSuppressed();
        java.lang.String str20 = timePeriodFormatException8.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 10);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        java.lang.String str11 = week2.toString();
        int int12 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 12, 12" + "'", str11.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        try {
            org.jfree.data.time.Year year7 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        long long20 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        long long12 = week11.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date14, timeZone15);
        java.util.Date date17 = null;
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        long long25 = week24.getFirstMillisecond();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date26, timeZone29);
        java.lang.Class<?> wildcardClass32 = timeZone29.getClass();
        int int33 = week20.compareTo((java.lang.Object) timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date17, timeZone29);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date3, timeZone29);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61782451200000L) + "'", long12 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61782451200000L) + "'", long25 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        int int12 = week11.getWeek();
        java.lang.String str13 = week11.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week11.next();
        java.util.Date date15 = week11.getEnd();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        java.lang.Class<?> wildcardClass20 = week18.getClass();
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date26 = week25.getStart();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.next();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        long long35 = week34.getFirstMillisecond();
        java.util.Date date36 = week34.getEnd();
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date36, timeZone39);
        java.lang.Class<?> wildcardClass42 = timeZone39.getClass();
        int int43 = week30.compareTo((java.lang.Object) timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date26, timeZone39);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date15, timeZone39);
        java.util.Locale locale46 = null;
        try {
            org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date5, timeZone39, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61782451200000L) + "'", long35 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(6, year4);
//        java.util.Calendar calendar6 = null;
//        try {
//            week5.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getSerialIndex();
        java.lang.String str9 = week2.toString();
        try {
            org.jfree.data.time.Year year10 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 12, 12" + "'", str9.equals("Week 12, 12"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        java.lang.Class<?> wildcardClass6 = week4.getClass();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        boolean boolean12 = week9.equals((java.lang.Object) 7);
        boolean boolean14 = week9.equals((java.lang.Object) '4');
        long long15 = week9.getSerialIndex();
        java.util.Date date16 = week9.getEnd();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass6, date16, timeZone20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        long long27 = week26.getFirstMillisecond();
        java.util.Date date28 = week26.getEnd();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date28, timeZone31);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date37 = week36.getStart();
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date37);
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week41.previous();
        java.lang.Class<?> wildcardClass43 = week41.getClass();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(12, 12);
        long long47 = week46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week46.next();
        java.util.Date date49 = regularTimePeriod48.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date49, timeZone50);
        boolean boolean52 = week38.equals((java.lang.Object) wildcardClass43);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(12, 12);
        long long56 = week55.getFirstMillisecond();
        java.util.Date date57 = week55.getEnd();
        java.util.Date date58 = week55.getStart();
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(12, 12);
        long long62 = week61.getFirstMillisecond();
        java.util.Date date63 = week61.getEnd();
        java.lang.Class class64 = null;
        java.util.Date date65 = null;
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class64, date65, timeZone66);
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date63, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date58, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date28, timeZone66);
        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date28);
        java.lang.Class class72 = null;
        java.util.Date date73 = null;
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone74);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date28, timeZone74);
        java.util.Locale locale77 = null;
        try {
            org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date0, timeZone74, locale77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 648L + "'", long15 == 648L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61782451200000L) + "'", long27 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61782451200000L) + "'", long47 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-61782451200000L) + "'", long56 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-61782451200000L) + "'", long62 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNull(regularTimePeriod76);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = regularTimePeriod4.getStart();
        java.util.Date date6 = regularTimePeriod4.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = regularTimePeriod4.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        long long13 = week10.getSerialIndex();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week10.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date8, timeZone11);
        java.lang.Class<?> wildcardClass14 = timeZone11.getClass();
        int int15 = week2.compareTo((java.lang.Object) timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week2.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        boolean boolean20 = week10.equals((java.lang.Object) throwableArray18);
        int int21 = week10.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        java.lang.String str19 = week11.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 12, 12" + "'", str19.equals("Week 12, 12"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        int int7 = week2.getWeek();
        int int8 = week2.getWeek();
        long long9 = week2.getMiddleMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week2.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782148800001L) + "'", long9 == (-61782148800001L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, (int) (short) 10);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str17 = timePeriodFormatException12.toString();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException12.getSuppressed();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        int int5 = week4.getWeek();
//        java.util.Date date6 = week4.getEnd();
//        org.jfree.data.time.Year year7 = week4.getYear();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(0, year7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(24, year7);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week((int) (byte) 1, year7);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(10, year7);
//        java.util.Calendar calendar12 = null;
//        try {
//            week11.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week2.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getFirstMillisecond();
        java.lang.Class<?> wildcardClass12 = week10.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week10.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        int int15 = week10.compareTo((java.lang.Object) (short) 1);
        long long16 = week10.getMiddleMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week10.getMiddleMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61782148800001L) + "'", long16 == (-61782148800001L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        java.util.Calendar calendar19 = null;
        try {
            week11.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        long long4 = week2.getLastMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-60526886400001L) + "'", long4 == (-60526886400001L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        long long6 = week2.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 648L + "'", long6 == 648L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            week10.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        java.util.Date date6 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week14.previous();
        boolean boolean17 = week14.equals((java.lang.Object) 7);
        boolean boolean19 = week14.equals((java.lang.Object) '4');
        long long20 = week14.getSerialIndex();
        java.util.Date date21 = week14.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date21);
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date21, timeZone25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date31 = week30.getEnd();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        java.lang.Class<?> wildcardClass36 = week34.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week39.next();
        java.util.Date date42 = regularTimePeriod41.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone43);
        java.util.Date date45 = null;
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.next();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(12, 12);
        long long53 = week52.getFirstMillisecond();
        java.util.Date date54 = week52.getEnd();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
        java.lang.Class<?> wildcardClass60 = timeZone57.getClass();
        int int61 = week48.compareTo((java.lang.Object) timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date45, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date31, timeZone57);
        java.util.Locale locale64 = null;
        try {
            org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date6, timeZone57, locale64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 648L + "'", long20 == 648L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61782451200000L) + "'", long53 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week10.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        long long5 = week0.getFirstMillisecond();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        java.util.Date date9 = week6.getEnd();
        boolean boolean10 = week2.equals((java.lang.Object) week6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62107833600000L) + "'", long3 == (-62107833600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        java.util.Date date5 = week3.getEnd();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date5, timeZone11);
        java.lang.Class class13 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        java.lang.Class<?> wildcardClass18 = week16.getClass();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        boolean boolean24 = week21.equals((java.lang.Object) 7);
        boolean boolean26 = week21.equals((java.lang.Object) '4');
        long long27 = week21.getSerialIndex();
        java.util.Date date28 = week21.getEnd();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        java.lang.Class class30 = null;
        java.util.Date date31 = null;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date28, timeZone32);
        java.lang.Class class35 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(12, 12);
        long long39 = week38.getFirstMillisecond();
        java.util.Date date40 = week38.getEnd();
        java.lang.Class class41 = null;
        java.util.Date date42 = null;
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date42, timeZone43);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date40, timeZone43);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date49 = week48.getStart();
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date49);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
        java.lang.Class<?> wildcardClass55 = week53.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(12, 12);
        long long59 = week58.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = week58.next();
        java.util.Date date61 = regularTimePeriod60.getStart();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date61, timeZone62);
        boolean boolean64 = week50.equals((java.lang.Object) wildcardClass55);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        long long68 = week67.getFirstMillisecond();
        java.util.Date date69 = week67.getEnd();
        java.util.Date date70 = week67.getStart();
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(12, 12);
        long long74 = week73.getFirstMillisecond();
        java.util.Date date75 = week73.getEnd();
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date75, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date70, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date40, timeZone78);
        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date40);
        java.lang.Class class84 = null;
        java.util.Date date85 = null;
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class84, date85, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date40, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone86);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 648L + "'", long27 == 648L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(class35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61782451200000L) + "'", long39 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-61782451200000L) + "'", long59 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61782451200000L) + "'", long68 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61782451200000L) + "'", long74 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNull(regularTimePeriod89);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        java.lang.Class<?> wildcardClass11 = week2.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        long long7 = week6.getFirstMillisecond();
        java.util.Date date8 = week6.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date8, timeZone11);
        java.lang.Class<?> wildcardClass14 = timeZone11.getClass();
        int int15 = week2.compareTo((java.lang.Object) timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week2.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        long long27 = week22.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getYearValue();
        long long11 = week2.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 648L + "'", long11 == 648L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        long long9 = week2.getFirstMillisecond();
        int int10 = week2.getWeek();
        int int11 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(24, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, year6);
//        long long10 = week9.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546761599999L + "'", long10 == 1546761599999L);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        long long9 = week2.getFirstMillisecond();
        long long10 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61781846400001L) + "'", long10 == (-61781846400001L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(class19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        long long13 = week2.getFirstMillisecond();
        java.util.Date date14 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        java.util.Date date10 = week2.getEnd();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week13.previous();
        java.lang.Class<?> wildcardClass15 = week13.getClass();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        boolean boolean21 = week18.equals((java.lang.Object) 7);
        boolean boolean23 = week18.equals((java.lang.Object) '4');
        long long24 = week18.getSerialIndex();
        java.util.Date date25 = week18.getEnd();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date25, timeZone29);
        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        long long36 = week35.getFirstMillisecond();
        java.util.Date date37 = week35.getEnd();
        java.lang.Class class38 = null;
        java.util.Date date39 = null;
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class38, date39, timeZone40);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date37, timeZone40);
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date46 = week45.getStart();
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        java.lang.Class<?> wildcardClass52 = week50.getClass();
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(12, 12);
        long long56 = week55.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week55.next();
        java.util.Date date58 = regularTimePeriod57.getStart();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date58, timeZone59);
        boolean boolean61 = week47.equals((java.lang.Object) wildcardClass52);
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(12, 12);
        long long65 = week64.getFirstMillisecond();
        java.util.Date date66 = week64.getEnd();
        java.util.Date date67 = week64.getStart();
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(12, 12);
        long long71 = week70.getFirstMillisecond();
        java.util.Date date72 = week70.getEnd();
        java.lang.Class class73 = null;
        java.util.Date date74 = null;
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class73, date74, timeZone75);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date72, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date67, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date37, timeZone75);
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date10, timeZone75);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 648L + "'", long24 == 648L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-61782451200000L) + "'", long36 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-61782451200000L) + "'", long56 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-61782451200000L) + "'", long65 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-61782451200000L) + "'", long71 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        boolean boolean20 = week10.equals((java.lang.Object) throwableArray18);
        long long21 = week10.getLastMillisecond();
        long long22 = week10.getSerialIndex();
        try {
            org.jfree.data.time.Year year23 = week10.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61781846400001L) + "'", long21 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 648L + "'", long22 == 648L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, 11);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) '#');
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        java.util.Date date19 = week11.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.lang.String str19 = week4.toString();
        boolean boolean21 = week4.equals((java.lang.Object) (byte) -1);
        try {
            org.jfree.data.time.Year year22 = week4.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 12, 12" + "'", str19.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        long long19 = week11.getLastMillisecond();
        java.util.Date date20 = week11.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        int int13 = week10.getYearValue();
        java.util.Date date14 = week10.getStart();
        int int15 = week10.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        int int13 = week10.getYearValue();
        long long14 = week10.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61781846400001L) + "'", long14 == (-61781846400001L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        boolean boolean5 = week2.equals((java.lang.Object) (byte) -1);
        long long6 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        long long10 = week9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week9.next();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week14.next();
        boolean boolean18 = week9.equals((java.lang.Object) regularTimePeriod17);
        try {
            int int19 = week2.compareTo((java.lang.Object) regularTimePeriod17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62162265600000L) + "'", long6 == (-62162265600000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61782451200000L) + "'", long10 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getWeek();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(24, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 1, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(7, year8);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 1, year8);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getSerialIndex();
        int int9 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.next();
        boolean boolean10 = week2.equals((java.lang.Object) week8);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((int) (byte) 0, 6);
        int int14 = week2.compareTo((java.lang.Object) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) week5);
        int int8 = week5.getWeek();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getFirstMillisecond();
        int int6 = week4.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62136259200000L) + "'", long5 == (-62136259200000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getSerialIndex();
        try {
            org.jfree.data.time.Year year9 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        java.lang.Class class2 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        java.lang.Class<?> wildcardClass7 = week5.getClass();
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        java.util.Date date14 = week12.getEnd();
        java.util.Date date15 = week12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date15, timeZone16);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.previous();
        java.lang.Class<?> wildcardClass22 = week20.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date28 = week27.getStart();
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week32.next();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(12, 12);
        long long37 = week36.getFirstMillisecond();
        java.util.Date date38 = week36.getEnd();
        java.lang.Class class39 = null;
        java.util.Date date40 = null;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date38, timeZone41);
        java.lang.Class<?> wildcardClass44 = timeZone41.getClass();
        int int45 = week32.compareTo((java.lang.Object) timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date28, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date15, timeZone41);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week50.previous();
        boolean boolean53 = week50.equals((java.lang.Object) 7);
        boolean boolean55 = week50.equals((java.lang.Object) '4');
        long long56 = week50.getSerialIndex();
        java.util.Date date57 = week50.getStart();
        java.lang.Class class58 = null;
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(12, 12);
        long long62 = week61.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week61.next();
        java.util.Date date64 = week61.getEnd();
        java.lang.Class class65 = null;
        java.util.Date date66 = null;
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date64, timeZone67);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date57, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date15, timeZone67);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(class2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61782451200000L) + "'", long37 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 648L + "'", long56 == 648L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-61782451200000L) + "'", long62 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        int int4 = week2.getWeek();
        java.util.Date date5 = week2.getStart();
        long long6 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getWeek();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62107833600000L) + "'", long3 == (-62107833600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
        java.util.Calendar calendar12 = null;
        try {
            week11.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        int int7 = week2.getWeek();
        long long8 = week2.getFirstMillisecond();
        int int9 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getStart();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 12, 12" + "'", str6.equals("Week 12, 12"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 97, 3");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getWeek();
        java.util.Date date5 = week2.getEnd();
        long long6 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62107833600000L) + "'", long3 == (-62107833600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62107833600000L) + "'", long6 == (-62107833600000L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        java.lang.Class<?> wildcardClass18 = date17.getClass();
        int int19 = week2.compareTo((java.lang.Object) date17);
        long long20 = week2.getMiddleMillisecond();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        boolean boolean26 = week23.equals((java.lang.Object) 7);
        boolean boolean28 = week23.equals((java.lang.Object) '4');
        long long29 = week23.getSerialIndex();
        java.util.Date date30 = week23.getEnd();
        int int31 = week23.getWeek();
        boolean boolean33 = week23.equals((java.lang.Object) 10.0f);
        java.lang.String str34 = week23.toString();
        long long35 = week23.getLastMillisecond();
        int int36 = week2.compareTo((java.lang.Object) long35);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782148800001L) + "'", long20 == (-61782148800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 648L + "'", long29 == 648L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 12 + "'", int31 == 12);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Week 12, 12" + "'", str34.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-61781846400001L) + "'", long35 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        long long13 = week2.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week2.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Object obj4 = null;
        boolean boolean5 = week2.equals(obj4);
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 12, 12" + "'", str6.equals("Week 12, 12"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str9 = timePeriodFormatException8.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException6.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str18 = timePeriodFormatException17.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        java.lang.String str22 = timePeriodFormatException17.toString();
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException17.getSuppressed();
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException17.getSuppressed();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        boolean boolean26 = week2.equals((java.lang.Object) timePeriodFormatException17);
        int int27 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date11, timeZone12);
        java.lang.Class<?> wildcardClass14 = regularTimePeriod13.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date18 = week17.getStart();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date18);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.previous();
        java.lang.Class<?> wildcardClass24 = week22.getClass();
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week27.previous();
        java.lang.Class<?> wildcardClass29 = week27.getClass();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
        java.util.Date date35 = regularTimePeriod34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date35, timeZone36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = week40.getClass();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week45.previous();
        boolean boolean48 = week45.equals((java.lang.Object) 7);
        boolean boolean50 = week45.equals((java.lang.Object) '4');
        long long51 = week45.getSerialIndex();
        java.util.Date date52 = week45.getEnd();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date52);
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date52, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date35, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date18, timeZone56);
        try {
            org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(date0, timeZone56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 648L + "'", long51 == 648L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782753600001L) + "'", long7 == (-61782753600001L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, (int) (short) -1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 0);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getWeek();
        java.util.Date date5 = week2.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62107833600000L) + "'", long3 == (-62107833600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        int int15 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week10.getEnd();
        try {
            org.jfree.data.time.Year year17 = week10.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        long long14 = week2.getLastMillisecond();
        java.util.Date date15 = week2.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61781846400001L) + "'", long14 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        java.lang.String str6 = week2.toString();
        int int7 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 12, 12" + "'", str6.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str14 = timePeriodFormatException13.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException13.getSuppressed();
        java.lang.Class<?> wildcardClass19 = throwableArray18.getClass();
        boolean boolean20 = week10.equals((java.lang.Object) throwableArray18);
        long long21 = week10.getLastMillisecond();
        long long22 = week10.getSerialIndex();
        java.util.Calendar calendar23 = null;
        try {
            long long24 = week10.getMiddleMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61782451200000L) + "'", long11 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61781846400001L) + "'", long21 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 648L + "'", long22 == 648L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
//        long long5 = week2.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        int int8 = week7.getWeek();
//        java.util.Date date9 = week7.getEnd();
//        org.jfree.data.time.Year year10 = week7.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((-1), year10);
//        int int12 = week2.compareTo((java.lang.Object) year10);
//        long long13 = week2.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61781846400001L) + "'", long13 == (-61781846400001L));
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        long long4 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        int int6 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61781846400001L) + "'", long4 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = regularTimePeriod3.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = regularTimePeriod3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = week15.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.previous();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week4.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        long long19 = week11.getFirstMillisecond();
        java.util.Calendar calendar20 = null;
        try {
            week11.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61782451200000L) + "'", long19 == (-61782451200000L));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.lang.Object obj27 = null;
        int int28 = week22.compareTo(obj27);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        long long6 = week5.getLastMillisecond();
        int int7 = week5.getYearValue();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        int int6 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getLastMillisecond();
        long long7 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62167104000001L) + "'", long5 == (-62167104000001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62167104000001L) + "'", long6 == (-62167104000001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167708800000L) + "'", long7 == (-62167708800000L));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        long long14 = week2.getSerialIndex();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week2.getMiddleMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.util.Date date18 = week10.getStart();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        long long27 = week26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
        java.util.Date date29 = regularTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date29, timeZone30);
        java.util.Locale locale32 = null;
        try {
            org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date18, timeZone30, locale32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-61782451200000L) + "'", long27 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 0");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str12 = timePeriodFormatException10.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 1, 0" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: Week 1, 0"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        boolean boolean9 = week6.equals((java.lang.Object) 7);
        boolean boolean11 = week6.equals((java.lang.Object) '4');
        long long12 = week6.getSerialIndex();
        java.util.Date date13 = week6.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        long long15 = week14.getLastMillisecond();
        int int16 = week14.getYearValue();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.previous();
        boolean boolean19 = week2.equals((java.lang.Object) week14);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = week14.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 648L + "'", long12 == 648L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61781846400001L) + "'", long15 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 12, 12" + "'", str17.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) 1, year5);
//        long long8 = week7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546761599999L + "'", long8 == 1546761599999L);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        java.util.Date date6 = week2.getStart();
        long long7 = week2.getFirstMillisecond();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = week10.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        long long16 = week15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week15.next();
        java.util.Date date18 = regularTimePeriod17.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date18, timeZone19);
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date25 = week24.getStart();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week29.previous();
        java.lang.Class<?> wildcardClass31 = week29.getClass();
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
        java.lang.Class<?> wildcardClass36 = week34.getClass();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week39.next();
        java.util.Date date42 = regularTimePeriod41.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date42, timeZone43);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        java.lang.Class<?> wildcardClass49 = week47.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week52.previous();
        boolean boolean55 = week52.equals((java.lang.Object) 7);
        boolean boolean57 = week52.equals((java.lang.Object) '4');
        long long58 = week52.getSerialIndex();
        java.util.Date date59 = week52.getEnd();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date59);
        java.lang.Class class61 = null;
        java.util.Date date62 = null;
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date62, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date59, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date42, timeZone63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone63);
        try {
            int int68 = week2.compareTo((java.lang.Object) regularTimePeriod67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61782451200000L) + "'", long16 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 648L + "'", long58 == 648L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-60526886400001L) + "'", long5 == (-60526886400001L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) week5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str13 = timePeriodFormatException12.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.String str17 = timePeriodFormatException12.toString();
        java.lang.Throwable[] throwableArray18 = timePeriodFormatException12.getSuppressed();
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        java.lang.String str21 = timePeriodFormatException12.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class<?> wildcardClass5 = week2.getClass();
        long long6 = week2.getSerialIndex();
        java.lang.String str7 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 648L + "'", long6 == 648L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 12, 12" + "'", str7.equals("Week 12, 12"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class5);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        int int13 = week9.compareTo((java.lang.Object) "Week 12, 12");
        long long14 = week9.getSerialIndex();
        java.util.Date date15 = week9.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.previous();
        java.lang.Class<?> wildcardClass20 = week18.getClass();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        boolean boolean26 = week23.equals((java.lang.Object) 7);
        boolean boolean28 = week23.equals((java.lang.Object) '4');
        long long29 = week23.getSerialIndex();
        java.util.Date date30 = week23.getEnd();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date30);
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date30, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date15, timeZone34);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 648L + "'", long29 == 648L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNull(regularTimePeriod37);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, 7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        long long5 = week4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 257L + "'", long5 == 257L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) ' ');
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week2.previous();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = week2.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            week2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        boolean boolean2 = week0.equals((java.lang.Object) '#');
//        java.lang.String str3 = week0.toString();
//        int int4 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date5, timeZone8);
        try {
            org.jfree.data.time.Year year11 = week10.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (byte) 100);
        long long3 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5301L + "'", long3 == 5301L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        long long5 = week2.getSerialIndex();
        long long6 = week2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 648L + "'", long5 == 648L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getStart();
        try {
            org.jfree.data.time.Year year6 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = regularTimePeriod5.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        java.util.Date date14 = week2.getStart();
        long long15 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        boolean boolean7 = week2.equals((java.lang.Object) week5);
        long long8 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException10.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException8.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray20 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("Week 1, 0");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str12 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date9 = week8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.lang.Object obj14 = null;
        boolean boolean15 = week12.equals(obj14);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        long long5 = week2.getMiddleMillisecond();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61782148800001L) + "'", long5 == (-61782148800001L));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getLastMillisecond();
        long long9 = week2.getLastMillisecond();
        long long10 = week2.getSerialIndex();
        java.util.Date date11 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61781846400001L) + "'", long8 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61781846400001L) + "'", long9 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 648L + "'", long10 == 648L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        java.util.Calendar calendar14 = null;
        try {
            week10.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        int int15 = week10.compareTo((java.lang.Object) (short) 1);
        int int16 = week10.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        long long6 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        java.lang.Class<?> wildcardClass8 = week2.getClass();
        long long9 = week2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 648L + "'", long9 == 648L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        java.lang.String str11 = week2.toString();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) '4', 1);
        int int15 = week2.compareTo((java.lang.Object) 1);
        long long16 = week2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Week 12, 12" + "'", str11.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61782451200000L) + "'", long16 == (-61782451200000L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        long long10 = week9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61782451200000L) + "'", long10 == (-61782451200000L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week -1, 0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        int int15 = week10.compareTo((java.lang.Object) (short) 1);
        java.util.Date date16 = week10.getEnd();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = week10.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 1);
        long long3 = week2.getSerialIndex();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 105L + "'", long3 == 105L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        try {
            org.jfree.data.time.Year year13 = week10.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        long long13 = week10.getSerialIndex();
        java.util.Date date14 = week10.getStart();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, 12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 1, (int) (short) 100);
        long long3 = week2.getLastMillisecond();
        long long4 = week2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-59011257600001L) + "'", long3 == (-59011257600001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-59011862400000L) + "'", long4 == (-59011862400000L));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(100, year5);
//        java.lang.Class<?> wildcardClass8 = year5.getClass();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        int int6 = week5.getWeek();
//        java.util.Date date7 = week5.getEnd();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(0, year8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(24, year8);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week((int) (byte) 1, year8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(7, year8);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week((-1), year8);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year8);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        int int4 = week3.getWeek();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Year year6 = week3.getYear();
//        java.util.Date date7 = year6.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) -1, year6);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) '#', year6);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(0, year6);
//        java.util.Calendar calendar11 = null;
//        try {
//            week10.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.String str11 = timePeriodFormatException9.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str17 = timePeriodFormatException16.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException16.getSuppressed();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str26 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        java.util.Date date2 = week0.getEnd();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.previous();
        java.lang.String str6 = week4.toString();
        long long7 = week4.getSerialIndex();
        java.util.Date date8 = week4.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 12, 12" + "'", str6.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 648L + "'", long7 == 648L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) ' ');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(10, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((-1), year5);
//        long long8 = week7.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107006L + "'", long8 == 107006L);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.lang.String str9 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week2.next();
        long long11 = regularTimePeriod10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 12, 12" + "'", str9.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781544000001L) + "'", long11 == (-61781544000001L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 12, 12");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 12, 12" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 12, 12"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        int int4 = week2.getWeek();
        long long5 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        java.util.Date date7 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62167104000001L) + "'", long5 == (-62167104000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (short) -1);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        long long19 = week11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week11.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.previous();
        boolean boolean9 = week6.equals((java.lang.Object) 7);
        boolean boolean11 = week6.equals((java.lang.Object) '4');
        long long12 = week6.getSerialIndex();
        java.util.Date date13 = week6.getEnd();
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
        long long15 = week14.getLastMillisecond();
        int int16 = week14.getYearValue();
        java.lang.String str17 = week14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week14.previous();
        boolean boolean19 = week2.equals((java.lang.Object) week14);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = week2.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 648L + "'", long12 == 648L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61781846400001L) + "'", long15 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 12, 12" + "'", str17.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        java.lang.String str28 = timePeriodFormatException26.toString();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        int int30 = week4.compareTo((java.lang.Object) timePeriodFormatException20);
        long long31 = week4.getLastMillisecond();
        try {
            org.jfree.data.time.Year year32 = week4.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-61781846400001L) + "'", long31 == (-61781846400001L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 52");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Week 0, 52" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Week 0, 52"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        try {
            org.jfree.data.time.Year year5 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        long long9 = week8.getFirstMillisecond();
        java.util.Date date10 = week8.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date10, timeZone13);
        boolean boolean16 = week2.equals((java.lang.Object) date10);
        try {
            org.jfree.data.time.Year year17 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61782451200000L) + "'", long9 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        long long6 = week2.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date18, timeZone21);
        java.lang.Class<?> wildcardClass24 = timeZone21.getClass();
        int int25 = week12.compareTo((java.lang.Object) timeZone21);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date9, timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(6, year4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.next();
//        long long7 = week5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1549180800000L + "'", long7 == 1549180800000L);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getStart();
        int int5 = week2.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str16 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        long long6 = week2.getLastMillisecond();
        int int7 = week2.getWeek();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        java.util.Calendar calendar6 = null;
        try {
            week5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getStart();
        java.util.Date date6 = week2.getStart();
        java.lang.Class class7 = null;
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = week10.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        boolean boolean18 = week15.equals((java.lang.Object) 7);
        boolean boolean20 = week15.equals((java.lang.Object) '4');
        long long21 = week15.getSerialIndex();
        java.util.Date date22 = week15.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = null;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone26);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(12, 12);
        long long33 = week32.getFirstMillisecond();
        java.util.Date date34 = week32.getEnd();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(date34, timeZone37);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date43 = week42.getStart();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.previous();
        java.lang.Class<?> wildcardClass49 = week47.getClass();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(12, 12);
        long long53 = week52.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week52.next();
        java.util.Date date55 = regularTimePeriod54.getStart();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date55, timeZone56);
        boolean boolean58 = week44.equals((java.lang.Object) wildcardClass49);
        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(12, 12);
        long long62 = week61.getFirstMillisecond();
        java.util.Date date63 = week61.getEnd();
        java.util.Date date64 = week61.getStart();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        long long68 = week67.getFirstMillisecond();
        java.util.Date date69 = week67.getEnd();
        java.lang.Class class70 = null;
        java.util.Date date71 = null;
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date71, timeZone72);
        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date69, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date64, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date34, timeZone72);
        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date34);
        java.lang.Class class78 = null;
        java.util.Date date79 = null;
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date79, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date34, timeZone80);
        java.util.Locale locale83 = null;
        try {
            org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date6, timeZone80, locale83);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 648L + "'", long21 == 648L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-61782451200000L) + "'", long33 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61782451200000L) + "'", long53 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-61782451200000L) + "'", long62 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-61782451200000L) + "'", long68 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNull(regularTimePeriod82);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) -1, (int) (byte) 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62162265600000L) + "'", long3 == (-62162265600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.previous();
        java.lang.Class<?> wildcardClass5 = week3.getClass();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        boolean boolean11 = week8.equals((java.lang.Object) 7);
        boolean boolean13 = week8.equals((java.lang.Object) '4');
        long long14 = week8.getSerialIndex();
        java.util.Date date15 = week8.getEnd();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date15, timeZone19);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        long long26 = week25.getFirstMillisecond();
        java.util.Date date27 = week25.getEnd();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date36 = week35.getStart();
        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date36);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.previous();
        java.lang.Class<?> wildcardClass42 = week40.getClass();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(12, 12);
        long long46 = week45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = week45.next();
        java.util.Date date48 = regularTimePeriod47.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date48, timeZone49);
        boolean boolean51 = week37.equals((java.lang.Object) wildcardClass42);
        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(12, 12);
        long long55 = week54.getFirstMillisecond();
        java.util.Date date56 = week54.getEnd();
        java.util.Date date57 = week54.getStart();
        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(12, 12);
        long long61 = week60.getFirstMillisecond();
        java.util.Date date62 = week60.getEnd();
        java.lang.Class class63 = null;
        java.util.Date date64 = null;
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date64, timeZone65);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date62, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date57, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date27, timeZone65);
        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(date27);
        java.lang.Class class71 = null;
        java.util.Date date72 = null;
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date72, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date27, timeZone73);
        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date79 = week78.getStart();
        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date79);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date79);
        java.lang.Class class82 = null;
        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(12, 12);
        long long86 = week85.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = week85.next();
        java.util.Date date88 = week85.getEnd();
        java.lang.Class class89 = null;
        java.util.Date date90 = null;
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class89, date90, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class82, date88, timeZone91);
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date79, timeZone91);
        java.util.Locale locale95 = null;
        try {
            org.jfree.data.time.Week week96 = new org.jfree.data.time.Week(date27, timeZone91, locale95);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61782451200000L) + "'", long26 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-61782451200000L) + "'", long46 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-61782451200000L) + "'", long55 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-61782451200000L) + "'", long61 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-61782451200000L) + "'", long86 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNull(regularTimePeriod92);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.lang.String str19 = week4.toString();
        boolean boolean21 = week4.equals((java.lang.Object) (byte) -1);
        int int22 = week4.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 12, 12" + "'", str19.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException14.getSuppressed();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        boolean boolean28 = week25.equals((java.lang.Object) 7);
        boolean boolean30 = week25.equals((java.lang.Object) '4');
        long long31 = week25.getSerialIndex();
        java.util.Date date32 = week25.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str35 = timePeriodFormatException34.toString();
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException34.getSuppressed();
        java.lang.String str37 = timePeriodFormatException34.toString();
        java.lang.String str38 = timePeriodFormatException34.toString();
        int int39 = week25.compareTo((java.lang.Object) timePeriodFormatException34);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Class<?> wildcardClass41 = timePeriodFormatException34.getClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 648L + "'", long31 == 648L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        int int4 = week2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Date date1 = week0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            week0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getStart();
        int int5 = week2.getWeek();
        int int6 = week2.getYearValue();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date9 = week8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = week12.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        long long6 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61781846400001L) + "'", long6 == (-61781846400001L));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        int int19 = week11.getWeek();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str11 = timePeriodFormatException1.toString();
        java.lang.String str12 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        int int13 = week11.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.next();
        try {
            int int18 = week11.compareTo((java.lang.Object) regularTimePeriod17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getLastMillisecond();
        long long9 = week2.getLastMillisecond();
        long long10 = week2.getFirstMillisecond();
        int int11 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61781846400001L) + "'", long8 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-61781846400001L) + "'", long9 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-61782451200000L) + "'", long10 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week2.next();
        java.util.Calendar calendar10 = null;
        try {
            week2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61781846400001L) + "'", long8 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date34, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone55);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        java.lang.Class<?> wildcardClass64 = week62.getClass();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        boolean boolean70 = week67.equals((java.lang.Object) 7);
        boolean boolean72 = week67.equals((java.lang.Object) '4');
        long long73 = week67.getSerialIndex();
        java.util.Date date74 = week67.getEnd();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date74);
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date74, timeZone78);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
        java.util.Date date82 = null;
        java.lang.Class class83 = null;
        java.util.Date date84 = null;
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date84, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone85);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date17, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = week88.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 648L + "'", long73 == 648L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(regularTimePeriod89);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        java.util.Date date4 = week2.getStart();
        int int5 = week2.getWeek();
        java.lang.String str6 = week2.toString();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 97, 3" + "'", str6.equals("Week 97, 3"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        int int5 = week2.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.next();
        long long7 = week2.getFirstMillisecond();
        long long8 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61782451200000L) + "'", long7 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61781846400001L) + "'", long8 == (-61781846400001L));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test421");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(53, year5);
//        java.util.Date date7 = year5.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(53, year5);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        long long6 = week2.getMiddleMillisecond();
        boolean boolean8 = week2.equals((java.lang.Object) 0);
        java.util.Calendar calendar9 = null;
        try {
            week2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.lang.Class<?> wildcardClass10 = timeZone7.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', (int) (short) -1);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        boolean boolean10 = week7.equals((java.lang.Object) 7);
        boolean boolean12 = week7.equals((java.lang.Object) '4');
        long long13 = week7.getSerialIndex();
        java.util.Date date14 = week7.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        java.lang.Class class16 = null;
        java.util.Date date17 = null;
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date14, timeZone18);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(12, 12);
        long long25 = week24.getFirstMillisecond();
        java.util.Date date26 = week24.getEnd();
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(date26, timeZone29);
        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date35 = week34.getStart();
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        long long45 = week44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = week44.next();
        java.util.Date date47 = regularTimePeriod46.getStart();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date47, timeZone48);
        boolean boolean50 = week36.equals((java.lang.Object) wildcardClass41);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        long long54 = week53.getFirstMillisecond();
        java.util.Date date55 = week53.getEnd();
        java.util.Date date56 = week53.getStart();
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(12, 12);
        long long60 = week59.getFirstMillisecond();
        java.util.Date date61 = week59.getEnd();
        java.lang.Class class62 = null;
        java.util.Date date63 = null;
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date63, timeZone64);
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date61, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date56, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date26, timeZone64);
        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date26);
        java.lang.String str70 = week69.toString();
        java.util.Calendar calendar71 = null;
        try {
            long long72 = week69.getLastMillisecond(calendar71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61782451200000L) + "'", long25 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61782451200000L) + "'", long45 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61782451200000L) + "'", long54 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61782451200000L) + "'", long60 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Week 12, 12" + "'", str70.equals("Week 12, 12"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        long long14 = week2.getSerialIndex();
        int int15 = week2.getYearValue();
        java.lang.String str16 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 648L + "'", long14 == 648L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 12, 12" + "'", str16.equals("Week 12, 12"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        long long14 = week10.getFirstMillisecond();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week10.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        java.util.Date date17 = regularTimePeriod16.getStart();
        java.lang.Class<?> wildcardClass18 = date17.getClass();
        int int19 = week2.compareTo((java.lang.Object) date17);
        long long20 = week2.getMiddleMillisecond();
        java.lang.String str21 = week2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782148800001L) + "'", long20 == (-61782148800001L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 12, 12" + "'", str21.equals("Week 12, 12"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int6 = week2.compareTo((java.lang.Object) "Week 12, 12");
        long long7 = week2.getSerialIndex();
        java.util.Date date8 = week2.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 648L + "'", long7 == 648L);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.util.Calendar calendar27 = null;
        try {
            week4.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        java.lang.String str4 = week2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.next();
        java.util.Date date6 = week2.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
        java.lang.Class<?> wildcardClass11 = week9.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.next();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        long long26 = week25.getFirstMillisecond();
        java.util.Date date27 = week25.getEnd();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date27, timeZone30);
        java.lang.Class<?> wildcardClass33 = timeZone30.getClass();
        int int34 = week21.compareTo((java.lang.Object) timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date17, timeZone30);
        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(date6, timeZone30);
        long long37 = week36.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 12, 12" + "'", str4.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-61782451200000L) + "'", long26 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-61782148800001L) + "'", long37 == (-61782148800001L));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(6, (-1));
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        int int5 = week4.getWeek();
        java.util.Calendar calendar6 = null;
        try {
            week4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        long long12 = week10.getSerialIndex();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        boolean boolean18 = week15.equals((java.lang.Object) 7);
        boolean boolean20 = week15.equals((java.lang.Object) '4');
        long long21 = week15.getSerialIndex();
        java.util.Date date22 = week15.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        long long24 = week23.getLastMillisecond();
        java.util.Date date25 = week23.getEnd();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.next();
        boolean boolean30 = week23.equals((java.lang.Object) week28);
        try {
            int int31 = week10.compareTo((java.lang.Object) week28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 648L + "'", long12 == 648L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 648L + "'", long21 == 648L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-61781846400001L) + "'", long24 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week7.next();
        boolean boolean11 = week2.equals((java.lang.Object) regularTimePeriod10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week2.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        int int8 = week2.getYearValue();
        java.lang.Object obj9 = null;
        int int10 = week2.compareTo(obj9);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 53);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 24);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        java.lang.String str13 = week2.toString();
        java.util.Date date14 = week2.getStart();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        long long18 = week17.getFirstMillisecond();
        java.util.Date date19 = week17.getEnd();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date19, timeZone22);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date14, timeZone22);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        int int29 = week28.getWeek();
        java.lang.String str30 = week28.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week28.next();
        java.util.Date date32 = week28.getEnd();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        java.lang.Class<?> wildcardClass37 = week35.getClass();
        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date43 = week42.getStart();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(date43);
        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week47.next();
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(12, 12);
        long long52 = week51.getFirstMillisecond();
        java.util.Date date53 = week51.getEnd();
        java.lang.Class class54 = null;
        java.util.Date date55 = null;
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class54, date55, timeZone56);
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date53, timeZone56);
        java.lang.Class<?> wildcardClass59 = timeZone56.getClass();
        int int60 = week47.compareTo((java.lang.Object) timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date43, timeZone56);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date32, timeZone56);
        java.util.Locale locale63 = null;
        try {
            org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date14, timeZone56, locale63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61782451200000L) + "'", long18 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 12, 12" + "'", str30.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(class38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-61782451200000L) + "'", long52 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(regularTimePeriod61);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        java.lang.String str5 = week0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.util.Date date1 = week0.getStart();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getWeek();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        java.util.Date date10 = regularTimePeriod9.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date10, timeZone11);
        java.lang.Class<?> wildcardClass13 = regularTimePeriod12.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date17 = week16.getStart();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week21.previous();
        java.lang.Class<?> wildcardClass23 = week21.getClass();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week39.previous();
        java.lang.Class<?> wildcardClass41 = week39.getClass();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week44.previous();
        boolean boolean47 = week44.equals((java.lang.Object) 7);
        boolean boolean49 = week44.equals((java.lang.Object) '4');
        long long50 = week44.getSerialIndex();
        java.util.Date date51 = week44.getEnd();
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date51);
        java.lang.Class class53 = null;
        java.util.Date date54 = null;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date34, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date17, timeZone55);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = week62.previous();
        java.lang.Class<?> wildcardClass64 = week62.getClass();
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        boolean boolean70 = week67.equals((java.lang.Object) 7);
        boolean boolean72 = week67.equals((java.lang.Object) '4');
        long long73 = week67.getSerialIndex();
        java.util.Date date74 = week67.getEnd();
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date74);
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date74, timeZone78);
        java.lang.Class class81 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
        java.util.Date date82 = null;
        java.lang.Class class83 = null;
        java.util.Date date84 = null;
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class83, date84, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance(class81, date82, timeZone85);
        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date17, timeZone85);
        java.lang.Class<?> wildcardClass89 = date17.getClass();
        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 648L + "'", long50 == 648L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 648L + "'", long73 == 648L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(class81);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNotNull(wildcardClass89);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
//        int int3 = week2.getYearValue();
//        long long4 = week2.getSerialIndex();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str9 = timePeriodFormatException8.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException8.getSuppressed();
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException6.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str18 = timePeriodFormatException17.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
//        java.lang.String str22 = timePeriodFormatException17.toString();
//        java.lang.Throwable[] throwableArray23 = timePeriodFormatException17.getSuppressed();
//        java.lang.Throwable[] throwableArray24 = timePeriodFormatException17.getSuppressed();
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        boolean boolean26 = week2.equals((java.lang.Object) timePeriodFormatException17);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        int int29 = week28.getWeek();
//        java.util.Date date30 = week28.getEnd();
//        org.jfree.data.time.Year year31 = week28.getYear();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(0, year31);
//        int int33 = week2.compareTo((java.lang.Object) 0);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str18.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertNotNull(throwableArray23);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        boolean boolean13 = week10.equals((java.lang.Object) 7);
        boolean boolean15 = week10.equals((java.lang.Object) '4');
        long long16 = week10.getSerialIndex();
        java.util.Date date17 = week10.getEnd();
        int int18 = week10.getWeek();
        boolean boolean20 = week10.equals((java.lang.Object) 10.0f);
        java.lang.String str21 = week10.toString();
        long long22 = week10.getLastMillisecond();
        long long23 = week10.getFirstMillisecond();
        long long24 = week10.getSerialIndex();
        java.util.Date date25 = week10.getEnd();
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.lang.Class<?> wildcardClass32 = week30.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        boolean boolean38 = week35.equals((java.lang.Object) 7);
        boolean boolean40 = week35.equals((java.lang.Object) '4');
        long long41 = week35.getSerialIndex();
        java.util.Date date42 = week35.getEnd();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date42, timeZone46);
        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(12, 12);
        long long53 = week52.getFirstMillisecond();
        java.util.Date date54 = week52.getEnd();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date54, timeZone57);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date63 = week62.getStart();
        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date63);
        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = week67.previous();
        java.lang.Class<?> wildcardClass69 = week67.getClass();
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(12, 12);
        long long73 = week72.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = week72.next();
        java.util.Date date75 = regularTimePeriod74.getStart();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date75, timeZone76);
        boolean boolean78 = week64.equals((java.lang.Object) wildcardClass69);
        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(12, 12);
        long long82 = week81.getFirstMillisecond();
        java.util.Date date83 = week81.getEnd();
        java.util.Date date84 = week81.getStart();
        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(12, 12);
        long long88 = week87.getFirstMillisecond();
        java.util.Date date89 = week87.getEnd();
        java.lang.Class class90 = null;
        java.util.Date date91 = null;
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class90, date91, timeZone92);
        org.jfree.data.time.Week week94 = new org.jfree.data.time.Week(date89, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date84, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date54, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date25, timeZone92);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(class7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 648L + "'", long16 == 648L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 12, 12" + "'", str21.equals("Week 12, 12"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61781846400001L) + "'", long22 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 648L + "'", long24 == 648L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 648L + "'", long41 == 648L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-61782451200000L) + "'", long53 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-61782451200000L) + "'", long73 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-61782451200000L) + "'", long82 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + (-61782451200000L) + "'", long88 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod93);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertNull(regularTimePeriod96);
        org.junit.Assert.assertNull(regularTimePeriod97);
        org.junit.Assert.assertNull(regularTimePeriod98);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.util.Date date5 = week2.getEnd();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        int int7 = week2.getWeek();
        int int8 = week2.getWeek();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week2.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        long long5 = week2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61781846400001L) + "'", long5 == (-61781846400001L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        long long13 = week2.getFirstMillisecond();
        int int14 = week2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week2.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        long long22 = regularTimePeriod20.getMiddleMillisecond();
        long long23 = regularTimePeriod20.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61782753600001L) + "'", long22 == (-61782753600001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782753600001L) + "'", long23 == (-61782753600001L));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        int int10 = week2.getWeek();
        boolean boolean12 = week2.equals((java.lang.Object) 10.0f);
        int int13 = week2.getWeek();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        long long17 = week16.getFirstMillisecond();
        java.util.Date date18 = week16.getEnd();
        int int19 = week2.compareTo((java.lang.Object) date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week2.previous();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        boolean boolean28 = week25.equals((java.lang.Object) 7);
        boolean boolean30 = week25.equals((java.lang.Object) '4');
        long long31 = week25.getSerialIndex();
        java.util.Date date32 = week25.getEnd();
        int int33 = week25.getWeek();
        boolean boolean35 = week25.equals((java.lang.Object) 10.0f);
        java.lang.String str36 = week25.toString();
        java.util.Date date37 = week25.getStart();
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week40.next();
        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(12, 12);
        long long45 = week44.getFirstMillisecond();
        java.util.Date date46 = week44.getEnd();
        java.lang.Class class47 = null;
        java.util.Date date48 = null;
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date48, timeZone49);
        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date46, timeZone49);
        java.lang.Class<?> wildcardClass52 = timeZone49.getClass();
        int int53 = week40.compareTo((java.lang.Object) timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date37, timeZone49);
        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 648L + "'", long31 == 648L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 12, 12" + "'", str36.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-61782451200000L) + "'", long45 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNull(regularTimePeriod54);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(24, year5);
//        long long8 = year5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException14.getSuppressed();
        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week25.previous();
        boolean boolean28 = week25.equals((java.lang.Object) 7);
        boolean boolean30 = week25.equals((java.lang.Object) '4');
        long long31 = week25.getSerialIndex();
        java.util.Date date32 = week25.getEnd();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str35 = timePeriodFormatException34.toString();
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException34.getSuppressed();
        java.lang.String str37 = timePeriodFormatException34.toString();
        java.lang.String str38 = timePeriodFormatException34.toString();
        int int39 = week25.compareTo((java.lang.Object) timePeriodFormatException34);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException34);
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException34.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 648L + "'", long31 == 648L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str35.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str38.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(throwableArray41);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
//        long long3 = week2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
//        java.util.Date date5 = week2.getStart();
//        java.util.Date date6 = week2.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week9.previous();
//        boolean boolean12 = week9.equals((java.lang.Object) 7);
//        boolean boolean14 = week9.equals((java.lang.Object) '4');
//        long long15 = week9.getSerialIndex();
//        java.util.Date date16 = week9.getStart();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
//        long long21 = week20.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week20.next();
//        java.util.Date date23 = week20.getEnd();
//        java.lang.Class class24 = null;
//        java.util.Date date25 = null;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone26);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date16, timeZone26);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date6, timeZone26);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
//        java.lang.Class<?> wildcardClass35 = week33.getClass();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(12, 12);
//        long long39 = week38.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = week38.next();
//        java.util.Date date41 = regularTimePeriod40.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date41, timeZone42);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
//        java.util.Date date45 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        int int49 = week48.getWeek();
//        java.util.Date date50 = week48.getEnd();
//        org.jfree.data.time.Year year51 = week48.getYear();
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(0, year51);
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(100, year51);
//        java.util.Date date54 = year51.getStart();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
//        java.util.Date date58 = week57.getEnd();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date58);
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
//        long long63 = week62.getFirstMillisecond();
//        java.util.Date date64 = week62.getEnd();
//        java.util.Date date65 = week62.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date65, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date58, timeZone66);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date54, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone66);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date6, timeZone66);
//        long long72 = week71.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 648L + "'", long15 == 648L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61782451200000L) + "'", long21 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61782451200000L) + "'", long39 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 24 + "'", int49 == 24);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61782451200000L) + "'", long63 == (-61782451200000L));
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 648L + "'", long72 == 648L);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str10 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: ");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str28 = timePeriodFormatException27.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException27.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException25.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str37 = timePeriodFormatException36.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException36.addSuppressed((java.lang.Throwable) timePeriodFormatException39);
        java.lang.String str41 = timePeriodFormatException36.toString();
        java.lang.Throwable[] throwableArray42 = timePeriodFormatException36.getSuppressed();
        java.lang.Throwable[] throwableArray43 = timePeriodFormatException36.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str41.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Week 1, 0");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date7 = week6.getEnd();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        long long12 = week11.getFirstMillisecond();
        java.util.Date date13 = week11.getEnd();
        java.util.Date date14 = week11.getEnd();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date14, timeZone15);
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date7, timeZone15);
        java.util.Locale locale18 = null;
        try {
            org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date3, timeZone15, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-61782451200000L) + "'", long12 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
//        long long6 = week5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1551600000000L + "'", long6 == 1551600000000L);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = timeZone12.getClass();
        int int16 = week3.compareTo((java.lang.Object) timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week3.next();
        java.util.Date date18 = week3.getEnd();
        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date22 = week21.getStart();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = week26.previous();
        java.lang.Class<?> wildcardClass28 = week26.getClass();
        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(12, 12);
        long long32 = week31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = week31.next();
        java.util.Date date34 = regularTimePeriod33.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone35);
        boolean boolean37 = week23.equals((java.lang.Object) wildcardClass28);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(12, 12);
        long long41 = week40.getFirstMillisecond();
        java.util.Date date42 = week40.getEnd();
        java.util.Date date43 = week40.getStart();
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(12, 12);
        long long47 = week46.getFirstMillisecond();
        java.util.Date date48 = week46.getEnd();
        java.lang.Class class49 = null;
        java.util.Date date50 = null;
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date50, timeZone51);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date48, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date43, timeZone51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date18, timeZone51);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-61782451200000L) + "'", long32 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61782451200000L) + "'", long41 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61782451200000L) + "'", long47 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNull(regularTimePeriod55);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        int int3 = week2.getWeek();
        long long4 = week2.getSerialIndex();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 648L + "'", long4 == 648L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date9, timeZone15);
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(12, 12);
        long long20 = week19.getFirstMillisecond();
        java.util.Date date21 = week19.getEnd();
        long long22 = week19.getFirstMillisecond();
        boolean boolean23 = week16.equals((java.lang.Object) week19);
        long long24 = week19.getSerialIndex();
        long long25 = week19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week19.previous();
        boolean boolean27 = week4.equals((java.lang.Object) week19);
        long long28 = week4.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-61782451200000L) + "'", long20 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-61782451200000L) + "'", long22 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 648L + "'", long24 == 648L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-61782451200000L) + "'", long25 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62135654400001L) + "'", long28 == (-62135654400001L));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        long long6 = week5.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782148800001L) + "'", long6 == (-61782148800001L));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        long long13 = week10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week10.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 648L + "'", long13 == 648L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.previous();
        java.util.Calendar calendar5 = null;
        try {
            week2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        int int2 = week1.getWeek();
//        java.util.Date date3 = week1.getEnd();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) '#', year4);
//        long long6 = week5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107042L + "'", long6 == 107042L);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        int int12 = week10.getYearValue();
        java.lang.String str13 = week10.toString();
        java.util.Date date14 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 12, 12" + "'", str13.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        int int13 = week11.getWeek();
        int int14 = week11.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        java.lang.Class<?> wildcardClass6 = week2.getClass();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week11.previous();
        java.lang.Class<?> wildcardClass13 = week11.getClass();
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week16.previous();
        boolean boolean19 = week16.equals((java.lang.Object) 7);
        boolean boolean21 = week16.equals((java.lang.Object) '4');
        long long22 = week16.getSerialIndex();
        java.util.Date date23 = week16.getEnd();
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date23);
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone27);
        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass13);
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
        long long34 = week33.getFirstMillisecond();
        java.util.Date date35 = week33.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date35, timeZone38);
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date44 = week43.getStart();
        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date44);
        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = week48.previous();
        java.lang.Class<?> wildcardClass50 = week48.getClass();
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        long long54 = week53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week53.next();
        java.util.Date date56 = regularTimePeriod55.getStart();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date56, timeZone57);
        boolean boolean59 = week45.equals((java.lang.Object) wildcardClass50);
        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(12, 12);
        long long63 = week62.getFirstMillisecond();
        java.util.Date date64 = week62.getEnd();
        java.util.Date date65 = week62.getStart();
        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(12, 12);
        long long69 = week68.getFirstMillisecond();
        java.util.Date date70 = week68.getEnd();
        java.lang.Class class71 = null;
        java.util.Date date72 = null;
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class71, date72, timeZone73);
        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date70, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date65, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date35, timeZone73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone73);
        int int79 = week2.compareTo((java.lang.Object) class7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 648L + "'", long22 == 648L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-61782451200000L) + "'", long34 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-61782451200000L) + "'", long54 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + (-61782451200000L) + "'", long63 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-61782451200000L) + "'", long69 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        long long17 = week14.getFirstMillisecond();
        boolean boolean18 = week11.equals((java.lang.Object) week14);
        long long19 = week11.getFirstMillisecond();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = week11.getMiddleMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61782451200000L) + "'", long17 == (-61782451200000L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61782451200000L) + "'", long19 == (-61782451200000L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        java.util.Date date19 = week4.getEnd();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        java.util.Date date24 = week22.getEnd();
        java.util.Date date25 = week22.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date19, timeZone26);
        java.util.Date date29 = week28.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        int int3 = week2.getWeek();
//        java.util.Date date4 = week2.getEnd();
//        org.jfree.data.time.Year year5 = week2.getYear();
//        java.util.Date date6 = year5.getEnd();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) (short) -1, year5);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) '#', year5);
//        int int9 = week8.getWeek();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week12.previous();
        java.lang.Class<?> wildcardClass14 = week12.getClass();
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week17.previous();
        java.lang.Class<?> wildcardClass19 = week17.getClass();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(12, 12);
        long long23 = week22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week22.next();
        java.util.Date date25 = regularTimePeriod24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date25, timeZone26);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week30.previous();
        java.lang.Class<?> wildcardClass32 = week30.getClass();
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.previous();
        boolean boolean38 = week35.equals((java.lang.Object) 7);
        boolean boolean40 = week35.equals((java.lang.Object) '4');
        long long41 = week35.getSerialIndex();
        java.util.Date date42 = week35.getEnd();
        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date42);
        java.lang.Class class44 = null;
        java.util.Date date45 = null;
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date45, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date42, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date25, timeZone46);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date9, timeZone46);
        java.util.Calendar calendar51 = null;
        try {
            week50.peg(calendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-61782451200000L) + "'", long23 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 648L + "'", long41 == 648L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.String str9 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        java.lang.Throwable[] throwableArray19 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable23 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.String str7 = timePeriodFormatException4.toString();
        java.lang.String str8 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        java.util.Date date5 = week4.getStart();
        java.util.Calendar calendar6 = null;
        try {
            week4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date9 = week8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(12, 12);
        int int17 = week16.getWeek();
        java.lang.String str18 = week16.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week16.next();
        java.util.Date date20 = week16.getEnd();
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week23.previous();
        java.lang.Class<?> wildcardClass25 = week23.getClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass25);
        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date31 = week30.getStart();
        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week35.next();
        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(12, 12);
        long long40 = week39.getFirstMillisecond();
        java.util.Date date41 = week39.getEnd();
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone44);
        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date41, timeZone44);
        java.lang.Class<?> wildcardClass47 = timeZone44.getClass();
        int int48 = week35.compareTo((java.lang.Object) timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date31, timeZone44);
        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date20, timeZone44);
        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week53.previous();
        java.lang.Class<?> wildcardClass55 = week53.getClass();
        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = week58.previous();
        boolean boolean61 = week58.equals((java.lang.Object) 7);
        boolean boolean63 = week58.equals((java.lang.Object) '4');
        long long64 = week58.getSerialIndex();
        java.util.Date date65 = week58.getEnd();
        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date65);
        java.lang.Class class67 = null;
        java.util.Date date68 = null;
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date68, timeZone69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date65, timeZone69);
        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date20, timeZone69);
        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(date9, timeZone69);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 12 + "'", int17 == 12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 12, 12" + "'", str18.equals("Week 12, 12"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-61782451200000L) + "'", long40 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 648L + "'", long64 == 648L);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        long long19 = week4.getLastMillisecond();
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = week22.next();
        boolean boolean25 = week22.equals((java.lang.Object) (byte) -1);
        boolean boolean26 = week4.equals((java.lang.Object) week22);
        java.util.Date date27 = week22.getEnd();
        boolean boolean29 = week22.equals((java.lang.Object) (-62162265600000L));
        java.util.Calendar calendar30 = null;
        try {
            week22.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-61781846400001L) + "'", long19 == (-61781846400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        java.util.Date date7 = null;
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week10.previous();
        java.lang.Class<?> wildcardClass12 = week10.getClass();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.previous();
        java.lang.Class<?> wildcardClass17 = week15.getClass();
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, 12);
        long long21 = week20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = week20.next();
        java.util.Date date23 = regularTimePeriod22.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone24);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week28.previous();
        java.lang.Class<?> wildcardClass30 = week28.getClass();
        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week33.previous();
        boolean boolean36 = week33.equals((java.lang.Object) 7);
        boolean boolean38 = week33.equals((java.lang.Object) '4');
        long long39 = week33.getSerialIndex();
        java.util.Date date40 = week33.getEnd();
        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
        java.lang.Class class42 = null;
        java.util.Date date43 = null;
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date43, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date40, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date23, timeZone44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date7, timeZone44);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-61782451200000L) + "'", long21 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 648L + "'", long39 == 648L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNull(regularTimePeriod48);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int1 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        int int3 = week0.getWeek();
//        long long4 = week0.getFirstMillisecond();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 24 + "'", int1 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560063600000L + "'", long4 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        long long4 = week2.getSerialIndex();
        java.util.Date date5 = week2.getStart();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = week2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week2.previous();
        java.util.Date date7 = week2.getStart();
        java.util.Date date8 = week2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getYearValue();
        long long6 = week2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week2.next();
        long long8 = week2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 648L + "'", long6 == 648L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782148800001L) + "'", long8 == (-61782148800001L));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str12 = timePeriodFormatException11.toString();
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str19 = timePeriodFormatException18.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        java.lang.Throwable[] throwableArray23 = timePeriodFormatException18.getSuppressed();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray27 = timePeriodFormatException5.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str19.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '4');
        java.util.Date date3 = week2.getStart();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week2.previous();
        int int6 = week2.getWeek();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (short) -1);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week((int) 'a', 3);
        java.util.Date date6 = week5.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date6);
        java.util.Date date8 = week7.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
        try {
            int int10 = week2.compareTo((java.lang.Object) week7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        java.lang.Class<?> wildcardClass4 = week2.getClass();
        int int5 = week2.getWeek();
        long long6 = week2.getSerialIndex();
        long long7 = week2.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week2.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167406400001L) + "'", long7 == (-62167406400001L));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        java.util.Date date10 = week9.getEnd();
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date10);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(12, 12);
        long long15 = week14.getFirstMillisecond();
        java.util.Date date16 = week14.getEnd();
        java.util.Date date17 = week14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date17, timeZone18);
        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date10, timeZone18);
        boolean boolean21 = week6.equals((java.lang.Object) week20);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-61782451200000L) + "'", long15 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, 0);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(12, 12);
        long long6 = week5.getFirstMillisecond();
        java.util.Date date7 = week5.getEnd();
        java.lang.Class class8 = null;
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date7, timeZone10);
        int int13 = week2.compareTo((java.lang.Object) timeZone10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61782451200000L) + "'", long6 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        java.util.Date date3 = week2.getStart();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week7.previous();
        java.lang.Class<?> wildcardClass9 = week7.getClass();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(12, 12);
        long long13 = week12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        boolean boolean18 = week4.equals((java.lang.Object) wildcardClass9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str27 = timePeriodFormatException26.toString();
        java.lang.String str28 = timePeriodFormatException26.toString();
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        int int30 = week4.compareTo((java.lang.Object) timePeriodFormatException20);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = week4.getMiddleMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61782451200000L) + "'", long13 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, (int) (byte) 100);
        java.util.Calendar calendar3 = null;
        try {
            week2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        long long4 = week3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
        java.util.Date date6 = week3.getEnd();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone9);
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date6);
        java.util.TimeZone timeZone13 = null;
        java.util.Locale locale14 = null;
        try {
            org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(date6, timeZone13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61782451200000L) + "'", long4 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.util.Date date18 = week10.getStart();
        long long19 = week10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = week10.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 648L + "'", long19 == 648L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(12, 12);
        long long14 = week13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
        java.util.Date date16 = week13.getEnd();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone19);
        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date9, timeZone19);
        java.lang.Class<?> wildcardClass23 = week22.getClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week22.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61782451200000L) + "'", long14 == (-61782451200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 5);
        java.util.Date date3 = week2.getStart();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.util.Date date0 = null;
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(12, 12);
        long long8 = week7.getFirstMillisecond();
        java.util.Date date9 = week7.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date9, timeZone12);
        java.lang.Class<?> wildcardClass15 = timeZone12.getClass();
        int int16 = week3.compareTo((java.lang.Object) timeZone12);
        java.util.Locale locale17 = null;
        try {
            org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date0, timeZone12, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61782451200000L) + "'", long8 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 10, 0);
        int int3 = week2.getYearValue();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        boolean boolean5 = week2.equals((java.lang.Object) 7);
        boolean boolean7 = week2.equals((java.lang.Object) '4');
        long long8 = week2.getSerialIndex();
        java.util.Date date9 = week2.getEnd();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        long long11 = week10.getLastMillisecond();
        java.util.Date date12 = week10.getEnd();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) (byte) 1, (int) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week15.next();
        boolean boolean17 = week10.equals((java.lang.Object) week15);
        java.util.Date date18 = week10.getStart();
        long long19 = week10.getSerialIndex();
        java.util.Calendar calendar20 = null;
        try {
            week10.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 648L + "'", long8 == 648L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-61781846400001L) + "'", long11 == (-61781846400001L));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 648L + "'", long19 == 648L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, 12);
        long long3 = week2.getFirstMillisecond();
        java.util.Date date4 = week2.getEnd();
        java.lang.Class class5 = null;
        java.util.Date date6 = null;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date4, timeZone7);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date4, timeZone10);
        java.util.Date date12 = week11.getStart();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str15 = timePeriodFormatException14.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str21 = timePeriodFormatException20.toString();
        java.lang.String str22 = timePeriodFormatException20.toString();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str28 = timePeriodFormatException27.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException27.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException27);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str37 = timePeriodFormatException36.toString();
        java.lang.Throwable[] throwableArray38 = timePeriodFormatException36.getSuppressed();
        java.lang.String str39 = timePeriodFormatException36.toString();
        timePeriodFormatException27.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
        java.lang.Throwable[] throwableArray41 = timePeriodFormatException36.getSuppressed();
        boolean boolean42 = week11.equals((java.lang.Object) throwableArray41);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61782451200000L) + "'", long3 == (-61782451200000L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str21.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str22.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str28.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str37.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str39.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }
}

