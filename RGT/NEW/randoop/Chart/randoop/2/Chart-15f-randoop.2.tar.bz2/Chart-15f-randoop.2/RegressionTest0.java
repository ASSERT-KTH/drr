import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 0, (java.lang.Object) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0L, (float) 1, (float) (short) -1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.data.Range range2 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint1.toRangeHeight(range2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("VerticalAlignment.TOP", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        try {
            piePlot3D0.setInteriorGap((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            piePlot3D0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            piePlot3D0.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) (short) 1, 10.0f, textAnchor8, (double) '4', textAnchor10);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D14, (float) (short) 1, 10.0f, textAnchor17, (double) '4', textAnchor19);
        try {
            java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("VerticalAlignment.TOP", graphics2D1, 0.0f, 0.0f, textAnchor10, (double) 4, textAnchor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        numberAxis19.setLowerMargin(0.0d);
        try {
            numberAxis19.zoomRange((double) 1.0f, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.05) <= upper (0.052500000000000005).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (-1), (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) '4', (float) (-1L), 0.0d, 0.0f, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D1.setAxisLinePaint((java.awt.Paint) color4);
        categoryAxis3D1.setTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        numberAxis19.setLowerMargin(0.0d);
        java.awt.Shape shape24 = null;
        try {
            numberAxis19.setLeftArrow(shape24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets10.getUnitType();
        double double13 = rectangleInsets10.calculateTopOutset((double) (byte) 10);
        try {
            org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("hi!", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font2 = null;
        java.awt.Color color3 = java.awt.Color.RED;
        try {
            textBlock0.addLine("", font2, (java.awt.Paint) color3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        numberAxis19.setLowerMargin(0.0d);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        try {
            org.jfree.chart.axis.AxisState axisState30 = numberAxis19.draw(graphics2D24, (double) (-1L), rectangle2D26, rectangle2D27, rectangleEdge28, plotRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        categoryAxis3D17.addCategoryLabelToolTip((java.lang.Comparable) 'a', "");
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) -1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double25 = numberAxis19.java2DToValue((double) (-1L), rectangle2D23, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = null;
        try {
            categoryPlot21.setDomainGridlinePosition(categoryAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLabelGenerator();
        piePlot3D1.setShadowYOffset((double) (short) 1);
        piePlot3D1.setIgnoreZeroValues(false);
        java.awt.Font font7 = piePlot3D1.getLabelFont();
        java.awt.Paint paint8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean11 = rectangleEdge9.equals((java.lang.Object) verticalAlignment10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str14 = verticalAlignment13.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double23 = rectangleInsets19.getLeft();
        try {
            org.jfree.chart.title.TextTitle textTitle24 = new org.jfree.chart.title.TextTitle("hi!", font7, paint8, rectangleEdge9, horizontalAlignment12, verticalAlignment13, rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VerticalAlignment.TOP" + "'", str14.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23 == (-1.0d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = color0.brighter();
        float[] floatArray9 = new float[] { (short) 0 };
        try {
            float[] floatArray10 = color0.getRGBColorComponents(floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        numberAxis19.setLowerMargin(0.0d);
        try {
            numberAxis19.setRange((double) 10L, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        numberAxis19.setLowerMargin(0.0d);
        java.awt.Shape shape24 = null;
        try {
            numberAxis19.setRightArrow(shape24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        double double2 = piePlot3D0.getInteriorGap();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08d + "'", double2 == 0.08d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets4.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor8 = null;
        try {
            piePlot3D0.setLabelDistributor(abstractPieLabelDistributor8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Paint paint4 = categoryAxis3D1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        piePlot3D0.setForegroundAlpha((float) (short) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        org.jfree.chart.plot.Plot plot4 = piePlot3D0.getParent();
        try {
            boolean boolean5 = plot4.isOutlineVisible();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.darkGray;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer6 = new org.jfree.chart.text.G2TextMeasurer(graphics2D5);
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.TOP_RIGHT", font1, (java.awt.Paint) color2, 0.0f, (int) (short) -1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("hi!", font1, paint2, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock0.draw(graphics2D1, (float) 10L, (float) '4', textBlockAnchor4);
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine7 = textBlock6.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textBlock6.getLineAlignment();
        textBlock0.setLineAlignment(horizontalAlignment8);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNull(textLine7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = null;
        try {
            xYPlot5.setDomainAxes(valueAxisArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        org.jfree.chart.plot.Plot plot4 = categoryAxis3D1.getPlot();
        java.lang.String str5 = categoryAxis3D1.getLabel();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean7 = categoryAxis3D1.equals((java.lang.Object) stroke6);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot5.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            rectangleInsets11.trim(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        java.lang.String str6 = basicProjectInfo5.getName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        java.awt.Shape shape22 = null;
        try {
            numberAxis19.setUpArrow(shape22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 90.0d, 0.0d, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color3);
        java.awt.Stroke stroke6 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double7 = piePlot3D1.getInteriorGap();
        piePlot3D1.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot3D1.axisChanged(axisChangeEvent10);
        java.awt.Font font12 = piePlot3D1.getLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font12, paint13, (float) (-1));
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            textFragment15.draw(graphics2D16, (float) (byte) -1, (float) ' ', textAnchor19, (float) 10, (float) (short) 0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(textAnchor19);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(0.0d);
        double double5 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "{0}", "ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        java.text.AttributedString attributedString4 = null;
        standardPieSectionLabelGenerator1.setAttributedLabel((int) (short) 0, attributedString4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) (short) 1, 10.0f, textAnchor8, (double) '4', textAnchor10);
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextAnchor.TOP_RIGHT", graphics2D1, 0.0f, (float) (short) 100, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        org.jfree.data.Range range5 = null;
        try {
            numberAxis1.setRange(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        numberAxis1.setLowerBound(1.0d);
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        boolean boolean3 = rotation0.equals((java.lang.Object) "VerticalAlignment.TOP");
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        java.awt.Image image6 = piePlot3D0.getBackgroundImage();
        double double7 = piePlot3D0.getLabelLinkMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(image6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot21.getDataset();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(categoryDataset30);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass2 = numberAxis1.getClass();
        org.jfree.data.RangeType rangeType3 = null;
        try {
            numberAxis1.setRangeType(rangeType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint5.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange1, lengthConstraintType2, 1.0E-8d, (org.jfree.data.Range) dateRange4, lengthConstraintType6);
        double double8 = dateRange4.getCentralValue();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer10);
        java.awt.Stroke stroke12 = xYPlot11.getRangeZeroBaselineStroke();
        java.awt.Color color13 = java.awt.Color.yellow;
        xYPlot11.setDomainGridlinePaint((java.awt.Paint) color13);
        xYPlot11.setDomainGridlinesVisible(false);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace20 = numberAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) xYPlot11, rectangle2D17, rectangleEdge18, axisSpace19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = color0.brighter();
        float[] floatArray11 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray12 = color7.getColorComponents(floatArray11);
        java.awt.color.ColorSpace colorSpace13 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Color color21 = color14.brighter();
        float[] floatArray25 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray26 = color21.getColorComponents(floatArray25);
        try {
            float[] floatArray27 = color7.getColorComponents(colorSpace13, floatArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot21.getDatasetRenderingOrder();
        boolean boolean24 = categoryPlot21.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = null;
        try {
            categoryPlot21.setAxisOffset(rectangleInsets33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D1.setAxisLinePaint((java.awt.Paint) color4);
        boolean boolean6 = categoryAxis3D1.isVisible();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getLibraries();
        java.lang.String str7 = basicProjectInfo5.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot21.getDomainAxis();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(categoryAxis34);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setLabelLinkStroke(stroke26);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = null;
        categoryPlot21.setFixedLegendItems(legendItemCollection30);
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        try {
            boolean boolean34 = categoryPlot21.removeDomainMarker(marker32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) rotation0, jFreeChart1, (int) '4', (int) (short) 0);
        org.jfree.chart.JFreeChart jFreeChart5 = chartProgressEvent4.getChart();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        categoryAxis3D1.setLabelToolTip("TextAnchor.TOP_RIGHT");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        categoryAxis3D1.setTickMarkPaint((java.awt.Paint) color13);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double25 = categoryAxis3D1.getCategoryMiddle(15, 15, rectangle2D23, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D1, jFreeChart2);
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        chartChangeEvent3.setChart(jFreeChart4);
        java.lang.Object obj6 = chartChangeEvent3.getSource();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        chartChangeEvent3.setChart(jFreeChart7);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 10, (double) '4', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        double double38 = categoryAxis3D34.getLowerMargin();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        int int9 = xYPlot5.getWeight();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str1 = verticalAlignment0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean3 = verticalAlignment0.equals((java.lang.Object) color2);
        java.lang.String str4 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.TOP" + "'", str1.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.TOP" + "'", str4.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.Color color8 = color1.brighter();
        float[] floatArray12 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray13 = color8.getColorComponents(floatArray12);
        try {
            float[] floatArray14 = color0.getComponents(floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        boolean boolean26 = piePlot3D0.getSimpleLabels();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.Color color8 = color1.brighter();
        float[] floatArray12 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray13 = color8.getColorComponents(floatArray12);
        float[] floatArray14 = color0.getColorComponents(floatArray13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color15.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        java.awt.Color color22 = color15.brighter();
        float[] floatArray26 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray27 = color22.getColorComponents(floatArray26);
        float[] floatArray28 = color0.getColorComponents(floatArray27);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        java.awt.Color color4 = java.awt.Color.yellow;
        org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("TextAnchor.TOP_RIGHT", font2, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(textBlock5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1]", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        double double30 = categoryAxis3D24.getLabelAngle();
        categoryAxis3D24.setCategoryLabelPositionOffset((int) '#');
        categoryAxis3D24.setCategoryLabelPositionOffset((int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            boolean boolean20 = xYPlot5.removeRangeMarker(marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double5 = dateAxis1.valueToJava2D(1.0E-8d, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedHeight((-1.0d));
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Color color0 = java.awt.Color.GREEN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        java.awt.Paint paint8 = null;
        try {
            xYPlot5.setRangeZeroBaselinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer8 };
        xYPlot5.setRenderers(xYItemRendererArray9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            xYPlot5.drawBackground(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            xYPlot5.handleClick((int) (short) 100, 15, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color3);
        java.awt.Stroke stroke6 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double7 = piePlot3D1.getInteriorGap();
        piePlot3D1.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot3D1.axisChanged(axisChangeEvent10);
        java.awt.Font font12 = piePlot3D1.getLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font12, paint13, (float) (-1));
        java.lang.String str16 = textFragment15.getText();
        java.lang.String str17 = textFragment15.getText();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot21.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot24 = categoryPlot21.getParent();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNull(plot24);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        double double10 = piePlot3D0.getExplodePercent((java.lang.Comparable) 0.05d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot3D0.getLabelDistributor();
        double double12 = piePlot3D0.getLabelGap();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.025d + "'", double12 == 0.025d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setBaseSectionOutlineStroke(stroke6);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        try {
            double double15 = dateAxis9.dateToJava2D(date11, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.Point point6 = polarPlot0.translateValueThetaRadiusToJava2D((double) 100L, 1.0E-5d, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        org.jfree.chart.util.Rotation rotation3 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) rotation3, jFreeChart4, (int) '4', (int) (short) 0);
        boolean boolean8 = textLine2.equals((java.lang.Object) '4');
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rotation3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace33 = categoryPlot21.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot21.getDomainAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker36, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(axisSpace33);
        org.junit.Assert.assertNotNull(categoryAxis35);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        boolean boolean33 = categoryPlot21.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer38);
        xYPlot39.clearAnnotations();
        java.awt.Paint paint41 = xYPlot39.getRangeCrosshairPaint();
        categoryPlot21.setDomainGridlinePaint(paint41);
        org.jfree.chart.plot.Marker marker43 = null;
        try {
            categoryPlot21.addRangeMarker(marker43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.calculateTopOutset((double) (byte) 10);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 90.0d };
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { (short) 100, (byte) -1, 0.025d, 0.0f, 0.5d };
        double[] doubleArray13 = new double[] { '4', (short) -1, 100L, '4', (-1L) };
        double[] doubleArray19 = new double[] { '4', (short) -1, 100L, '4', (-1L) };
        double[] doubleArray25 = new double[] { '4', (short) -1, 100L, '4', (-1L) };
        double[][] doubleArray26 = new double[][] { doubleArray13, doubleArray19, doubleArray25 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray7, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        java.lang.String str2 = lengthConstraintType1.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LengthConstraintType.NONE" + "'", str2.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot3D14.getLabelGenerator();
        piePlot3D14.setShadowYOffset((double) (short) 1);
        piePlot3D14.setSimpleLabels(false);
        java.awt.Font font20 = piePlot3D14.getNoDataMessageFont();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.TOP;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace24 = categoryAxis3D1.reserveSpace(graphics2D13, (org.jfree.chart.plot.Plot) piePlot3D14, rectangle2D21, rectangleEdge22, axisSpace23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        java.lang.Object obj10 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        java.awt.Paint paint22 = categoryAxis3D17.getLabelPaint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint5.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange1, lengthConstraintType2, 1.0E-8d, (org.jfree.data.Range) dateRange4, lengthConstraintType6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) (short) 100);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(lengthConstraintType2);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection3 = waferMapPlot2.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer8 };
        xYPlot5.setRenderers(xYItemRendererArray9);
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            xYPlot5.addDomainMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        java.lang.Object obj22 = numberAxis19.clone();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D(pieDataset24);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = numberAxis19.reserveSpace(graphics2D23, (org.jfree.chart.plot.Plot) piePlot3D25, rectangle2D26, rectangleEdge27, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot5.getSeriesRenderingOrder();
        boolean boolean19 = xYPlot5.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLabelGenerator();
        piePlot3D1.setShadowYOffset((double) (short) 1);
        piePlot3D1.setSimpleLabels(false);
        java.awt.Font font7 = piePlot3D1.getNoDataMessageFont();
        java.awt.Paint paint8 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge9);
        java.lang.String str11 = rectangleEdge9.toString();
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textBlock12.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean16 = rectangleEdge14.equals((java.lang.Object) verticalAlignment15);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        boolean boolean18 = verticalAlignment15.equals((java.lang.Object) paint17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("", font7, paint8, rectangleEdge9, horizontalAlignment13, verticalAlignment15, rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'spacer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleEdge.LEFT" + "'", str11.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(verticalAlignment15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass4 = numberAxis3.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNotNull(inputStream6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer5);
        java.awt.Stroke stroke7 = xYPlot6.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double11 = numberAxis10.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis10.setRangeWithMargins((org.jfree.data.Range) dateRange12);
        xYPlot6.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis10.lengthToJava2D((double) (-1L), rectangle2D16, rectangleEdge17);
        java.awt.Font font19 = numberAxis10.getTickLabelFont();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer23 = new org.jfree.chart.text.G2TextMeasurer(graphics2D22);
        try {
            org.jfree.chart.text.TextBlock textBlock24 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.LEFT", font19, paint20, (float) ' ', (org.jfree.chart.text.TextMeasurer) g2TextMeasurer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-8d + "'", double11 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart1, (int) 'a', (-1));
        java.lang.String str5 = chartProgressEvent4.toString();
        int int6 = chartProgressEvent4.getPercent();
        chartProgressEvent4.setPercent((int) (byte) -1);
        chartProgressEvent4.setType(0);
        int int11 = chartProgressEvent4.getType();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str5.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        double double42 = categoryPlot21.getAnchorValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        java.awt.Font font7 = null;
        try {
            piePlot3D0.setLabelFont(font7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setIgnoreZeroValues(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        piePlot3D0.setShadowPaint((java.awt.Paint) color6);
        boolean boolean8 = piePlot3D0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int4 = categoryAxis3D3.getCategoryLabelPositionOffset();
        categoryAxis3D3.setLabelURL("");
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D3.setLabelPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D3.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets13);
        double double17 = rectangleInsets13.calculateRightInset((double) 1L);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType19, lengthAdjustmentType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.4d + "'", double17 == 0.4d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        numberAxis1.setLowerBound(1.0d);
        org.jfree.data.Range range4 = null;
        try {
            numberAxis1.setRange(range4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double8 = numberAxis7.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis7.setRangeWithMargins((org.jfree.data.Range) dateRange9);
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange12, lengthConstraintType13, 1.0E-8d, (org.jfree.data.Range) dateRange15, lengthConstraintType17);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange9, (org.jfree.data.Range) dateRange12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, (org.jfree.data.Range) dateRange12);
        try {
            org.jfree.chart.util.Size2D size2D21 = columnArrangement0.arrange(blockContainer3, graphics2D4, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-8d + "'", double8 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange9);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        boolean boolean11 = xYPlot5.isRangeZoomable();
        xYPlot5.clearRangeMarkers((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer18);
        java.awt.Stroke stroke20 = xYPlot19.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot19.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray23 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer22 };
        xYPlot19.setRenderers(xYItemRendererArray23);
        xYPlot5.setRenderers(xYItemRendererArray23);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(xYItemRendererArray23);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        double double2 = ringPlot0.getOuterSeparatorExtension();
        double double3 = ringPlot0.getInnerSeparatorExtension();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) '#');
        try {
            boolean boolean46 = categoryPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        categoryPlot21.setRangeGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot21.zoomDomainAxes(1.0E-8d, 1.0E-8d, plotRenderingInfo38, point2D39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) rotation0, jFreeChart1, (int) '4', (int) (short) 0);
        chartProgressEvent4.setType(0);
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint1 = rectangleConstraint0.toUnconstrainedWidth();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range5 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange2, 90.0d, false);
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, 90.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range5, (org.jfree.data.Range) dateRange6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint0.toRangeWidth((org.jfree.data.Range) dateRange6);
        boolean boolean14 = dateRange6.intersects(0.0d, (double) '#');
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint1);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setIgnoreZeroValues(false);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        piePlot3D0.setShadowPaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        piePlot3D0.setLabelOutlineStroke(stroke8);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        categoryPlot21.mapDatasetToRangeAxis(1, (int) (byte) 1);
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot21.getDataset(500);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(categoryDataset44);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) ringPlot1);
        ringPlot1.setSeparatorsVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        double double11 = dateAxis9.getLowerMargin();
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        double[] doubleArray21 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray27 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray28 = new double[][] { doubleArray21, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer34);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot35.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D38.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D38.setAxisLinePaint((java.awt.Paint) color41);
        int int43 = categoryPlot35.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D38);
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot35.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot35.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot35.zoomDomainAxes((double) 100.0f, plotRenderingInfo47, point2D48, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = categoryPlot35.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot35.getDomainAxisEdge((int) ' ');
        try {
            double double54 = dateAxis9.dateToJava2D(date12, rectangle2D13, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNull(categoryItemRenderer45);
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        chartEntity4.setURLText("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setLabelGap(0.0d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D0.getLegendLabelToolTipGenerator();
        java.awt.Paint paint8 = piePlot3D0.getLabelOutlinePaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot5.getSeriesRenderingOrder();
        java.awt.geom.Point2D point2D19 = null;
        try {
            xYPlot5.setQuadrantOrigin(point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        categoryAxis3D34.setLabelURL("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        boolean boolean40 = categoryAxis3D34.isAxisLineVisible();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        boolean boolean3 = objectList1.equals((java.lang.Object) 1.0d);
        objectList1.clear();
        java.lang.Object obj6 = objectList1.get((int) (short) 100);
        int int7 = objectList1.size();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 90.0d, 1.0E-5d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        categoryAxis3D34.setLabelURL("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        java.lang.String str41 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNull(str41);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis9.lengthToJava2D((double) (-1L), rectangle2D15, rectangleEdge16);
        java.awt.Font font18 = numberAxis9.getTickLabelFont();
        numberAxis9.setLabelURL("{0}");
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis(255);
        double[] doubleArray34 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray40 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray41);
        categoryPlot21.setDataset(categoryDataset42);
        boolean boolean44 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset42);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("PlotOrientation.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name PlotOrientation.VERTICAL, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) ringPlot1);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        ringPlot1.drawBackgroundImage(graphics2D4, rectangle2D5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        double[] doubleArray31 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray37 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray38);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis43, categoryItemRenderer44);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot45.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D48.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D48.setAxisLinePaint((java.awt.Paint) color51);
        int int53 = categoryPlot45.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D48);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot45.getColumnRenderingOrder();
        categoryPlot22.setColumnRenderingOrder(sortOrder54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot22.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot22.zoomDomainAxes(0.05d, plotRenderingInfo59, point2D60);
        boolean boolean62 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent63 = null;
        categoryPlot22.notifyListeners(plotChangeEvent63);
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", (org.jfree.chart.plot.Plot) categoryPlot22);
        try {
            java.awt.image.BufferedImage bufferedImage68 = jFreeChart65.createBufferedImage((int) (short) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        int int3 = polarPlot0.getSeriesCount();
        java.awt.Stroke stroke4 = polarPlot0.getAngleGridlineStroke();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        java.lang.Object obj5 = chartEntity4.clone();
        java.awt.Shape shape6 = chartEntity4.getArea();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        double double10 = piePlot3D0.getExplodePercent((java.lang.Comparable) 0.05d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot3D0.getLabelDistributor();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            piePlot3D0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer7);
        java.awt.Stroke stroke9 = xYPlot8.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation10 = xYPlot8.getRangeAxisLocation();
        double[] doubleArray18 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray24 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray25 = new double[][] { doubleArray18, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray25);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D28, (org.jfree.chart.axis.ValueAxis) numberAxis30, categoryItemRenderer31);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot32.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D35.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D35.setAxisLinePaint((java.awt.Paint) color38);
        int int40 = categoryPlot32.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D35);
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot32.getColumnRenderingOrder();
        categoryPlot32.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot32.setFixedDomainAxisSpace(axisSpace43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot32.setOrientation(plotOrientation45);
        org.jfree.chart.plot.PlotOrientation plotOrientation47 = categoryPlot32.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation47);
        try {
            double double49 = dateAxis0.valueToJava2D(0.05d, rectangle2D2, rectangleEdge48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(sortOrder41);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(plotOrientation47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        double double34 = categoryPlot21.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        try {
            int int36 = categoryPlot21.getDomainAxisIndex(categoryAxis35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) rotation0, jFreeChart1, (int) '4', (int) (short) 0);
        int int5 = chartProgressEvent4.getType();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, range7);
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle1.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight(0.0d);
        org.jfree.chart.util.Size2D size2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setSimpleLabels(false);
        piePlot3D0.setPieIndex(1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str2 = categoryAxis3D1.getLabel();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart1, (int) 'a', (-1));
        java.lang.String str5 = chartProgressEvent4.toString();
        int int6 = chartProgressEvent4.getPercent();
        int int7 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str5.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot5.getSeriesRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double22 = numberAxis21.getAutoRangeMinimumSize();
        try {
            xYPlot5.setRangeAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) numberAxis21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        boolean boolean11 = xYPlot5.isRangeZoomable();
        xYPlot5.clearRangeMarkers((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot5.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) 'a');
        java.lang.String str5 = rectangleConstraint2.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str5.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        try {
            java.util.List list34 = categoryAxis3D24.refreshTicks(graphics2D30, axisState31, rectangle2D32, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        java.awt.Paint paint7 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setCategoryLabelPositionOffset(10);
        java.lang.String str11 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "Rotation.CLOCKWISE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double3 = numberAxis2.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis2.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange7, lengthConstraintType8, 1.0E-8d, (org.jfree.data.Range) dateRange10, lengthConstraintType12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, (org.jfree.data.Range) dateRange7);
        double double16 = dateRange7.getCentralValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5d + "'", double16 == 0.5d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int4 = categoryAxis3D3.getCategoryLabelPositionOffset();
        categoryAxis3D3.setLabelURL("");
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D3.setLabelPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D3.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            lineBorder15.draw(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart1, (int) 'a', (-1));
        java.lang.Object obj5 = chartProgressEvent4.getSource();
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (byte) -1 + "'", obj5.equals((byte) -1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Paint paint11 = dateAxis9.getLabelPaint();
        dateAxis9.zoomRange((double) (-1L), (double) 0L);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot21.getRangeAxisForDataset((int) 'a');
        java.awt.Paint paint25 = valueAxis24.getAxisLinePaint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(valueAxis24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        java.awt.Color color11 = color4.brighter();
        float[] floatArray15 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray16 = color11.getColorComponents(floatArray15);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("VerticalAlignment.TOP", font2, (java.awt.Paint) color11);
        java.awt.Graphics2D graphics2D18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = textLine17.calculateDimensions(graphics2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.LEFT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        int int3 = polarPlot0.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 0L, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot5.getIndexOf(xYItemRenderer18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot5.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem22 = legendItemCollection20.get((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, (double) ' ');
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.Point2D point2D39 = null;
        org.jfree.chart.plot.PlotState plotState40 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            categoryPlot21.draw(graphics2D37, rectangle2D38, point2D39, plotState40, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D5, (float) (short) 0, (float) (short) 100, textAnchor8, (double) 0L, (float) (byte) -1, (float) (short) 1);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", graphics2D1, (float) 0L, (float) 52, textAnchor8, 1.0E-8d, 0.0f, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot21.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot21.zoomDomainAxes(0.05d, plotRenderingInfo58, point2D59);
        boolean boolean61 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D64 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryPlot21.setDomainAxis((int) (byte) 0, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D64);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        double[] doubleArray31 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray37 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray38);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis43, categoryItemRenderer44);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot45.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D48.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D48.setAxisLinePaint((java.awt.Paint) color51);
        int int53 = categoryPlot45.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D48);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot45.getColumnRenderingOrder();
        categoryPlot22.setColumnRenderingOrder(sortOrder54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot22.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot22.zoomDomainAxes(0.05d, plotRenderingInfo59, point2D60);
        boolean boolean62 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent63 = null;
        categoryPlot22.notifyListeners(plotChangeEvent63);
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", (org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.title.TextTitle textTitle67 = new org.jfree.chart.title.TextTitle();
        textTitle67.setToolTipText("");
        try {
            jFreeChart65.addSubtitle((int) (short) -1, (org.jfree.chart.title.Title) textTitle67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot3D0.getLegendItems();
        double double7 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.12d + "'", double7 == 0.12d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine2 = textBlock1.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock1.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) verticalAlignment5);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment5, (double) (short) -1, 0.05d);
        boolean boolean10 = textTitle0.equals((java.lang.Object) 0.05d);
        textTitle0.setWidth(1.0E-8d);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double16 = numberAxis15.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis15.setRangeWithMargins((org.jfree.data.Range) dateRange17);
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType21 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType25 = rectangleConstraint24.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange20, lengthConstraintType21, 1.0E-8d, (org.jfree.data.Range) dateRange23, lengthConstraintType25);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange17, (org.jfree.data.Range) dateRange20);
        try {
            org.jfree.chart.util.Size2D size2D28 = textTitle0.arrange(graphics2D13, rectangleConstraint27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(textLine2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0E-8d + "'", double16 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange17);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(lengthConstraintType21);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(lengthConstraintType25);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        categoryAxis3D1.setLabelToolTip("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean21 = rectangleEdge19.equals((java.lang.Object) verticalAlignment20);
        try {
            double double22 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor15, (int) '4', (int) (byte) -1, rectangle2D18, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(verticalAlignment20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        java.awt.Paint paint6 = textFragment5.getPaint();
        valueMarker1.setLabelPaint(paint6);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker1.setLabelTextAnchor(textAnchor9);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "", "TextAnchor.TOP_RIGHT");
        piePlot3D1.setLegendItemShape(shape2);
        org.jfree.data.general.PieDataset pieDataset7 = piePlot3D1.getDataset();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(pieDataset7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        java.awt.Paint paint3 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes(0.2d, plotRenderingInfo5, point2D6, true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setInverted(true);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        double double24 = dateAxis22.getLowerMargin();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange26, lengthConstraintType27, 1.0E-8d, (org.jfree.data.Range) dateRange29, lengthConstraintType31);
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange29, true, true);
        org.jfree.data.Range range38 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange29, (double) 100.0f);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(range38);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setInverted(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit13 = null;
        dateAxis9.setTickUnit(dateTickUnit13, false, true);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            double double20 = dateAxis9.java2DToValue((double) 'a', rectangle2D18, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot21.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            categoryPlot21.addRangeMarker(marker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.TOP");
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass4 = numberAxis3.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass4);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Pie 3D Plot", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        boolean boolean9 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = xYPlot5.getOrientation();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass2 = numberAxis1.getClass();
        numberAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis9.setRange(date11, date12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.awt.Paint paint21 = xYPlot5.getRangeZeroBaselinePaint();
        java.awt.Paint paint22 = xYPlot5.getRangeCrosshairPaint();
        java.lang.Object obj23 = xYPlot5.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        boolean boolean11 = piePlot3D0.getIgnoreNullValues();
        java.lang.String str12 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Pie 3D Plot" + "'", str12.equals("Pie 3D Plot"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.awt.Paint paint34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis33.setTickMarkPaint(paint34);
        categoryPlot21.setDomainGridlinePaint(paint34);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot21.getRangeAxis(4);
        categoryPlot21.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNull(valueAxis56);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        waferMapPlot1.rendererChanged(rendererChangeEvent2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        java.lang.Object obj10 = piePlot3D3.clone();
        double double11 = piePlot3D3.getInteriorGap();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot21.getDatasetRenderingOrder();
        org.jfree.chart.plot.Plot plot38 = categoryPlot21.getRootPlot();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(plot38);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setInverted(true);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        double double24 = dateAxis22.getLowerMargin();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange26, lengthConstraintType27, 1.0E-8d, (org.jfree.data.Range) dateRange29, lengthConstraintType31);
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange29, true, true);
        try {
            dateAxis9.zoomRange((double) (short) 10, 0.12d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-9.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean2 = rectangleEdge0.equals((java.lang.Object) verticalAlignment1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean4 = verticalAlignment1.equals((java.lang.Object) stroke3);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot5.rendererChanged(rendererChangeEvent8);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        double double11 = dateAxis9.getLowerMargin();
        dateAxis9.setPositiveArrowVisible(false);
        try {
            dateAxis9.zoomRange((double) 100L, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker7.setLabelTextAnchor(textAnchor8);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (short) 100, textAnchor4, 0.0d, textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setIgnoreZeroValues(false);
        java.lang.String str6 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Pie 3D Plot" + "'", str6.equals("Pie 3D Plot"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        double double10 = piePlot3D0.getExplodePercent((java.lang.Comparable) 0.05d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor11 = piePlot3D0.getLabelDistributor();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor12 = piePlot3D0.getLabelDistributor();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor11);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor12);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        polarPlot37.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        polarPlot37.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass47 = numberAxis46.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = numberAxis46.getTickUnit();
        polarPlot37.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit48);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        polarPlot37.setRenderer(polarItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        polarPlot37.zoomDomainAxes((double) '4', 0.2d, plotRenderingInfo54, point2D55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass59 = numberAxis58.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = numberAxis58.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass63 = numberAxis62.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit64 = numberAxis62.getTickUnit();
        numberAxis58.setTickUnit(numberTickUnit64);
        polarPlot37.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis58);
        int int67 = categoryPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis58);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder68 = categoryPlot22.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(numberTickUnit60);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(numberTickUnit64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder68);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            piePlot3D0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D2.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color4);
        java.awt.Stroke stroke7 = piePlot3D2.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double8 = piePlot3D2.getInteriorGap();
        piePlot3D2.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot3D2.axisChanged(axisChangeEvent11);
        java.awt.Font font13 = piePlot3D2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        piePlot3D2.setDataset(pieDataset14);
        java.awt.Paint paint16 = piePlot3D2.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        double double24 = rectangleInsets21.calculateTopOutset((double) (byte) 10);
        double double26 = rectangleInsets21.calculateLeftOutset((double) 0L);
        piePlot3D2.setLabelPadding(rectangleInsets21);
        piePlot3D0.setLabelPadding(rectangleInsets21);
        piePlot3D0.setLabelLinkMargin(0.12d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace11, true);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass10 = numberAxis9.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis9.getTickUnit();
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit11);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        polarPlot0.setRenderer(polarItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        polarPlot0.zoomDomainAxes((double) '4', 0.2d, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = polarPlot0.getAxis();
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        objectList1.clear();
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot21.getDatasetRenderingOrder();
        categoryPlot21.mapDatasetToRangeAxis(100, 15);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D0.setBackgroundPaint(paint1);
        java.awt.Paint paint4 = piePlot3D0.getSectionPaint((java.lang.Comparable) 255);
        java.awt.Paint paint5 = piePlot3D0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        double double30 = categoryAxis3D24.getLabelAngle();
        org.jfree.chart.plot.Plot plot31 = categoryAxis3D24.getPlot();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(plot31);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        double double11 = dateAxis9.getLowerMargin();
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange13, lengthConstraintType14, 1.0E-8d, (org.jfree.data.Range) dateRange16, lengthConstraintType18);
        dateAxis9.setDefaultAutoRange((org.jfree.data.Range) dateRange16);
        double double21 = dateRange16.getUpperBound();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        xYPlot5.setDomainCrosshairValue((double) 1L, true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass12 = numberAxis11.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = numberAxis11.getTickUnit();
        int int14 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo16, point2D17, false);
        xYPlot5.configureDomainAxes();
        java.awt.Paint paint21 = null;
        xYPlot5.setRangeTickBandPaint(paint21);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot21.setInsets(rectangleInsets38);
        categoryPlot21.setNoDataMessage("RectangleEdge.LEFT");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent42);
        double[] doubleArray52 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray58 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray59 = new double[][] { doubleArray52, doubleArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray59);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D62, (org.jfree.chart.axis.ValueAxis) numberAxis64, categoryItemRenderer65);
        org.jfree.chart.util.SortOrder sortOrder67 = categoryPlot66.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D69 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D69.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D69.setAxisLinePaint((java.awt.Paint) color72);
        int int74 = categoryPlot66.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D69);
        org.jfree.chart.util.SortOrder sortOrder75 = categoryPlot66.getColumnRenderingOrder();
        categoryPlot66.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent78 = null;
        categoryPlot66.rendererChanged(rendererChangeEvent78);
        boolean boolean80 = categoryPlot66.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis82 = categoryPlot66.getRangeAxis((int) (short) 0);
        categoryPlot21.setRangeAxis((int) '#', valueAxis82, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertNotNull(sortOrder67);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertNotNull(sortOrder75);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(valueAxis82);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets31.getUnitType();
        double double34 = rectangleInsets31.calculateTopOutset((double) (byte) 10);
        double double35 = rectangleInsets31.getLeft();
        double double37 = rectangleInsets31.calculateRightInset(0.2d);
        piePlot3D0.setLabelPadding(rectangleInsets31);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 10.0d + "'", double34 == 10.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + (-1.0d) + "'", double35 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.4d + "'", double37 == 0.4d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        double[] doubleArray39 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray45 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray46 = new double[][] { doubleArray39, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray46);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D49, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryItemRenderer52);
        int int54 = categoryPlot53.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot53.getDomainAxis(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot53.getDomainAxis(255);
        double[] doubleArray66 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray72 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray73 = new double[][] { doubleArray66, doubleArray72 };
        org.jfree.data.category.CategoryDataset categoryDataset74 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray73);
        categoryPlot53.setDataset(categoryDataset74);
        categoryPlot21.setDataset(categoryDataset74);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNull(categoryAxis56);
        org.junit.Assert.assertNull(categoryAxis58);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(categoryDataset74);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer8 };
        xYPlot5.setRenderers(xYItemRendererArray9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis12.setTickMarkPaint(paint13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double25 = numberAxis24.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis24.setRangeWithMargins((org.jfree.data.Range) dateRange26);
        xYPlot20.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer33);
        xYPlot34.clearAnnotations();
        java.awt.Paint paint36 = xYPlot34.getRangeCrosshairPaint();
        java.awt.Stroke stroke37 = xYPlot34.getDomainGridlineStroke();
        xYPlot20.setDomainZeroBaselineStroke(stroke37);
        numberAxis12.setTickMarkStroke(stroke37);
        xYPlot5.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean42 = xYPlot5.removeAnnotation(xYAnnotation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setToolTipText("");
        java.lang.String str3 = textTitle0.getToolTipText();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 90.0d, false);
        boolean boolean6 = dateRange0.intersects((double) 52, (double) 0L);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = rectangleConstraint12.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange8, lengthConstraintType9, 1.0E-8d, (org.jfree.data.Range) dateRange11, lengthConstraintType13);
        boolean boolean15 = piePlot3D0.equals((java.lang.Object) lengthConstraintType9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        double double30 = categoryAxis3D24.getLabelAngle();
        double double31 = categoryAxis3D24.getUpperMargin();
        categoryAxis3D24.setCategoryLabelPositionOffset((int) 'a');
        java.lang.String str34 = categoryAxis3D24.getLabelToolTip();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot5.getFixedLegendItems();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        xYPlot5.setRangeCrosshairStroke(stroke9);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        piePlot3D0.setMinimumArcAngleToDraw((double) 500);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        java.awt.Stroke stroke7 = categoryAxis3D1.getAxisLineStroke();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = categoryAxis3D1.draw(graphics2D8, (double) 1.0f, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart36.getCategoryPlot();
        jFreeChart36.setBackgroundImageAlignment(4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(categoryPlot40);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        categoryPlot21.clearDomainMarkers();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) ringPlot1);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        ringPlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator4);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        boolean boolean1 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot21.setInsets(rectangleInsets38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot21.getRangeAxisLocation(10);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation41, plotOrientation42);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer8 };
        xYPlot5.setRenderers(xYItemRendererArray9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            boolean boolean13 = xYPlot5.removeAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock0.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean5 = rectangleEdge3.equals((java.lang.Object) verticalAlignment4);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, (double) (short) -1, 0.05d);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray15 = basicProjectInfo14.getLibraries();
        java.lang.String str16 = basicProjectInfo14.getCopyright();
        java.lang.String str17 = basicProjectInfo14.getCopyright();
        boolean boolean18 = flowArrangement8.equals((java.lang.Object) str17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot24.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        xYPlot24.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        dateAxis28.setInverted(true);
        boolean boolean32 = flowArrangement8.equals((java.lang.Object) dateAxis28);
        dateAxis28.configure();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(libraryArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer8 };
        xYPlot5.setRenderers(xYItemRendererArray9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis12.setTickMarkPaint(paint13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer19);
        java.awt.Stroke stroke21 = xYPlot20.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double25 = numberAxis24.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis24.setRangeWithMargins((org.jfree.data.Range) dateRange26);
        xYPlot20.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, (org.jfree.chart.axis.ValueAxis) numberAxis32, xYItemRenderer33);
        xYPlot34.clearAnnotations();
        java.awt.Paint paint36 = xYPlot34.getRangeCrosshairPaint();
        java.awt.Stroke stroke37 = xYPlot34.getDomainGridlineStroke();
        xYPlot20.setDomainZeroBaselineStroke(stroke37);
        numberAxis12.setTickMarkStroke(stroke37);
        xYPlot5.setDomainCrosshairStroke(stroke37);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.Point2D point2D43 = null;
        org.jfree.chart.plot.PlotState plotState44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            xYPlot5.draw(graphics2D41, rectangle2D42, point2D43, plotState44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.awt.Paint paint21 = xYPlot5.getRangeZeroBaselinePaint();
        xYPlot5.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        org.jfree.chart.plot.Plot plot4 = piePlot3D0.getParent();
        java.awt.Color color8 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 0, (float) 0L);
        piePlot3D0.setLabelOutlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass10 = numberAxis9.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis9.getTickUnit();
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit11);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        polarPlot0.setRenderer(polarItemRenderer13);
        boolean boolean15 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            xYPlot5.drawBackground(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        java.awt.Paint paint38 = categoryPlot21.getRangeCrosshairPaint();
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot21.setOutlineStroke(stroke39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        java.lang.Object obj5 = chartEntity4.clone();
        chartEntity4.setURLText("XY Plot");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint3);
        java.lang.String str5 = piePlot3D0.getPlotType();
        java.awt.Stroke stroke6 = piePlot3D0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        java.awt.Stroke stroke7 = categoryAxis3D1.getAxisLineStroke();
        categoryAxis3D1.setTickMarkInsideLength((float) 0L);
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font11);
        categoryAxis3D1.setLabelFont(font11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D7.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color9);
        java.awt.Stroke stroke12 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double13 = piePlot3D7.getInteriorGap();
        piePlot3D7.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot3D7.axisChanged(axisChangeEvent16);
        java.awt.Font font18 = piePlot3D7.getLabelFont();
        boolean boolean19 = piePlot3D0.equals((java.lang.Object) piePlot3D7);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot3D22.getLabelGenerator();
        piePlot3D22.setShadowYOffset((double) (short) 1);
        piePlot3D22.setIgnoreZeroValues(false);
        java.awt.Font font28 = piePlot3D22.getLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.PiePlotState piePlotState31 = piePlot3D0.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.PiePlot) piePlot3D22, (java.lang.Integer) 2, plotRenderingInfo30);
        piePlotState31.setTotal(2.0d);
        double double34 = piePlotState31.getPieHRadius();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(piePlotState31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.AxisState axisState23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        double[] doubleArray32 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray38 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray39 = new double[][] { doubleArray32, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray39);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D42, (org.jfree.chart.axis.ValueAxis) numberAxis44, categoryItemRenderer45);
        org.jfree.chart.util.SortOrder sortOrder47 = categoryPlot46.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D49 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D49.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D49.setAxisLinePaint((java.awt.Paint) color52);
        int int54 = categoryPlot46.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D49);
        org.jfree.chart.util.SortOrder sortOrder55 = categoryPlot46.getColumnRenderingOrder();
        categoryPlot46.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent58 = null;
        categoryPlot46.rendererChanged(rendererChangeEvent58);
        boolean boolean60 = categoryPlot46.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot46.getRangeAxisEdge();
        try {
            java.util.List list62 = numberAxis19.refreshTicks(graphics2D22, axisState23, rectangle2D24, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(sortOrder47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(sortOrder55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int4 = categoryAxis3D3.getCategoryLabelPositionOffset();
        categoryAxis3D3.setLabelURL("");
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D3.setLabelPaint(paint7);
        java.awt.Paint paint9 = categoryAxis3D3.getTickMarkPaint();
        textTitle1.setPaint(paint9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot5.getFixedLegendItems();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot5.markerChanged(markerChangeEvent9);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(legendItemCollection8);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        double[] doubleArray31 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray37 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray38);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis43, categoryItemRenderer44);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot45.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D48.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D48.setAxisLinePaint((java.awt.Paint) color51);
        int int53 = categoryPlot45.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D48);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot45.getColumnRenderingOrder();
        categoryPlot22.setColumnRenderingOrder(sortOrder54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot22.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot22.zoomDomainAxes(0.05d, plotRenderingInfo59, point2D60);
        boolean boolean62 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent63 = null;
        categoryPlot22.notifyListeners(plotChangeEvent63);
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.RenderingHints renderingHints66 = null;
        try {
            jFreeChart65.setRenderingHints(renderingHints66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("PlotOrientation.VERTICAL", graphics2D1, 0.0f, 10.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = xYPlot5.getRangeMarkers(layer7);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(collection8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        double double11 = dateAxis9.getLowerMargin();
        dateAxis9.setPositiveArrowVisible(false);
        boolean boolean14 = dateAxis9.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setIgnoreZeroValues(false);
        java.awt.Font font6 = piePlot3D0.getLabelFont();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator7 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("java.awt.Color[r=255,g=255,b=255]", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "org.jfree.chart.event.ChartProgressEvent[source=-1]", "java.awt.Color[r=255,g=255,b=255]");
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        piePlot3D3.setForegroundAlpha((float) (byte) 1);
        java.awt.Stroke stroke12 = piePlot3D3.getLabelOutlineStroke();
        boolean boolean13 = piePlot3D3.getIgnoreNullValues();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        double double34 = categoryPlot21.getRangeCrosshairValue();
        categoryPlot21.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot21.setInsets(rectangleInsets38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot21.getRangeAxisLocation(10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.Plot plot43 = categoryPlot21.getRootPlot();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(plot43);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        categoryPlot21.clearAnnotations();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        double double11 = dateAxis9.getLowerMargin();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis9.getTickMarkPosition();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        int int10 = xYPlot5.getIndexOf(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        chartEntity4.setToolTipText("java.awt.Color[r=255,g=255,b=255]");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) ringPlot1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color5.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        ringPlot0.setSectionOutlinePaint((java.lang.Comparable) 100L, (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        org.jfree.chart.text.TextFragment textFragment3 = textLine2.getLastTextFragment();
        java.lang.Object obj4 = null;
        boolean boolean5 = textLine2.equals(obj4);
        org.jfree.chart.text.TextFragment textFragment6 = textLine2.getFirstTextFragment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textFragment3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textFragment6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        xYPlot5.setDomainGridlinesVisible(false);
        int int17 = xYPlot5.getDatasetCount();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.lang.String str21 = xYPlot5.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis26, xYItemRenderer27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot28.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        xYPlot28.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        dateAxis32.configure();
        xYPlot5.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) dateAxis32);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis(255);
        double[] doubleArray34 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray40 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray41);
        categoryPlot21.setDataset(categoryDataset42);
        try {
            org.jfree.data.general.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset42, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        try {
            categoryPlot21.addAnnotation(categoryAnnotation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(legendItemCollection33);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass10 = numberAxis9.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis9.getTickUnit();
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        try {
            polarPlot0.zoomRangeAxes(0.0d, plotRenderingInfo14, point2D15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        try {
            java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset3, (java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str10 = categoryAxis3D8.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        boolean boolean11 = textTitle1.equals((java.lang.Object) 90.0d);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(xYDataset8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot5.getRangeMarkers((int) ' ', layer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer17);
        numberAxis16.setPositiveArrowVisible(false);
        xYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        xYPlot5.zoomDomainAxes((double) 0.0f, 0.5d, plotRenderingInfo24, point2D25);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot21.setRangeCrosshairValue((double) 2.0f, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.Color color10 = color3.brighter();
        float[] floatArray14 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray15 = color10.getColorComponents(floatArray14);
        float[] floatArray16 = color2.getColorComponents(floatArray15);
        float[] floatArray17 = color1.getColorComponents(floatArray16);
        try {
            float[] floatArray18 = color0.getRGBComponents(floatArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle2.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame5 = textTitle2.getFrame();
        textTitle2.setExpandToFitSpace(false);
        java.awt.Font font8 = textTitle2.getFont();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getLastTextFragment();
        java.awt.Paint paint15 = textFragment14.getPaint();
        valueMarker10.setLabelPaint(paint15);
        org.jfree.chart.text.TextAnchor textAnchor17 = valueMarker10.getLabelTextAnchor();
        java.awt.Paint paint18 = valueMarker10.getOutlinePaint();
        double[] doubleArray26 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray32 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray33 = new double[][] { doubleArray26, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer39);
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot40.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D43 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D43.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D43.setAxisLinePaint((java.awt.Paint) color46);
        int int48 = categoryPlot40.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D43);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot40.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset50, valueAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis53, xYItemRenderer54);
        java.awt.Stroke stroke56 = xYPlot55.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation57 = xYPlot55.getRangeAxisLocation();
        java.awt.Paint paint58 = xYPlot55.getDomainCrosshairPaint();
        categoryPlot40.setDomainGridlinePaint(paint58);
        valueMarker10.setPaint(paint58);
        org.jfree.chart.text.TextBlock textBlock61 = org.jfree.chart.text.TextUtilities.createTextBlock("VerticalAlignment.TOP", font8, paint58);
        org.junit.Assert.assertNotNull(blockFrame5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(sortOrder41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(textBlock61);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("");
        double double3 = textTitle0.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        textTitle0.setText("");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.Marker marker18 = null;
        try {
            boolean boolean19 = xYPlot5.removeRangeMarker(marker18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        boolean boolean11 = xYPlot5.isRangeZoomable();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot5.markerChanged(markerChangeEvent12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer18);
        numberAxis17.setVisible(true);
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        try {
            xYPlot5.setDataset((int) (byte) -1, xYDataset24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Font font2 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        java.awt.Color color11 = color4.brighter();
        float[] floatArray15 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray16 = color11.getColorComponents(floatArray15);
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("VerticalAlignment.TOP", font2, (java.awt.Paint) color11);
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment21 = textLine20.getLastTextFragment();
        org.jfree.chart.text.TextFragment textFragment22 = textLine20.getLastTextFragment();
        textLine17.removeFragment(textFragment22);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(textFragment21);
        org.junit.Assert.assertNotNull(textFragment22);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        java.lang.Object obj7 = null;
        boolean boolean8 = textTitle1.equals(obj7);
        double double9 = textTitle1.getWidth();
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        int int18 = xYPlot5.getRangeAxisCount();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot21.getOrientation();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(plotOrientation35);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot5.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            boolean boolean13 = xYPlot5.removeAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        double[] doubleArray19 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray25 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray26 = new double[][] { doubleArray19, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray26);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D29, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer32);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot33.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D36.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D36.setAxisLinePaint((java.awt.Paint) color39);
        int int41 = categoryPlot33.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D36);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot33.getColumnRenderingOrder();
        categoryPlot33.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D46 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str48 = categoryAxis3D46.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot33.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D46);
        java.awt.Paint paint50 = categoryPlot33.getRangeCrosshairPaint();
        boolean boolean51 = piePlot3D0.equals((java.lang.Object) paint50);
        org.jfree.chart.plot.PiePlot3D piePlot3D53 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D53.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color55);
        java.awt.Stroke stroke58 = piePlot3D53.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double59 = piePlot3D53.getInteriorGap();
        piePlot3D53.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent62 = null;
        piePlot3D53.axisChanged(axisChangeEvent62);
        java.awt.Font font64 = piePlot3D53.getLabelFont();
        java.awt.Paint paint65 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextFragment textFragment67 = new org.jfree.chart.text.TextFragment("hi!", font64, paint65, (float) (-1));
        piePlot3D0.setLabelFont(font64);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.08d + "'", double59 == 0.08d);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        double double14 = rectangleInsets11.calculateBottomInset((double) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = categoryPlot21.isRangeCrosshairVisible();
        float float36 = categoryPlot21.getBackgroundAlpha();
        categoryPlot21.setDrawSharedDomainAxis(false);
        categoryPlot21.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(xYDataset8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot5.getRangeMarkers((int) ' ', layer11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer17);
        numberAxis16.setPositiveArrowVisible(false);
        xYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis16);
        java.awt.Paint paint22 = null;
        try {
            numberAxis16.setAxisLinePaint(paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot21.getRangeAxisLocation((int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 90.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange0, 90.0d);
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint9 = ringPlot8.getSeparatorPaint();
        piePlot3D0.setLabelBackgroundPaint(paint9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("");
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Image image4 = piePlot3D0.getBackgroundImage();
        java.awt.Paint paint5 = null;
        piePlot3D0.setLabelBackgroundPaint(paint5);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        double double16 = piePlot3D0.getExplodePercent((java.lang.Comparable) "TextAnchor.TOP_RIGHT");
        java.awt.Color color17 = java.awt.Color.RED;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int21 = categoryAxis3D20.getCategoryLabelPositionOffset();
        categoryAxis3D20.setLabelURL("");
        java.awt.Paint paint24 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D20.setLabelPaint(paint24);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D20.setTickLabelInsets(rectangleInsets30);
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets30);
        double double34 = rectangleInsets30.calculateRightInset((double) 1L);
        piePlot3D0.setSimpleLabelOffset(rectangleInsets30);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.Point2D point2D38 = null;
        org.jfree.chart.plot.PlotState plotState39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            piePlot3D0.draw(graphics2D36, rectangle2D37, point2D38, plotState39, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.4d + "'", double34 == 0.4d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot21.setRenderer(10, categoryItemRenderer33, true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D2.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color4);
        java.awt.Stroke stroke7 = piePlot3D2.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double8 = piePlot3D2.getInteriorGap();
        piePlot3D2.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot3D2.axisChanged(axisChangeEvent11);
        java.awt.Font font13 = piePlot3D2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        piePlot3D2.setDataset(pieDataset14);
        java.awt.Paint paint16 = piePlot3D2.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType22 = rectangleInsets21.getUnitType();
        double double24 = rectangleInsets21.calculateTopOutset((double) (byte) 10);
        double double26 = rectangleInsets21.calculateLeftOutset((double) 0L);
        piePlot3D2.setLabelPadding(rectangleInsets21);
        piePlot3D0.setLabelPadding(rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets21.createOutsetRectangle(rectangle2D29, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 10.0d + "'", double24 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        categoryAxis3D1.setTickMarkPaint((java.awt.Paint) color13);
        java.lang.String str21 = categoryAxis3D1.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot14.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        dateAxis18.setInverted(true);
        org.jfree.data.Range range22 = xYPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot5.getDomainAxis(10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis0.setRange(date1, date2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent31);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("-3,-3,3,3");
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot4.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem13 = legendItemCollection11.get((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        double double27 = rectangleInsets19.trimWidth(0.025d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.6249999999999999d + "'", double27 == 0.6249999999999999d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape9 = textBlock0.calculateBounds(graphics2D2, (float) 1, 10.0f, textBlockAnchor5, 10.0f, 0.0f, 0.5d);
        java.awt.Font font13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("", font13);
        double[] doubleArray22 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray28 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray29 = new double[][] { doubleArray22, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray29);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer35);
        org.jfree.chart.util.SortOrder sortOrder37 = categoryPlot36.getRowRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot36.rendererChanged(rendererChangeEvent38);
        java.awt.Paint paint40 = categoryPlot36.getRangeCrosshairPaint();
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT", font13, paint40);
        java.awt.Paint paint42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        textBlock0.addLine("Pie 3D Plot", font13, paint42);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(sortOrder37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.lang.String str21 = xYPlot5.getPlotType();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        try {
            xYPlot5.setRangeAxisLocation(0, axisLocation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "XY Plot" + "'", str21.equals("XY Plot"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        categoryAxis3D34.setLabelURL("org.jfree.chart.event.ChartProgressEvent[source=-1]");
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis3D34.setTickLabelPaint((java.lang.Comparable) "-3,-3,3,3", paint41);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setAntiAlias(false);
        java.awt.Paint paint39 = jFreeChart36.getBackgroundPaint();
        int int40 = jFreeChart36.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        piePlot3D3.setForegroundAlpha((float) (byte) 1);
        java.awt.Stroke stroke12 = piePlot3D3.getLabelOutlineStroke();
        java.awt.Paint paint13 = piePlot3D3.getBaseSectionOutlinePaint();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        java.awt.Color color21 = color14.brighter();
        int int22 = color21.getTransparency();
        piePlot3D3.setBaseSectionOutlinePaint((java.awt.Paint) color21);
        java.awt.Color color24 = java.awt.Color.black;
        piePlot3D3.setBaseSectionPaint((java.awt.Paint) color24);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.plot.PiePlotState piePlotState1 = new org.jfree.chart.plot.PiePlotState(plotRenderingInfo0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot21.getDatasetRenderingOrder();
        java.awt.Stroke stroke38 = null;
        categoryPlot21.setOutlineStroke(stroke38);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = polarPlot4.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        polarPlot4.setDataset(xYDataset6);
        org.junit.Assert.assertNull(polarItemRenderer5);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        java.awt.Font font6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font6);
        double[] doubleArray15 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray21 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot29.getRowRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent31 = null;
        categoryPlot29.rendererChanged(rendererChangeEvent31);
        java.awt.Paint paint33 = categoryPlot29.getRangeCrosshairPaint();
        org.jfree.chart.text.TextLine textLine34 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT", font6, paint33);
        textTitle1.setFont(font6);
        java.lang.String str36 = textTitle1.getURLText();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(str36);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color3);
        java.awt.Stroke stroke6 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double7 = piePlot3D1.getInteriorGap();
        piePlot3D1.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        piePlot3D1.axisChanged(axisChangeEvent10);
        java.awt.Font font12 = piePlot3D1.getLabelFont();
        java.awt.Paint paint13 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("hi!", font12, paint13, (float) (-1));
        java.lang.String str16 = textFragment15.getText();
        java.awt.Paint paint17 = textFragment15.getPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setSimpleLabels(false);
        java.awt.Font font6 = piePlot3D0.getNoDataMessageFont();
        piePlot3D0.setSimpleLabels(true);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer13);
        xYPlot14.clearAnnotations();
        xYPlot14.setDomainCrosshairValue((double) 1L, true);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass21 = numberAxis20.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis20.getTickUnit();
        int int23 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        numberAxis20.setFixedAutoRange((double) 2);
        boolean boolean26 = piePlot3D0.equals((java.lang.Object) numberAxis20);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass29 = numberAxis28.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = numberAxis28.getTickUnit();
        numberAxis20.setTickUnit(numberTickUnit30, false, false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(numberTickUnit30);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        piePlot3D0.setLabelPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        piePlot3D0.setBackgroundPaint(paint1);
        java.awt.Paint paint4 = piePlot3D0.getSectionPaint((java.lang.Comparable) 255);
        piePlot3D0.setForegroundAlpha((float) 4);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = color0.brighter();
        java.awt.color.ColorSpace colorSpace8 = null;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        java.awt.Color color17 = color10.brighter();
        float[] floatArray21 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray22 = color17.getColorComponents(floatArray21);
        float[] floatArray23 = color9.getColorComponents(floatArray22);
        try {
            float[] floatArray24 = color0.getColorComponents(colorSpace8, floatArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = polarPlot0.getDataset();
        org.junit.Assert.assertNull(xYDataset8);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range4 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange1, 90.0d, false);
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range8 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange5, 90.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range4, (org.jfree.data.Range) dateRange5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(0.12d, (org.jfree.data.Range) dateRange5);
        double double11 = dateRange5.getUpperBound();
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertNotNull(dateRange5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray11 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray17 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer24);
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot25.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D28.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D28.setAxisLinePaint((java.awt.Paint) color31);
        int int33 = categoryPlot25.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D28);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot25.getColumnRenderingOrder();
        categoryPlot25.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace36);
        boolean boolean38 = columnArrangement3.equals((java.lang.Object) axisSpace36);
        blockContainer2.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D42 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D42.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color44);
        java.awt.Stroke stroke47 = piePlot3D42.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double48 = piePlot3D42.getInteriorGap();
        piePlot3D42.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = null;
        piePlot3D42.axisChanged(axisChangeEvent51);
        java.awt.Font font53 = piePlot3D42.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset54 = null;
        piePlot3D42.setDataset(pieDataset54);
        java.awt.Paint paint56 = piePlot3D42.getBaseSectionOutlinePaint();
        double double58 = piePlot3D42.getExplodePercent((java.lang.Comparable) "TextAnchor.TOP_RIGHT");
        java.awt.Color color59 = java.awt.Color.RED;
        java.awt.Stroke stroke60 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D62 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int63 = categoryAxis3D62.getCategoryLabelPositionOffset();
        categoryAxis3D62.setLabelURL("");
        java.awt.Paint paint66 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D62.setLabelPaint(paint66);
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D62.setTickLabelInsets(rectangleInsets72);
        org.jfree.chart.block.LineBorder lineBorder74 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color59, stroke60, rectangleInsets72);
        double double76 = rectangleInsets72.calculateRightInset((double) 1L);
        piePlot3D42.setSimpleLabelOffset(rectangleInsets72);
        try {
            java.lang.Object obj78 = blockContainer2.draw(graphics2D40, rectangle2D41, (java.lang.Object) piePlot3D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNull(stroke47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.08d + "'", double48 == 0.08d);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 4 + "'", int63 == 4);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.4d + "'", double76 == 0.4d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 90.0d, (double) (byte) 1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int6 = categoryAxis3D5.getCategoryLabelPositionOffset();
        categoryAxis3D5.setLabelURL("");
        java.awt.Paint paint9 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D5.setLabelPaint(paint9);
        java.awt.Stroke stroke11 = categoryAxis3D5.getAxisLineStroke();
        java.awt.Color color12 = java.awt.Color.RED;
        categoryAxis3D5.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.chart.plot.PiePlot3D piePlot3D14 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D14.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color16);
        java.awt.Stroke stroke19 = piePlot3D14.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double20 = piePlot3D14.getInteriorGap();
        piePlot3D14.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = null;
        piePlot3D14.axisChanged(axisChangeEvent23);
        java.awt.Font font25 = piePlot3D14.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset26 = null;
        piePlot3D14.setDataset(pieDataset26);
        java.awt.Stroke stroke28 = piePlot3D14.getOutlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10, (java.awt.Paint) color1, stroke3, (java.awt.Paint) color12, stroke28, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.08d + "'", double20 == 0.08d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        float float5 = polarPlot4.getBackgroundAlpha();
        org.jfree.chart.axis.TickUnit tickUnit6 = polarPlot4.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(tickUnit6);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D7.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color9);
        java.awt.Stroke stroke12 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double13 = piePlot3D7.getInteriorGap();
        piePlot3D7.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot3D7.axisChanged(axisChangeEvent16);
        java.awt.Font font18 = piePlot3D7.getLabelFont();
        boolean boolean19 = piePlot3D0.equals((java.lang.Object) piePlot3D7);
        int int20 = piePlot3D0.getPieIndex();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) ringPlot1);
        java.awt.Paint paint4 = null;
        try {
            ringPlot0.setLabelPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabel();
        boolean boolean2 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean5 = rectangleEdge3.equals((java.lang.Object) verticalAlignment4);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        boolean boolean7 = verticalAlignment4.equals((java.lang.Object) paint6);
        boolean boolean8 = categoryAxis0.equals((java.lang.Object) boolean7);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setIgnoreZeroValues(false);
        java.lang.String str6 = piePlot3D0.getNoDataMessage();
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot3D0.equals(obj7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint3);
        java.lang.String str5 = piePlot3D0.getPlotType();
        java.awt.Paint paint6 = null;
        piePlot3D0.setLabelBackgroundPaint(paint6);
        piePlot3D0.setShadowYOffset((double) ' ');
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock0.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean5 = rectangleEdge3.equals((java.lang.Object) verticalAlignment4);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, (double) (short) -1, 0.05d);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray15 = basicProjectInfo14.getLibraries();
        java.lang.String str16 = basicProjectInfo14.getCopyright();
        java.lang.String str17 = basicProjectInfo14.getCopyright();
        boolean boolean18 = flowArrangement8.equals((java.lang.Object) str17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot24.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        xYPlot24.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        dateAxis28.setInverted(true);
        boolean boolean32 = flowArrangement8.equals((java.lang.Object) dateAxis28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit33 = dateAxis28.getTickUnit();
        java.lang.Object obj34 = dateAxis28.clone();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(libraryArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTickUnit33);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        jFreeChart36.fireChartChanged();
        jFreeChart36.removeLegend();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        categoryPlot21.configureDomainAxes();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        boolean boolean42 = categoryPlot21.render(graphics2D38, rectangle2D39, (int) ' ', plotRenderingInfo41);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot21.setRangeGridlinesVisible(false);
        categoryPlot21.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D46 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str48 = categoryAxis3D46.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        int int49 = categoryAxis3D46.getMaximumCategoryLabelLines();
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D46);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setSimpleLabels(false);
        java.awt.Font font6 = piePlot3D0.getNoDataMessageFont();
        piePlot3D0.setSimpleLabels(true);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer13);
        xYPlot14.clearAnnotations();
        xYPlot14.setDomainCrosshairValue((double) 1L, true);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass21 = numberAxis20.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis20.getTickUnit();
        int int23 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis20);
        numberAxis20.setFixedAutoRange((double) 2);
        boolean boolean26 = piePlot3D0.equals((java.lang.Object) numberAxis20);
        numberAxis20.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setInverted(true);
        double[] doubleArray20 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray26 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis32, categoryItemRenderer33);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot34.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D37.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D37.setAxisLinePaint((java.awt.Paint) color40);
        int int42 = categoryPlot34.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D37);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot34.getColumnRenderingOrder();
        categoryPlot34.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str49 = categoryAxis3D47.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot34.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        boolean boolean52 = categoryPlot34.equals((java.lang.Object) false);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot34.setRangeCrosshairStroke(stroke53);
        boolean boolean55 = dateAxis9.equals((java.lang.Object) stroke53);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D0.getLegendLabelToolTipGenerator();
        double double8 = piePlot3D0.getInteriorGap();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        numberAxis2.setTickMarksVisible(true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        double double16 = piePlot3D0.getExplodePercent((java.lang.Comparable) "TextAnchor.TOP_RIGHT");
        java.awt.Shape shape17 = piePlot3D0.getLegendItemShape();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock0.draw(graphics2D1, (float) 10L, (float) '4', textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        ringPlot0.setShadowXOffset(90.0d);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0L, (float) 4, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis(255);
        double[] doubleArray34 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray40 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray41);
        categoryPlot21.setDataset(categoryDataset42);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot21.getLegendItems();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(legendItemCollection44);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.plot.Plot plot40 = jFreeChart36.getPlot();
        java.awt.RenderingHints renderingHints41 = null;
        try {
            jFreeChart36.setRenderingHints(renderingHints41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(plot40);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        boolean boolean11 = xYPlot5.isRangeZoomable();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = xYPlot5.getRangeMarkers((int) ' ', layer13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace15);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot21.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot21.zoomDomainAxes(0.05d, plotRenderingInfo58, point2D59);
        java.awt.Image image61 = null;
        categoryPlot21.setBackgroundImage(image61);
        org.jfree.chart.axis.AxisLocation axisLocation64 = categoryPlot21.getDomainAxisLocation((int) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertNotNull(axisLocation64);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot21.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot21.zoomDomainAxes(0.05d, plotRenderingInfo58, point2D59);
        java.awt.Image image61 = null;
        categoryPlot21.setBackgroundImage(image61);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = null;
        org.jfree.chart.plot.XYPlot xYPlot68 = new org.jfree.chart.plot.XYPlot(xYDataset63, valueAxis64, (org.jfree.chart.axis.ValueAxis) numberAxis66, xYItemRenderer67);
        org.jfree.data.xy.XYDataset xYDataset69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset69, valueAxis70, (org.jfree.chart.axis.ValueAxis) numberAxis72, xYItemRenderer73);
        java.util.List list75 = xYPlot74.getAnnotations();
        xYPlot74.setDomainCrosshairVisible(false);
        boolean boolean78 = xYPlot68.equals((java.lang.Object) xYPlot74);
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font82 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine83 = new org.jfree.chart.text.TextLine("", font82);
        org.jfree.chart.text.TextFragment textFragment84 = textLine83.getLastTextFragment();
        java.awt.Paint paint85 = textFragment84.getPaint();
        valueMarker80.setLabelPaint(paint85);
        xYPlot68.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker80);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = valueMarker80.getLabelAnchor();
        try {
            boolean boolean89 = categoryPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(font82);
        org.junit.Assert.assertNotNull(textFragment84);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot4.getLegendItems();
        org.jfree.chart.LegendItem legendItem12 = null;
        legendItemCollection11.add(legendItem12);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("");
        double double3 = textTitle0.getHeight();
        textTitle0.setPadding(0.0d, (double) 1L, (-109.5d), (-109.5d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.TOP_RIGHT", graphics2D1, (float) 4, (float) 4, textAnchor4, (double) (short) 0, (float) (-1), (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str5.equals("TextAnchor.TOP_RIGHT"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.Color color8 = color1.brighter();
        float[] floatArray12 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray13 = color8.getColorComponents(floatArray12);
        try {
            float[] floatArray14 = color0.getComponents(floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot21.getDomainAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker32.setLabelTextAnchor(textAnchor33);
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32, layer35);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_CYAN;
        valueMarker32.setOutlinePaint((java.awt.Paint) color37);
        valueMarker32.setAlpha(0.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        java.lang.String str1 = size2D0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str1.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot5.getOrientation();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(plotOrientation11);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Color color1 = java.awt.Color.white;
        double[] doubleArray9 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray15 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray9, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D26.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D26.setAxisLinePaint((java.awt.Paint) color29);
        int int31 = categoryPlot23.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D26);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot23.getColumnRenderingOrder();
        categoryPlot23.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str38 = categoryAxis3D36.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot23.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D36);
        boolean boolean41 = categoryPlot23.equals((java.lang.Object) false);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot23.setRangeCrosshairStroke(stroke42);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset44, valueAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis47, xYItemRenderer48);
        xYPlot49.clearAnnotations();
        java.awt.Paint paint51 = xYPlot49.getRangeCrosshairPaint();
        org.jfree.chart.plot.PiePlot3D piePlot3D52 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D52.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color54);
        piePlot3D52.setBackgroundImageAlignment((int) 'a');
        boolean boolean58 = piePlot3D52.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D59 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color61 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D59.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color61);
        java.awt.Stroke stroke64 = piePlot3D59.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double65 = piePlot3D59.getInteriorGap();
        piePlot3D59.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent68 = null;
        piePlot3D59.axisChanged(axisChangeEvent68);
        java.awt.Font font70 = piePlot3D59.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset71 = null;
        piePlot3D59.setDataset(pieDataset71);
        java.awt.Stroke stroke73 = piePlot3D59.getOutlineStroke();
        boolean boolean74 = piePlot3D52.equals((java.lang.Object) stroke73);
        org.jfree.chart.plot.ValueMarker valueMarker76 = new org.jfree.chart.plot.ValueMarker((double) 100, (java.awt.Paint) color1, stroke42, paint51, stroke73, (float) (byte) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNull(stroke64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.08d + "'", double65 == 0.08d);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = categoryPlot21.isRangeCrosshairVisible();
        float float36 = categoryPlot21.getBackgroundAlpha();
        categoryPlot21.setDrawSharedDomainAxis(false);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset39, valueAxis40, (org.jfree.chart.axis.ValueAxis) numberAxis42, xYItemRenderer43);
        java.awt.Stroke stroke45 = xYPlot44.getRangeZeroBaselineStroke();
        java.awt.Color color46 = java.awt.Color.yellow;
        xYPlot44.setDomainGridlinePaint((java.awt.Paint) color46);
        double[] doubleArray56 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray62 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray63 = new double[][] { doubleArray56, doubleArray62 };
        org.jfree.data.category.CategoryDataset categoryDataset64 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray63);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D66 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset64, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D66, (org.jfree.chart.axis.ValueAxis) numberAxis68, categoryItemRenderer69);
        org.jfree.chart.axis.TickUnitSource tickUnitSource71 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis68.setStandardTickUnits(tickUnitSource71);
        xYPlot44.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis68);
        int int74 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis68);
        boolean boolean75 = numberAxis68.isTickMarksVisible();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(categoryDataset64);
        org.junit.Assert.assertNotNull(tickUnitSource71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextStroke();
        java.awt.Paint paint4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 255, paint1, stroke3, paint4, stroke5, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot5.setDataset(xYDataset8);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = xYPlot5.getRangeMarkers((int) ' ', layer11);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            xYPlot5.addDomainMarker(marker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.plot.Plot plot40 = jFreeChart36.getPlot();
        java.lang.Object obj41 = jFreeChart36.clone();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(plot40);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.awt.Paint paint21 = xYPlot5.getRangeZeroBaselinePaint();
        java.awt.Paint paint22 = xYPlot5.getRangeCrosshairPaint();
        xYPlot5.setRangeGridlinesVisible(false);
        boolean boolean25 = xYPlot5.isSubplot();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot3D0.getLegendItems();
        boolean boolean8 = legendItemCollection6.equals((java.lang.Object) (short) -1);
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D9.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color11);
        boolean boolean13 = legendItemCollection6.equals((java.lang.Object) piePlot3D9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        double double26 = rectangleInsets19.getBottom();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        org.jfree.chart.text.TextFragment textFragment32 = textLine31.getLastTextFragment();
        java.awt.Paint paint33 = textFragment32.getPaint();
        valueMarker28.setLabelPaint(paint33);
        org.jfree.chart.text.TextAnchor textAnchor35 = valueMarker28.getLabelTextAnchor();
        java.awt.Paint paint36 = valueMarker28.getOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder(rectangleInsets19, paint36);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        boolean boolean11 = polarPlot4.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D7.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color9);
        java.awt.Stroke stroke12 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double13 = piePlot3D7.getInteriorGap();
        piePlot3D7.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot3D7.axisChanged(axisChangeEvent16);
        java.awt.Font font18 = piePlot3D7.getLabelFont();
        boolean boolean19 = piePlot3D0.equals((java.lang.Object) piePlot3D7);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot3D22.getLabelGenerator();
        piePlot3D22.setShadowYOffset((double) (short) 1);
        piePlot3D22.setIgnoreZeroValues(false);
        java.awt.Font font28 = piePlot3D22.getLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.PiePlotState piePlotState31 = piePlot3D0.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.PiePlot) piePlot3D22, (java.lang.Integer) 2, plotRenderingInfo30);
        java.awt.Font font32 = piePlot3D22.getLabelFont();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(piePlotState31);
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Stroke stroke37 = categoryPlot22.getDomainGridlineStroke();
        java.awt.Paint paint38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot22.setDomainGridlinePaint(paint38);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot4.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem13 = legendItemCollection11.get((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }
}

