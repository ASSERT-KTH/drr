import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot21.zoomDomainAxes((-1.0d), plotRenderingInfo24, point2D25);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        java.awt.Paint paint10 = textFragment9.getPaint();
        valueMarker5.setLabelPaint(paint10);
        org.jfree.chart.text.TextAnchor textAnchor12 = valueMarker5.getLabelTextAnchor();
        java.awt.Paint paint13 = valueMarker5.getOutlinePaint();
        double[] doubleArray21 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray27 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray28 = new double[][] { doubleArray21, doubleArray27 };
        org.jfree.data.category.CategoryDataset categoryDataset29 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D31, (org.jfree.chart.axis.ValueAxis) numberAxis33, categoryItemRenderer34);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot35.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D38 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D38.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D38.setAxisLinePaint((java.awt.Paint) color41);
        int int43 = categoryPlot35.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D38);
        org.jfree.chart.axis.AxisLocation axisLocation44 = categoryPlot35.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis48, xYItemRenderer49);
        java.awt.Stroke stroke51 = xYPlot50.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot50.getRangeAxisLocation();
        java.awt.Paint paint53 = xYPlot50.getDomainCrosshairPaint();
        categoryPlot35.setDomainGridlinePaint(paint53);
        valueMarker5.setPaint(paint53);
        piePlot3D0.setBaseSectionPaint(paint53);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textFragment9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(categoryDataset29);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis3D1.getLabelInsets();
        float float14 = categoryAxis3D1.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineBorder0.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        java.awt.Paint paint7 = categoryAxis3D1.getTickMarkPaint();
        categoryAxis3D1.setLabelToolTip("RectangleEdge.LEFT");
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis3D1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets10.createOutsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        java.lang.Object obj11 = polarPlot4.clone();
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        xYPlot5.setRangeCrosshairValue((double) (-1L), false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            xYPlot5.addAnnotation(xYAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        valueMarker1.setStroke(stroke2);
        java.awt.Stroke stroke4 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        polarPlot37.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        polarPlot37.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass47 = numberAxis46.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = numberAxis46.getTickUnit();
        polarPlot37.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit48);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        polarPlot37.setRenderer(polarItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        polarPlot37.zoomDomainAxes((double) '4', 0.2d, plotRenderingInfo54, point2D55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass59 = numberAxis58.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = numberAxis58.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass63 = numberAxis62.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit64 = numberAxis62.getTickUnit();
        numberAxis58.setTickUnit(numberTickUnit64);
        polarPlot37.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis58);
        int int67 = categoryPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis58);
        double double68 = numberAxis58.getFixedDimension();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(numberTickUnit60);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(numberTickUnit64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0, (double) 255, (double) 10L, (double) (byte) -1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) (byte) -1, jFreeChart1, (int) 'a', (-1));
        java.lang.String str5 = chartProgressEvent4.toString();
        chartProgressEvent4.setPercent((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1]" + "'", str5.equals("org.jfree.chart.event.ChartProgressEvent[source=-1]"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str3 = standardPieSectionLabelGenerator2.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3D4.getLabelGenerator();
        piePlot3D4.setShadowYOffset((double) (short) 1);
        piePlot3D4.setIgnoreZeroValues(false);
        boolean boolean10 = standardPieSectionLabelGenerator2.equals((java.lang.Object) piePlot3D4);
        java.awt.Font font11 = piePlot3D4.getNoDataMessageFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot5.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot5.getRangeAxisEdge((int) '#');
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 52, (double) (short) -1);
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle1.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        java.lang.String str3 = rectangleConstraint2.toString();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double6 = numberAxis5.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange7);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange10, lengthConstraintType11, 1.0E-8d, (org.jfree.data.Range) dateRange13, lengthConstraintType15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange7, (org.jfree.data.Range) dateRange10);
        double double18 = dateRange10.getCentralValue();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint2.toRangeHeight((org.jfree.data.Range) dateRange10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str3.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5d + "'", double18 == 0.5d);
        org.junit.Assert.assertNotNull(rectangleConstraint19);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setDrawSharedDomainAxis(false);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot39.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("");
        xYPlot39.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis43);
        java.awt.Paint paint45 = dateAxis43.getLabelPaint();
        categoryPlot21.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis) dateAxis43, true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        java.lang.Object obj5 = chartEntity4.clone();
        java.lang.String str6 = chartEntity4.getShapeCoords();
        java.lang.String str7 = chartEntity4.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-3,-3,3,3" + "'", str6.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartEntity: tooltip = ThreadContext" + "'", str7.equals("ChartEntity: tooltip = ThreadContext"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("");
        double double3 = textTitle0.getHeight();
        java.lang.Object obj4 = textTitle0.clone();
        java.lang.Object obj5 = textTitle0.clone();
        boolean boolean6 = textTitle0.getNotify();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextStroke();
        java.awt.Shape shape9 = defaultDrawingSupplier7.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "ThreadContext");
        piePlot3D0.setLegendItemShape(shape9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font7 = null;
        try {
            textTitle1.setFont(font7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockFrame4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        float float22 = categoryAxis3D17.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("");
        double double3 = textTitle0.getHeight();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent4 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = textTitle0.getMargin();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent6 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot21.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Point2D point2D59 = null;
        categoryPlot21.zoomDomainAxes(0.05d, plotRenderingInfo58, point2D59);
        boolean boolean61 = categoryPlot21.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent62 = null;
        categoryPlot21.notifyListeners(plotChangeEvent62);
        org.jfree.chart.util.Layer layer64 = null;
        java.util.Collection collection65 = categoryPlot21.getDomainMarkers(layer64);
        org.jfree.chart.util.Layer layer66 = null;
        java.util.Collection collection67 = categoryPlot21.getRangeMarkers(layer66);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertNull(collection67);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        jFreeChart36.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle41 = jFreeChart36.getTitle();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(textTitle41);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.text.TextLine textLine2 = textBlock0.getLastLine();
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNull(textLine2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot4.getLegendItems();
        polarPlot4.setAngleGridlinesVisible(true);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Image image4 = piePlot3D0.getBackgroundImage();
        java.awt.Paint paint5 = piePlot3D0.getBaseSectionPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(image4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.ColumnArrangement columnArrangement3 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray11 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray17 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D21 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D21, (org.jfree.chart.axis.ValueAxis) numberAxis23, categoryItemRenderer24);
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot25.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D28 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D28.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D28.setAxisLinePaint((java.awt.Paint) color31);
        int int33 = categoryPlot25.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D28);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot25.getColumnRenderingOrder();
        categoryPlot25.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot25.setFixedDomainAxisSpace(axisSpace36);
        boolean boolean38 = columnArrangement3.equals((java.lang.Object) axisSpace36);
        blockContainer2.setArrangement((org.jfree.chart.block.Arrangement) columnArrangement3);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            blockContainer2.draw(graphics2D40, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
        org.junit.Assert.assertNotNull(sortOrder26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        java.awt.Paint paint9 = xYPlot5.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedRangeAxisSpace(axisSpace10, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        org.jfree.chart.plot.Plot plot4 = categoryAxis3D1.getPlot();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis8, xYItemRenderer9);
        java.awt.Stroke stroke11 = xYPlot10.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot10.getFixedLegendItems();
        java.awt.Paint paint14 = xYPlot10.getDomainGridlinePaint();
        categoryAxis3D1.setAxisLinePaint(paint14);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer5);
        java.util.List list7 = xYPlot6.getAnnotations();
        java.util.Collection collection8 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list7);
        projectInfo0.setContributors(list7);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) list7);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        waferMapPlot2.rendererChanged(rendererChangeEvent3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Font font4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel7 = null;
        java.awt.Rectangle rectangle8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.AffineTransform affineTransform10 = null;
        java.awt.RenderingHints renderingHints11 = null;
        java.awt.PaintContext paintContext12 = color6.createContext(colorModel7, rectangle8, rectangle2D9, affineTransform10, renderingHints11);
        java.awt.Color color13 = color6.brighter();
        float[] floatArray17 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray18 = color13.getColorComponents(floatArray17);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("VerticalAlignment.TOP", font4, (java.awt.Paint) color13);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        java.awt.Color color27 = color20.brighter();
        float[] floatArray31 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray32 = color27.getColorComponents(floatArray31);
        int int33 = color27.getAlpha();
        int int34 = color27.getAlpha();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer37 = new org.jfree.chart.text.G2TextMeasurer(graphics2D36);
        org.jfree.chart.text.TextBlock textBlock38 = org.jfree.chart.text.TextUtilities.createTextBlock("", font4, (java.awt.Paint) color27, (float) 2, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer37);
        org.jfree.chart.text.TextLine textLine39 = new org.jfree.chart.text.TextLine("ClassContext", font4);
        java.awt.Graphics2D graphics2D40 = null;
        try {
            org.jfree.chart.util.Size2D size2D41 = textLine39.calculateDimensions(graphics2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintContext12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 255 + "'", int33 == 255);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertNotNull(textBlock38);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.event.ChartProgressListener chartProgressListener37 = null;
        jFreeChart36.addProgressListener(chartProgressListener37);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setAntiAlias(false);
        java.awt.Paint paint39 = jFreeChart36.getBackgroundPaint();
        java.awt.Stroke stroke40 = jFreeChart36.getBorderStroke();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = categoryPlot21.isRangeCrosshairVisible();
        float float36 = categoryPlot21.getBackgroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot21.getIndexOf(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        piePlot3D5.setBackgroundImageAlignment((int) 'a');
        boolean boolean11 = piePlot3D5.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        boolean boolean24 = piePlot3D5.equals((java.lang.Object) piePlot3D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D12, (java.lang.Integer) 4, plotRenderingInfo26);
        ringPlot0.setStartAngle((double) 10.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(piePlotState27);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.lang.String str15 = plotOrientation14.toString();
        double[] doubleArray23 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray29 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray30 = new double[][] { doubleArray23, doubleArray29 };
        org.jfree.data.category.CategoryDataset categoryDataset31 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray30);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D33 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D33, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer36);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot37.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D40.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D40.setAxisLinePaint((java.awt.Paint) color43);
        int int45 = categoryPlot37.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D40);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot37.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = categoryPlot37.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot37.zoomDomainAxes((double) 100.0f, plotRenderingInfo49, point2D50, false);
        categoryPlot37.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass56 = numberAxis55.getClass();
        int int57 = categoryPlot37.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis55);
        boolean boolean58 = plotOrientation14.equals((java.lang.Object) categoryPlot37);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PlotOrientation.VERTICAL" + "'", str15.equals("PlotOrientation.VERTICAL"));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(categoryDataset31);
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNull(categoryItemRenderer47);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) 'a');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace33);
        boolean boolean35 = columnArrangement0.equals((java.lang.Object) axisSpace33);
        org.jfree.chart.ui.ProjectInfo projectInfo36 = org.jfree.chart.JFreeChart.INFO;
        projectInfo36.setCopyright("ThreadContext");
        boolean boolean39 = columnArrangement0.equals((java.lang.Object) projectInfo36);
        org.jfree.chart.ui.ProjectInfo projectInfo40 = org.jfree.chart.JFreeChart.INFO;
        projectInfo40.setCopyright("ThreadContext");
        projectInfo36.addLibrary((org.jfree.chart.ui.Library) projectInfo40);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(projectInfo36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(projectInfo40);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("", 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.data.time.DateRange dateRange6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range9 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange6, 90.0d, false);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range13 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange10, 90.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range9, (org.jfree.data.Range) dateRange10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint4.toRangeWidth((org.jfree.data.Range) dateRange10);
        dateAxis1.setRange((org.jfree.data.Range) dateRange10, true, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(dateRange6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        boolean boolean2 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight((double) (byte) 10);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        size2D4.height = (byte) 0;
        double double7 = size2D4.width;
        org.jfree.chart.util.Size2D size2D8 = rectangleConstraint0.calculateConstrainedSize(size2D4);
        java.lang.Object obj9 = size2D8.clone();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.jfree.chart.LegendItem legendItem2 = null;
        legendItemCollection0.add(legendItem2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        piePlot3D5.setBackgroundImageAlignment((int) 'a');
        boolean boolean11 = piePlot3D5.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        boolean boolean24 = piePlot3D5.equals((java.lang.Object) piePlot3D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D12, (java.lang.Integer) 4, plotRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = piePlotState27.getPieArea();
        piePlotState27.setTotal(0.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertNull(rectangle2D28);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range3 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange0, 90.0d, false);
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.data.Range range7 = org.jfree.data.Range.shift((org.jfree.data.Range) dateRange4, 90.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range3, (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        double double10 = rectangleConstraint9.getHeight();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine4 = textBlock3.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textBlock3.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) verticalAlignment7);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment7, (double) (short) -1, 0.05d);
        blockContainer2.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        boolean boolean15 = blockContainer2.equals((java.lang.Object) boolean14);
        org.jfree.chart.block.Arrangement arrangement16 = blockContainer2.getArrangement();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str19 = standardPieSectionLabelGenerator18.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator21 = piePlot3D20.getLabelGenerator();
        piePlot3D20.setShadowYOffset((double) (short) 1);
        piePlot3D20.setIgnoreZeroValues(false);
        boolean boolean26 = standardPieSectionLabelGenerator18.equals((java.lang.Object) piePlot3D20);
        java.awt.Font font27 = piePlot3D20.getNoDataMessageFont();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor28 = piePlot3D20.getLabelDistributor();
        boolean boolean29 = blockContainer2.equals((java.lang.Object) piePlot3D20);
        org.junit.Assert.assertNull(textLine4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(arrangement16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine2 = textBlock1.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock1.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean6 = rectangleEdge4.equals((java.lang.Object) verticalAlignment5);
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment5, (double) (short) -1, 0.05d);
        boolean boolean10 = textTitle0.equals((java.lang.Object) 0.05d);
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D11.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color13);
        java.awt.Stroke stroke16 = piePlot3D11.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double17 = piePlot3D11.getInteriorGap();
        piePlot3D11.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        piePlot3D11.axisChanged(axisChangeEvent20);
        java.awt.Font font22 = piePlot3D11.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        piePlot3D11.setDataset(pieDataset23);
        boolean boolean25 = piePlot3D11.getLabelLinksVisible();
        boolean boolean26 = textTitle0.equals((java.lang.Object) piePlot3D11);
        java.lang.Object obj27 = textTitle0.clone();
        textTitle0.setToolTipText("java.awt.Color[r=255,g=255,b=255]");
        org.junit.Assert.assertNull(textLine2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.08d + "'", double17 == 0.08d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D1.setAxisLinePaint((java.awt.Paint) color4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        java.awt.Color color15 = color8.brighter();
        float[] floatArray19 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray20 = color15.getColorComponents(floatArray19);
        float[] floatArray21 = color7.getColorComponents(floatArray20);
        float[] floatArray22 = color6.getColorComponents(floatArray21);
        try {
            float[] floatArray23 = color4.getComponents(floatArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace33);
        boolean boolean35 = columnArrangement0.equals((java.lang.Object) axisSpace33);
        org.jfree.chart.ui.ProjectInfo projectInfo36 = org.jfree.chart.JFreeChart.INFO;
        projectInfo36.setCopyright("ThreadContext");
        boolean boolean39 = columnArrangement0.equals((java.lang.Object) projectInfo36);
        java.lang.String str40 = projectInfo36.toString();
        java.lang.String str41 = projectInfo36.getInfo();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(projectInfo36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str41.equals("http://www.jfree.org/jfreechart/index.html"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        double double16 = piePlot3D0.getExplodePercent((java.lang.Comparable) "TextAnchor.TOP_RIGHT");
        java.lang.String str17 = piePlot3D0.getPlotType();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Pie 3D Plot" + "'", str17.equals("Pie 3D Plot"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot21.getRangeAxisForDataset((int) 'a');
        double double24 = valueAxis23.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.05d + "'", double24 == 1.05d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        boolean boolean11 = xYPlot5.isRangeZoomable();
        xYPlot5.clearRangeMarkers((int) (byte) 1);
        xYPlot5.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        boolean boolean2 = ringPlot0.getLabelLinksVisible();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setCopyright("ThreadContext");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo8 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray9 = basicProjectInfo8.getLibraries();
        java.lang.String str10 = basicProjectInfo8.getCopyright();
        basicProjectInfo8.addOptionalLibrary("");
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo8);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(libraryArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot5.getIndexOf(xYItemRenderer18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot5.getLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot5.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer29);
        java.awt.Stroke stroke31 = xYPlot30.getRangeZeroBaselineStroke();
        java.awt.Color color32 = java.awt.Color.yellow;
        xYPlot30.setDomainGridlinePaint((java.awt.Paint) color32);
        xYPlot30.setDomainGridlinesVisible(false);
        java.awt.Paint paint36 = xYPlot30.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = null;
        java.awt.geom.Point2D point2D41 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D39, rectangleAnchor40);
        xYPlot30.zoomDomainAxes((double) (byte) 0, plotRenderingInfo38, point2D41, true);
        try {
            xYPlot5.zoomRangeAxes((double) 100.0f, (double) 52, plotRenderingInfo24, point2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (105.0) <= upper (54.6).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(point2D41);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setVisible(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        double double2 = piePlot3D0.getLabelGap();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        boolean boolean33 = categoryPlot21.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer38);
        xYPlot39.clearAnnotations();
        java.awt.Paint paint41 = xYPlot39.getRangeCrosshairPaint();
        categoryPlot21.setDomainGridlinePaint(paint41);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int46 = categoryAxis3D45.getCategoryLabelPositionOffset();
        categoryAxis3D45.setLabelURL("");
        categoryAxis3D45.setTickMarkInsideLength((float) (byte) 0);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D45);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot21.getDomainAxisEdge(500);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        categoryPlot21.configureDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        try {
            categoryPlot21.setRenderer((int) (short) -1, categoryItemRenderer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNull(legendItemCollection38);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        java.awt.Paint paint11 = xYPlot5.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer16);
        xYPlot17.clearAnnotations();
        java.awt.Paint paint19 = xYPlot17.getRangeCrosshairPaint();
        java.awt.Stroke stroke20 = xYPlot17.getDomainGridlineStroke();
        xYPlot5.setRangeGridlineStroke(stroke20);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYPlot5);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot5.setRangeGridlinePaint((java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot21.setInsets(rectangleInsets38);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        try {
            categoryPlot21.setRenderer((int) (byte) -1, categoryItemRenderer41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        double[] doubleArray49 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray55 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray56 = new double[][] { doubleArray49, doubleArray55 };
        org.jfree.data.category.CategoryDataset categoryDataset57 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray56);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D59 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D59, (org.jfree.chart.axis.ValueAxis) numberAxis61, categoryItemRenderer62);
        org.jfree.chart.util.SortOrder sortOrder64 = categoryPlot63.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D66 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D66.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color69 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D66.setAxisLinePaint((java.awt.Paint) color69);
        int int71 = categoryPlot63.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D66);
        org.jfree.chart.util.SortOrder sortOrder72 = categoryPlot63.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = categoryPlot63.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        java.awt.geom.Point2D point2D76 = null;
        categoryPlot63.zoomDomainAxes((double) 100.0f, plotRenderingInfo75, point2D76, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder79 = categoryPlot63.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot63.getDomainAxisEdge((int) ' ');
        java.util.List list82 = categoryPlot63.getCategories();
        try {
            jFreeChart36.setSubtitles(list82);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(categoryDataset57);
        org.junit.Assert.assertNotNull(sortOrder64);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertNotNull(sortOrder72);
        org.junit.Assert.assertNull(categoryItemRenderer73);
        org.junit.Assert.assertNotNull(datasetRenderingOrder79);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertNotNull(list82);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        numberAxis19.setLowerMargin(0.0d);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = xYPlot29.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis33);
        dateAxis33.setInverted(true);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis40, xYItemRenderer41);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot42.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        xYPlot42.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis46);
        double double48 = dateAxis46.getLowerMargin();
        org.jfree.data.time.DateRange dateRange50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType51 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange53 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType55 = rectangleConstraint54.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange50, lengthConstraintType51, 1.0E-8d, (org.jfree.data.Range) dateRange53, lengthConstraintType55);
        dateAxis46.setDefaultAutoRange((org.jfree.data.Range) dateRange53);
        dateAxis33.setRangeWithMargins((org.jfree.data.Range) dateRange53, true, true);
        boolean boolean63 = dateRange53.intersects((double) '4', 1.0E-5d);
        numberAxis19.setRange((org.jfree.data.Range) dateRange53);
        numberAxis19.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange50);
        org.junit.Assert.assertNotNull(lengthConstraintType51);
        org.junit.Assert.assertNotNull(dateRange53);
        org.junit.Assert.assertNotNull(rectangleConstraint54);
        org.junit.Assert.assertNotNull(lengthConstraintType55);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        boolean boolean9 = xYPlot5.isDomainZoomable();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = waferMapPlot2.getDataset();
        java.lang.String str4 = waferMapPlot2.getPlotType();
        org.jfree.data.general.WaferMapDataset waferMapDataset5 = null;
        waferMapPlot2.setDataset(waferMapDataset5);
        org.jfree.data.general.WaferMapDataset waferMapDataset7 = null;
        waferMapPlot2.setDataset(waferMapDataset7);
        org.junit.Assert.assertNull(waferMapDataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "WMAP_Plot" + "'", str4.equals("WMAP_Plot"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        double[] doubleArray30 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray36 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.jfree.data.category.CategoryDataset categoryDataset38 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D40, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer43);
        org.jfree.chart.util.SortOrder sortOrder45 = categoryPlot44.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D47 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D47.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D47.setAxisLinePaint((java.awt.Paint) color50);
        int int52 = categoryPlot44.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D47);
        org.jfree.chart.util.SortOrder sortOrder53 = categoryPlot44.getColumnRenderingOrder();
        categoryPlot21.setColumnRenderingOrder(sortOrder53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = categoryPlot21.getRangeAxis(4);
        java.lang.String str57 = categoryPlot21.getPlotType();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(categoryDataset38);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(sortOrder53);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "Category Plot" + "'", str57.equals("Category Plot"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot3D0.setLabelLinkPaint(paint4);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        piePlot3D0.setToolTipGenerator(pieToolTipGenerator6);
        boolean boolean8 = piePlot3D0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle41.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = legendTitle41.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType49 = rectangleInsets48.getUnitType();
        double double51 = rectangleInsets48.calculateTopOutset((double) (byte) 10);
        double double53 = rectangleInsets48.calculateLeftOutset((double) 0L);
        double double55 = rectangleInsets48.calculateLeftInset(0.5d);
        legendTitle41.setItemLabelPadding(rectangleInsets48);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(unitType49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 10.0d + "'", double51 == 10.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-1.0d) + "'", double53 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + (-1.0d) + "'", double55 == (-1.0d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass11 = numberAxis10.getClass();
        numberAxis10.setVerticalTickLabels(true);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer18);
        numberAxis17.setVisible(true);
        numberAxis17.setLowerBound((double) 10.0f);
        float float24 = numberAxis17.getTickMarkOutsideLength();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot30.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        xYPlot30.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { numberAxis10, numberAxis17, dateAxis34 };
        xYPlot5.setRangeAxes(valueAxisArray36);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(valueAxisArray36);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint0.toFixedHeight((double) (byte) 10);
        org.jfree.chart.util.Size2D size2D4 = new org.jfree.chart.util.Size2D();
        size2D4.height = (byte) 0;
        double double7 = size2D4.width;
        org.jfree.chart.util.Size2D size2D8 = rectangleConstraint0.calculateConstrainedSize(size2D4);
        java.lang.String str9 = size2D8.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str9.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setSimpleLabels(false);
        boolean boolean6 = piePlot3D0.isCircular();
        piePlot3D0.setDarkerSides(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Size2D[width=0.0, height=0.0]", "java.awt.Color[r=255,g=255,b=255]", "RectangleEdge.LEFT", "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        piePlot3D0.setShadowYOffset(0.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        java.awt.Paint paint11 = xYPlot5.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer16);
        xYPlot17.clearAnnotations();
        java.awt.Paint paint19 = xYPlot17.getRangeCrosshairPaint();
        java.awt.Stroke stroke20 = xYPlot17.getDomainGridlineStroke();
        xYPlot5.setRangeGridlineStroke(stroke20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace22, false);
        xYPlot5.clearRangeAxes();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        piePlot3D5.setBackgroundImageAlignment((int) 'a');
        boolean boolean11 = piePlot3D5.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        boolean boolean24 = piePlot3D5.equals((java.lang.Object) piePlot3D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D12, (java.lang.Integer) 4, plotRenderingInfo26);
        java.awt.Color color28 = java.awt.Color.yellow;
        ringPlot0.setSeparatorPaint((java.awt.Paint) color28);
        ringPlot0.setExplodePercent((java.lang.Comparable) 0L, 1.0E-8d);
        boolean boolean33 = ringPlot0.getIgnoreNullValues();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        piePlot3D5.setBackgroundImageAlignment((int) 'a');
        boolean boolean11 = piePlot3D5.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        boolean boolean24 = piePlot3D5.equals((java.lang.Object) piePlot3D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D12, (java.lang.Integer) 4, plotRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        piePlotState27.setPieArea(rectangle2D28);
        piePlotState27.setPieWRadius(1.0E-8d);
        double double32 = piePlotState27.getLatestAngle();
        double double33 = piePlotState27.getLatestAngle();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 90.0d + "'", double32 == 90.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass11 = numberAxis10.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass15 = numberAxis14.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis14.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit16);
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit16);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        polarPlot0.setRenderer(polarItemRenderer19);
        java.lang.String str21 = polarPlot0.getPlotType();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Polar Plot" + "'", str21.equals("Polar Plot"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass10 = numberAxis9.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis9.getTickUnit();
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit11);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        polarPlot0.setRenderer(polarItemRenderer13);
        java.awt.Color color15 = java.awt.Color.white;
        float[] floatArray16 = null;
        float[] floatArray17 = color15.getRGBColorComponents(floatArray16);
        java.lang.String str18 = color15.toString();
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.TickUnit tickUnit20 = null;
        try {
            polarPlot0.setAngleTickUnit(tickUnit20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str18.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.util.List list6 = xYPlot5.getAnnotations();
        xYPlot5.configureRangeAxes();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot21.getRangeAxisLocation(0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart36.getCategoryPlot();
        jFreeChart36.setBackgroundImageAlignment((int) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(categoryPlot40);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(100);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D1, jFreeChart2);
        float float4 = categoryAxis3D1.getMaximumCategoryLabelWidthRatio();
        java.lang.Object obj5 = categoryAxis3D1.clone();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        double double4 = piePlot3D0.getLabelLinkMargin();
        org.jfree.chart.util.Rotation rotation5 = piePlot3D0.getDirection();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Paint paint11 = dateAxis9.getLabelPaint();
        java.util.TimeZone timeZone12 = null;
        try {
            dateAxis9.setTimeZone(timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock1.getLineAlignment();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        java.awt.Stroke stroke10 = piePlot3D5.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double11 = piePlot3D5.getInteriorGap();
        piePlot3D5.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot3D5.axisChanged(axisChangeEvent14);
        java.awt.Font font16 = piePlot3D5.getLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.Color color24 = color17.brighter();
        float[] floatArray28 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray29 = color24.getColorComponents(floatArray28);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("VerticalAlignment.TOP", font16, (java.awt.Paint) color24, 0.0f);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_YELLOW;
        textBlock1.addLine("ThreadContext", font16, (java.awt.Paint) color32);
        double[] doubleArray41 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray47 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer54);
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot55.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D58.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D58.setAxisLinePaint((java.awt.Paint) color61);
        int int63 = categoryPlot55.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D58);
        org.jfree.chart.util.SortOrder sortOrder64 = categoryPlot55.getColumnRenderingOrder();
        categoryPlot55.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        categoryPlot55.rendererChanged(rendererChangeEvent67);
        boolean boolean69 = categoryPlot55.isRangeCrosshairVisible();
        float float70 = categoryPlot55.getBackgroundAlpha();
        categoryPlot55.setDrawSharedDomainAxis(false);
        org.jfree.chart.JFreeChart jFreeChart74 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font16, (org.jfree.chart.plot.Plot) categoryPlot55, false);
        org.jfree.chart.ui.ProjectInfo projectInfo75 = org.jfree.chart.JFreeChart.INFO;
        projectInfo75.setCopyright("{0}");
        java.awt.Image image78 = projectInfo75.getLogo();
        jFreeChart74.setBackgroundImage(image78);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(sortOrder56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(sortOrder64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(projectInfo75);
        org.junit.Assert.assertNotNull(image78);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.setInverted(true);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer17);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot18.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        xYPlot18.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        double double24 = dateAxis22.getLowerMargin();
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType27 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange29 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType31 = rectangleConstraint30.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange26, lengthConstraintType27, 1.0E-8d, (org.jfree.data.Range) dateRange29, lengthConstraintType31);
        dateAxis22.setDefaultAutoRange((org.jfree.data.Range) dateRange29);
        dateAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange29, true, true);
        org.jfree.data.Range range37 = dateAxis9.getRange();
        double double38 = range37.getLength();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(dateRange26);
        org.junit.Assert.assertNotNull(lengthConstraintType27);
        org.junit.Assert.assertNotNull(dateRange29);
        org.junit.Assert.assertNotNull(rectangleConstraint30);
        org.junit.Assert.assertNotNull(lengthConstraintType31);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.1d + "'", double38 == 1.1d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.configure();
        org.jfree.chart.axis.Timeline timeline12 = dateAxis9.getTimeline();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(timeline12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color3.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.Color color10 = color3.brighter();
        float[] floatArray14 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray15 = color10.getColorComponents(floatArray14);
        float[] floatArray16 = color2.getColorComponents(floatArray15);
        try {
            float[] floatArray17 = color0.getComponents(colorSpace1, floatArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        jFreeChart36.setBorderVisible(true);
        jFreeChart36.fireChartChanged();
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart36.createBufferedImage((int) (byte) 10, 4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(bufferedImage45);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Paint paint11 = dateAxis9.getLabelPaint();
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine13 = textBlock12.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = textBlock12.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean17 = rectangleEdge15.equals((java.lang.Object) verticalAlignment16);
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment16, (double) (short) -1, 0.05d);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo26 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray27 = basicProjectInfo26.getLibraries();
        java.lang.String str28 = basicProjectInfo26.getCopyright();
        java.lang.String str29 = basicProjectInfo26.getCopyright();
        boolean boolean30 = flowArrangement20.equals((java.lang.Object) str29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot36.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        xYPlot36.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis40);
        dateAxis40.setInverted(true);
        boolean boolean44 = flowArrangement20.equals((java.lang.Object) dateAxis40);
        org.jfree.chart.axis.DateTickUnit dateTickUnit45 = dateAxis40.getTickUnit();
        dateAxis9.setTickUnit(dateTickUnit45);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(textLine13);
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(libraryArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTickUnit45);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis(4);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxis(255);
        categoryPlot21.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNull(categoryAxis26);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot14.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        dateAxis18.setInverted(true);
        org.jfree.data.Range range22 = xYPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.lang.Object obj23 = dateAxis18.clone();
        double double24 = dateAxis18.getUpperBound();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot5 = piePlot3D1.getParent();
        boolean boolean6 = textBlockAnchor0.equals((java.lang.Object) plot5);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3D7.getLabelGenerator();
        piePlot3D7.setShadowYOffset((double) (short) 1);
        piePlot3D7.setIgnoreZeroValues(false);
        java.lang.String str13 = piePlot3D7.getNoDataMessage();
        boolean boolean14 = textBlockAnchor0.equals((java.lang.Object) piePlot3D7);
        piePlot3D7.setIgnoreZeroValues(true);
        java.awt.Color color17 = java.awt.Color.green;
        piePlot3D7.setLabelLinkPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(plot5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { 52, 1.0f, 4, (short) 100 };
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { false, (-1.0d), 'a', '4', "RectangleAnchor.BOTTOM_LEFT" };
        double[] doubleArray18 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray24 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray25 = new double[][] { doubleArray18, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray25);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray4, comparableArray10, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray4);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TextAnchor.TOP_RIGHT", graphics2D1, 0.0f, (float) '4', textAnchor4, (double) 1L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        double double6 = rectangleInsets4.calculateLeftOutset((double) (short) 100);
        double double8 = rectangleInsets4.calculateRightInset(0.12d);
        double double10 = rectangleInsets4.calculateLeftInset((double) 52);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.4d + "'", double8 == 0.4d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint2 = ringPlot1.getSeparatorPaint();
        boolean boolean3 = ringPlot0.equals((java.lang.Object) ringPlot1);
        boolean boolean4 = ringPlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer13);
        java.awt.Stroke stroke15 = xYPlot14.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double19 = numberAxis18.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis18.setRangeWithMargins((org.jfree.data.Range) dateRange20);
        xYPlot14.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot14.getOrientation();
        java.lang.String str24 = plotOrientation23.toString();
        xYPlot5.setOrientation(plotOrientation23);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-8d + "'", double19 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "PlotOrientation.VERTICAL" + "'", str24.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock0.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textBlock0.getLineAlignment();
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine5 = textBlock4.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock4.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean9 = rectangleEdge7.equals((java.lang.Object) verticalAlignment8);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment8, (double) (short) -1, 0.05d);
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment8, (double) 4, (double) (short) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) 52, (double) (short) -1);
        boolean boolean19 = flowArrangement15.equals((java.lang.Object) 52);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNull(textLine5);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(verticalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot22.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot22.zoomDomainAxes((double) 100.0f, plotRenderingInfo34, point2D35, false);
        categoryPlot22.configureDomainAxes();
        java.util.List list39 = categoryPlot22.getCategories();
        boolean boolean40 = standardPieSectionLabelGenerator0.equals((java.lang.Object) categoryPlot22);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertNotNull(list39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        java.lang.Object obj5 = chartEntity4.clone();
        java.lang.String str6 = chartEntity4.getShapeCoords();
        java.lang.String str7 = chartEntity4.getShapeCoords();
        java.lang.Object obj8 = chartEntity4.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-3,-3,3,3" + "'", str6.equals("-3,-3,3,3"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-3,-3,3,3" + "'", str7.equals("-3,-3,3,3"));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double3 = numberAxis2.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis2.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange7, lengthConstraintType8, 1.0E-8d, (org.jfree.data.Range) dateRange10, lengthConstraintType12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, (org.jfree.data.Range) dateRange7);
        boolean boolean18 = dateRange7.intersects(0.6249999999999999d, (-109.5d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        jFreeChart36.setBorderVisible(true);
        jFreeChart36.fireChartChanged();
        jFreeChart36.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        java.awt.image.BufferedImage bufferedImage50 = jFreeChart36.createBufferedImage(255, (int) (byte) 10, 1.0d, (double) 'a', chartRenderingInfo49);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(bufferedImage50);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock1.getLineAlignment();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        java.awt.Stroke stroke10 = piePlot3D5.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double11 = piePlot3D5.getInteriorGap();
        piePlot3D5.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot3D5.axisChanged(axisChangeEvent14);
        java.awt.Font font16 = piePlot3D5.getLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.Color color24 = color17.brighter();
        float[] floatArray28 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray29 = color24.getColorComponents(floatArray28);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("VerticalAlignment.TOP", font16, (java.awt.Paint) color24, 0.0f);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_YELLOW;
        textBlock1.addLine("ThreadContext", font16, (java.awt.Paint) color32);
        double[] doubleArray41 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray47 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer54);
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot55.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D58.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D58.setAxisLinePaint((java.awt.Paint) color61);
        int int63 = categoryPlot55.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D58);
        org.jfree.chart.util.SortOrder sortOrder64 = categoryPlot55.getColumnRenderingOrder();
        categoryPlot55.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        categoryPlot55.rendererChanged(rendererChangeEvent67);
        boolean boolean69 = categoryPlot55.isRangeCrosshairVisible();
        float float70 = categoryPlot55.getBackgroundAlpha();
        categoryPlot55.setDrawSharedDomainAxis(false);
        org.jfree.chart.JFreeChart jFreeChart74 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font16, (org.jfree.chart.plot.Plot) categoryPlot55, false);
        java.awt.Stroke stroke75 = categoryPlot55.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(sortOrder56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(sortOrder64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        textTitle1.setID("ThreadContext");
        boolean boolean9 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        piePlot3D5.setBackgroundImageAlignment((int) 'a');
        boolean boolean11 = piePlot3D5.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        boolean boolean24 = piePlot3D5.equals((java.lang.Object) piePlot3D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D12, (java.lang.Integer) 4, plotRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        piePlotState27.setPieArea(rectangle2D28);
        piePlotState27.setPieWRadius(1.0E-8d);
        piePlotState27.setPassesRequired((int) (byte) 1);
        double double34 = piePlotState27.getPieHRadius();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis9.lengthToJava2D((double) (-1L), rectangle2D15, rectangleEdge16);
        java.awt.Font font18 = numberAxis9.getTickLabelFont();
        float float19 = numberAxis9.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        boolean boolean3 = objectList1.equals((java.lang.Object) 1.0d);
        objectList1.clear();
        int int5 = objectList1.size();
        java.lang.Object obj6 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = xYPlot5.getFixedLegendItems();
        java.awt.Paint paint9 = xYPlot5.getDomainGridlinePaint();
        java.lang.Object obj10 = xYPlot5.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str1.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = textBlock0.equals((java.lang.Object) lineBorder1);
        double[] doubleArray10 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray16 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray17);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer23);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot24.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D27.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D27.setAxisLinePaint((java.awt.Paint) color30);
        int int32 = categoryPlot24.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D27);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot24.getColumnRenderingOrder();
        categoryPlot24.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent36 = null;
        categoryPlot24.rendererChanged(rendererChangeEvent36);
        boolean boolean38 = categoryPlot24.isRangeCrosshairVisible();
        float float39 = categoryPlot24.getBackgroundAlpha();
        categoryPlot24.setDrawSharedDomainAxis(false);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis45, xYItemRenderer46);
        java.awt.Stroke stroke48 = xYPlot47.getRangeZeroBaselineStroke();
        java.awt.Color color49 = java.awt.Color.yellow;
        xYPlot47.setDomainGridlinePaint((java.awt.Paint) color49);
        double[] doubleArray59 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray65 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray66 = new double[][] { doubleArray59, doubleArray65 };
        org.jfree.data.category.CategoryDataset categoryDataset67 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray66);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D69 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer72 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot(categoryDataset67, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D69, (org.jfree.chart.axis.ValueAxis) numberAxis71, categoryItemRenderer72);
        org.jfree.chart.axis.TickUnitSource tickUnitSource74 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        numberAxis71.setStandardTickUnits(tickUnitSource74);
        xYPlot47.setRangeAxis((int) (byte) 0, (org.jfree.chart.axis.ValueAxis) numberAxis71);
        int int77 = categoryPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis71);
        boolean boolean78 = lineBorder1.equals((java.lang.Object) int77);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(categoryDataset67);
        org.junit.Assert.assertNotNull(tickUnitSource74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1) + "'", int77 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.axis.AxisSpace axisSpace14 = xYPlot5.getFixedDomainAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot5.setDataset(xYDataset15);
        double[] doubleArray25 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray31 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray32);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D35, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer38);
        org.jfree.chart.util.SortOrder sortOrder40 = categoryPlot39.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D42 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D42.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D42.setAxisLinePaint((java.awt.Paint) color45);
        int int47 = categoryPlot39.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D42);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot39.getDomainAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker50.setLabelTextAnchor(textAnchor51);
        org.jfree.chart.util.Layer layer53 = null;
        boolean boolean54 = categoryPlot39.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker50, layer53);
        org.jfree.chart.util.Layer layer55 = null;
        xYPlot5.addRangeMarker(500, (org.jfree.chart.plot.Marker) valueMarker50, layer55);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(sortOrder40);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot21.getRangeMarkers(1, layer33);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot21.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color1.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        java.awt.Color color8 = color1.brighter();
        float[] floatArray12 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray13 = color8.getColorComponents(floatArray12);
        float[] floatArray14 = color0.getColorComponents(floatArray13);
        java.awt.color.ColorSpace colorSpace15 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(colorSpace15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getLibraries();
        java.lang.String str7 = basicProjectInfo5.getCopyright();
        java.lang.String str8 = basicProjectInfo5.getCopyright();
        java.lang.String str9 = basicProjectInfo5.getCopyright();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLabelGenerator();
        piePlot3D1.setShadowYOffset((double) (short) 1);
        piePlot3D1.setSimpleLabels(false);
        java.awt.Font font7 = piePlot3D1.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextFragment textFragment9 = textLine8.getLastTextFragment();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textFragment9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        double double1 = size2D0.getWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        piePlot3D5.setBackgroundImageAlignment((int) 'a');
        boolean boolean11 = piePlot3D5.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        boolean boolean24 = piePlot3D5.equals((java.lang.Object) piePlot3D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = ringPlot0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.PiePlot) piePlot3D12, (java.lang.Integer) 4, plotRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = piePlotState27.getPieArea();
        double double29 = piePlotState27.getTotal();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot21.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot21.getRenderer();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNull(categoryItemRenderer38);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = textBlock0.calculateDimensions(graphics2D2);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(size2D3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot21.clearRangeAxes();
        double double43 = categoryPlot21.getRangeCrosshairValue();
        double[] doubleArray51 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray57 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray58 = new double[][] { doubleArray51, doubleArray57 };
        org.jfree.data.category.CategoryDataset categoryDataset59 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray58);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D61, (org.jfree.chart.axis.ValueAxis) numberAxis63, categoryItemRenderer64);
        org.jfree.chart.util.SortOrder sortOrder66 = categoryPlot65.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D68 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D68.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D68.setAxisLinePaint((java.awt.Paint) color71);
        int int73 = categoryPlot65.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D68);
        double double74 = categoryAxis3D68.getLabelAngle();
        categoryAxis3D68.setCategoryLabelPositionOffset((int) '#');
        java.util.List list77 = categoryPlot21.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D68);
        boolean boolean78 = categoryAxis3D68.isTickMarksVisible();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(categoryDataset59);
        org.junit.Assert.assertNotNull(sortOrder66);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(list77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock1.getLineAlignment();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        java.awt.Stroke stroke10 = piePlot3D5.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double11 = piePlot3D5.getInteriorGap();
        piePlot3D5.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot3D5.axisChanged(axisChangeEvent14);
        java.awt.Font font16 = piePlot3D5.getLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.Color color24 = color17.brighter();
        float[] floatArray28 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray29 = color24.getColorComponents(floatArray28);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("VerticalAlignment.TOP", font16, (java.awt.Paint) color24, 0.0f);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_YELLOW;
        textBlock1.addLine("ThreadContext", font16, (java.awt.Paint) color32);
        double[] doubleArray41 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray47 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer54);
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot55.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D58.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D58.setAxisLinePaint((java.awt.Paint) color61);
        int int63 = categoryPlot55.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D58);
        org.jfree.chart.util.SortOrder sortOrder64 = categoryPlot55.getColumnRenderingOrder();
        categoryPlot55.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        categoryPlot55.rendererChanged(rendererChangeEvent67);
        boolean boolean69 = categoryPlot55.isRangeCrosshairVisible();
        float float70 = categoryPlot55.getBackgroundAlpha();
        categoryPlot55.setDrawSharedDomainAxis(false);
        org.jfree.chart.JFreeChart jFreeChart74 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font16, (org.jfree.chart.plot.Plot) categoryPlot55, false);
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot();
        polarPlot75.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        java.awt.geom.Point2D point2D81 = null;
        polarPlot75.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo80, point2D81);
        org.jfree.chart.axis.NumberAxis numberAxis84 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass85 = numberAxis84.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit86 = numberAxis84.getTickUnit();
        polarPlot75.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit86);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer88 = null;
        polarPlot75.setRenderer(polarItemRenderer88);
        boolean boolean90 = categoryPlot55.equals((java.lang.Object) polarPlot75);
        polarPlot75.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(sortOrder56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(sortOrder64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(wildcardClass85);
        org.junit.Assert.assertNotNull(numberTickUnit86);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        java.awt.Font font7 = textTitle1.getFont();
        org.jfree.chart.block.BlockFrame blockFrame8 = textTitle1.getFrame();
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(blockFrame8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass10 = numberAxis9.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis9.getTickUnit();
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        polarPlot0.zoomDomainAxes(2.0d, (-1.0d), plotRenderingInfo15, point2D16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        polarPlot0.setDataset(xYDataset18);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        double double30 = categoryAxis3D24.getLabelAngle();
        categoryAxis3D24.setVisible(false);
        categoryAxis3D24.setLabel("LengthConstraintType.NONE");
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer10);
        java.util.List list12 = xYPlot11.getAnnotations();
        xYPlot11.setDomainCrosshairVisible(false);
        boolean boolean15 = xYPlot5.equals((java.lang.Object) xYPlot11);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment21 = textLine20.getLastTextFragment();
        java.awt.Paint paint22 = textFragment21.getPaint();
        valueMarker17.setLabelPaint(paint22);
        xYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.Plot plot25 = xYPlot5.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Stroke stroke28 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        valueMarker27.setStroke(stroke28);
        boolean boolean30 = xYPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(textFragment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot5.getRangeAxis();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(valueAxis9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "PlotOrientation.VERTICAL", (org.jfree.data.KeyedValues) pieDataset24);
        double double26 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset24);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(pieDataset24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 164.0d + "'", double26 == 164.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        objectList1.set(0, (java.lang.Object) paint3);
        int int5 = objectList1.size();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        java.lang.String str12 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset10, (java.lang.Comparable) 1);
        double[] doubleArray20 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray26 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray27);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D30 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D30, (org.jfree.chart.axis.ValueAxis) numberAxis32, categoryItemRenderer33);
        org.jfree.data.general.PieDataset pieDataset36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset28, 0);
        double double37 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset36);
        try {
            java.lang.String str39 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset36, (java.lang.Comparable) 52);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Key not found: 52");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(pieDataset36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 164.0d + "'", double37 == 164.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint3);
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextStroke();
        java.awt.Shape shape8 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape9 = defaultDrawingSupplier6.getNextShape();
        piePlot3D0.setLegendItemShape(shape9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3D0);
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        polarPlot12.removeCornerTextItem("");
        java.awt.Paint paint15 = polarPlot12.getRadiusGridlinePaint();
        java.awt.Paint paint16 = polarPlot12.getAngleLabelPaint();
        piePlot3D0.setShadowPaint(paint16);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        java.awt.Image image39 = jFreeChart36.getBackgroundImage();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNull(image39);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        double double27 = rectangleInsets19.trimHeight(0.5d);
        double double29 = rectangleInsets19.trimWidth((double) 500);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-109.5d) + "'", double27 == (-109.5d));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 500.6d + "'", double29 == 500.6d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) (byte) -1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        pieLabelDistributor1.distributeLabels((double) 2.0f, 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape9 = textBlock0.calculateBounds(graphics2D2, (float) 1, 10.0f, textBlockAnchor5, 10.0f, 0.0f, 0.5d);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextStroke();
        java.awt.Shape shape13 = defaultDrawingSupplier11.getNextShape();
        xYPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11);
        boolean boolean15 = textBlockAnchor5.equals((java.lang.Object) defaultDrawingSupplier11);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock1.getLineAlignment();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        java.awt.Stroke stroke10 = piePlot3D5.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double11 = piePlot3D5.getInteriorGap();
        piePlot3D5.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot3D5.axisChanged(axisChangeEvent14);
        java.awt.Font font16 = piePlot3D5.getLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel18 = null;
        java.awt.Rectangle rectangle19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.AffineTransform affineTransform21 = null;
        java.awt.RenderingHints renderingHints22 = null;
        java.awt.PaintContext paintContext23 = color17.createContext(colorModel18, rectangle19, rectangle2D20, affineTransform21, renderingHints22);
        java.awt.Color color24 = color17.brighter();
        float[] floatArray28 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray29 = color24.getColorComponents(floatArray28);
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("VerticalAlignment.TOP", font16, (java.awt.Paint) color24, 0.0f);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_YELLOW;
        textBlock1.addLine("ThreadContext", font16, (java.awt.Paint) color32);
        double[] doubleArray41 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray47 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray48);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D51 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D51, (org.jfree.chart.axis.ValueAxis) numberAxis53, categoryItemRenderer54);
        org.jfree.chart.util.SortOrder sortOrder56 = categoryPlot55.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D58.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color61 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D58.setAxisLinePaint((java.awt.Paint) color61);
        int int63 = categoryPlot55.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D58);
        org.jfree.chart.util.SortOrder sortOrder64 = categoryPlot55.getColumnRenderingOrder();
        categoryPlot55.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        categoryPlot55.rendererChanged(rendererChangeEvent67);
        boolean boolean69 = categoryPlot55.isRangeCrosshairVisible();
        float float70 = categoryPlot55.getBackgroundAlpha();
        categoryPlot55.setDrawSharedDomainAxis(false);
        org.jfree.chart.JFreeChart jFreeChart74 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", font16, (org.jfree.chart.plot.Plot) categoryPlot55, false);
        org.jfree.chart.plot.Plot plot75 = jFreeChart74.getPlot();
        org.jfree.chart.title.TextTitle textTitle76 = jFreeChart74.getTitle();
        try {
            org.jfree.chart.title.Title title78 = jFreeChart74.getSubtitle((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintContext23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(sortOrder56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(sortOrder64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(plot75);
        org.junit.Assert.assertNotNull(textTitle76);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray42 = legendTitle41.getSources();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = null;
        legendTitle41.setLegendItemGraphicLocation(rectangleAnchor43);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(legendItemSourceArray42);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.clear();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        xYPlot5.rendererChanged(rendererChangeEvent8);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Image image37 = null;
        jFreeChart36.setBackgroundImage(image37);
        jFreeChart36.setTitle("ThreadContext");
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Stroke stroke43 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        valueMarker42.setStroke(stroke43);
        jFreeChart36.setBorderStroke(stroke43);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        pieLabelDistributor1.sort();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D1.setAxisLinePaint((java.awt.Paint) color4);
        float float6 = categoryAxis3D1.getTickMarkOutsideLength();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int9 = categoryAxis3D8.getCategoryLabelPositionOffset();
        categoryAxis3D8.setLabelURL("");
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D8.setLabelPaint(paint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D8.setTickLabelInsets(rectangleInsets18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.awt.geom.AffineTransform affineTransform24 = null;
        java.awt.RenderingHints renderingHints25 = null;
        java.awt.PaintContext paintContext26 = color20.createContext(colorModel21, rectangle22, rectangle2D23, affineTransform24, renderingHints25);
        categoryAxis3D8.setTickMarkPaint((java.awt.Paint) color20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = categoryAxis3D8.getCategoryLabelPositions();
        categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions28);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintContext26);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.block.LineBorder lineBorder1 = new org.jfree.chart.block.LineBorder();
        boolean boolean2 = textBlock0.equals((java.lang.Object) lineBorder1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            lineBorder1.draw(graphics2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.awt.Paint paint21 = xYPlot5.getRangeZeroBaselinePaint();
        java.awt.Color color22 = java.awt.Color.magenta;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.CrosshairState crosshairState28 = null;
        boolean boolean29 = xYPlot5.render(graphics2D24, rectangle2D25, 500, plotRenderingInfo27, crosshairState28);
        java.awt.Stroke stroke30 = xYPlot5.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        categoryPlot21.mapDatasetToRangeAxis(1, (int) (byte) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot21.getRangeAxisEdge((int) '4');
        java.awt.Paint paint45 = categoryPlot21.getOutlinePaint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        java.awt.Stroke stroke8 = xYPlot5.getDomainGridlineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot5.setDomainAxisLocation((int) (short) 1, axisLocation10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = xYPlot5.getInsets();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int15 = categoryAxis3D14.getCategoryLabelPositionOffset();
        categoryAxis3D14.setLabelURL("");
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D14.setLabelPaint(paint18);
        java.awt.Stroke stroke20 = categoryAxis3D14.getAxisLineStroke();
        xYPlot5.setRangeGridlineStroke(stroke20);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange3);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNull(markerAxisBand5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("");
        double double3 = textTitle0.getHeight();
        java.lang.Object obj4 = textTitle0.clone();
        java.lang.String str5 = textTitle0.getText();
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        boolean boolean7 = textTitle0.equals((java.lang.Object) textBlock6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        textBlock6.draw(graphics2D8, (float) (byte) 100, (float) 2, textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getLibraries();
        java.lang.String str7 = basicProjectInfo5.getCopyright();
        basicProjectInfo5.addOptionalLibrary("");
        java.lang.String str10 = basicProjectInfo5.getLicenceName();
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "VerticalAlignment.TOP" + "'", str10.equals("VerticalAlignment.TOP"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("{0}");
        java.lang.String str2 = textFragment1.getText();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("", font9);
        org.jfree.chart.text.TextFragment textFragment11 = textLine10.getLastTextFragment();
        java.awt.Paint paint12 = textFragment11.getPaint();
        valueMarker7.setLabelPaint(paint12);
        org.jfree.chart.text.TextAnchor textAnchor14 = valueMarker7.getLabelTextAnchor();
        try {
            textFragment1.draw(graphics2D3, (float) 0L, 0.0f, textAnchor14, 100.0f, (float) 'a', (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(textFragment11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray42 = legendTitle41.getSources();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = legendTitle41.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(legendItemSourceArray42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        jFreeChart36.fireChartChanged();
        boolean boolean41 = jFreeChart36.isBorderVisible();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D1, jFreeChart2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        java.awt.Color color11 = color4.brighter();
        categoryAxis3D1.setTickLabelPaint((java.awt.Paint) color4);
        java.awt.Paint paint13 = categoryAxis3D1.getTickLabelPaint();
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        java.awt.Font font11 = piePlot3D0.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        piePlot3D0.setDataset(pieDataset12);
        java.awt.Paint paint14 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets19.getUnitType();
        double double22 = rectangleInsets19.calculateTopOutset((double) (byte) 10);
        double double24 = rectangleInsets19.calculateLeftOutset((double) 0L);
        piePlot3D0.setLabelPadding(rectangleInsets19);
        double double27 = rectangleInsets19.trimHeight(0.5d);
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets19.getUnitType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets19);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-1.0d) + "'", double24 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-109.5d) + "'", double27 == (-109.5d));
        org.junit.Assert.assertNotNull(unitType28);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        jFreeChart36.setBorderVisible(true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass4 = numberAxis3.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis3.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass8 = numberAxis7.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis7.getTickUnit();
        numberAxis3.setTickUnit(numberTickUnit9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Color color19 = color12.brighter();
        float[] floatArray23 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray24 = color19.getColorComponents(floatArray23);
        float[] floatArray25 = color11.getColorComponents(floatArray24);
        ringPlot1.setSectionPaint((java.lang.Comparable) numberTickUnit9, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = jFreeChart36.getPadding();
        org.jfree.chart.event.ChartProgressListener chartProgressListener40 = null;
        jFreeChart36.removeProgressListener(chartProgressListener40);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Size2D[width=0.0, height=0.0]", "hi!", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("LengthConstraintType.NONE");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType47 = rectangleInsets46.getUnitType();
        double double49 = rectangleInsets46.calculateTopOutset((double) (byte) 10);
        double double50 = rectangleInsets46.getLeft();
        legendTitle41.setLegendItemGraphicPadding(rectangleInsets46);
        org.jfree.chart.ui.ProjectInfo projectInfo52 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset53, valueAxis54, (org.jfree.chart.axis.ValueAxis) numberAxis56, xYItemRenderer57);
        java.util.List list59 = xYPlot58.getAnnotations();
        java.util.Collection collection60 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list59);
        projectInfo52.setContributors(list59);
        boolean boolean62 = legendTitle41.equals((java.lang.Object) list59);
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.data.Range range65 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint(0.0d, range65);
        java.lang.String str67 = rectangleConstraint66.toString();
        org.jfree.chart.util.Size2D size2D68 = legendTitle41.arrange(graphics2D63, rectangleConstraint66);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        legendTitle41.setLegendItemGraphicLocation(rectangleAnchor69);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(unitType47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 10.0d + "'", double49 == 10.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-1.0d) + "'", double50 == (-1.0d));
        org.junit.Assert.assertNotNull(projectInfo52);
        org.junit.Assert.assertNotNull(list59);
        org.junit.Assert.assertNotNull(collection60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]" + "'", str67.equals("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(size2D68);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot5.getIndexOf(xYItemRenderer18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color21.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        java.awt.Color color28 = color21.brighter();
        float[] floatArray32 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray33 = color28.getColorComponents(floatArray32);
        float[] floatArray34 = color20.getColorComponents(floatArray33);
        xYPlot5.setRangeZeroBaselinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass11 = numberAxis10.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis10.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass15 = numberAxis14.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis14.getTickUnit();
        numberAxis10.setTickUnit(numberTickUnit16);
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit16);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        polarPlot0.setRenderer(polarItemRenderer19);
        org.jfree.chart.plot.RingPlot ringPlot21 = new org.jfree.chart.plot.RingPlot();
        boolean boolean22 = polarPlot0.equals((java.lang.Object) ringPlot21);
        double double23 = ringPlot21.getSectionDepth();
        boolean boolean24 = ringPlot21.getSeparatorsVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.2d + "'", double23 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "ThreadContext");
        java.lang.String str5 = chartEntity4.getToolTipText();
        java.lang.Object obj6 = chartEntity4.clone();
        java.awt.Shape shape7 = chartEntity4.getArea();
        java.awt.Shape shape8 = chartEntity4.getArea();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray9 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray15 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray9, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D26.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D26.setAxisLinePaint((java.awt.Paint) color29);
        int int31 = categoryPlot23.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D26);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot23.getColumnRenderingOrder();
        categoryPlot23.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot23.setFixedDomainAxisSpace(axisSpace34);
        boolean boolean36 = columnArrangement1.equals((java.lang.Object) axisSpace34);
        org.jfree.chart.ui.ProjectInfo projectInfo37 = org.jfree.chart.JFreeChart.INFO;
        projectInfo37.setCopyright("ThreadContext");
        boolean boolean40 = columnArrangement1.equals((java.lang.Object) projectInfo37);
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo37);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(projectInfo37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setText("");
        java.lang.String str4 = textTitle1.getURLText();
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.lang.String str6 = verticalAlignment5.toString();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean8 = verticalAlignment5.equals((java.lang.Object) color7);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color7);
        textTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder9);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(verticalAlignment5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "VerticalAlignment.TOP" + "'", str6.equals("VerticalAlignment.TOP"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot3D3.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator11 = null;
        piePlot3D3.setToolTipGenerator(pieToolTipGenerator11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(pieURLGenerator10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        xYPlot5.setDomainCrosshairValue((double) 1L, true);
        int int10 = xYPlot5.getDatasetCount();
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D11.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color13);
        piePlot3D11.setBackgroundImageAlignment((int) 'a');
        boolean boolean17 = piePlot3D11.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D18 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D18.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color20);
        java.awt.Stroke stroke23 = piePlot3D18.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double24 = piePlot3D18.getInteriorGap();
        piePlot3D18.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = null;
        piePlot3D18.axisChanged(axisChangeEvent27);
        java.awt.Font font29 = piePlot3D18.getLabelFont();
        boolean boolean30 = piePlot3D11.equals((java.lang.Object) piePlot3D18);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D33 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator34 = piePlot3D33.getLabelGenerator();
        piePlot3D33.setShadowYOffset((double) (short) 1);
        piePlot3D33.setIgnoreZeroValues(false);
        java.awt.Font font39 = piePlot3D33.getLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.plot.PiePlotState piePlotState42 = piePlot3D11.initialise(graphics2D31, rectangle2D32, (org.jfree.chart.plot.PiePlot) piePlot3D33, (java.lang.Integer) 2, plotRenderingInfo41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer47);
        xYPlot48.clearAnnotations();
        java.awt.Paint paint50 = xYPlot48.getRangeCrosshairPaint();
        java.awt.Stroke stroke51 = xYPlot48.getDomainGridlineStroke();
        piePlot3D11.setLabelOutlineStroke(stroke51);
        xYPlot5.setDomainCrosshairStroke(stroke51);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.08d + "'", double24 == 0.08d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator34);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(piePlotState42);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer10);
        java.util.List list12 = xYPlot11.getAnnotations();
        xYPlot11.setDomainCrosshairVisible(false);
        boolean boolean15 = xYPlot5.equals((java.lang.Object) xYPlot11);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment21 = textLine20.getLastTextFragment();
        java.awt.Paint paint22 = textFragment21.getPaint();
        valueMarker17.setLabelPaint(paint22);
        xYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = valueMarker17.getLabelAnchor();
        java.lang.Object obj26 = valueMarker17.clone();
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(textFragment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextStroke();
        java.awt.Shape shape37 = defaultDrawingSupplier35.getNextShape();
        xYPlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        java.awt.Paint paint39 = defaultDrawingSupplier35.getNextOutlinePaint();
        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray9 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer8 };
        xYPlot5.setRenderers(xYItemRendererArray9);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot5);
        org.jfree.chart.plot.Plot plot12 = plotChangeEvent11.getPlot();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(xYItemRendererArray9);
        org.junit.Assert.assertNotNull(plot12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        java.lang.Object obj35 = categoryPlot21.clone();
        org.jfree.chart.plot.Marker marker36 = null;
        try {
            boolean boolean37 = categoryPlot21.removeRangeMarker(marker36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.data.KeyToGroupMap keyToGroupMap22 = null;
        try {
            org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, keyToGroupMap22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("XY Plot");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot21.getDomainAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker32.setLabelTextAnchor(textAnchor33);
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32, layer35);
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        valueMarker32.setLabelTextAnchor(textAnchor37);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(textAnchor37);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        java.awt.Paint paint3 = null;
        try {
            categoryAxis3D1.setAxisLinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = textTitle1.getHorizontalAlignment();
        java.lang.String str5 = textTitle1.getText();
        java.lang.Object obj6 = textTitle1.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Rotation.CLOCKWISE" + "'", str5.equals("Rotation.CLOCKWISE"));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = categoryPlot21.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot21.getRangeAxisEdge();
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot21.getRangeMarkers(layer37);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot21.getRangeMarkers(1, layer33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean39 = dateAxis37.isHiddenValue((long) (short) 100);
        java.awt.Shape shape40 = dateAxis37.getLeftArrow();
        int int41 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis37);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            categoryPlot21.drawBackground(graphics2D42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        java.awt.Paint paint6 = textFragment5.getPaint();
        valueMarker1.setLabelPaint(paint6);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = valueMarker1.getLabelAnchor();
        java.awt.Font font10 = valueMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        polarPlot0.setDataset(xYDataset9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot0.getLegendItems();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent23);
        java.awt.Paint paint25 = categoryPlot21.getRangeCrosshairPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot21);
        boolean boolean27 = categoryPlot21.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        xYPlot5.setDomainCrosshairValue((double) 1L, true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass12 = numberAxis11.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = numberAxis11.getTickUnit();
        int int14 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot5.zoomDomainAxes(1.0E-8d, plotRenderingInfo16, point2D17, false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis23, xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = xYPlot25.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        xYPlot25.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        dateAxis29.configure();
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis29);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str3 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        int int4 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color7);
        java.awt.Stroke stroke10 = piePlot3D5.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double11 = piePlot3D5.getInteriorGap();
        piePlot3D5.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        piePlot3D5.axisChanged(axisChangeEvent14);
        java.awt.Font font16 = piePlot3D5.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot3D5.setDataset(pieDataset17);
        boolean boolean19 = piePlot3D5.getLabelLinksVisible();
        org.jfree.chart.plot.PiePlot3D piePlot3D20 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D20.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color22);
        java.awt.Stroke stroke25 = piePlot3D20.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot3D20.setInsets(rectangleInsets26);
        org.jfree.chart.util.Rotation rotation28 = piePlot3D20.getDirection();
        piePlot3D5.setDirection(rotation28);
        categoryAxis3D1.setPlot((org.jfree.chart.plot.Plot) piePlot3D5);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D5.setShadowPaint((java.awt.Paint) color31);
        int int33 = color31.getBlue();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08d + "'", double11 == 0.08d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rotation28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 192 + "'", int33 == 192);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Stroke stroke4 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) (byte) 1);
        ringPlot0.setSectionDepth((double) (short) 1);
        double[] doubleArray15 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray21 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray22);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D25, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer28);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot29.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D32 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D32.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D32.setAxisLinePaint((java.awt.Paint) color35);
        int int37 = categoryPlot29.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D32);
        org.jfree.chart.util.SortOrder sortOrder38 = categoryPlot29.getColumnRenderingOrder();
        categoryPlot29.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        categoryPlot29.rendererChanged(rendererChangeEvent41);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot29);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.String str45 = chartChangeEventType44.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 1, jFreeChart43, chartChangeEventType44);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(sortOrder38);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str45.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot21.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer35);
        java.awt.Stroke stroke37 = xYPlot36.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation38 = xYPlot36.getRangeAxisLocation();
        java.awt.Paint paint39 = xYPlot36.getDomainCrosshairPaint();
        categoryPlot21.setDomainGridlinePaint(paint39);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine4 = textBlock3.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textBlock3.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean8 = rectangleEdge6.equals((java.lang.Object) verticalAlignment7);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment7, (double) (short) -1, 0.05d);
        blockContainer2.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement11);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        boolean boolean15 = blockContainer2.equals((java.lang.Object) boolean14);
        org.jfree.chart.block.Arrangement arrangement16 = blockContainer2.getArrangement();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            java.lang.Object obj20 = blockContainer2.draw(graphics2D17, rectangle2D18, (java.lang.Object) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(textLine4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(arrangement16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot5.getIndexOf(xYItemRenderer18);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        int int21 = xYPlot5.getIndexOf(xYItemRenderer20);
        xYPlot5.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot5.getDomainAxisLocation((int) '#');
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle2.setWidth((double) (byte) -1);
        java.awt.Font font7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font7);
        double[] doubleArray16 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray22 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray23 = new double[][] { doubleArray16, doubleArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer29);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot30.getRowRenderingOrder();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot30.rendererChanged(rendererChangeEvent32);
        java.awt.Paint paint34 = categoryPlot30.getRangeCrosshairPaint();
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("TextAnchor.TOP_RIGHT", font7, paint34);
        textTitle2.setFont(font7);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", font7);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        xYPlot5.mapDatasetToDomainAxis((int) (short) 1, 0);
        int int24 = xYPlot5.getDatasetCount();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setSimpleLabels(false);
        org.jfree.chart.util.Rotation rotation6 = piePlot3D0.getDirection();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rotation6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = xYPlot5.getSeriesRenderingOrder();
        xYPlot5.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot5.getRenderer(255);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = xYPlot5.getDomainMarkers(layer23);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder18);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint3);
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextStroke();
        java.awt.Shape shape8 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape9 = defaultDrawingSupplier6.getNextShape();
        piePlot3D0.setLegendItemShape(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "Rotation.CLOCKWISE");
        java.lang.String str13 = chartEntity12.toString();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ChartEntity: tooltip = Rotation.CLOCKWISE" + "'", str13.equals("ChartEntity: tooltip = Rotation.CLOCKWISE"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace35);
        categoryPlot21.clearDomainAxes();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot21.setInsets(rectangleInsets38);
        java.util.List list40 = categoryPlot21.getAnnotations();
        java.util.Collection collection41 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list40);
        java.util.Collection collection42 = org.jfree.chart.util.ObjectUtilities.deepClone(collection41);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double3 = numberAxis2.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis2.setRangeWithMargins((org.jfree.data.Range) dateRange4);
        org.jfree.data.time.DateRange dateRange7 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType12 = rectangleConstraint11.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange7, lengthConstraintType8, 1.0E-8d, (org.jfree.data.Range) dateRange10, lengthConstraintType12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange4, (org.jfree.data.Range) dateRange7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) 'a', (org.jfree.data.Range) dateRange4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange4);
        org.junit.Assert.assertNotNull(dateRange7);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(lengthConstraintType12);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot21.setRenderers(categoryItemRendererArray24);
        boolean boolean26 = categoryPlot21.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        org.jfree.chart.text.TextFragment textFragment32 = textLine31.getLastTextFragment();
        java.awt.Paint paint33 = textFragment32.getPaint();
        valueMarker28.setLabelPaint(paint33);
        org.jfree.chart.text.TextAnchor textAnchor35 = valueMarker28.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = valueMarker28.getLabelAnchor();
        valueMarker28.setLabel("XY Plot");
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker28, layer39);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = null;
        try {
            valueMarker28.setLabelOffsetType(lengthAdjustmentType41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = textBlock0.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean5 = rectangleEdge3.equals((java.lang.Object) verticalAlignment4);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment4, (double) (short) -1, 0.05d);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray15 = basicProjectInfo14.getLibraries();
        java.lang.String str16 = basicProjectInfo14.getCopyright();
        java.lang.String str17 = basicProjectInfo14.getCopyright();
        boolean boolean18 = flowArrangement8.equals((java.lang.Object) str17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = xYPlot24.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        xYPlot24.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis28);
        dateAxis28.setInverted(true);
        boolean boolean32 = flowArrangement8.equals((java.lang.Object) dateAxis28);
        try {
            dateAxis28.setRange((double) 100L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(libraryArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.plot.Marker marker44 = null;
        org.jfree.chart.util.Layer layer45 = null;
        try {
            boolean boolean46 = categoryPlot21.removeDomainMarker(15, marker44, layer45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        categoryPlot21.mapDatasetToRangeAxis(1, (int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer47);
        java.awt.Stroke stroke49 = xYPlot48.getRangeZeroBaselineStroke();
        java.awt.Color color50 = java.awt.Color.yellow;
        xYPlot48.setDomainGridlinePaint((java.awt.Paint) color50);
        xYPlot48.setDomainGridlinesVisible(false);
        boolean boolean54 = xYPlot48.isRangeZoomable();
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = xYPlot48.getRangeMarkers((int) ' ', layer56);
        java.awt.Paint paint58 = xYPlot48.getRangeCrosshairPaint();
        categoryPlot21.setBackgroundPaint(paint58);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D2.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color4);
        java.awt.Stroke stroke7 = piePlot3D2.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double8 = piePlot3D2.getInteriorGap();
        piePlot3D2.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        piePlot3D2.axisChanged(axisChangeEvent11);
        java.awt.Font font13 = piePlot3D2.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        piePlot3D2.setDataset(pieDataset14);
        java.awt.Stroke stroke16 = piePlot3D2.getOutlineStroke();
        valueMarker1.setStroke(stroke16);
        java.lang.Class class18 = null;
        try {
            java.util.EventListener[] eventListenerArray19 = valueMarker1.getListeners(class18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(stroke16);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        java.lang.Class class1 = null;
//        try {
//            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=255,g=255,b=255]", class1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot21.setRenderers(categoryItemRendererArray24);
        boolean boolean26 = categoryPlot21.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        org.jfree.chart.text.TextFragment textFragment32 = textLine31.getLastTextFragment();
        java.awt.Paint paint33 = textFragment32.getPaint();
        valueMarker28.setLabelPaint(paint33);
        org.jfree.chart.text.TextAnchor textAnchor35 = valueMarker28.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = valueMarker28.getLabelAnchor();
        valueMarker28.setLabel("XY Plot");
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker28, layer39);
        categoryPlot21.clearRangeAxes();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Color color0 = java.awt.Color.RED;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int4 = categoryAxis3D3.getCategoryLabelPositionOffset();
        categoryAxis3D3.setLabelURL("");
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D3.setLabelPaint(paint7);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D3.setTickLabelInsets(rectangleInsets13);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets13);
        double double16 = rectangleInsets13.getTop();
        double double18 = rectangleInsets13.calculateTopOutset(90.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot3D3.getLabelGenerator();
        piePlot3D3.setShadowYOffset((double) (short) 1);
        piePlot3D3.setIgnoreZeroValues(false);
        boolean boolean9 = standardPieSectionLabelGenerator1.equals((java.lang.Object) piePlot3D3);
        piePlot3D3.setLabelLinkMargin((double) 255);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        textBlock0.draw(graphics2D1, (float) 10L, (float) '4', textBlockAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock0.setLineAlignment(horizontalAlignment6);
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment8, (double) '#', (double) 10L);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
        org.junit.Assert.assertNotNull(verticalAlignment8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        polarPlot0.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        polarPlot0.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass10 = numberAxis9.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis9.getTickUnit();
        polarPlot0.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit11);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        polarPlot0.setRenderer(polarItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        polarPlot0.zoomDomainAxes((double) '4', 0.2d, plotRenderingInfo17, point2D18);
        polarPlot0.addCornerTextItem("Rotation.CLOCKWISE");
        org.jfree.chart.text.TextBlock textBlock22 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine23 = textBlock22.getLastLine();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = textBlock22.getLineAlignment();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean27 = rectangleEdge25.equals((java.lang.Object) verticalAlignment26);
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment24, verticalAlignment26, (double) (short) -1, 0.05d);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo36 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "", "VerticalAlignment.TOP");
        org.jfree.chart.ui.Library[] libraryArray37 = basicProjectInfo36.getLibraries();
        java.lang.String str38 = basicProjectInfo36.getCopyright();
        java.lang.String str39 = basicProjectInfo36.getCopyright();
        boolean boolean40 = flowArrangement30.equals((java.lang.Object) str39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset41, valueAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis44, xYItemRenderer45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot46.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("");
        xYPlot46.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis50);
        dateAxis50.setInverted(true);
        boolean boolean54 = flowArrangement30.equals((java.lang.Object) dateAxis50);
        org.jfree.chart.axis.DateTickUnit dateTickUnit55 = dateAxis50.getTickUnit();
        org.jfree.data.Range range56 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis50);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertNull(textLine23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(libraryArray37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dateTickUnit55);
        org.junit.Assert.assertNull(range56);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        boolean boolean11 = xYPlot5.isRangeZoomable();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot5.markerChanged(markerChangeEvent12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot5.zoomDomainAxes((double) (-1.0f), (double) 0L, plotRenderingInfo16, point2D17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = xYPlot5.getFixedLegendItems();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        xYPlot5.setDataset(xYDataset20);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.awt.Graphics2D graphics2D2 = null;
        double[] doubleArray10 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray16 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray17);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D20, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer23);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot24.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D27.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D27.setAxisLinePaint((java.awt.Paint) color30);
        int int32 = categoryPlot24.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D27);
        org.jfree.chart.util.SortOrder sortOrder33 = categoryPlot24.getColumnRenderingOrder();
        categoryPlot24.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace35);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot24.setOrientation(plotOrientation37);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = categoryPlot24.getOrientation();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.LEFT;
        boolean boolean42 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge41);
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace44 = numberAxis1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot24, rectangle2D40, rectangleEdge41, axisSpace43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(sortOrder25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(sortOrder33);
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer23 };
        categoryPlot21.setRenderers(categoryItemRendererArray24);
        boolean boolean26 = categoryPlot21.isRangeCrosshairLockedOnData();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font30 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("", font30);
        org.jfree.chart.text.TextFragment textFragment32 = textLine31.getLastTextFragment();
        java.awt.Paint paint33 = textFragment32.getPaint();
        valueMarker28.setLabelPaint(paint33);
        org.jfree.chart.text.TextAnchor textAnchor35 = valueMarker28.getLabelTextAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = valueMarker28.getLabelAnchor();
        valueMarker28.setLabel("XY Plot");
        org.jfree.chart.util.Layer layer39 = null;
        boolean boolean40 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker28, layer39);
        double double41 = categoryPlot21.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(textFragment32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.Arrangement arrangement3 = blockContainer2.getArrangement();
        org.junit.Assert.assertNotNull(arrangement3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot21.setInsets(rectangleInsets38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot21.getRangeAxisLocation(10);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, (org.jfree.chart.axis.ValueAxis) numberAxis45, xYItemRenderer46);
        java.awt.Stroke stroke48 = xYPlot47.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot47.getRangeAxisLocation();
        java.awt.Paint paint50 = xYPlot47.getDomainCrosshairPaint();
        categoryPlot21.setParent((org.jfree.chart.plot.Plot) xYPlot47);
        org.jfree.chart.JFreeChart jFreeChart52 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent55 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryPlot21, jFreeChart52, (int) (short) 0, (int) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(axisLocation49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D1.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color3);
        java.awt.Stroke stroke6 = piePlot3D1.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double7 = piePlot3D1.getInteriorGap();
        piePlot3D1.setIgnoreZeroValues(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = null;
        piePlot3D1.setURLGenerator(pieURLGenerator10);
        java.lang.Class<?> wildcardClass12 = piePlot3D1.getClass();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass17 = numberAxis16.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", (java.lang.Class) wildcardClass17);
        java.io.InputStream inputStream19 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("LengthConstraintType.NONE", (java.lang.Class) wildcardClass17);
        java.lang.Object obj20 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass12, (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.08d + "'", double7 == 0.08d);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
        org.junit.Assert.assertNull(inputStream19);
        org.junit.Assert.assertNull(obj20);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle3.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame6 = textTitle3.getFrame();
        textTitle3.setExpandToFitSpace(false);
        java.awt.Font font9 = textTitle3.getFont();
        valueMarker1.setLabelFont(font9);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = polarPlot4.getLegendItems();
        boolean boolean12 = polarPlot4.isRangeZoomable();
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray1 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray1);
        org.junit.Assert.assertNotNull(valueAxisArray1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        numberAxis3.setVisible(true);
        numberAxis3.setLowerBound((double) 10.0f);
        float float10 = numberAxis3.getTickMarkOutsideLength();
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement11.clear();
        columnArrangement11.clear();
        boolean boolean14 = numberAxis3.equals((java.lang.Object) columnArrangement11);
        java.text.NumberFormat numberFormat15 = numberAxis3.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(numberFormat15);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace33);
        boolean boolean35 = columnArrangement0.equals((java.lang.Object) axisSpace33);
        org.jfree.chart.ui.ProjectInfo projectInfo36 = org.jfree.chart.JFreeChart.INFO;
        projectInfo36.setCopyright("ThreadContext");
        boolean boolean39 = columnArrangement0.equals((java.lang.Object) projectInfo36);
        java.lang.String str40 = projectInfo36.toString();
        projectInfo36.setLicenceText("");
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(projectInfo36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        pieLabelDistributor1.sort();
        java.lang.String str3 = pieLabelDistributor1.toString();
        java.lang.String str4 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot5.getIndexOf(xYItemRenderer18);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot5.getLegendItems();
        org.jfree.chart.axis.AxisSpace axisSpace21 = xYPlot5.getFixedDomainAxisSpace();
        double double22 = xYPlot5.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = new org.jfree.chart.LegendItemCollection();
        xYPlot5.setFixedLegendItems(legendItemCollection23);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = piePlot3D1.getLabelGenerator();
        piePlot3D1.setShadowYOffset((double) (short) 1);
        piePlot3D1.setSimpleLabels(false);
        java.awt.Font font7 = piePlot3D1.getNoDataMessageFont();
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font7);
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textLine8.calculateDimensions(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator2);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        boolean boolean7 = unitType5.equals((java.lang.Object) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType5, 100.0d, 0.5d, (double) 0.5f, (double) 4);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.awt.Paint paint2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis1.setTickMarkPaint(paint2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis7, xYItemRenderer8);
        java.awt.Stroke stroke10 = xYPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double14 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis13.setRangeWithMargins((org.jfree.data.Range) dateRange15);
        xYPlot9.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer22);
        xYPlot23.clearAnnotations();
        java.awt.Paint paint25 = xYPlot23.getRangeCrosshairPaint();
        java.awt.Stroke stroke26 = xYPlot23.getDomainGridlineStroke();
        xYPlot9.setDomainZeroBaselineStroke(stroke26);
        numberAxis1.setTickMarkStroke(stroke26);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double31 = numberAxis30.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis30.setRangeWithMargins((org.jfree.data.Range) dateRange32);
        org.jfree.data.time.DateRange dateRange35 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType36 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType40 = rectangleConstraint39.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((-1.0d), (org.jfree.data.Range) dateRange35, lengthConstraintType36, 1.0E-8d, (org.jfree.data.Range) dateRange38, lengthConstraintType40);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range) dateRange32, (org.jfree.data.Range) dateRange35);
        double double43 = dateRange35.getCentralValue();
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange35);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0E-8d + "'", double14 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0E-8d + "'", double31 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange32);
        org.junit.Assert.assertNotNull(dateRange35);
        org.junit.Assert.assertNotNull(lengthConstraintType36);
        org.junit.Assert.assertNotNull(dateRange38);
        org.junit.Assert.assertNotNull(rectangleConstraint39);
        org.junit.Assert.assertNotNull(lengthConstraintType40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.5d + "'", double43 == 0.5d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, 0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot24 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(pieDataset23);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass2 = numberAxis1.getClass();
        numberAxis1.setLowerBound(1.05d);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = textBlock0.getLastLine();
        double[] doubleArray9 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray15 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray9, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D26.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D26.setAxisLinePaint((java.awt.Paint) color29);
        int int31 = categoryPlot23.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D26);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot23.getColumnRenderingOrder();
        categoryPlot23.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot23.setFixedDomainAxisSpace(axisSpace34);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryPlot23.setInsets(rectangleInsets40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = categoryPlot23.getRangeAxisLocation(10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = categoryPlot23.getRenderer();
        boolean boolean45 = textBlock0.equals((java.lang.Object) categoryItemRenderer44);
        org.junit.Assert.assertNull(textLine1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNull(categoryItemRenderer44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getRangeAxisLocation();
        java.awt.Paint paint8 = xYPlot5.getDomainCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = xYPlot14.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        xYPlot14.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        dateAxis18.setInverted(true);
        org.jfree.data.Range range22 = xYPlot5.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis18);
        dateAxis18.setRange(0.0d, 0.6249999999999999d);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.BOTTOM_LEFT");
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        piePlot3D0.setShadowYOffset((double) (short) 1);
        piePlot3D0.setIgnoreZeroValues(false);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 1.0E-8d, (double) 2);
        double[] doubleArray16 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray22 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray23 = new double[][] { doubleArray16, doubleArray22 };
        org.jfree.data.category.CategoryDataset categoryDataset24 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray23);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D26, (org.jfree.chart.axis.ValueAxis) numberAxis28, categoryItemRenderer29);
        org.jfree.data.general.PieDataset pieDataset32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset24, 0);
        double double33 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset32);
        piePlot3D0.setDataset(pieDataset32);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(categoryDataset24);
        org.junit.Assert.assertNotNull(pieDataset32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 164.0d + "'", double33 == 164.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setToolTipText("");
        textTitle0.setID("ClassContext");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        java.awt.Color color7 = java.awt.Color.yellow;
        xYPlot5.setDomainGridlinePaint((java.awt.Paint) color7);
        xYPlot5.setDomainGridlinesVisible(false);
        java.awt.Paint paint11 = xYPlot5.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer16);
        xYPlot17.clearAnnotations();
        java.awt.Paint paint19 = xYPlot17.getRangeCrosshairPaint();
        java.awt.Stroke stroke20 = xYPlot17.getDomainGridlineStroke();
        xYPlot5.setRangeGridlineStroke(stroke20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace22, false);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = xYPlot5.getLegendItems();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(legendItemCollection25);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.data.general.PieDataset pieDataset24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "PlotOrientation.VERTICAL", (org.jfree.data.KeyedValues) pieDataset24);
        try {
            java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset25);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(pieDataset24);
        org.junit.Assert.assertNotNull(categoryDataset25);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, polarItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot4.zoomDomainAxes((double) 255, plotRenderingInfo6, point2D7);
        polarPlot4.zoom(0.0d);
        boolean boolean12 = polarPlot4.equals((java.lang.Object) 0.6249999999999999d);
        polarPlot4.setOutlineVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        polarPlot4.datasetChanged(datasetChangeEvent15);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(pieURLGenerator7);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getAlpha();
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D2.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color4);
        java.awt.Stroke stroke7 = piePlot3D2.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double8 = piePlot3D2.getInteriorGap();
        piePlot3D2.setIgnoreZeroValues(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot3D2.setURLGenerator(pieURLGenerator11);
        boolean boolean13 = piePlot3D2.getIgnoreZeroValues();
        piePlot3D2.setIgnoreNullValues(false);
        boolean boolean16 = color0.equals((java.lang.Object) piePlot3D2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.08d + "'", double8 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        java.lang.Object obj35 = categoryPlot21.clone();
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot21.getRangeMarkers(2, layer37);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(collection38);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        xYPlot5.mapDatasetToDomainAxis((int) (short) 1, 0);
        xYPlot5.setDomainCrosshairValue((double) 1, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = piePlot3D0.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint3 = lineBorder2.getPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint3);
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextStroke();
        java.awt.Shape shape8 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape9 = defaultDrawingSupplier6.getNextShape();
        piePlot3D0.setLegendItemShape(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "Rotation.CLOCKWISE");
        java.lang.Object obj13 = chartEntity12.clone();
        java.lang.String str14 = chartEntity12.getShapeType();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "poly" + "'", str14.equals("poly"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray42 = legendTitle41.getSources();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment44 = org.jfree.chart.util.VerticalAlignment.TOP;
        boolean boolean45 = rectangleEdge43.equals((java.lang.Object) verticalAlignment44);
        legendTitle41.setLegendItemGraphicEdge(rectangleEdge43);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(legendItemSourceArray42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(verticalAlignment44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        categoryAxis3D1.setTickMarkPaint((java.awt.Paint) color13);
        java.awt.Font font22 = null;
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) "ClassContext", font22);
        categoryAxis3D1.setLabelToolTip("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D7.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color9);
        java.awt.Stroke stroke12 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double13 = piePlot3D7.getInteriorGap();
        piePlot3D7.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot3D7.axisChanged(axisChangeEvent16);
        java.awt.Font font18 = piePlot3D7.getLabelFont();
        boolean boolean19 = piePlot3D0.equals((java.lang.Object) piePlot3D7);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D22 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator23 = piePlot3D22.getLabelGenerator();
        piePlot3D22.setShadowYOffset((double) (short) 1);
        piePlot3D22.setIgnoreZeroValues(false);
        java.awt.Font font28 = piePlot3D22.getLabelFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.PiePlotState piePlotState31 = piePlot3D0.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.PiePlot) piePlot3D22, (java.lang.Integer) 2, plotRenderingInfo30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        piePlot3D22.setInsets(rectangleInsets32);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(piePlotState31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer10);
        java.util.List list12 = xYPlot11.getAnnotations();
        xYPlot11.setDomainCrosshairVisible(false);
        boolean boolean15 = xYPlot5.equals((java.lang.Object) xYPlot11);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine20 = new org.jfree.chart.text.TextLine("", font19);
        org.jfree.chart.text.TextFragment textFragment21 = textLine20.getLastTextFragment();
        java.awt.Paint paint22 = textFragment21.getPaint();
        valueMarker17.setLabelPaint(paint22);
        xYPlot5.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        java.lang.String str25 = valueMarker17.getLabel();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = valueMarker17.getLabelOffsetType();
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(textFragment21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        jFreeChart36.setTitle("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = jFreeChart36.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle41 = jFreeChart36.getLegend((int) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendTitle41.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = legendTitle41.getLegendItemGraphicEdge();
        org.jfree.chart.block.BlockBorder blockBorder44 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle41.setFrame((org.jfree.chart.block.BlockFrame) blockBorder44);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(categoryPlot39);
        org.junit.Assert.assertNotNull(legendTitle41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(blockBorder44);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D7.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color9);
        java.awt.Stroke stroke12 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double13 = piePlot3D7.getInteriorGap();
        piePlot3D7.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot3D7.axisChanged(axisChangeEvent16);
        java.awt.Font font18 = piePlot3D7.getLabelFont();
        boolean boolean19 = piePlot3D0.equals((java.lang.Object) piePlot3D7);
        java.lang.String str20 = piePlot3D0.getPlotType();
        double double21 = piePlot3D0.getMaximumLabelWidth();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Pie 3D Plot" + "'", str20.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.14d + "'", double21 == 0.14d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextStroke();
        java.awt.Shape shape3 = defaultDrawingSupplier1.getNextShape();
        xYPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        xYPlot0.setRenderer(xYItemRenderer5);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        xYPlot5.setDomainCrosshairValue((-1.0d), true);
        org.junit.Assert.assertNotNull(axisLocation7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        xYPlot5.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int19 = categoryAxis3D18.getCategoryLabelPositionOffset();
        categoryAxis3D18.setLabelURL("");
        java.awt.Paint paint22 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D18.setLabelPaint(paint22);
        java.awt.Paint paint24 = categoryAxis3D18.getTickMarkPaint();
        categoryAxis3D18.setLabelToolTip("RectangleEdge.LEFT");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis3D18.getTickLabelInsets();
        xYPlot5.setInsets(rectangleInsets27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        int int30 = xYPlot5.indexOf(xYDataset29);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot21.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomDomainAxes((double) 100.0f, plotRenderingInfo33, point2D34, false);
        categoryPlot21.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass40 = numberAxis39.getClass();
        int int41 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        categoryPlot21.setOutlineVisible(true);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font47 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("", font47);
        org.jfree.chart.text.TextFragment textFragment49 = textLine48.getLastTextFragment();
        java.awt.Paint paint50 = textFragment49.getPaint();
        valueMarker45.setLabelPaint(paint50);
        org.jfree.chart.text.TextAnchor textAnchor52 = valueMarker45.getLabelTextAnchor();
        java.awt.Paint paint53 = valueMarker45.getOutlinePaint();
        org.jfree.chart.util.Layer layer54 = null;
        try {
            boolean boolean55 = categoryPlot21.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker45, layer54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(categoryItemRenderer31);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(textFragment49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        dateAxis9.configure();
        java.lang.Object obj12 = dateAxis9.clone();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot5.getRangeAxis((int) (short) -1);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = xYPlot5.getRangeMarkers(0, layer18);
        java.awt.Stroke stroke20 = xYPlot5.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        java.awt.Stroke stroke42 = categoryPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean47 = dateAxis45.isHiddenValue((long) (short) 100);
        java.awt.Shape shape48 = dateAxis45.getLeftArrow();
        dateAxis45.resizeRange((double) 52);
        categoryPlot21.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) dateAxis45);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.JFreeChart jFreeChart54 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent55 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAxis3D53, jFreeChart54);
        int int56 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D53);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        java.awt.Stroke stroke6 = xYPlot5.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("{0}");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        org.jfree.data.time.DateRange dateRange11 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis9.setRangeWithMargins((org.jfree.data.Range) dateRange11);
        xYPlot5.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = xYPlot5.getOrientation();
        java.awt.Font font16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        org.jfree.chart.text.TextFragment textFragment18 = textLine17.getLastTextFragment();
        java.awt.Paint paint19 = textFragment18.getPaint();
        xYPlot5.setDomainGridlinePaint(paint19);
        java.awt.Paint paint21 = xYPlot5.getRangeZeroBaselinePaint();
        java.awt.Color color22 = java.awt.Color.magenta;
        xYPlot5.setDomainTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color24.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        java.awt.Color color31 = color24.brighter();
        float[] floatArray35 = new float[] { (byte) 100, 0, 0 };
        float[] floatArray36 = color31.getColorComponents(floatArray35);
        float[] floatArray37 = color22.getRGBColorComponents(floatArray36);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNotNull(dateRange11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(textFragment18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setWidth((double) (byte) -1);
        org.jfree.chart.block.BlockFrame blockFrame4 = textTitle1.getFrame();
        textTitle1.setText("");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str10 = categoryAxis3D8.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        int int11 = categoryAxis3D8.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color14);
        java.awt.Stroke stroke17 = piePlot3D12.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double18 = piePlot3D12.getInteriorGap();
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = null;
        piePlot3D12.axisChanged(axisChangeEvent21);
        java.awt.Font font23 = piePlot3D12.getLabelFont();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        piePlot3D12.setDataset(pieDataset24);
        boolean boolean26 = piePlot3D12.getLabelLinksVisible();
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D27.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color29);
        java.awt.Stroke stroke32 = piePlot3D27.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        piePlot3D27.setInsets(rectangleInsets33);
        org.jfree.chart.util.Rotation rotation35 = piePlot3D27.getDirection();
        piePlot3D12.setDirection(rotation35);
        categoryAxis3D8.setPlot((org.jfree.chart.plot.Plot) piePlot3D12);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D12.setShadowPaint((java.awt.Paint) color38);
        boolean boolean40 = textTitle1.equals((java.lang.Object) color38);
        org.junit.Assert.assertNotNull(blockFrame4);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08d + "'", double18 == 0.08d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rotation35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        piePlot3D0.setBackgroundImageAlignment((int) 'a');
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D7.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color9);
        java.awt.Stroke stroke12 = piePlot3D7.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double13 = piePlot3D7.getInteriorGap();
        piePlot3D7.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = null;
        piePlot3D7.axisChanged(axisChangeEvent16);
        java.awt.Font font18 = piePlot3D7.getLabelFont();
        boolean boolean19 = piePlot3D0.equals((java.lang.Object) piePlot3D7);
        piePlot3D0.setStartAngle((double) (short) 100);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        float float7 = xYPlot5.getBackgroundImageAlpha();
        java.awt.Stroke stroke8 = xYPlot5.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.5f + "'", float7 == 0.5f);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = categoryPlot21.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis37 = categoryPlot21.getRangeAxis((int) (short) 0);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.awt.Paint paint40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis39.setTickMarkPaint(paint40);
        categoryPlot21.setRangeCrosshairPaint(paint40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis48, xYItemRenderer49);
        java.awt.Stroke stroke51 = xYPlot50.getRangeZeroBaselineStroke();
        java.awt.Color color52 = java.awt.Color.yellow;
        xYPlot50.setDomainGridlinePaint((java.awt.Paint) color52);
        xYPlot50.setDomainGridlinesVisible(false);
        java.awt.Paint paint56 = xYPlot50.getRangeTickBandPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = null;
        java.awt.geom.Point2D point2D61 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D59, rectangleAnchor60);
        xYPlot50.zoomDomainAxes((double) (byte) 0, plotRenderingInfo58, point2D61, true);
        try {
            categoryPlot21.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D61, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(valueAxis37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(point2D61);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        boolean boolean33 = categoryPlot21.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer38);
        xYPlot39.clearAnnotations();
        java.awt.Paint paint41 = xYPlot39.getRangeCrosshairPaint();
        categoryPlot21.setDomainGridlinePaint(paint41);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot21.getDomainAxis();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(categoryAxis44);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        xYPlot5.setDomainCrosshairValue((double) 1L, true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        xYPlot5.setFixedDomainAxisSpace(axisSpace10, false);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = xYPlot5.getRangeMarkers((int) (byte) 0, layer14);
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot21.setOrientation(plotOrientation34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = categoryPlot21.getOrientation();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        categoryPlot21.setRenderer((int) (short) 1, categoryItemRenderer38);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(plotOrientation36);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        boolean boolean3 = dateAxis1.isHiddenValue((long) (short) 100);
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = piePlot3D4.getLabelGenerator();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint7 = lineBorder6.getPaint();
        piePlot3D4.setBaseSectionOutlinePaint(paint7);
        java.lang.String str9 = piePlot3D4.getPlotType();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextStroke();
        java.awt.Shape shape12 = defaultDrawingSupplier10.getNextShape();
        java.awt.Shape shape13 = defaultDrawingSupplier10.getNextShape();
        piePlot3D4.setLegendItemShape(shape13);
        org.jfree.chart.entity.ChartEntity chartEntity16 = new org.jfree.chart.entity.ChartEntity(shape13, "Rotation.CLOCKWISE");
        dateAxis1.setRightArrow(shape13);
        org.jfree.chart.axis.DateTickUnit dateTickUnit18 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date19 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit18);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Pie 3D Plot" + "'", str9.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(dateTickUnit18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        xYPlot5.clearAnnotations();
        java.awt.Paint paint7 = xYPlot5.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation8 = xYPlot5.getRangeAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '#');
        try {
            boolean boolean11 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Rotation.CLOCKWISE", graphics2D1, 0.0d, (float) (byte) 0, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis3D1.getCategoryLabelPositions();
        double double14 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis3D1.getLabelInsets();
        java.awt.Paint paint14 = categoryAxis3D1.getTickLabelPaint();
        double double15 = categoryAxis3D1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        numberAxis3.setVisible(true);
        numberAxis3.setLowerBound((double) 10.0f);
        float float10 = numberAxis3.getTickMarkOutsideLength();
        java.awt.Paint paint11 = numberAxis3.getAxisLinePaint();
        numberAxis3.setPositiveArrowVisible(true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Image image37 = null;
        jFreeChart36.setBackgroundImage(image37);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        try {
            jFreeChart36.handleClick(1, 10, chartRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, xYItemRenderer4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = xYPlot5.getDomainAxisLocation(0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot13.getDomainAxisLocation(0);
        xYPlot5.setDomainAxisLocation(axisLocation15, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        int int19 = xYPlot5.getIndexOf(xYItemRenderer18);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = null;
        xYPlot5.axisChanged(axisChangeEvent20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot5.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        double[] doubleArray31 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray37 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray38);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D41 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D41, (org.jfree.chart.axis.ValueAxis) numberAxis43, categoryItemRenderer44);
        org.jfree.chart.util.SortOrder sortOrder46 = categoryPlot45.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D48 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D48.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D48.setAxisLinePaint((java.awt.Paint) color51);
        int int53 = categoryPlot45.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D48);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot45.getColumnRenderingOrder();
        categoryPlot22.setColumnRenderingOrder(sortOrder54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = categoryPlot22.getRangeAxis(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot22.zoomDomainAxes(0.05d, plotRenderingInfo59, point2D60);
        boolean boolean62 = categoryPlot22.isDomainGridlinesVisible();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent63 = null;
        categoryPlot22.notifyListeners(plotChangeEvent63);
        org.jfree.chart.JFreeChart jFreeChart65 = new org.jfree.chart.JFreeChart("RectangleEdge.LEFT", (org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.axis.ValueAxis valueAxis66 = categoryPlot22.getRangeAxis();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(sortOrder54);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(valueAxis66);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        java.awt.Color color9 = java.awt.Color.RED;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int13 = categoryAxis3D12.getCategoryLabelPositionOffset();
        categoryAxis3D12.setLabelURL("");
        java.awt.Paint paint16 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D12.setLabelPaint(paint16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D12.setTickLabelInsets(rectangleInsets22);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets22);
        piePlot3D0.setInsets(rectangleInsets22);
        double double26 = rectangleInsets22.getLeft();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
        java.text.NumberFormat numberFormat4 = standardPieSectionLabelGenerator3.getNumberFormat();
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator3.getNumberFormat();
        numberAxis1.setNumberFormatOverride(numberFormat5);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getSeparatorPaint();
        java.awt.Stroke stroke2 = ringPlot0.getSeparatorStroke();
        java.awt.Stroke stroke4 = ringPlot0.getSectionOutlineStroke((java.lang.Comparable) (byte) 1);
        org.jfree.chart.util.Rotation rotation5 = ringPlot0.getDirection();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNotNull(rotation5);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        java.awt.Paint paint7 = categoryAxis3D1.getTickMarkPaint();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis11, xYItemRenderer12);
        java.awt.Stroke stroke14 = xYPlot13.getRangeZeroBaselineStroke();
        java.awt.Color color15 = java.awt.Color.yellow;
        xYPlot13.setDomainGridlinePaint((java.awt.Paint) color15);
        xYPlot13.setDomainGridlinesVisible(false);
        double[] doubleArray26 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray32 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray33 = new double[][] { doubleArray26, doubleArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray33);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D36, (org.jfree.chart.axis.ValueAxis) numberAxis38, categoryItemRenderer39);
        java.lang.Object obj41 = numberAxis38.clone();
        int int42 = xYPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis38);
        boolean boolean43 = categoryAxis3D1.equals((java.lang.Object) xYPlot13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        double[] doubleArray9 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray15 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray16 = new double[][] { doubleArray9, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray16);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D19 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D19, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot23.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D26.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D26.setAxisLinePaint((java.awt.Paint) color29);
        int int31 = categoryPlot23.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D26);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot23.getDomainAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker34.setLabelTextAnchor(textAnchor35);
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot23.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker34, layer37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_CYAN;
        valueMarker34.setOutlinePaint((java.awt.Paint) color39);
        org.jfree.chart.util.Layer layer41 = null;
        xYPlot0.addRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker34, layer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot0.getRangeAxisEdge((int) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset46, valueAxis47, (org.jfree.chart.axis.ValueAxis) numberAxis49, xYItemRenderer50);
        java.awt.Stroke stroke52 = xYPlot51.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation53 = xYPlot51.getRangeAxisLocation();
        double[] doubleArray61 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray67 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray68 = new double[][] { doubleArray61, doubleArray67 };
        org.jfree.data.category.CategoryDataset categoryDataset69 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray68);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D71 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset69, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D71, (org.jfree.chart.axis.ValueAxis) numberAxis73, categoryItemRenderer74);
        org.jfree.chart.util.SortOrder sortOrder76 = categoryPlot75.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D78 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D78.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color81 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D78.setAxisLinePaint((java.awt.Paint) color81);
        int int83 = categoryPlot75.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D78);
        org.jfree.chart.util.SortOrder sortOrder84 = categoryPlot75.getColumnRenderingOrder();
        categoryPlot75.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace86 = null;
        categoryPlot75.setFixedDomainAxisSpace(axisSpace86);
        org.jfree.chart.plot.PlotOrientation plotOrientation88 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot75.setOrientation(plotOrientation88);
        org.jfree.chart.plot.PlotOrientation plotOrientation90 = categoryPlot75.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge91 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation53, plotOrientation90);
        xYPlot0.setDomainAxisLocation(255, axisLocation53, false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(categoryDataset69);
        org.junit.Assert.assertNotNull(sortOrder76);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertNotNull(sortOrder84);
        org.junit.Assert.assertNotNull(plotOrientation88);
        org.junit.Assert.assertNotNull(plotOrientation90);
        org.junit.Assert.assertNotNull(rectangleEdge91);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        try {
            categoryPlot21.addDomainMarker(categoryMarker34, layer35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent33);
        boolean boolean35 = categoryPlot21.isRangeCrosshairVisible();
        float float36 = categoryPlot21.getBackgroundAlpha();
        categoryPlot21.setDrawSharedDomainAxis(false);
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset40, valueAxis41, (org.jfree.chart.axis.ValueAxis) numberAxis43, xYItemRenderer44);
        java.awt.Stroke stroke46 = xYPlot45.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation47 = xYPlot45.getRangeAxisLocation();
        categoryPlot21.setDomainAxisLocation(2, axisLocation47, false);
        categoryPlot21.zoom(1.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        int int22 = categoryPlot21.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot21.getDomainAxis(4);
        java.awt.Stroke stroke25 = categoryPlot21.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D0.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color2);
        java.awt.Stroke stroke5 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double6 = piePlot3D0.getInteriorGap();
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        piePlot3D0.axisChanged(axisChangeEvent9);
        double[] doubleArray19 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray25 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray26 = new double[][] { doubleArray19, doubleArray25 };
        org.jfree.data.category.CategoryDataset categoryDataset27 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray26);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D29 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D29, (org.jfree.chart.axis.ValueAxis) numberAxis31, categoryItemRenderer32);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot33.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D36 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D36.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D36.setAxisLinePaint((java.awt.Paint) color39);
        int int41 = categoryPlot33.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D36);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot33.getColumnRenderingOrder();
        categoryPlot33.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        categoryPlot33.rendererChanged(rendererChangeEvent45);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot33);
        jFreeChart47.setAntiAlias(false);
        java.awt.Paint paint50 = jFreeChart47.getBackgroundPaint();
        piePlot3D0.setBaseSectionOutlinePaint(paint50);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(categoryDataset27);
        org.junit.Assert.assertNotNull(sortOrder34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot();
        polarPlot37.removeCornerTextItem("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        polarPlot37.zoomDomainAxes((double) (-1L), (double) 0, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass47 = numberAxis46.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = numberAxis46.getTickUnit();
        polarPlot37.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit48);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer50 = null;
        polarPlot37.setRenderer(polarItemRenderer50);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        polarPlot37.zoomDomainAxes((double) '4', 0.2d, plotRenderingInfo54, point2D55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass59 = numberAxis58.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = numberAxis58.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("{0}");
        java.lang.Class<?> wildcardClass63 = numberAxis62.getClass();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit64 = numberAxis62.getTickUnit();
        numberAxis58.setTickUnit(numberTickUnit64);
        polarPlot37.setAxis((org.jfree.chart.axis.ValueAxis) numberAxis58);
        int int67 = categoryPlot22.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis58);
        java.text.NumberFormat numberFormat68 = numberAxis58.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(numberTickUnit60);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(numberTickUnit64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertNull(numberFormat68);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer5);
        numberAxis4.setVisible(true);
        numberAxis4.setLowerBound((double) 10.0f);
        float float11 = numberAxis4.getTickMarkOutsideLength();
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement12.clear();
        columnArrangement12.clear();
        boolean boolean15 = numberAxis4.equals((java.lang.Object) columnArrangement12);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis4, polarItemRenderer16);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        java.awt.Paint paint6 = textFragment5.getPaint();
        valueMarker1.setLabelPaint(paint6);
        java.awt.Stroke stroke8 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setID("");
        textTitle1.setToolTipText("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]");
        textTitle1.setID("");
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        categoryPlot21.mapDatasetToRangeAxis(1, (int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D44 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D44.setLabelURL("");
        categoryAxis3D44.configure();
        java.util.List list48 = categoryPlot21.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D44);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double[] doubleArray8 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray14 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D18, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer21);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot22.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D25 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D25.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryPlot22.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D25);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setRangeCrosshairVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent34);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot) categoryPlot22);
        java.awt.Image image37 = null;
        jFreeChart36.setBackgroundImage(image37);
        jFreeChart36.setTitle("ThreadContext");
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        jFreeChart36.setBorderStroke(stroke41);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        try {
            java.awt.image.BufferedImage bufferedImage48 = jFreeChart36.createBufferedImage(0, 2, 0.5d, 0.4d, chartRenderingInfo47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (2) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=0.0]", "TextAnchor.TOP_RIGHT");
        java.awt.Shape shape6 = chartEntity5.getArea();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int2 = categoryAxis3D1.getCategoryLabelPositionOffset();
        categoryAxis3D1.setLabelURL("");
        java.awt.Paint paint5 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D1.setLabelPaint(paint5);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D1.setTickLabelInsets(rectangleInsets11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer18);
        java.awt.Stroke stroke20 = xYPlot19.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot19.getRangeAxisLocation();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = xYPlot19.getFixedLegendItems();
        int int23 = xYPlot19.getSeriesCount();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer29);
        java.awt.Stroke stroke31 = xYPlot30.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot30.getRangeAxisLocation();
        double[] doubleArray40 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray46 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray47 = new double[][] { doubleArray40, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D50 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D50, (org.jfree.chart.axis.ValueAxis) numberAxis52, categoryItemRenderer53);
        org.jfree.chart.util.SortOrder sortOrder55 = categoryPlot54.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D57 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D57.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D57.setAxisLinePaint((java.awt.Paint) color60);
        int int62 = categoryPlot54.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D57);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot54.getColumnRenderingOrder();
        categoryPlot54.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        categoryPlot54.setFixedDomainAxisSpace(axisSpace65);
        org.jfree.chart.plot.PlotOrientation plotOrientation67 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot54.setOrientation(plotOrientation67);
        org.jfree.chart.plot.PlotOrientation plotOrientation69 = categoryPlot54.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation32, plotOrientation69);
        org.jfree.chart.axis.AxisSpace axisSpace71 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace72 = categoryAxis3D1.reserveSpace(graphics2D13, (org.jfree.chart.plot.Plot) xYPlot19, rectangle2D24, rectangleEdge70, axisSpace71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(sortOrder55);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertNotNull(plotOrientation67);
        org.junit.Assert.assertNotNull(plotOrientation69);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        piePlot3D1.setDepthFactor((double) 2.0f);
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        piePlot3D4.setSectionPaint((java.lang.Comparable) 0.4d, (java.awt.Paint) color6);
        java.awt.Stroke stroke9 = piePlot3D4.getSectionOutlineStroke((java.lang.Comparable) 1.0E-8d);
        double double10 = piePlot3D4.getInteriorGap();
        piePlot3D4.setIgnoreZeroValues(false);
        java.awt.Color color13 = java.awt.Color.RED;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D16 = new org.jfree.chart.axis.CategoryAxis3D("");
        int int17 = categoryAxis3D16.getCategoryLabelPositionOffset();
        categoryAxis3D16.setLabelURL("");
        java.awt.Paint paint20 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis3D16.setLabelPaint(paint20);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) (-1.0f), (double) (short) 100, 0.4d);
        categoryAxis3D16.setTickLabelInsets(rectangleInsets26);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color13, stroke14, rectangleInsets26);
        piePlot3D4.setInsets(rectangleInsets26);
        double double31 = rectangleInsets26.calculateTopInset((double) 10L);
        piePlot3D1.setInsets(rectangleInsets26, true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.08d + "'", double10 == 0.08d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 10.0d + "'", double31 == 10.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape22, "", "TextAnchor.TOP_RIGHT");
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape22, "Pie 3D Plot");
        numberAxis19.setLeftArrow(shape22);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double[] doubleArray7 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray13 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D17 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis19, categoryItemRenderer20);
        org.jfree.chart.util.SortOrder sortOrder22 = categoryPlot21.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D24.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D24.setAxisLinePaint((java.awt.Paint) color27);
        int int29 = categoryPlot21.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D24);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot21.getColumnRenderingOrder();
        categoryPlot21.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        java.lang.String str36 = categoryAxis3D34.getCategoryLabelToolTip((java.lang.Comparable) 90.0d);
        categoryPlot21.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        boolean boolean39 = categoryPlot21.equals((java.lang.Object) false);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot21.setRangeGridlinesVisible(false);
        double[] doubleArray51 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray57 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray58 = new double[][] { doubleArray51, doubleArray57 };
        org.jfree.data.category.CategoryDataset categoryDataset59 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray58);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D61 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D61, (org.jfree.chart.axis.ValueAxis) numberAxis63, categoryItemRenderer64);
        org.jfree.chart.util.SortOrder sortOrder66 = categoryPlot65.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D68 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D68.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D68.setAxisLinePaint((java.awt.Paint) color71);
        int int73 = categoryPlot65.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D68);
        org.jfree.chart.axis.AxisLocation axisLocation74 = categoryPlot65.getDomainAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker76 = new org.jfree.chart.plot.ValueMarker((double) '#');
        org.jfree.chart.text.TextAnchor textAnchor77 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker76.setLabelTextAnchor(textAnchor77);
        org.jfree.chart.util.Layer layer79 = null;
        boolean boolean80 = categoryPlot65.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker76, layer79);
        java.awt.Color color81 = org.jfree.chart.ChartColor.DARK_CYAN;
        valueMarker76.setOutlinePaint((java.awt.Paint) color81);
        categoryPlot21.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker76);
        org.jfree.chart.util.SortOrder sortOrder84 = categoryPlot21.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(sortOrder22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(categoryDataset59);
        org.junit.Assert.assertNotNull(sortOrder66);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(axisLocation74);
        org.junit.Assert.assertNotNull(textAnchor77);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(sortOrder84);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) "RectangleEdge.LEFT");
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) '#');
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getLastTextFragment();
        java.awt.Paint paint6 = textFragment5.getPaint();
        valueMarker1.setLabelPaint(paint6);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker1.getLabelTextAnchor();
        java.awt.Paint paint9 = valueMarker1.getOutlinePaint();
        double[] doubleArray17 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[] doubleArray23 = new double[] { 1, 1L, 10.0f, 100L, '4' };
        double[][] doubleArray24 = new double[][] { doubleArray17, doubleArray23 };
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray24);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D27 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D27, (org.jfree.chart.axis.ValueAxis) numberAxis29, categoryItemRenderer30);
        org.jfree.chart.util.SortOrder sortOrder32 = categoryPlot31.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D34 = new org.jfree.chart.axis.CategoryAxis3D("");
        categoryAxis3D34.setMaximumCategoryLabelWidthRatio((float) 1L);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryAxis3D34.setAxisLinePaint((java.awt.Paint) color37);
        int int39 = categoryPlot31.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D34);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("{0}");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset41, valueAxis42, (org.jfree.chart.axis.ValueAxis) numberAxis44, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot46.getRangeAxisLocation();
        java.awt.Paint paint49 = xYPlot46.getDomainCrosshairPaint();
        categoryPlot31.setDomainGridlinePaint(paint49);
        valueMarker1.setPaint(paint49);
        java.awt.Font font52 = valueMarker1.getLabelFont();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNotNull(sortOrder32);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(font52);
    }
}

