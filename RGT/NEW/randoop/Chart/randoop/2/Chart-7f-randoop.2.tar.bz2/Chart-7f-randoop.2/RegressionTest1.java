import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 1);
        int int8 = timePeriodValues3.getMinStartIndex();
        int int9 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        java.lang.Number number12 = null;
        try {
            timePeriodValues3.update(5, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        java.lang.Object obj15 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date20 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date25 = simpleTimePeriod24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues30.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date39 = simpleTimePeriod38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date39, timeZone42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date25, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone42);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(class47);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues14.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener17);
        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date23 = simpleTimePeriod22.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date23, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date23, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long32 = simpleTimePeriod31.getStartMillis();
        java.util.Date date33 = simpleTimePeriod31.getEnd();
        long long34 = simpleTimePeriod31.getEndMillis();
        java.util.Date date35 = simpleTimePeriod31.getStart();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        java.util.Date date38 = regularTimePeriod37.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long42 = simpleTimePeriod41.getStartMillis();
        java.util.Date date43 = simpleTimePeriod41.getEnd();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj50 = timePeriodValues49.clone();
        int int51 = year45.compareTo((java.lang.Object) timePeriodValues49);
        java.util.Date date52 = year45.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date43, date52);
        java.lang.Class<?> wildcardClass54 = date43.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long58 = simpleTimePeriod57.getStartMillis();
        java.util.Date date59 = simpleTimePeriod57.getEnd();
        long long60 = simpleTimePeriod57.getEndMillis();
        java.util.Date date61 = simpleTimePeriod57.getStart();
        long long62 = simpleTimePeriod57.getStartMillis();
        long long63 = simpleTimePeriod57.getEndMillis();
        java.util.Date date64 = simpleTimePeriod57.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues68.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timePeriodValues68.removePropertyChangeListener(propertyChangeListener71);
        java.lang.Class<?> wildcardClass73 = timePeriodValues68.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date77 = simpleTimePeriod76.getStart();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date77, timeZone78);
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date77, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass54, date64, timeZone80);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date38, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date23, timeZone80);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 97L + "'", long34 == 97L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 97L + "'", long60 == 97L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 97L + "'", long63 == 97L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        boolean boolean10 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        timePeriodValues3.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues3.createCopy((int) ' ', 1969);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timePeriodValues17);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year5, "2019", "31-December-1969");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        timePeriodValues8.add(timePeriodValue17);
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue17.getPeriod();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(timePeriod19);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.lang.String str9 = timePeriodValue8.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long13 = simpleTimePeriod12.getStartMillis();
        java.util.Date date14 = simpleTimePeriod12.getEnd();
        long long15 = simpleTimePeriod12.getEndMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        long long17 = simpleTimePeriod12.getStartMillis();
        long long18 = simpleTimePeriod12.getEndMillis();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod12.equals(obj19);
        boolean boolean21 = timePeriodValue8.equals((java.lang.Object) boolean20);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str9.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 97L + "'", long18 == 97L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        java.lang.Object obj2 = seriesChangeEvent1.getSource();
//        java.lang.String str3 = seriesChangeEvent1.toString();
//        org.junit.Assert.assertNotNull(obj2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long6 = simpleTimePeriod5.getStartMillis();
        java.util.Date date7 = simpleTimePeriod5.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
        int int9 = timePeriodValues1.getMinStartIndex();
        java.lang.String str10 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod12);
        long long16 = simpleTimePeriod12.getStartMillis();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj22 = timePeriodValues21.clone();
        int int23 = year17.compareTo((java.lang.Object) timePeriodValues21);
        java.util.Date date24 = year17.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        java.lang.String str26 = year25.toString();
        java.util.Date date27 = year25.getEnd();
        boolean boolean28 = simpleTimePeriod12.equals((java.lang.Object) date27);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getYear();
//        long long4 = day2.getFirstMillisecond();
//        java.lang.String str5 = day2.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues9.setRangeDescription("");
//        int int12 = timePeriodValues9.getMinMiddleIndex();
//        java.lang.Object obj13 = timePeriodValues9.clone();
//        int int14 = day2.compareTo((java.lang.Object) timePeriodValues9);
//        java.util.Date date15 = day2.getEnd();
//        boolean boolean16 = day0.equals((java.lang.Object) day2);
//        long long17 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        long long8 = year5.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        long long19 = simpleTimePeriod18.getEndMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        int int5 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener6);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener8);
//        int int10 = timePeriodValues3.getMinEndIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj18 = timePeriodValues17.clone();
//        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
//        java.util.Date date20 = year13.getEnd();
//        int int21 = year13.getYear();
//        boolean boolean22 = day11.equals((java.lang.Object) int21);
//        int int24 = day11.compareTo((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day11.next();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        int int27 = day26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day26.previous();
//        java.lang.String str29 = day26.toString();
//        int int30 = day11.compareTo((java.lang.Object) str29);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day11, (double) (-15739200001L));
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        try {
            java.lang.Number number7 = timePeriodValues3.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues12.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date21 = simpleTimePeriod20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21, timeZone24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone24);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date7, timeZone24);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone24);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10 + "'", comparable9.equals(10));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMinMiddleIndex();
        int int3 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 1);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy((-1), 0);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod12, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 2019", "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        long long9 = simpleTimePeriod2.getEndMillis();
        java.util.Date date10 = simpleTimePeriod2.getStart();
        java.util.Date date11 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues15.createCopy((int) (short) 1, (int) (byte) 100);
        int int19 = timePeriodValues15.getMinStartIndex();
        boolean boolean20 = timePeriodValues15.getNotify();
        try {
            int int21 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timePeriodValues18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 1969");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 1969" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 1969"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        timePeriodValues6.setRangeDescription("");
        int int12 = timePeriodValues6.getMinEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj18 = timePeriodValues17.clone();
        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        java.lang.String str22 = timePeriodValue21.toString();
        timePeriodValue21.setValue((java.lang.Number) 0.0f);
        java.lang.Number number25 = timePeriodValue21.getValue();
        java.lang.String str26 = timePeriodValue21.toString();
        timePeriodValues6.add(timePeriodValue21);
        try {
            java.lang.Number number29 = timePeriodValues6.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str22.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0f + "'", number25.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str26.equals("TimePeriodValue[2019,0.0]"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) (-1));
        java.lang.Object obj12 = timePeriodValues3.clone();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj18 = timePeriodValues17.clone();
        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        long long22 = year13.getFirstMillisecond();
        long long23 = year13.getSerialIndex();
        int int24 = year13.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int24);
        int int26 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener29);
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues18.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener21);
        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date27 = simpleTimePeriod26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date27, timeZone30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues35.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        java.lang.Class<?> wildcardClass40 = timePeriodValues35.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date44 = simpleTimePeriod43.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date44, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj52 = timePeriodValues51.clone();
        int int53 = year47.compareTo((java.lang.Object) timePeriodValues51);
        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year47, (double) (-1L));
        java.util.Date date56 = year47.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues60.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener63);
        java.lang.Class<?> wildcardClass65 = timePeriodValues60.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date69 = simpleTimePeriod68.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date69, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date56, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date27, timeZone70);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date13, timeZone70);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
        int int76 = day75.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day75.previous();
        boolean boolean78 = year74.equals((java.lang.Object) day75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year74.previous();
        long long80 = year74.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1577865599999L + "'", long80 == 1577865599999L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        int int8 = year0.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        java.util.Date date7 = year5.getStart();
        java.lang.Class<?> wildcardClass8 = date7.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 1);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy((-1), 0);
        java.lang.String str6 = timePeriodValues5.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues5.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1562097599999L, "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]", "org.jfree.data.time.TimePeriodFormatException: 1969");
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getMonth();
//        long long3 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray9 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray10 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues21.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener24);
        java.lang.Class<?> wildcardClass26 = timePeriodValues21.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date30 = simpleTimePeriod29.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date30, timeZone33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date12, timeZone33);
        java.util.Date date37 = year36.getStart();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10 + "'", comparable4.equals(10));
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy((int) (short) 100, 2);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        java.util.Date date15 = day12.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues19.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValues19.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date28 = simpleTimePeriod27.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date15, timeZone29);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 0L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 100.0d);
        java.lang.Number number9 = timePeriodValue8.getValue();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100.0d + "'", number9.equals(100.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long6 = simpleTimePeriod5.getStartMillis();
        java.util.Date date7 = simpleTimePeriod5.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod5);
        long long10 = simpleTimePeriod5.getEndMillis();
        java.util.Date date11 = simpleTimePeriod5.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.lang.String str7 = year0.toString();
        java.lang.String str8 = year0.toString();
        long long9 = year0.getLastMillisecond();
        long long10 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) (-1L));
        java.util.Date date15 = year6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year6.previous();
        java.lang.Number number17 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year6, number17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year6.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Date date6 = day0.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues10.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener13 = null;
//        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
//        java.lang.Class<?> wildcardClass15 = timePeriodValues10.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date19 = simpleTimePeriod18.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone20);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date19, timeZone22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues27.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timePeriodValues27.removePropertyChangeListener(propertyChangeListener30);
//        java.lang.Class<?> wildcardClass32 = timePeriodValues27.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date36 = simpleTimePeriod35.getStart();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj44 = timePeriodValues43.clone();
//        int int45 = year39.compareTo((java.lang.Object) timePeriodValues43);
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, (double) (-1L));
//        java.util.Date date48 = year39.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues52.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timePeriodValues52.removePropertyChangeListener(propertyChangeListener55);
//        java.lang.Class<?> wildcardClass57 = timePeriodValues52.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date61 = simpleTimePeriod60.getStart();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date61, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date48, timeZone62);
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date19, timeZone62);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date6, timeZone62);
//        java.lang.Class<?> wildcardClass67 = day66.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(obj44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        boolean boolean5 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.Object obj6 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setDescription("2019");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj19 = timePeriodValues18.clone();
        int int20 = year14.compareTo((java.lang.Object) timePeriodValues18);
        java.util.Date date21 = year14.getEnd();
        int int22 = year14.getYear();
        boolean boolean23 = day12.equals((java.lang.Object) int22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 0L);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day12.next();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        timePeriodValues6.setRangeDescription("");
        int int12 = timePeriodValues6.getMinMiddleIndex();
        java.lang.Comparable comparable13 = timePeriodValues6.getKey();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10 + "'", comparable13.equals(10));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        boolean boolean8 = timePeriodValues3.getNotify();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, 0.0d);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj19 = timePeriodValues18.clone();
        int int20 = year14.compareTo((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (-1L));
        java.lang.String str23 = timePeriodValue22.toString();
        timePeriodValues3.add(timePeriodValue22);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str23.equals("TimePeriodValue[2019,-1.0]"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        java.util.Date date9 = simpleTimePeriod2.getEnd();
        long long10 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setNotify(false);
        java.lang.Object obj13 = timePeriodValues3.clone();
        int int14 = timePeriodValues3.getMinStartIndex();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        int int16 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 1969");
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues62.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues62.removePropertyChangeListener(propertyChangeListener65);
        java.lang.Class<?> wildcardClass67 = timePeriodValues62.getClass();
        java.lang.Class class68 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass67);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long72 = simpleTimePeriod71.getStartMillis();
        java.util.Date date73 = simpleTimePeriod71.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues77.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener80 = null;
        timePeriodValues77.removePropertyChangeListener(propertyChangeListener80);
        java.lang.Class<?> wildcardClass82 = timePeriodValues77.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod85 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date86 = simpleTimePeriod85.getStart();
        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass82, date86, timeZone87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date86, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date73, timeZone89);
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date12, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date12);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeZone87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNotNull(regularTimePeriod91);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        timePeriodValues6.setRangeDescription("");
        int int12 = timePeriodValues6.getMinMiddleIndex();
        int int13 = timePeriodValues6.getMinEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        int int8 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        java.util.Date date10 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, 0);
        timePeriodValues13.setDescription("TimePeriodValue[2019,-1.0]");
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        java.util.TimeZone timeZone20 = null;
        try {
            org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17, timeZone20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        long long13 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) ' ', 10);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getDayOfMonth();
//        timePeriodValues8.add((org.jfree.data.time.TimePeriod) day9, (double) 5);
//        long long13 = day9.getLastMillisecond();
//        int int14 = day9.getMonth();
//        org.junit.Assert.assertNotNull(timePeriodValues8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj8 = timePeriodValues7.clone();
        int int9 = year3.compareTo((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, 100.0d);
        timePeriodValues1.add(timePeriodValue11);
        java.lang.String str13 = timePeriodValue11.toString();
        java.lang.Number number14 = timePeriodValue11.getValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str13.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100.0d + "'", number14.equals(100.0d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        try {
            org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        long long5 = day4.getSerialIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long9 = simpleTimePeriod8.getStartMillis();
//        java.util.Date date10 = simpleTimePeriod8.getEnd();
//        long long11 = simpleTimePeriod8.getEndMillis();
//        java.util.Date date12 = simpleTimePeriod8.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        int int15 = day4.compareTo((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day4);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timePeriodValues16.removeChangeListener(seriesChangeListener17);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        java.lang.String str15 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 10 + "'", comparable14.equals(10));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        boolean boolean10 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        int int8 = day5.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues12.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date21 = simpleTimePeriod20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
//        int int25 = day5.compareTo((java.lang.Object) year24);
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj31 = timePeriodValues30.clone();
//        int int32 = year26.compareTo((java.lang.Object) timePeriodValues30);
//        java.util.Date date33 = year26.getEnd();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
//        java.lang.String str35 = year34.toString();
//        long long36 = year34.getLastMillisecond();
//        int int37 = year24.compareTo((java.lang.Object) year34);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-50) + "'", int37 == (-50));
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.lang.String str9 = timePeriodValue8.toString();
        java.lang.String str10 = timePeriodValue8.toString();
        java.lang.Object obj11 = timePeriodValue8.clone();
        boolean boolean13 = timePeriodValue8.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue8.getPeriod();
        java.lang.Number number15 = null;
        timePeriodValue8.setValue(number15);
        java.lang.Number number17 = timePeriodValue8.getValue();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str9.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str10.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertNull(number17);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        java.lang.Comparable comparable2 = timePeriodValues1.getKey();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj8 = timePeriodValues7.clone();
        int int9 = year3.compareTo((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) (-1L));
        long long12 = year3.getFirstMillisecond();
        long long13 = year3.getSerialIndex();
        java.lang.String str14 = year3.toString();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year3, (double) 43629L);
        int int18 = year3.compareTo((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 6 + "'", comparable2.equals(6));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        timePeriodValues3.fireSeriesChanged();
        int int6 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Class<?> wildcardClass20 = timePeriodValues15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date24 = simpleTimePeriod23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date24, timeZone27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone27);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date10, timeZone27);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year30, (double) (-1));
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year30, (java.lang.Number) 3);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10 + "'", comparable4.equals(10));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Object obj9 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod5, (double) 0);
//        java.lang.String str8 = timePeriodValue7.toString();
//        java.lang.String str9 = timePeriodValue7.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "TimePeriodValue[12-June-2019,0.0]" + "'", str8.equals("TimePeriodValue[12-June-2019,0.0]"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[12-June-2019,0.0]" + "'", str9.equals("TimePeriodValue[12-June-2019,0.0]"));
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj12 = timePeriodValues11.clone();
//        int int13 = year7.compareTo((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1L));
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValue15);
//        java.lang.String str17 = day0.toString();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = day0.getLastMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDescription("1969");
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10 + "'", comparable13.equals(10));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 1);
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(7, (int) (short) 10);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue13 = timePeriodValues3.getDataItem((-50));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(8, (int) (byte) 0);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (short) 10);
        long long19 = year10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1562097599999L + "'", long19 == 1562097599999L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinStartIndex();
        java.lang.Object obj6 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        try {
            java.lang.Number number10 = timePeriodValues3.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        long long14 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        long long9 = simpleTimePeriod2.getEndMillis();
        java.util.Date date10 = simpleTimePeriod2.getStart();
        java.util.Date date11 = simpleTimePeriod2.getStart();
        java.util.Date date12 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "TimePeriodValue[2019,-1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L);
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj10 = timePeriodValues9.clone();
        int int11 = year5.compareTo((java.lang.Object) timePeriodValues9);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
        long long14 = year5.getFirstMillisecond();
        long long15 = year5.getSerialIndex();
        java.util.Date date16 = year5.getStart();
        long long17 = year5.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year5, (double) ' ');
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year5, 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update(0, (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getStartMillis();
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod2.equals(obj10);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues15.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Class<?> wildcardClass20 = timePeriodValues15.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date24 = simpleTimePeriod23.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24);
        boolean boolean28 = simpleTimePeriod2.equals((java.lang.Object) year27);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        int int10 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj16 = timePeriodValues15.clone();
        int int17 = year11.compareTo((java.lang.Object) timePeriodValues15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) (-1L));
        long long20 = year11.getFirstMillisecond();
        long long21 = year11.getSerialIndex();
        int int22 = year11.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year11.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod23, (java.lang.Number) 6);
        timePeriodValues3.add(timePeriodValue25);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) (-1L));
//        long long11 = year2.getLastMillisecond();
//        boolean boolean12 = day0.equals((java.lang.Object) year2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year2.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13, "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 2019", "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setNotify(false);
        java.lang.Object obj13 = timePeriodValues3.clone();
        int int14 = timePeriodValues3.getMinStartIndex();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        int int16 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValues3.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: 2019", "hi!");
        int int4 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        long long18 = year9.getFirstMillisecond();
        long long19 = year9.getSerialIndex();
        int int20 = year0.compareTo((java.lang.Object) year9);
        java.lang.String str21 = year9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year9.previous();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019" + "'", str21.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-31507200000L), 1560409200000L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues6.createCopy((int) (short) 10, 1);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.String str12 = timePeriodValues10.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues10.getDataItem((-50));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues18.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.removePropertyChangeListener(propertyChangeListener21);
        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date27 = simpleTimePeriod26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date27, timeZone28);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date27, timeZone30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues35.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues35.removePropertyChangeListener(propertyChangeListener38);
        java.lang.Class<?> wildcardClass40 = timePeriodValues35.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date44 = simpleTimePeriod43.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date44, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj52 = timePeriodValues51.clone();
        int int53 = year47.compareTo((java.lang.Object) timePeriodValues51);
        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year47, (double) (-1L));
        java.util.Date date56 = year47.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues60.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener63);
        java.lang.Class<?> wildcardClass65 = timePeriodValues60.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date69 = simpleTimePeriod68.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date69, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date56, timeZone70);
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date27, timeZone70);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date13, timeZone70);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
        int int76 = day75.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = day75.previous();
        boolean boolean78 = year74.equals((java.lang.Object) day75);
        boolean boolean80 = year74.equals((java.lang.Object) 43629L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 2019 + "'", int76 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod12);
        timePeriodValues15.setNotify(true);
        java.lang.String str18 = timePeriodValues15.getDomainDescription();
        java.lang.String str19 = timePeriodValues15.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues15.addChangeListener(seriesChangeListener20);
        timePeriodValues15.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        long long6 = day5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-57600000L) + "'", long6 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) (-1L));
//        long long11 = year2.getLastMillisecond();
//        boolean boolean12 = day0.equals((java.lang.Object) year2);
//        int int13 = day0.getYear();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        timePeriodValues3.setKey((java.lang.Comparable) day12);
//        int int17 = timePeriodValues3.getMinMiddleIndex();
//        java.lang.Comparable comparable18 = timePeriodValues3.getKey();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod21, 0.0d);
//        boolean boolean24 = timePeriodValues3.equals((java.lang.Object) regularTimePeriod21);
//        try {
//            timePeriodValues3.delete(2, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertNotNull(comparable18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        int int11 = year0.getYear();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getItemCount();
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10 + "'", comparable11.equals(10));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long6 = simpleTimePeriod5.getStartMillis();
        java.util.Date date7 = simpleTimePeriod5.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues13.setRangeDescription("");
        int int16 = timePeriodValues13.getMinMiddleIndex();
        timePeriodValues13.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable19 = timePeriodValues13.getKey();
        boolean boolean21 = timePeriodValues13.equals((java.lang.Object) (-1));
        java.lang.Object obj22 = timePeriodValues13.clone();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj28 = timePeriodValues27.clone();
        int int29 = year23.compareTo((java.lang.Object) timePeriodValues27);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) (-1L));
        long long32 = year23.getFirstMillisecond();
        long long33 = year23.getSerialIndex();
        int int34 = year23.getYear();
        timePeriodValues13.setKey((java.lang.Comparable) int34);
        int int36 = timePeriodValues13.getItemCount();
        timePeriodValues13.setDomainDescription("TimePeriodValue[2019,-1.0]");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj44 = timePeriodValues43.clone();
        int int45 = year39.compareTo((java.lang.Object) timePeriodValues43);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, 100.0d);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) (-1.0d));
        long long50 = year39.getFirstMillisecond();
        boolean boolean51 = simpleTimePeriod5.equals((java.lang.Object) year39);
        long long52 = year39.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + false + "'", comparable19.equals(false));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 2019L + "'", long52 == 2019L);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.lang.String str9 = year2.toString();
//        java.lang.String str10 = year2.toString();
//        long long11 = year2.getLastMillisecond();
//        int int12 = day0.compareTo((java.lang.Object) long11);
//        long long13 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        int int10 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete((int) ' ', 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        int int8 = day5.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues12.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date21 = simpleTimePeriod20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
//        int int25 = day5.compareTo((java.lang.Object) year24);
//        long long26 = day5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560452399999L + "'", long26 == 1560452399999L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        int int11 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.previous();
        long long13 = year0.getFirstMillisecond();
        org.jfree.data.general.SeriesException seriesException15 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray16 = seriesException15.getSuppressed();
        java.lang.Throwable[] throwableArray17 = seriesException15.getSuppressed();
        boolean boolean18 = year0.equals((java.lang.Object) throwableArray17);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getYear();
//        long long4 = day2.getFirstMillisecond();
//        java.lang.String str5 = day2.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues9.setRangeDescription("");
//        int int12 = timePeriodValues9.getMinMiddleIndex();
//        java.lang.Object obj13 = timePeriodValues9.clone();
//        int int14 = day2.compareTo((java.lang.Object) timePeriodValues9);
//        java.util.Date date15 = day2.getEnd();
//        boolean boolean16 = day0.equals((java.lang.Object) day2);
//        java.lang.Object obj17 = null;
//        int int18 = day2.compareTo(obj17);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy((int) 'a', (int) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable17 = timePeriodValues16.getKey();
        int int18 = timePeriodValues16.getMaxMiddleIndex();
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) int18);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 10 + "'", comparable17.equals(10));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        boolean boolean8 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        long long20 = simpleTimePeriod19.getEndMillis();
        java.util.Date date21 = simpleTimePeriod19.getEnd();
        java.util.Date date22 = simpleTimePeriod19.getStart();
        long long23 = simpleTimePeriod19.getStartMillis();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.lang.String str7 = year0.toString();
        java.lang.String str8 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues12.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues15.fireSeriesChanged();
        timePeriodValues15.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) simpleTimePeriod21, (double) (short) 100);
        timePeriodValues15.update(0, (java.lang.Number) (short) -1);
        boolean boolean27 = timePeriodValues15.getNotify();
        boolean boolean28 = year0.equals((java.lang.Object) timePeriodValues15);
        java.util.Calendar calendar29 = null;
        try {
            year0.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(obj7);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.lang.Class<?> wildcardClass15 = date4.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        long long21 = simpleTimePeriod18.getEndMillis();
        java.util.Date date22 = simpleTimePeriod18.getStart();
        long long23 = simpleTimePeriod18.getStartMillis();
        long long24 = simpleTimePeriod18.getEndMillis();
        java.util.Date date25 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues29.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        java.lang.Class<?> wildcardClass34 = timePeriodValues29.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date38 = simpleTimePeriod37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date25, timeZone41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date25);
        long long45 = year44.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 97L + "'", long24 == 97L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 28799999L + "'", long45 == 28799999L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 100.0d);
        java.lang.String str9 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) str9, "", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 1969");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        java.util.Calendar calendar12 = null;
        try {
            year0.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj20 = timePeriodValues19.clone();
        int int21 = year15.compareTo((java.lang.Object) timePeriodValues19);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) (-1L));
        java.util.Date date24 = year15.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues28.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.removePropertyChangeListener(propertyChangeListener31);
        java.lang.Class<?> wildcardClass33 = timePeriodValues28.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date37 = simpleTimePeriod36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date37, timeZone38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date24, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj46 = timePeriodValues45.clone();
        int int47 = year41.compareTo((java.lang.Object) timePeriodValues45);
        java.lang.String str48 = year41.toString();
        java.lang.String str49 = year41.toString();
        long long50 = year41.getLastMillisecond();
        java.util.Date date51 = year41.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date24, date51);
        java.util.Date date53 = simpleTimePeriod52.getStart();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "2019" + "'", str48.equals("2019"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "2019" + "'", str49.equals("2019"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date53);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        timePeriodValues7.setNotify(true);
//        timePeriodValues7.fireSeriesChanged();
//        int int16 = timePeriodValues7.getMaxMiddleIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int13 = timePeriodValues12.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long17 = simpleTimePeriod16.getStartMillis();
        java.util.Date date18 = simpleTimePeriod16.getEnd();
        timePeriodValues12.setKey((java.lang.Comparable) simpleTimePeriod16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod16);
        long long21 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long25 = simpleTimePeriod24.getStartMillis();
        java.util.Date date26 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year27, "2019", "31-December-1969");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj36 = timePeriodValues35.clone();
        int int37 = year31.compareTo((java.lang.Object) timePeriodValues35);
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) (-1L));
        timePeriodValues30.add(timePeriodValue39);
        boolean boolean41 = simpleTimePeriod16.equals((java.lang.Object) timePeriodValue39);
        timePeriodValues3.add(timePeriodValue39);
        try {
            org.jfree.data.time.TimePeriod timePeriod44 = timePeriodValues3.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int13 = timePeriodValues12.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long17 = simpleTimePeriod16.getStartMillis();
        java.util.Date date18 = simpleTimePeriod16.getEnd();
        timePeriodValues12.setKey((java.lang.Comparable) simpleTimePeriod16);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod16);
        long long21 = simpleTimePeriod16.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long25 = simpleTimePeriod24.getStartMillis();
        java.util.Date date26 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year27, "2019", "31-December-1969");
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj36 = timePeriodValues35.clone();
        int int37 = year31.compareTo((java.lang.Object) timePeriodValues35);
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year31, (double) (-1L));
        timePeriodValues30.add(timePeriodValue39);
        boolean boolean41 = simpleTimePeriod16.equals((java.lang.Object) timePeriodValue39);
        timePeriodValues3.add(timePeriodValue39);
        org.jfree.data.time.TimePeriod timePeriod43 = timePeriodValue39.getPeriod();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 97L + "'", long21 == 97L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(timePeriod43);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        java.lang.Comparable comparable10 = timePeriodValues6.getKey();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener11);
        java.lang.Object obj13 = timePeriodValues6.clone();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10 + "'", comparable10.equals(10));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) (-1));
        java.lang.Object obj12 = timePeriodValues3.clone();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj18 = timePeriodValues17.clone();
        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        long long22 = year13.getFirstMillisecond();
        long long23 = year13.getSerialIndex();
        int int24 = year13.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int24);
        boolean boolean26 = timePeriodValues3.getNotify();
        int int27 = timePeriodValues3.getMinStartIndex();
        boolean boolean28 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date20 = simpleTimePeriod19.getStart();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date25 = simpleTimePeriod24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues30.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date39 = simpleTimePeriod38.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone40);
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date39, timeZone42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone42);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date25, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date20, timeZone42);
        java.util.TimeZone timeZone47 = null;
        try {
            org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date20, timeZone47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0f));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (-1.0f) + "'", obj3.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 1, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getLastMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        int int4 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues6.getMinMiddleIndex();
        timePeriodValues6.setDescription("TimePeriodValue[2019,-1.0]");
        int int10 = timePeriodValues6.getMaxStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean9 = timePeriodValues4.equals((java.lang.Object) timePeriodValues8);
        int int10 = timePeriodValues4.getMinStartIndex();
        boolean boolean11 = year0.equals((java.lang.Object) timePeriodValues4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray9 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray10 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray11 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray12 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        timePeriodValue7.setValue((java.lang.Number) (byte) 0);
//        java.lang.Number number10 = timePeriodValue7.getValue();
//        timePeriodValue7.setValue((java.lang.Number) (-47318400001L));
//        timePeriodValue7.setValue((java.lang.Number) (byte) 0);
//        java.lang.Number number15 = timePeriodValue7.getValue();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
//        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (byte) 0 + "'", number15.equals((byte) 0));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinMiddleIndex();
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) 1577865599999L);
        java.lang.Number number11 = timePeriodValue10.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1577865599999L + "'", number11.equals(1577865599999L));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1969);
        long long2 = year1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-15739200001L) + "'", long2 == (-15739200001L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        int int13 = day0.compareTo((java.lang.Object) 11);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        boolean boolean22 = timePeriodValues17.equals((java.lang.Object) timePeriodValues21);
//        timePeriodValues17.setKey((java.lang.Comparable) 100);
//        timePeriodValues17.fireSeriesChanged();
//        boolean boolean26 = day0.equals((java.lang.Object) timePeriodValues17);
//        long long27 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day0.next();
//        java.util.Date date29 = regularTimePeriod28.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date29);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        long long12 = day0.getFirstMillisecond();
//        java.lang.String str13 = day0.toString();
//        java.util.Date date14 = day0.getStart();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day0.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        long long15 = simpleTimePeriod14.getStartMillis();
        long long16 = simpleTimePeriod14.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 97L + "'", long15 == 97L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 97L + "'", long16 == 97L);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        int int2 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long6 = simpleTimePeriod5.getStartMillis();
//        java.util.Date date7 = simpleTimePeriod5.getEnd();
//        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues13.setRangeDescription("");
//        int int16 = timePeriodValues13.getMinMiddleIndex();
//        timePeriodValues13.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable19 = timePeriodValues13.getKey();
//        boolean boolean21 = timePeriodValues13.equals((java.lang.Object) (-1));
//        java.lang.Object obj22 = timePeriodValues13.clone();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj28 = timePeriodValues27.clone();
//        int int29 = year23.compareTo((java.lang.Object) timePeriodValues27);
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) (-1L));
//        long long32 = year23.getFirstMillisecond();
//        long long33 = year23.getSerialIndex();
//        int int34 = year23.getYear();
//        timePeriodValues13.setKey((java.lang.Comparable) int34);
//        int int36 = timePeriodValues13.getItemCount();
//        timePeriodValues13.setDomainDescription("TimePeriodValue[2019,-1.0]");
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj44 = timePeriodValues43.clone();
//        int int45 = year39.compareTo((java.lang.Object) timePeriodValues43);
//        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, 100.0d);
//        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) (-1.0d));
//        long long50 = year39.getFirstMillisecond();
//        boolean boolean51 = simpleTimePeriod5.equals((java.lang.Object) year39);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        int int53 = day52.getYear();
//        long long54 = day52.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate55 = day52.getSerialDate();
//        java.lang.Object obj56 = null;
//        int int57 = day52.compareTo(obj56);
//        boolean boolean58 = simpleTimePeriod5.equals((java.lang.Object) day52);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + false + "'", comparable19.equals(false));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertNotNull(obj28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(obj44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        try {
            java.lang.Number number10 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (8) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.util.Date date0 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long4 = simpleTimePeriod3.getStartMillis();
        java.util.Date date5 = simpleTimePeriod3.getEnd();
        long long6 = simpleTimePeriod3.getEndMillis();
        java.util.Date date7 = simpleTimePeriod3.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj13 = timePeriodValues12.clone();
        int int14 = timePeriodValues12.getMinStartIndex();
        java.lang.Class<?> wildcardClass15 = timePeriodValues12.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        int int22 = year21.getYear();
        java.util.Date date23 = year21.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues27.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener30);
        java.lang.Class<?> wildcardClass32 = timePeriodValues27.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date36 = simpleTimePeriod35.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass32);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize(class39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date44 = simpleTimePeriod43.getStart();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date49 = simpleTimePeriod48.getStart();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues54.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener57);
        java.lang.Class<?> wildcardClass59 = timePeriodValues54.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date63 = simpleTimePeriod62.getStart();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date63, timeZone66);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone66);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date49, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date44, timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date23, timeZone66);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date7, timeZone66);
        try {
            org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date0, timeZone66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1969 + "'", int22 == 1969);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.lang.String str9 = timePeriodValue8.toString();
        java.lang.String str10 = timePeriodValue8.toString();
        java.lang.Object obj11 = timePeriodValue8.clone();
        boolean boolean13 = timePeriodValue8.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue8.getPeriod();
        java.lang.Number number15 = timePeriodValue8.getValue();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj21 = timePeriodValues20.clone();
        int int22 = year16.compareTo((java.lang.Object) timePeriodValues20);
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) (-1L));
        java.util.Date date25 = year16.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year16.previous();
        java.util.Date date27 = regularTimePeriod26.getStart();
        boolean boolean28 = timePeriodValue8.equals((java.lang.Object) date27);
        java.lang.Object obj29 = timePeriodValue8.clone();
        java.lang.Object obj30 = timePeriodValue8.clone();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str9.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str10.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timePeriod14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-1.0d) + "'", number15.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj30);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.lang.String str9 = year8.toString();
        java.util.Date date10 = year8.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long14 = simpleTimePeriod13.getStartMillis();
        java.util.Date date15 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        int int17 = year16.getYear();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int21 = timePeriodValues20.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long25 = simpleTimePeriod24.getStartMillis();
        java.util.Date date26 = simpleTimePeriod24.getEnd();
        timePeriodValues20.setKey((java.lang.Comparable) simpleTimePeriod24);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod24);
        long long29 = simpleTimePeriod24.getStartMillis();
        java.util.Date date30 = simpleTimePeriod24.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues34.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.Class<?> wildcardClass39 = timePeriodValues34.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date43 = simpleTimePeriod42.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date43, timeZone46);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date30, timeZone46);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date18, timeZone46);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date10, timeZone46);
        int int52 = day51.getDayOfMonth();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 31 + "'", int52 == 31);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day10, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        timePeriodValues3.setKey((java.lang.Comparable) day12);
//        int int17 = timePeriodValues3.getMinMiddleIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener18);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str12 = timePeriodValues3.getDescription();
        java.lang.Object obj13 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues17.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues20.fireSeriesChanged();
        timePeriodValues20.setDescription("hi!");
        timePeriodValues20.setRangeDescription("");
        int int26 = timePeriodValues20.getMinEndIndex();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj32 = timePeriodValues31.clone();
        int int33 = year27.compareTo((java.lang.Object) timePeriodValues31);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) (-1L));
        java.lang.String str36 = timePeriodValue35.toString();
        timePeriodValue35.setValue((java.lang.Number) 0.0f);
        java.lang.Number number39 = timePeriodValue35.getValue();
        java.lang.String str40 = timePeriodValue35.toString();
        timePeriodValues20.add(timePeriodValue35);
        timePeriodValues3.add(timePeriodValue35);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str36.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 0.0f + "'", number39.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str40.equals("TimePeriodValue[2019,0.0]"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj6 = timePeriodValues5.clone();
        int int7 = year1.compareTo((java.lang.Object) timePeriodValues5);
        java.util.Date date8 = year1.getEnd();
        int int9 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year1.previous();
        java.util.Date date11 = year1.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int14 = timePeriodValues13.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long18 = simpleTimePeriod17.getStartMillis();
        java.util.Date date19 = simpleTimePeriod17.getEnd();
        timePeriodValues13.setKey((java.lang.Comparable) simpleTimePeriod17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod17);
        long long22 = simpleTimePeriod17.getStartMillis();
        java.util.Date date23 = simpleTimePeriod17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues27.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener30);
        java.lang.Class<?> wildcardClass32 = timePeriodValues27.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date36 = simpleTimePeriod35.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date36, timeZone37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date36, timeZone39);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone39);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date23, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date11, timeZone39);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod43);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod8, (java.lang.Number) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj12 = timePeriodValues11.clone();
//        int int13 = year7.compareTo((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1L));
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValue15);
//        org.jfree.data.time.SerialDate serialDate17 = day0.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        java.util.Date date9 = year2.getEnd();
        int int10 = year2.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        int int13 = day0.compareTo((java.lang.Object) 11);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1546329600000L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj27 = timePeriodValues26.clone();
        int int28 = year22.compareTo((java.lang.Object) timePeriodValues26);
        java.util.Date date29 = year22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date20, date29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues34.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.Class<?> wildcardClass39 = timePeriodValues34.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date43 = simpleTimePeriod42.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date43, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues51.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues51.removePropertyChangeListener(propertyChangeListener54);
        java.lang.Class<?> wildcardClass56 = timePeriodValues51.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date60 = simpleTimePeriod59.getStart();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj68 = timePeriodValues67.clone();
        int int69 = year63.compareTo((java.lang.Object) timePeriodValues67);
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (double) (-1L));
        java.util.Date date72 = year63.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues76.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener79 = null;
        timePeriodValues76.removePropertyChangeListener(propertyChangeListener79);
        java.lang.Class<?> wildcardClass81 = timePeriodValues76.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date85 = simpleTimePeriod84.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date85, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date72, timeZone86);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date43, timeZone86);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date29, timeZone86);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day();
        int int92 = day91.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = day91.previous();
        boolean boolean94 = year90.equals((java.lang.Object) day91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = year90.previous();
        boolean boolean96 = timePeriodValue15.equals((java.lang.Object) year90);
        org.jfree.data.time.TimePeriodValue timePeriodValue98 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year90, 0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2019 + "'", int92 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj10 = timePeriodValues9.clone();
//        int int11 = year5.compareTo((java.lang.Object) timePeriodValues9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year5, (double) (-1L));
//        long long14 = year5.getFirstMillisecond();
//        long long15 = year5.getSerialIndex();
//        long long16 = year5.getFirstMillisecond();
//        java.lang.String str17 = year5.toString();
//        boolean boolean18 = day0.equals((java.lang.Object) year5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj12 = timePeriodValues11.clone();
//        int int13 = year7.compareTo((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1L));
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValue15);
//        org.jfree.data.time.SerialDate serialDate17 = day0.getSerialDate();
//        long long18 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj23 = timePeriodValues22.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues22.createCopy(0, (int) (short) 1);
//        int int27 = timePeriodValues22.getMinStartIndex();
//        int int28 = timePeriodValues22.getMinStartIndex();
//        timePeriodValues22.setDescription("2019");
//        timePeriodValues22.setKey((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: 1969");
//        boolean boolean33 = timePeriodValues22.isEmpty();
//        int int34 = day0.compareTo((java.lang.Object) timePeriodValues22);
//        java.lang.String str35 = timePeriodValues22.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560495599999L + "'", long18 == 1560495599999L);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertNotNull(timePeriodValues26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray8 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray10 = seriesException7.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException7);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.Throwable[] throwableArray13 = seriesException7.getSuppressed();
        java.lang.Throwable[] throwableArray14 = seriesException7.getSuppressed();
        java.lang.String str15 = seriesException7.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str15.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        long long6 = simpleTimePeriod2.getEndMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        long long8 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 97L + "'", long6 == 97L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long11 = simpleTimePeriod10.getStartMillis();
        java.util.Date date12 = simpleTimePeriod10.getEnd();
        long long13 = simpleTimePeriod10.getEndMillis();
        java.util.Date date14 = simpleTimePeriod10.getStart();
        long long15 = simpleTimePeriod10.getStartMillis();
        long long16 = simpleTimePeriod10.getStartMillis();
        try {
            int int17 = simpleTimePeriod2.compareTo((java.lang.Object) long16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        int int11 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        long long15 = year0.getLastMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        int int12 = timePeriodValues3.getItemCount();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues3.createCopy((int) '4', (-1));
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDomainDescription("");
        int int10 = timePeriodValues3.getMinEndIndex();
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,0.0]");
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long9 = simpleTimePeriod8.getStartMillis();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        timePeriodValues4.setKey((java.lang.Comparable) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8);
        long long13 = simpleTimePeriod8.getStartMillis();
        java.util.Date date14 = simpleTimePeriod8.getStart();
        boolean boolean15 = day0.equals((java.lang.Object) simpleTimePeriod8);
        java.util.Date date16 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setDescription("TimePeriodValue[12-June-2019,0.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy((int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDomainDescription("");
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        boolean boolean11 = timePeriodValues3.getNotify();
        boolean boolean12 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues16.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener19);
        timePeriodValues16.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj23 = timePeriodValues16.clone();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj29 = timePeriodValues28.clone();
        int int30 = year24.compareTo((java.lang.Object) timePeriodValues28);
        java.lang.String str31 = year24.toString();
        java.lang.String str32 = year24.toString();
        long long33 = year24.getLastMillisecond();
        java.util.Date date34 = year24.getStart();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 1560495599999L);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) 2019);
        long long39 = year24.getSerialIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2019" + "'", str31.equals("2019"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "2019" + "'", str32.equals("2019"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long6 = simpleTimePeriod5.getStartMillis();
        java.util.Date date7 = simpleTimePeriod5.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues13.setRangeDescription("");
        int int16 = timePeriodValues13.getMinMiddleIndex();
        timePeriodValues13.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable19 = timePeriodValues13.getKey();
        boolean boolean21 = timePeriodValues13.equals((java.lang.Object) (-1));
        java.lang.Object obj22 = timePeriodValues13.clone();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj28 = timePeriodValues27.clone();
        int int29 = year23.compareTo((java.lang.Object) timePeriodValues27);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year23, (double) (-1L));
        long long32 = year23.getFirstMillisecond();
        long long33 = year23.getSerialIndex();
        int int34 = year23.getYear();
        timePeriodValues13.setKey((java.lang.Comparable) int34);
        int int36 = timePeriodValues13.getItemCount();
        timePeriodValues13.setDomainDescription("TimePeriodValue[2019,-1.0]");
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj44 = timePeriodValues43.clone();
        int int45 = year39.compareTo((java.lang.Object) timePeriodValues43);
        org.jfree.data.time.TimePeriodValue timePeriodValue47 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year39, 100.0d);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) year39, (java.lang.Number) (-1.0d));
        long long50 = year39.getFirstMillisecond();
        boolean boolean51 = simpleTimePeriod5.equals((java.lang.Object) year39);
        java.util.Date date52 = simpleTimePeriod5.getStart();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + false + "'", comparable19.equals(false));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod12);
        timePeriodValues15.setDescription("TimePeriodValue[2019,0.0]");
        try {
            java.lang.Number number19 = timePeriodValues15.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        long long8 = year5.getMiddleMillisecond();
        java.lang.String str9 = year5.toString();
        java.util.Date date10 = year5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-15739200001L) + "'", long8 == (-15739200001L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.lang.String str9 = timePeriodValue8.toString();
        java.lang.Number number10 = timePeriodValue8.getValue();
        java.lang.Number number11 = timePeriodValue8.getValue();
        timePeriodValue8.setValue((java.lang.Number) 0.0f);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str9.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.0d) + "'", number10.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj12 = timePeriodValues11.clone();
//        int int13 = year7.compareTo((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1L));
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValue15);
//        org.jfree.data.time.SerialDate serialDate17 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.lang.String str9 = timePeriodValue8.toString();
        java.lang.String str10 = timePeriodValue8.toString();
        java.lang.Object obj11 = timePeriodValue8.clone();
        boolean boolean13 = timePeriodValue8.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue8.getPeriod();
        timePeriodValue8.setValue((java.lang.Number) (-57600000L));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str9.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str10.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timePeriod14);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Number number10 = null;
        try {
            timePeriodValues3.update(12, number10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        long long13 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues17.createCopy((int) (short) 1, (int) (byte) 100);
//        timePeriodValues20.fireSeriesChanged();
//        int int22 = timePeriodValues20.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy(10, (int) '#');
//        boolean boolean26 = day0.equals((java.lang.Object) timePeriodValues20);
//        try {
//            timePeriodValues20.update((int) (byte) 100, (java.lang.Number) 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.lang.Object obj15 = null;
        boolean boolean16 = simpleTimePeriod14.equals(obj15);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod14, "31-December-1969", "13-June-2019");
        int int20 = timePeriodValues19.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setDomainDescription("13-June-2019");
        int int10 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getYear();
//        long long4 = day2.getFirstMillisecond();
//        java.lang.String str5 = day2.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues9.setRangeDescription("");
//        int int12 = timePeriodValues9.getMinMiddleIndex();
//        java.lang.Object obj13 = timePeriodValues9.clone();
//        int int14 = day2.compareTo((java.lang.Object) timePeriodValues9);
//        java.util.Date date15 = day2.getEnd();
//        boolean boolean16 = day0.equals((java.lang.Object) day2);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj22 = timePeriodValues21.clone();
//        int int23 = year17.compareTo((java.lang.Object) timePeriodValues21);
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 100.0d);
//        java.lang.String str26 = year17.toString();
//        int int27 = day2.compareTo((java.lang.Object) str26);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0f));
//        java.lang.String str30 = seriesChangeEvent29.toString();
//        java.lang.Object obj31 = seriesChangeEvent29.getSource();
//        java.lang.String str32 = seriesChangeEvent29.toString();
//        int int33 = day2.compareTo((java.lang.Object) seriesChangeEvent29);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str30.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
//        org.junit.Assert.assertTrue("'" + obj31 + "' != '" + (-1.0f) + "'", obj31.equals((-1.0f)));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str32.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues3.createCopy((int) (short) 100, 2);
        int int12 = timePeriodValues11.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(timePeriodValues11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 1);
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) (-1L));
        java.lang.String str11 = timePeriodValue10.toString();
        java.lang.String str12 = timePeriodValue10.toString();
        java.lang.Number number13 = timePeriodValue10.getValue();
        java.lang.Number number14 = timePeriodValue10.getValue();
        java.lang.Object obj15 = timePeriodValue10.clone();
        java.lang.String str16 = timePeriodValue10.toString();
        boolean boolean17 = timePeriodValues1.equals((java.lang.Object) str16);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str11.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str12.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0d) + "'", number14.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str16.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        long long20 = simpleTimePeriod19.getEndMillis();
        java.util.Date date21 = simpleTimePeriod19.getEnd();
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date24, "org.jfree.data.time.TimePeriodFormatException: 1969", "TimePeriodValue[2019,100.0]");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date22, date24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj16 = timePeriodValues15.clone();
        int int17 = year11.compareTo((java.lang.Object) timePeriodValues15);
        java.lang.String str18 = year11.toString();
        java.lang.String str19 = year11.toString();
        long long20 = year11.getLastMillisecond();
        java.util.Date date21 = year11.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 1560495599999L);
        timePeriodValues3.setDescription("TimePeriodValue[2019,null]");
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        int int8 = year0.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        java.util.Date date18 = year9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        java.util.Date date20 = regularTimePeriod19.getStart();
        int int21 = year0.compareTo((java.lang.Object) date20);
        java.lang.String str22 = year0.toString();
        java.lang.Object obj23 = null;
        int int24 = year0.compareTo(obj23);
        long long25 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2019" + "'", str22.equals("2019"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        java.util.Date date8 = day5.getEnd();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.lang.Object obj4 = null;
//        int int5 = day0.compareTo(obj4);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        int int6 = timePeriodValues3.getMinStartIndex();
//        int int7 = timePeriodValues3.getMinStartIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) 100L);
//        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues15.setRangeDescription("");
//        timePeriodValues15.setDescription("hi!");
//        java.lang.Comparable comparable20 = timePeriodValues15.getKey();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        int int22 = timePeriodValues15.getMinStartIndex();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        int int24 = day23.getYear();
//        long long25 = day23.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day23.next();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) regularTimePeriod26, (java.lang.Number) 100);
//        boolean boolean29 = timePeriodValues3.equals((java.lang.Object) timePeriodValues15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener30);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 10 + "'", comparable20.equals(10));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560495599999L + "'", long25 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxEndIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.lang.String str13 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        int int11 = year0.getYear();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long15 = simpleTimePeriod14.getStartMillis();
        java.util.Date date16 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        java.lang.String str18 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        long long20 = year17.getMiddleMillisecond();
        java.lang.String str21 = year17.toString();
        int int22 = year0.compareTo((java.lang.Object) year17);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-15739200001L) + "'", long20 == (-15739200001L));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969" + "'", str21.equals("1969"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 50 + "'", int22 == 50);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-50));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-50) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        int int9 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str11 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues3.getDescription();
        boolean boolean14 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj20 = timePeriodValues19.clone();
        int int21 = timePeriodValues19.getMinStartIndex();
        java.lang.Class<?> wildcardClass22 = timePeriodValues19.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long27 = simpleTimePeriod26.getStartMillis();
        java.util.Date date28 = simpleTimePeriod26.getEnd();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj35 = timePeriodValues34.clone();
        int int36 = year30.compareTo((java.lang.Object) timePeriodValues34);
        java.util.Date date37 = year30.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date28, date37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date42 = simpleTimePeriod41.getStart();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date42);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues47.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timePeriodValues47.removePropertyChangeListener(propertyChangeListener50);
        java.lang.Class<?> wildcardClass52 = timePeriodValues47.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date56 = simpleTimePeriod55.getStart();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date56, timeZone57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date56, timeZone59);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone59);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date42, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date37, timeZone59);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date12, timeZone59);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod63);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        int int4 = timePeriodValues3.getMaxMiddleIndex();
//        int int5 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getYear();
//        long long8 = day6.getLastMillisecond();
//        long long9 = day6.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 7);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) (-1L));
//        java.lang.Number number15 = null;
//        try {
//            timePeriodValues3.update((-1), number15);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getDayOfMonth();
//        java.util.Calendar calendar7 = null;
//        try {
//            day0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        int int6 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(2, (int) (short) 10);
        timePeriodValues9.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10 + "'", comparable4.equals(10));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "13-June-2019", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues12.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 100, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        int int11 = year0.getYear();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue13);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue13.getPeriod();
        timePeriodValue13.setValue((java.lang.Number) 5);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(timePeriod15);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
//        timePeriodValues6.fireSeriesChanged();
//        int int8 = timePeriodValues6.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = timePeriodValues6.createCopy(10, (int) '#');
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj20 = timePeriodValues19.clone();
//        int int21 = year15.compareTo((java.lang.Object) timePeriodValues19);
//        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, 100.0d);
//        int int24 = day12.compareTo((java.lang.Object) year15);
//        java.util.Date date25 = day12.getEnd();
//        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day12, (double) 8);
//        try {
//            timePeriodValues6.update((int) ' ', (java.lang.Number) 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(obj20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        long long8 = year5.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues12.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date21 = simpleTimePeriod20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date21, timeZone24);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues29.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        java.lang.Class<?> wildcardClass34 = timePeriodValues29.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date38 = simpleTimePeriod37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj46 = timePeriodValues45.clone();
        int int47 = year41.compareTo((java.lang.Object) timePeriodValues45);
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year41, (double) (-1L));
        java.util.Date date50 = year41.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues54.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener57 = null;
        timePeriodValues54.removePropertyChangeListener(propertyChangeListener57);
        java.lang.Class<?> wildcardClass59 = timePeriodValues54.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date63 = simpleTimePeriod62.getStart();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date63, timeZone64);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date50, timeZone64);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date21, timeZone64);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj73 = timePeriodValues72.clone();
        int int74 = year68.compareTo((java.lang.Object) timePeriodValues72);
        org.jfree.data.time.TimePeriodValue timePeriodValue76 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year68, 100.0d);
        int int77 = day67.compareTo((java.lang.Object) 100.0d);
        int int78 = year5.compareTo((java.lang.Object) int77);
        long long79 = year5.getFirstMillisecond();
        long long80 = year5.getSerialIndex();
        java.util.Calendar calendar81 = null;
        try {
            long long82 = year5.getLastMillisecond(calendar81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNull(regularTimePeriod65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(obj73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-31507200000L) + "'", long79 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1969L + "'", long80 == 1969L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.lang.String str7 = year0.toString();
        java.lang.String str8 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 5);
        long long11 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        int int13 = year0.getYear();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.previous();
        long long7 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        long long9 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj10 = null;
        try {
            int int11 = simpleTimePeriod2.compareTo(obj10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 1969" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: 1969"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        int int8 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year0.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year0.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
//        int int7 = timePeriodValues3.getMinStartIndex();
//        int int8 = timePeriodValues3.getMaxEndIndex();
//        int int9 = timePeriodValues3.getItemCount();
//        java.lang.Object obj10 = timePeriodValues3.clone();
//        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener12);
//        java.lang.String str14 = timePeriodValues3.getDescription();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        long long17 = day15.getLastMillisecond();
//        long long18 = day15.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate19 = day15.getSerialDate();
//        timePeriodValues3.setKey((java.lang.Comparable) serialDate19);
//        boolean boolean21 = timePeriodValues3.getNotify();
//        org.junit.Assert.assertNotNull(timePeriodValues6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10 + "'", comparable11.equals(10));
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) 'a', 2019);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = day11.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj18 = timePeriodValues17.clone();
        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
        java.util.Date date20 = year13.getEnd();
        int int21 = year13.getYear();
        boolean boolean22 = day11.equals((java.lang.Object) int21);
        int int24 = day11.compareTo((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day11.next();
        timePeriodValues10.setKey((java.lang.Comparable) day11);
        int int27 = timePeriodValues10.getMaxStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        timePeriodValues3.setDescription("hi!");
//        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
//        int int9 = timePeriodValues3.getMinStartIndex();
//        int int10 = timePeriodValues3.getMinStartIndex();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        long long13 = day11.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (java.lang.Number) 100);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        int int19 = timePeriodValues18.getMaxStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long23 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date24 = simpleTimePeriod22.getEnd();
//        timePeriodValues18.setKey((java.lang.Comparable) simpleTimePeriod22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod22);
//        long long27 = simpleTimePeriod22.getStartMillis();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, 0.0d);
//        org.jfree.data.general.SeriesException seriesException31 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
//        boolean boolean32 = simpleTimePeriod22.equals((java.lang.Object) seriesException31);
//        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
//        long long8 = day7.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43629L + "'", long8 == 43629L);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 43629L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        int int11 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        int int15 = year0.getYear();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        int int8 = day5.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues12.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues12.removePropertyChangeListener(propertyChangeListener15);
//        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date21 = simpleTimePeriod20.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
//        int int25 = day5.compareTo((java.lang.Object) year24);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues32 = timePeriodValues29.createCopy((int) (short) 1, (int) (byte) 100);
//        timePeriodValues32.fireSeriesChanged();
//        timePeriodValues32.setDescription("hi!");
//        timePeriodValues32.setRangeDescription("");
//        int int38 = day5.compareTo((java.lang.Object) timePeriodValues32);
//        try {
//            timePeriodValues32.delete(8, 1969);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(timePeriodValues32);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean4 = timePeriodValues3.isEmpty();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Number number7 = null;
        try {
            timePeriodValues3.update(12, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        long long12 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-31507200000L), 1560409200000L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-31507200000L) + "'", long3 == (-31507200000L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        int int8 = year0.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        java.util.Date date18 = year9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        java.util.Date date20 = regularTimePeriod19.getStart();
        int int21 = year0.compareTo((java.lang.Object) date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "hi!", "hi!");
        int int26 = year0.compareTo((java.lang.Object) "hi!");
        long long27 = year0.getFirstMillisecond();
        int int28 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year0.next();
        java.util.Calendar calendar30 = null;
        try {
            long long31 = year0.getMiddleMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        timePeriodValue7.setValue((java.lang.Number) (byte) 0);
//        java.lang.Number number10 = timePeriodValue7.getValue();
//        timePeriodValue7.setValue((java.lang.Number) (-47318400001L));
//        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue7.getPeriod();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
//        org.junit.Assert.assertNotNull(timePeriod13);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year2, (double) (-1L));
//        java.lang.String str11 = timePeriodValue10.toString();
//        java.lang.String str12 = timePeriodValue10.toString();
//        java.lang.Object obj13 = timePeriodValue10.clone();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue10.getPeriod();
//        int int15 = day0.compareTo((java.lang.Object) timePeriod14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str11.equals("TimePeriodValue[2019,-1.0]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str12.equals("TimePeriodValue[2019,-1.0]"));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(10, 0);
        try {
            timePeriodValues3.delete(2, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        java.lang.String str2 = seriesChangeEvent1.toString();
//        java.lang.String str3 = seriesChangeEvent1.toString();
//        java.lang.Object obj4 = seriesChangeEvent1.getSource();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=13-June-2019]"));
//        org.junit.Assert.assertNotNull(obj4);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        int int11 = year0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 0.0d);
        java.util.Calendar calendar15 = null;
        try {
            year0.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        int int16 = day0.getDayOfMonth();
//        int int17 = day0.getYear();
//        int int18 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        timePeriodValue7.setValue((java.lang.Number) (byte) 0);
//        timePeriodValue7.setValue((java.lang.Number) 2019L);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        timePeriodValues3.setNotify(false);
//        timePeriodValues3.fireSeriesChanged();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj16 = timePeriodValues15.clone();
//        int int17 = year11.compareTo((java.lang.Object) timePeriodValues15);
//        java.util.Date date18 = year11.getEnd();
//        int int19 = year11.getYear();
//        boolean boolean20 = day9.equals((java.lang.Object) int19);
//        long long21 = day9.getFirstMillisecond();
//        java.lang.String str22 = day9.toString();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (double) 1969);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(obj16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        java.lang.Object obj10 = timePeriodValues3.clone();
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener12);
        boolean boolean14 = timePeriodValues3.getNotify();
        java.lang.Comparable comparable15 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues3.getDataItem((-50));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10 + "'", comparable11.equals(10));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 10 + "'", comparable15.equals(10));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "13-June-2019", "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 2019");
        long long13 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', (-50), 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        int int13 = day0.compareTo((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.next();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
//        java.lang.String str18 = day15.toString();
//        int int19 = day0.compareTo((java.lang.Object) str18);
//        int int20 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        java.util.Date date7 = year5.getStart();
        java.lang.String str8 = year5.toString();
        long long9 = year5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-15739200001L) + "'", long9 == (-15739200001L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 1);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = timePeriodValues1.createCopy((-1), 0);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        int int14 = year6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year6.previous();
        boolean boolean16 = timePeriodValues5.equals((java.lang.Object) year6);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        int int23 = timePeriodValues20.getMinMiddleIndex();
        timePeriodValues20.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable26 = timePeriodValues20.getKey();
        boolean boolean28 = timePeriodValues20.equals((java.lang.Object) (-1));
        java.lang.Comparable comparable29 = timePeriodValues20.getKey();
        boolean boolean30 = timePeriodValues5.equals((java.lang.Object) comparable29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues5);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + false + "'", comparable26.equals(false));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + false + "'", comparable29.equals(false));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year5, "2019", "31-December-1969");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        timePeriodValues8.add(timePeriodValue17);
        java.lang.Object obj19 = timePeriodValue17.clone();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str5 = timePeriodFormatException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray14 = seriesException13.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str17 = timePeriodFormatException16.toString();
        seriesException13.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) seriesException13);
        seriesException9.addSuppressed((java.lang.Throwable) seriesException13);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException13);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinStartIndex();
        int int7 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) 100L);
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        long long13 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj21 = timePeriodValues20.clone();
//        int int22 = year16.compareTo((java.lang.Object) timePeriodValues20);
//        java.util.Date date23 = year16.getEnd();
//        int int24 = year16.getYear();
//        boolean boolean25 = day14.equals((java.lang.Object) int24);
//        long long26 = day14.getFirstMillisecond();
//        java.lang.String str27 = day14.toString();
//        java.util.Date date28 = day14.getStart();
//        boolean boolean29 = day0.equals((java.lang.Object) date28);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues33.setRangeDescription("");
//        int int36 = timePeriodValues33.getMinMiddleIndex();
//        timePeriodValues33.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable39 = timePeriodValues33.getKey();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener40 = null;
//        timePeriodValues33.addChangeListener(seriesChangeListener40);
//        int int42 = day0.compareTo((java.lang.Object) seriesChangeListener40);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + false + "'", comparable39.equals(false));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        int int6 = day5.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        long long8 = day5.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        long long9 = simpleTimePeriod2.getEndMillis();
        java.util.Date date10 = simpleTimePeriod2.getStart();
        java.util.Date date11 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long15 = simpleTimePeriod14.getStartMillis();
        java.util.Date date16 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date11, date16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        try {
            timePeriodValues3.delete((-50), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj10 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("hi!");
        int int13 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 1);
        int int8 = timePeriodValues3.getMinStartIndex();
        int int9 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener2);
        int int4 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod12);
        timePeriodValues15.setNotify(true);
        java.lang.String str18 = timePeriodValues15.getDomainDescription();
        java.lang.String str19 = timePeriodValues15.getDomainDescription();
        java.lang.String str20 = timePeriodValues15.getDescription();
        int int21 = timePeriodValues15.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int6 = timePeriodValues5.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long10 = simpleTimePeriod9.getStartMillis();
        java.util.Date date11 = simpleTimePeriod9.getEnd();
        timePeriodValues5.setKey((java.lang.Comparable) simpleTimePeriod9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod9);
        long long14 = simpleTimePeriod9.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long18 = simpleTimePeriod17.getStartMillis();
        java.util.Date date19 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year20, "2019", "31-December-1969");
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj29 = timePeriodValues28.clone();
        int int30 = year24.compareTo((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year24, (double) (-1L));
        timePeriodValues23.add(timePeriodValue32);
        boolean boolean34 = simpleTimePeriod9.equals((java.lang.Object) timePeriodValue32);
        java.lang.Number number35 = timePeriodValue32.getValue();
        try {
            int int36 = simpleTimePeriod2.compareTo((java.lang.Object) number35);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 97L + "'", long14 == 97L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (-1.0d) + "'", number35.equals((-1.0d)));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) ' ', 10);
        int int9 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update(8, (java.lang.Number) 7L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,-1.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = seriesException9.getSuppressed();
        java.lang.Throwable[] throwableArray12 = seriesException9.getSuppressed();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException9);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.String str15 = seriesException9.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str15.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        int int2 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj19 = timePeriodValues18.clone();
        int int20 = year14.compareTo((java.lang.Object) timePeriodValues18);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (-1L));
        long long23 = year14.getFirstMillisecond();
        long long24 = year14.getSerialIndex();
        int int25 = year14.getYear();
        java.lang.Number number26 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, number26);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue27);
        boolean boolean29 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent28);
        java.lang.Object obj30 = seriesChangeEvent28.getSource();
        java.lang.String str31 = seriesChangeEvent28.toString();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[2019,null]]" + "'", str31.equals("org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[2019,null]]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, 43629L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues6.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues9.fireSeriesChanged();
        timePeriodValues9.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod15);
        timePeriodValues18.setNotify(true);
        java.lang.String str21 = timePeriodValues18.getDomainDescription();
        java.lang.String str22 = timePeriodValues18.getRangeDescription();
        boolean boolean23 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues18);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 1, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.lang.Object obj15 = null;
        boolean boolean16 = simpleTimePeriod14.equals(obj15);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod14, "31-December-1969", "13-June-2019");
        try {
            timePeriodValues19.delete(5, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        long long18 = year9.getFirstMillisecond();
        long long19 = year9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy((int) (short) 1, 0);
        java.lang.String str26 = timePeriodValues25.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timePeriodValues25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        timePeriodValues3.setKey((java.lang.Comparable) day12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        int int19 = timePeriodValues18.getMaxStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long23 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date24 = simpleTimePeriod22.getEnd();
//        timePeriodValues18.setKey((java.lang.Comparable) simpleTimePeriod22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod22);
//        long long27 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date28 = simpleTimePeriod22.getStart();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 43629L);
//        timePeriodValues3.setRangeDescription("31-December-1969");
//        java.lang.Comparable comparable33 = timePeriodValues3.getKey();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(comparable33);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setNotify(false);
        java.lang.Object obj13 = timePeriodValues3.clone();
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("");
        int int18 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        timePeriodValues3.setKey((java.lang.Comparable) 1L);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        int int13 = day12.getYear();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj19 = timePeriodValues18.clone();
        int int20 = year14.compareTo((java.lang.Object) timePeriodValues18);
        java.util.Date date21 = year14.getEnd();
        int int22 = year14.getYear();
        boolean boolean23 = day12.equals((java.lang.Object) int22);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) 0L);
        try {
            timePeriodValues3.delete(12, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDomainDescription("");
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        timePeriodValues3.fireSeriesChanged();
        int int12 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + 10 + "'", comparable13.equals(10));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long11 = simpleTimePeriod10.getStartMillis();
        java.util.Date date12 = simpleTimePeriod10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj19 = timePeriodValues18.clone();
        int int20 = year14.compareTo((java.lang.Object) timePeriodValues18);
        java.util.Date date21 = year14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date12, date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues26.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
        java.lang.Class<?> wildcardClass31 = timePeriodValues26.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date35 = simpleTimePeriod34.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass31, date35, timeZone36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date35, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues43.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.removePropertyChangeListener(propertyChangeListener46);
        java.lang.Class<?> wildcardClass48 = timePeriodValues43.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date52 = simpleTimePeriod51.getStart();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date52, timeZone53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj60 = timePeriodValues59.clone();
        int int61 = year55.compareTo((java.lang.Object) timePeriodValues59);
        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year55, (double) (-1L));
        java.util.Date date64 = year55.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues68.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timePeriodValues68.removePropertyChangeListener(propertyChangeListener71);
        java.lang.Class<?> wildcardClass73 = timePeriodValues68.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date77 = simpleTimePeriod76.getStart();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date77, timeZone78);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass48, date64, timeZone78);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date35, timeZone78);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date21, timeZone78);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
        int int84 = day83.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = day83.previous();
        boolean boolean86 = year82.equals((java.lang.Object) day83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = year82.previous();
        int int88 = year82.getYear();
        long long89 = year82.getFirstMillisecond();
        long long90 = year82.getFirstMillisecond();
        timePeriodValues3.setKey((java.lang.Comparable) year82);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 2019 + "'", int84 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1546329600000L + "'", long89 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1546329600000L + "'", long90 == 1546329600000L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue3 = timePeriodValues1.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj6 = timePeriodValues5.clone();
        int int7 = year1.compareTo((java.lang.Object) timePeriodValues5);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (double) (-1L));
        java.util.Date date10 = year1.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 50);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        long long20 = simpleTimePeriod19.getEndMillis();
        long long21 = simpleTimePeriod19.getEndMillis();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        java.lang.Comparable comparable2 = timePeriodValues1.getKey();
        int int3 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + comparable2 + "' != '" + 6 + "'", comparable2.equals(6));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues6.createCopy((int) (short) 10, 1);
        boolean boolean11 = timePeriodValues10.isEmpty();
        timePeriodValues10.setDescription("TimePeriodValue[2019,-1.0]");
        timePeriodValues10.setDomainDescription("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 1969");
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 5);
        java.lang.Object obj11 = timePeriodValue10.clone();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        java.util.Date date9 = year2.getEnd();
        int int10 = year2.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
        java.util.Calendar calendar16 = null;
        try {
            day15.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long6 = simpleTimePeriod5.getStartMillis();
        java.util.Date date7 = simpleTimePeriod5.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod5);
        long long10 = simpleTimePeriod5.getStartMillis();
        java.util.Date date11 = simpleTimePeriod5.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 100L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        long long18 = year9.getFirstMillisecond();
        long long19 = year9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (double) (short) 100);
        timePeriodValues3.setDomainDescription("31-December-1969");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        boolean boolean9 = timePeriodValues3.equals((java.lang.Object) timePeriodFormatException7);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10 + "'", comparable4.equals(10));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        long long13 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues17.createCopy((int) (short) 1, (int) (byte) 100);
//        timePeriodValues20.fireSeriesChanged();
//        int int22 = timePeriodValues20.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues20.createCopy(10, (int) '#');
//        boolean boolean26 = day0.equals((java.lang.Object) timePeriodValues20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(timePeriodValues20);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        int int11 = year0.getYear();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number12);
        int int14 = year0.getYear();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Date date2 = day0.getEnd();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues6.createCopy((int) (short) 10, 1);
        boolean boolean11 = timePeriodValues10.isEmpty();
        java.lang.String str12 = timePeriodValues10.getDomainDescription();
        java.lang.Object obj13 = timePeriodValues10.clone();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        org.jfree.data.time.TimePeriodValue timePeriodValue60 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day58, (java.lang.Number) 100.0d);
        org.jfree.data.time.TimePeriod timePeriod61 = timePeriodValue60.getPeriod();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timePeriod61);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setDomainDescription("13-June-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, 100.0d);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 5);
        timePeriodValue10.setValue((java.lang.Number) (byte) 1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        long long13 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj21 = timePeriodValues20.clone();
//        int int22 = year16.compareTo((java.lang.Object) timePeriodValues20);
//        java.util.Date date23 = year16.getEnd();
//        int int24 = year16.getYear();
//        boolean boolean25 = day14.equals((java.lang.Object) int24);
//        long long26 = day14.getFirstMillisecond();
//        java.lang.String str27 = day14.toString();
//        java.util.Date date28 = day14.getStart();
//        boolean boolean29 = day0.equals((java.lang.Object) date28);
//        java.lang.Class<?> wildcardClass30 = day0.getClass();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        timePeriodValues3.setNotify(false);
//        int int8 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        int int10 = day9.getYear();
//        long long11 = day9.getFirstMillisecond();
//        java.util.Date date12 = day9.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues16.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues16.removePropertyChangeListener(propertyChangeListener19);
//        java.lang.Class<?> wildcardClass21 = timePeriodValues16.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date25 = simpleTimePeriod24.getStart();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date12, timeZone26);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues6.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date1, timeZone16);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.lang.String str7 = year0.toString();
        java.lang.String str8 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 5);
        long long11 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.next();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        int int2 = timePeriodValues1.getMaxStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long6 = simpleTimePeriod5.getStartMillis();
//        java.util.Date date7 = simpleTimePeriod5.getEnd();
//        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod5);
//        timePeriodValues9.setKey((java.lang.Comparable) "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues15.setRangeDescription("");
//        timePeriodValues15.setDescription("hi!");
//        java.lang.Comparable comparable20 = timePeriodValues15.getKey();
//        int int21 = timePeriodValues15.getMinStartIndex();
//        int int22 = timePeriodValues15.getMinStartIndex();
//        timePeriodValues15.setNotify(false);
//        java.lang.Object obj25 = timePeriodValues15.clone();
//        timePeriodValues15.setNotify(false);
//        timePeriodValues15.setDescription("");
//        timePeriodValues15.fireSeriesChanged();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getYear();
//        long long33 = day31.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        int int35 = day31.getYear();
//        org.jfree.data.time.SerialDate serialDate36 = day31.getSerialDate();
//        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day31, (java.lang.Number) 11);
//        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day31, (double) (-1));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 10 + "'", comparable20.equals(10));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertNotNull(obj25);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertNotNull(serialDate36);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        timePeriodValues3.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy(50, (int) (byte) 0);
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        long long8 = year5.getLastMillisecond();
        int int9 = year5.getYear();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year5.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28799999L + "'", long8 == 28799999L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        boolean boolean3 = year0.equals((java.lang.Object) long2);
//        java.util.Calendar calendar4 = null;
//        try {
//            year0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) (byte) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        int int6 = day5.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.delete((int) (short) 10, 0);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getEndMillis();
        long long9 = simpleTimePeriod2.getEndMillis();
        java.util.Date date10 = simpleTimePeriod2.getStart();
        java.util.Date date11 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date15 = simpleTimePeriod14.getStart();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date29, timeZone32);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone32);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date15, timeZone32);
        long long36 = year35.getSerialIndex();
        int int37 = simpleTimePeriod2.compareTo((java.lang.Object) year35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1969L + "'", long36 == 1969L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod2, 0.0d);
        java.util.Date date5 = regularTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int8 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        timePeriodValues7.setKey((java.lang.Comparable) simpleTimePeriod11);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod11);
        long long16 = simpleTimePeriod11.getStartMillis();
        java.util.Date date17 = simpleTimePeriod11.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues21.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues21.removePropertyChangeListener(propertyChangeListener24);
        java.lang.Class<?> wildcardClass26 = timePeriodValues21.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date30 = simpleTimePeriod29.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date30, timeZone31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date30, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues39.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues39.removePropertyChangeListener(propertyChangeListener42);
        java.lang.Class<?> wildcardClass44 = timePeriodValues39.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date48 = simpleTimePeriod47.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone49);
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date48, timeZone51);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone51);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date30, timeZone51);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date17, timeZone51);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date5, timeZone51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(timeZone51);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0, "org.jfree.data.time.TimePeriodFormatException: 2019", "hi!");
        long long4 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getFirstMillisecond();
        java.lang.String str12 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year0.next();
        int int14 = year0.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int14, "TimePeriodValue[12-June-2019,0.0]", "org.jfree.data.time.TimePeriodFormatException: 1969");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        long long8 = year5.getMiddleMillisecond();
        java.lang.Object obj9 = null;
        boolean boolean10 = year5.equals(obj9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-15739200001L) + "'", long8 == (-15739200001L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year0.next();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        java.lang.String str9 = timePeriodValues7.getDescription();
        int int10 = timePeriodValues7.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues14.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.removePropertyChangeListener(propertyChangeListener17);
        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues29.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
        java.lang.Class<?> wildcardClass34 = timePeriodValues29.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date38 = simpleTimePeriod37.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date38, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date25, timeZone41);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod43, (java.lang.Number) 11);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        long long7 = simpleTimePeriod2.getStartMillis();
        boolean boolean9 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: 2019");
        long long10 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        int int59 = day58.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int59);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 8);
        java.lang.String str10 = timePeriodValue9.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues14.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
        timePeriodValues14.setKey((java.lang.Comparable) "13-June-2019");
        boolean boolean21 = timePeriodValues14.isEmpty();
        boolean boolean22 = timePeriodValue9.equals((java.lang.Object) boolean21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TimePeriodValue[1969,8.0]" + "'", str10.equals("TimePeriodValue[1969,8.0]"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues10.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues10.createCopy((int) 'a', 2019);
        try {
            int int18 = simpleTimePeriod2.compareTo((java.lang.Object) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timePeriodValues17);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getFirstMillisecond();
        java.lang.String str12 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.next();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str9 = seriesException4.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Class<?> wildcardClass9 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj4 = timePeriodValues3.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 1);
//        java.lang.String str8 = timePeriodValues3.getRangeDescription();
//        timePeriodValues3.setRangeDescription("");
//        int int11 = timePeriodValues3.getMaxEndIndex();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        int int16 = day12.getYear();
//        org.jfree.data.time.SerialDate serialDate17 = day12.getSerialDate();
//        int int18 = day12.getMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day12, (double) 10L);
//        org.junit.Assert.assertNotNull(obj4);
//        org.junit.Assert.assertNotNull(timePeriodValues7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.lang.Object obj15 = null;
        boolean boolean16 = simpleTimePeriod14.equals(obj15);
        long long17 = simpleTimePeriod14.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        long long2 = day1.getSerialIndex();
//        boolean boolean3 = year0.equals((java.lang.Object) long2);
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 1562097599999L);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj11 = timePeriodValues10.clone();
//        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
//        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, (double) (-1L));
//        long long15 = year6.getFirstMillisecond();
//        long long16 = year6.getSerialIndex();
//        int int17 = year6.getYear();
//        java.lang.Number number18 = null;
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, number18);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue19);
//        timePeriodValue19.setValue((java.lang.Number) 6);
//        timePeriodValue19.setValue((java.lang.Number) 1530561599999L);
//        boolean boolean25 = timePeriodValue5.equals((java.lang.Object) timePeriodValue19);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2019L + "'", long16 == 2019L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int5 = timePeriodValues4.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long9 = simpleTimePeriod8.getStartMillis();
        java.util.Date date10 = simpleTimePeriod8.getEnd();
        timePeriodValues4.setKey((java.lang.Comparable) simpleTimePeriod8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod8);
        long long13 = simpleTimePeriod8.getStartMillis();
        java.util.Date date14 = simpleTimePeriod8.getStart();
        boolean boolean15 = day0.equals((java.lang.Object) simpleTimePeriod8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 1);
        int int8 = timePeriodValues3.getMinStartIndex();
        int int9 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDescription("2019");
        timePeriodValues3.setKey((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: 1969");
        try {
            java.lang.Number number15 = timePeriodValues3.getValue(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj5 = timePeriodValues4.clone();
//        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
//        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
//        java.util.Date date9 = year0.getStart();
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj15 = timePeriodValues14.clone();
//        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
//        java.util.Date date17 = year10.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
//        long long20 = simpleTimePeriod19.getEndMillis();
//        java.util.Date date21 = simpleTimePeriod19.getEnd();
//        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("2019");
//        java.lang.String str27 = timePeriodFormatException26.toString();
//        seriesException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
//        java.lang.Throwable[] throwableArray29 = seriesException23.getSuppressed();
//        boolean boolean30 = simpleTimePeriod19.equals((java.lang.Object) throwableArray29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getYear();
//        long long33 = day31.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate34);
//        org.jfree.data.time.SerialDate serialDate37 = day36.getSerialDate();
//        int int38 = day36.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day36);
//        boolean boolean40 = simpleTimePeriod19.equals((java.lang.Object) day36);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(obj15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(throwableArray24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
//        org.junit.Assert.assertNotNull(throwableArray29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj6 = timePeriodValues5.clone();
        int int7 = year1.compareTo((java.lang.Object) timePeriodValues5);
        org.jfree.data.time.TimePeriodValue timePeriodValue9 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (double) (-1L));
        java.util.Date date10 = year1.getStart();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long16 = simpleTimePeriod15.getStartMillis();
        java.util.Date date17 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj24 = timePeriodValues23.clone();
        int int25 = year19.compareTo((java.lang.Object) timePeriodValues23);
        java.util.Date date26 = year19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date17, date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues31.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues31.removePropertyChangeListener(propertyChangeListener34);
        java.lang.Class<?> wildcardClass36 = timePeriodValues31.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date40 = simpleTimePeriod39.getStart();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date40, timeZone41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date40, timeZone43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues48.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues48.removePropertyChangeListener(propertyChangeListener51);
        java.lang.Class<?> wildcardClass53 = timePeriodValues48.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date57 = simpleTimePeriod56.getStart();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date57, timeZone58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj65 = timePeriodValues64.clone();
        int int66 = year60.compareTo((java.lang.Object) timePeriodValues64);
        org.jfree.data.time.TimePeriodValue timePeriodValue68 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year60, (double) (-1L));
        java.util.Date date69 = year60.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues73.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener76 = null;
        timePeriodValues73.removePropertyChangeListener(propertyChangeListener76);
        java.lang.Class<?> wildcardClass78 = timePeriodValues73.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date82 = simpleTimePeriod81.getStart();
        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass78, date82, timeZone83);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date69, timeZone83);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date40, timeZone83);
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date26, timeZone83);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod88 = new org.jfree.data.time.SimpleTimePeriod(date10, date26);
        long long89 = simpleTimePeriod88.getEndMillis();
        long long90 = simpleTimePeriod88.getEndMillis();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(timeZone83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1577865599999L + "'", long90 == 1577865599999L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        java.util.Date date9 = year2.getEnd();
        int int10 = year2.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day0.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        int int7 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10 + "'", comparable4.equals(10));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNotNull(obj10);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getYear();
//        long long4 = day2.getFirstMillisecond();
//        java.lang.String str5 = day2.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues9.setRangeDescription("");
//        int int12 = timePeriodValues9.getMinMiddleIndex();
//        java.lang.Object obj13 = timePeriodValues9.clone();
//        int int14 = day2.compareTo((java.lang.Object) timePeriodValues9);
//        java.util.Date date15 = day2.getEnd();
//        boolean boolean16 = day0.equals((java.lang.Object) day2);
//        java.util.Date date17 = day0.getEnd();
//        int int18 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        int int8 = timePeriodValues3.getMaxEndIndex();
        int int9 = timePeriodValues3.getItemCount();
        int int10 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        long long59 = day58.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 25568L + "'", long59 == 25568L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) (-1));
        java.lang.Object obj12 = timePeriodValues3.clone();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj18 = timePeriodValues17.clone();
        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        long long22 = year13.getFirstMillisecond();
        long long23 = year13.getSerialIndex();
        int int24 = year13.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int24);
        int int26 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener27);
        int int29 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str12 = timePeriodFormatException11.toString();
        int int13 = year0.compareTo((java.lang.Object) timePeriodFormatException11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year0.previous();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str12.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long5 = simpleTimePeriod4.getStartMillis();
        java.util.Date date6 = simpleTimePeriod4.getEnd();
        long long7 = simpleTimePeriod4.getEndMillis();
        java.util.Date date8 = simpleTimePeriod4.getStart();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) year9);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) 'a', 2019);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = day11.getYear();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj18 = timePeriodValues17.clone();
//        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
//        java.util.Date date20 = year13.getEnd();
//        int int21 = year13.getYear();
//        boolean boolean22 = day11.equals((java.lang.Object) int21);
//        int int24 = day11.compareTo((java.lang.Object) 11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day11.next();
//        timePeriodValues10.setKey((java.lang.Comparable) day11);
//        int int27 = day11.getYear();
//        long long28 = day11.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        int int4 = timePeriodValues3.getMaxMiddleIndex();
//        int int5 = timePeriodValues3.getMaxMiddleIndex();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        int int7 = day6.getYear();
//        long long8 = day6.getLastMillisecond();
//        long long9 = day6.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 7);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) (-1L));
//        timePeriodValues3.setKey((java.lang.Comparable) 1546329600000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560495599999L + "'", long8 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560409200000L + "'", long9 == 1560409200000L);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) ' ');
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        int int6 = day5.getMonth();
        long long7 = day5.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28799999L + "'", long7 == 28799999L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long6 = simpleTimePeriod5.getStartMillis();
        java.util.Date date7 = simpleTimePeriod5.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod5);
        boolean boolean10 = simpleTimePeriod5.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.util.Date date7 = year0.getEnd();
        int int8 = year0.getYear();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        java.util.Date date18 = year9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year9.previous();
        java.util.Date date20 = regularTimePeriod19.getStart();
        int int21 = year0.compareTo((java.lang.Object) date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "hi!", "hi!");
        int int26 = year0.compareTo((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year0.next();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj64 = timePeriodValues63.clone();
        int int65 = year59.compareTo((java.lang.Object) timePeriodValues63);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, 100.0d);
        int int68 = day58.compareTo((java.lang.Object) 100.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        int int72 = day58.compareTo((java.lang.Object) simpleTimePeriod71);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = day58.next();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year0.previous();
        long long11 = year0.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        try {
            year0.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        long long20 = simpleTimePeriod19.getEndMillis();
        java.util.Date date21 = simpleTimePeriod19.getEnd();
        org.jfree.data.general.SeriesException seriesException23 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray24 = seriesException23.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str27 = timePeriodFormatException26.toString();
        seriesException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.Throwable[] throwableArray29 = seriesException23.getSuppressed();
        boolean boolean30 = simpleTimePeriod19.equals((java.lang.Object) throwableArray29);
        java.lang.Object obj31 = null;
        try {
            int int32 = simpleTimePeriod19.compareTo(obj31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        timePeriodValues3.setKey((java.lang.Comparable) day12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        int int19 = timePeriodValues18.getMaxStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long23 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date24 = simpleTimePeriod22.getEnd();
//        timePeriodValues18.setKey((java.lang.Comparable) simpleTimePeriod22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod22);
//        long long27 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date28 = simpleTimePeriod22.getStart();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 43629L);
//        timePeriodValues3.setRangeDescription("31-December-1969");
//        timePeriodValues3.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(date28);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.next();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str10 = seriesException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        int int6 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.next();
        java.lang.String str8 = year5.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, 7L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        java.lang.String str8 = timePeriodValues3.getDescription();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day9, (java.lang.Number) 0L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date16 = simpleTimePeriod15.getStart();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (java.lang.Number) (short) 100);
        java.lang.Object obj19 = null;
        try {
            int int20 = simpleTimePeriod15.compareTo(obj19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(10, 0);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        int int59 = day58.getYear();
        java.util.Calendar calendar60 = null;
        try {
            long long61 = day58.getMiddleMillisecond(calendar60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj12 = timePeriodValues11.clone();
//        int int13 = year7.compareTo((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1L));
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValue15);
//        org.jfree.data.time.SerialDate serialDate17 = day0.getSerialDate();
//        long long18 = day0.getSerialIndex();
//        long long19 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod12, (double) (short) 100);
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getEnd();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues3.createCopy(0, (int) (short) 1);
        int int8 = timePeriodValues3.getMinStartIndex();
        int int9 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setDescription("2019");
        timePeriodValues3.setKey((java.lang.Comparable) "org.jfree.data.time.TimePeriodFormatException: 1969");
        int int14 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(timePeriodValues7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        long long18 = year9.getFirstMillisecond();
        long long19 = year9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (double) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy((int) (short) 1, 0);
        timePeriodValues25.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        int int10 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setNotify(false);
        java.lang.Object obj13 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        java.lang.Object obj16 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10 + "'", comparable8.equals(10));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        int int7 = timePeriodValues3.getMinStartIndex();
        boolean boolean8 = timePeriodValues3.getNotify();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod11, 0.0d);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        java.util.Date date9 = regularTimePeriod8.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        long long6 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1969L + "'", long6 == 1969L);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj7 = timePeriodValues6.clone();
//        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
//        java.util.Date date9 = year2.getEnd();
//        int int10 = year2.getYear();
//        boolean boolean11 = day0.equals((java.lang.Object) int10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
//        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        int int16 = day0.getDayOfMonth();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj22 = timePeriodValues21.clone();
//        int int23 = year17.compareTo((java.lang.Object) timePeriodValues21);
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) (-1L));
//        long long26 = year17.getFirstMillisecond();
//        long long27 = year17.getSerialIndex();
//        int int28 = year17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year17.previous();
//        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod29, (java.lang.Number) 6);
//        boolean boolean32 = day0.equals((java.lang.Object) 6);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 2019L + "'", long27 == 2019L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        boolean boolean10 = timePeriodValues3.isEmpty();
        int int11 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj17 = timePeriodValues16.clone();
        int int18 = year12.compareTo((java.lang.Object) timePeriodValues16);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (double) (-1L));
        java.lang.String str21 = timePeriodValue20.toString();
        java.lang.String str22 = timePeriodValue20.toString();
        java.lang.Object obj23 = timePeriodValue20.clone();
        boolean boolean25 = timePeriodValue20.equals((java.lang.Object) (short) -1);
        java.lang.Object obj26 = null;
        boolean boolean27 = timePeriodValue20.equals(obj26);
        java.lang.Number number28 = timePeriodValue20.getValue();
        timePeriodValues3.add(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str21.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str22.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (-1.0d) + "'", number28.equals((-1.0d)));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) (-1L));
        java.lang.String str19 = timePeriodValue18.toString();
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue18.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue18.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValue18.getPeriod();
        java.lang.Object obj23 = timePeriodValue18.clone();
        timePeriodValues3.add(timePeriodValue18);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,-1.0]" + "'", str19.equals("TimePeriodValue[2019,-1.0]"));
        org.junit.Assert.assertNotNull(timePeriod20);
        org.junit.Assert.assertNotNull(timePeriod21);
        org.junit.Assert.assertNotNull(timePeriod22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "org.jfree.data.general.SeriesChangeEvent[source=TimePeriodValue[2019,null]]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str7 = timePeriodFormatException6.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = seriesException14.getSuppressed();
        java.lang.Throwable[] throwableArray17 = seriesException14.getSuppressed();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
        java.lang.Throwable[] throwableArray19 = seriesException14.getSuppressed();
        java.lang.Class<?> wildcardClass20 = seriesException14.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException14);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj64 = timePeriodValues63.clone();
        int int65 = year59.compareTo((java.lang.Object) timePeriodValues63);
        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year59, 100.0d);
        int int68 = day58.compareTo((java.lang.Object) 100.0d);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        int int72 = day58.compareTo((java.lang.Object) simpleTimePeriod71);
        java.lang.Class<?> wildcardClass73 = day58.getClass();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(wildcardClass73);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        java.util.Date date9 = year2.getEnd();
        int int10 = year2.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
        int int16 = day15.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[1969,8.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        java.lang.String str11 = year0.toString();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues15.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = timePeriodValues15.createCopy((int) ' ', 10);
        timePeriodValues15.setKey((java.lang.Comparable) 10.0f);
        boolean boolean23 = year0.equals((java.lang.Object) 10.0f);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year0.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2019" + "'", str11.equals("2019"));
        org.junit.Assert.assertNotNull(timePeriodValues20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        long long5 = day4.getSerialIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long9 = simpleTimePeriod8.getStartMillis();
//        java.util.Date date10 = simpleTimePeriod8.getEnd();
//        long long11 = simpleTimePeriod8.getEndMillis();
//        java.util.Date date12 = simpleTimePeriod8.getStart();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
//        int int15 = day4.compareTo((java.lang.Object) regularTimePeriod14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day4);
//        java.util.Calendar calendar17 = null;
//        try {
//            day4.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43629L + "'", long5 == 43629L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.util.Date date9 = year0.getStart();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj15 = timePeriodValues14.clone();
        int int16 = year10.compareTo((java.lang.Object) timePeriodValues14);
        java.util.Date date17 = year10.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date9, date17);
        long long20 = simpleTimePeriod19.getEndMillis();
        java.util.Date date21 = simpleTimePeriod19.getEnd();
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        long long23 = simpleTimePeriod19.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        int int28 = timePeriodValues27.getMaxMiddleIndex();
        int int29 = timePeriodValues27.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues27.removePropertyChangeListener(propertyChangeListener30);
        java.lang.String str32 = timePeriodValues27.getDescription();
        int int33 = timePeriodValues27.getMinStartIndex();
        boolean boolean34 = simpleTimePeriod19.equals((java.lang.Object) int33);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test378");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        int int8 = day5.getMonth();
//        long long9 = day5.getSerialIndex();
//        long long10 = day5.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj16 = timePeriodValues15.clone();
        int int17 = year11.compareTo((java.lang.Object) timePeriodValues15);
        java.util.Date date18 = year11.getEnd();
        int int19 = year11.getYear();
        boolean boolean20 = day9.equals((java.lang.Object) int19);
        int int22 = day9.compareTo((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day9.next();
        int int24 = year0.compareTo((java.lang.Object) day9);
        long long25 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getFirstMillisecond();
        long long10 = year0.getSerialIndex();
        long long11 = year0.getFirstMillisecond();
        java.lang.String str12 = year0.toString();
        long long13 = year0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj10 = null;
        boolean boolean11 = timePeriodValues3.equals(obj10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues20.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener23);
        java.lang.Class<?> wildcardClass25 = timePeriodValues20.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date29 = simpleTimePeriod28.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date29, timeZone30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj37 = timePeriodValues36.clone();
        int int38 = year32.compareTo((java.lang.Object) timePeriodValues36);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year32, (double) (-1L));
        java.util.Date date41 = year32.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues45.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.removePropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date54 = simpleTimePeriod53.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date54, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date41, timeZone55);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date12, timeZone55);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year60, "TimePeriodValue[2019,0.0]", "TimePeriodValue[2019,-1.0]");
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNull(regularTimePeriod57);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test383");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy((int) (short) 1, (int) (byte) 100);
//        timePeriodValues10.fireSeriesChanged();
//        int int12 = timePeriodValues10.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues10.createCopy(10, (int) '#');
//        boolean boolean16 = timePeriodValues10.getNotify();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        int int18 = day17.getYear();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day17.previous();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod21, (java.lang.Number) 3);
//        int int24 = day0.compareTo((java.lang.Object) regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560495599999L + "'", long19 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) "13-June-2019");
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
        boolean boolean12 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getYear();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj20 = timePeriodValues19.clone();
        int int21 = year15.compareTo((java.lang.Object) timePeriodValues19);
        java.util.Date date22 = year15.getEnd();
        int int23 = year15.getYear();
        boolean boolean24 = day13.equals((java.lang.Object) int23);
        int int26 = day13.compareTo((java.lang.Object) 11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day13.next();
        boolean boolean28 = timePeriodValues3.equals((java.lang.Object) regularTimePeriod27);
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener29);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L);
        java.lang.String str2 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        java.lang.String str10 = timePeriodValues6.getDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues6.getTimePeriod(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: 2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray10 = seriesException9.getSuppressed();
        java.lang.Throwable[] throwableArray11 = seriesException9.getSuppressed();
        java.lang.Throwable[] throwableArray12 = seriesException9.getSuppressed();
        seriesException6.addSuppressed((java.lang.Throwable) seriesException9);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException9);
        java.lang.Throwable[] throwableArray16 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        java.lang.String str7 = year0.toString();
        java.lang.String str8 = year0.toString();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 5);
        long long11 = year0.getLastMillisecond();
        long long12 = year0.getSerialIndex();
        long long13 = year0.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            year0.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2019" + "'", str7.equals("2019"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj14 = timePeriodValues13.clone();
        int int15 = year9.compareTo((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (-1L));
        long long18 = year9.getFirstMillisecond();
        long long19 = year9.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year9.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (double) (short) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener23);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener25);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue28 = timePeriodValues3.getDataItem(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2019L + "'", long19 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date12 = simpleTimePeriod11.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues19.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
        java.lang.Class<?> wildcardClass24 = timePeriodValues19.getClass();
        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize(class26);
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize(class27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date33 = simpleTimePeriod32.getStart();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
        int int37 = timePeriodValues36.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long41 = simpleTimePeriod40.getStartMillis();
        java.util.Date date42 = simpleTimePeriod40.getEnd();
        timePeriodValues36.setKey((java.lang.Comparable) simpleTimePeriod40);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod40);
        long long45 = simpleTimePeriod40.getStartMillis();
        java.util.Date date46 = simpleTimePeriod40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues50.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues50.removePropertyChangeListener(propertyChangeListener53);
        java.lang.Class<?> wildcardClass55 = timePeriodValues50.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date59 = simpleTimePeriod58.getStart();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date59, timeZone62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date59);
        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues68.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timePeriodValues68.removePropertyChangeListener(propertyChangeListener71);
        java.lang.Class<?> wildcardClass73 = timePeriodValues68.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date77 = simpleTimePeriod76.getStart();
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass73, date77, timeZone78);
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year81 = new org.jfree.data.time.Year(date77, timeZone80);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent82 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone80);
        org.jfree.data.time.Year year83 = new org.jfree.data.time.Year(date59, timeZone80);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date46, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone80);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date12, timeZone80);
        java.lang.String str87 = year86.toString();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(class27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(wildcardClass73);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "1969" + "'", str87.equals("1969"));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10 + "'", comparable10.equals(10));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        int int8 = timePeriodValues6.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        long long9 = year0.getLastMillisecond();
        long long10 = year0.getFirstMillisecond();
        long long11 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        long long5 = simpleTimePeriod2.getEndMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        long long9 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 97L + "'", long5 == 97L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        java.lang.Object obj5 = null;
//        boolean boolean6 = day0.equals(obj5);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj12 = timePeriodValues11.clone();
//        int int13 = year7.compareTo((java.lang.Object) timePeriodValues11);
//        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-1L));
//        boolean boolean16 = day0.equals((java.lang.Object) timePeriodValue15);
//        org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValue15.getPeriod();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(timePeriod17);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test398");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, 43629L);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        int int4 = day3.getDayOfMonth();
//        int int5 = day3.getMonth();
//        java.lang.String str6 = day3.toString();
//        long long7 = day3.getSerialIndex();
//        boolean boolean8 = simpleTimePeriod2.equals((java.lang.Object) day3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        int int3 = day2.getYear();
//        long long4 = day2.getFirstMillisecond();
//        java.lang.String str5 = day2.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues9.setRangeDescription("");
//        int int12 = timePeriodValues9.getMinMiddleIndex();
//        java.lang.Object obj13 = timePeriodValues9.clone();
//        int int14 = day2.compareTo((java.lang.Object) timePeriodValues9);
//        java.util.Date date15 = day2.getEnd();
//        boolean boolean16 = day0.equals((java.lang.Object) day2);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj22 = timePeriodValues21.clone();
//        int int23 = year17.compareTo((java.lang.Object) timePeriodValues21);
//        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 100.0d);
//        java.lang.String str26 = year17.toString();
//        int int27 = day2.compareTo((java.lang.Object) str26);
//        java.util.Date date28 = day2.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day2.next();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2019" + "'", str26.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setNotify(false);
        int int8 = timePeriodValues3.getMaxMiddleIndex();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues7.setRangeDescription("");
//        int int10 = timePeriodValues7.getMinMiddleIndex();
//        java.lang.Object obj11 = timePeriodValues7.clone();
//        int int12 = day0.compareTo((java.lang.Object) timePeriodValues7);
//        long long13 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getYear();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        java.lang.Object obj21 = timePeriodValues20.clone();
//        int int22 = year16.compareTo((java.lang.Object) timePeriodValues20);
//        java.util.Date date23 = year16.getEnd();
//        int int24 = year16.getYear();
//        boolean boolean25 = day14.equals((java.lang.Object) int24);
//        long long26 = day14.getFirstMillisecond();
//        java.lang.String str27 = day14.toString();
//        java.util.Date date28 = day14.getStart();
//        boolean boolean29 = day0.equals((java.lang.Object) date28);
//        long long30 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertNotNull(obj11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560409200000L + "'", long26 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        boolean boolean11 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        java.util.Date date9 = year2.getEnd();
        int int10 = year2.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day0.previous();
        org.jfree.data.time.SerialDate serialDate13 = day0.getSerialDate();
        int int14 = day0.getYear();
        int int15 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        boolean boolean10 = timePeriodValues3.isEmpty();
        int int11 = timePeriodValues3.getMinMiddleIndex();
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Comparable comparable11 = timePeriodValues10.getKey();
        timePeriodValues10.fireSeriesChanged();
        int int13 = timePeriodValues10.getMinMiddleIndex();
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) int13);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10 + "'", comparable11.equals(10));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues3.setRangeDescription("");
//        int int6 = timePeriodValues3.getMinMiddleIndex();
//        timePeriodValues3.setKey((java.lang.Comparable) false);
//        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
//        timePeriodValues3.setKey((java.lang.Comparable) 1L);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getYear();
//        long long14 = day12.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        timePeriodValues3.setKey((java.lang.Comparable) day12);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10);
//        int int19 = timePeriodValues18.getMaxStartIndex();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        long long23 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date24 = simpleTimePeriod22.getEnd();
//        timePeriodValues18.setKey((java.lang.Comparable) simpleTimePeriod22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod22);
//        long long27 = simpleTimePeriod22.getStartMillis();
//        java.util.Date date28 = simpleTimePeriod22.getStart();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod22, (double) 43629L);
//        java.lang.Class<?> wildcardClass31 = timePeriodValues3.getClass();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj5 = timePeriodValues4.clone();
        int int6 = year0.compareTo((java.lang.Object) timePeriodValues4);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (-1L));
        java.lang.Number number9 = timePeriodValue8.getValue();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue8.getPeriod();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1.0d) + "'", number9.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L);
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj8 = timePeriodValues7.clone();
        int int9 = year3.compareTo((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, (double) (-1L));
        long long12 = year3.getFirstMillisecond();
        long long13 = year3.getSerialIndex();
        java.util.Date date14 = year3.getStart();
        long long15 = year3.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year3, (double) ' ');
        java.lang.Object obj18 = timePeriodValues1.clone();
        timePeriodValues1.setRangeDescription("TimePeriodValue[2019,100.0]");
        try {
            timePeriodValues1.delete(5, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2019L + "'", long13 == 2019L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj8 = timePeriodValues7.clone();
        int int9 = year3.compareTo((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, 100.0d);
        timePeriodValues1.add(timePeriodValue11);
        int int13 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy((int) (short) 1, (int) (byte) 100);
        timePeriodValues6.fireSeriesChanged();
        timePeriodValues6.setDescription("hi!");
        timePeriodValues6.setRangeDescription("");
        int int12 = timePeriodValues6.getMinMiddleIndex();
        timePeriodValues6.setDescription("");
        int int15 = timePeriodValues6.getItemCount();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues3.setRangeDescription("");
        int int6 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) false);
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) (-1));
        java.lang.Object obj12 = timePeriodValues3.clone();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj18 = timePeriodValues17.clone();
        int int19 = year13.compareTo((java.lang.Object) timePeriodValues17);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (-1L));
        long long22 = year13.getFirstMillisecond();
        long long23 = year13.getSerialIndex();
        int int24 = year13.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) int24);
        int int26 = timePeriodValues3.getItemCount();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,-1.0]");
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj34 = timePeriodValues33.clone();
        int int35 = year29.compareTo((java.lang.Object) timePeriodValues33);
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, 100.0d);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) (-1.0d));
        long long40 = year29.getFirstMillisecond();
        long long41 = year29.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + false + "'", comparable9.equals(false));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 2019L + "'", long41 == 2019L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getYear();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj7 = timePeriodValues6.clone();
        int int8 = year2.compareTo((java.lang.Object) timePeriodValues6);
        java.util.Date date9 = year2.getEnd();
        int int10 = year2.getYear();
        boolean boolean11 = day0.equals((java.lang.Object) int10);
        int int13 = day0.compareTo((java.lang.Object) 11);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 1546329600000L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long19 = simpleTimePeriod18.getStartMillis();
        java.util.Date date20 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj27 = timePeriodValues26.clone();
        int int28 = year22.compareTo((java.lang.Object) timePeriodValues26);
        java.util.Date date29 = year22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date20, date29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues34.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        java.lang.Class<?> wildcardClass39 = timePeriodValues34.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date43 = simpleTimePeriod42.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date43, timeZone44);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date43, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues51.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues51.removePropertyChangeListener(propertyChangeListener54);
        java.lang.Class<?> wildcardClass56 = timePeriodValues51.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date60 = simpleTimePeriod59.getStart();
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date60, timeZone61);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj68 = timePeriodValues67.clone();
        int int69 = year63.compareTo((java.lang.Object) timePeriodValues67);
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (double) (-1L));
        java.util.Date date72 = year63.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues76.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener79 = null;
        timePeriodValues76.removePropertyChangeListener(propertyChangeListener79);
        java.lang.Class<?> wildcardClass81 = timePeriodValues76.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date85 = simpleTimePeriod84.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass81, date85, timeZone86);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date72, timeZone86);
        org.jfree.data.time.Day day89 = new org.jfree.data.time.Day(date43, timeZone86);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date29, timeZone86);
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day();
        int int92 = day91.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = day91.previous();
        boolean boolean94 = year90.equals((java.lang.Object) day91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = year90.previous();
        boolean boolean96 = timePeriodValue15.equals((java.lang.Object) year90);
        timePeriodValue15.setValue((java.lang.Number) 12);
        java.lang.Object obj99 = timePeriodValue15.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2019 + "'", int92 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(obj99);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 6);
        int int2 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj8 = timePeriodValues7.clone();
        int int9 = year3.compareTo((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year3, 100.0d);
        timePeriodValues1.add(timePeriodValue11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L, "", "2019");
        boolean boolean17 = timePeriodValue11.equals((java.lang.Object) "");
        java.lang.String str18 = timePeriodValue11.toString();
        java.lang.String str19 = timePeriodValue11.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str18.equals("TimePeriodValue[2019,100.0]"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str19.equals("TimePeriodValue[2019,100.0]"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10 + "'", comparable11.equals(10));
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test416");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day5, (java.lang.Number) 13);
//        timePeriodValue7.setValue((java.lang.Number) (byte) 0);
//        java.lang.Number number10 = timePeriodValue7.getValue();
//        timePeriodValue7.setValue((java.lang.Number) (-47318400001L));
//        timePeriodValue7.setValue((java.lang.Number) (byte) 0);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getYear();
//        long long17 = day15.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate18);
//        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, (java.lang.Number) 13);
//        timePeriodValue22.setValue((java.lang.Number) (byte) 0);
//        boolean boolean25 = timePeriodValue7.equals((java.lang.Object) timePeriodValue22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
//        timePeriodValues29.setRangeDescription("");
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timePeriodValues29.removePropertyChangeListener(propertyChangeListener32);
//        java.lang.Class<?> wildcardClass34 = timePeriodValues29.getClass();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
//        java.util.Date date38 = simpleTimePeriod37.getStart();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone39);
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize(class42);
//        boolean boolean44 = timePeriodValue22.equals((java.lang.Object) class42);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (byte) 0 + "'", number10.equals((byte) 0));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj11 = timePeriodValues10.clone();
        int int12 = year6.compareTo((java.lang.Object) timePeriodValues10);
        java.util.Date date13 = year6.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date4, date13);
        java.lang.Class<?> wildcardClass15 = date4.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(0L, 0L);
        java.util.Date date19 = simpleTimePeriod18.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        long long26 = simpleTimePeriod23.getEndMillis();
        java.util.Date date27 = simpleTimePeriod23.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        java.util.Date date30 = regularTimePeriod29.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long34 = simpleTimePeriod33.getStartMillis();
        java.util.Date date35 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        java.lang.Object obj42 = timePeriodValues41.clone();
        int int43 = year37.compareTo((java.lang.Object) timePeriodValues41);
        java.util.Date date44 = year37.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date35, date44);
        java.lang.Class<?> wildcardClass46 = date35.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        long long50 = simpleTimePeriod49.getStartMillis();
        java.util.Date date51 = simpleTimePeriod49.getEnd();
        long long52 = simpleTimePeriod49.getEndMillis();
        java.util.Date date53 = simpleTimePeriod49.getStart();
        long long54 = simpleTimePeriod49.getStartMillis();
        long long55 = simpleTimePeriod49.getEndMillis();
        java.util.Date date56 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10, "hi!", "");
        timePeriodValues60.setRangeDescription("");
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timePeriodValues60.removePropertyChangeListener(propertyChangeListener63);
        java.lang.Class<?> wildcardClass65 = timePeriodValues60.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, (long) 'a');
        java.util.Date date69 = simpleTimePeriod68.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass65, date69, timeZone70);
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date69, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date56, timeZone72);
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date30, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date19, timeZone72);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 97L + "'", long52 == 97L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 97L + "'", long55 == 97L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNull(regularTimePeriod76);
    }
}

