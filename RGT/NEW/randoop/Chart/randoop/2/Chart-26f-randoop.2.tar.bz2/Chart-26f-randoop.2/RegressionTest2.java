import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getBaseSectionOutlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font8 = categoryAxis6.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer4.setBaseItemLabelFont(font8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        stackedAreaRenderer4.notifyListeners(rendererChangeEvent10);
        java.awt.Paint paint13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer15 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font19 = categoryAxis17.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer15.setBaseItemLabelFont(font19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = stackedAreaRenderer15.getURLGenerator(0, 3);
        stackedAreaRenderer15.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer15.setBaseStroke(stroke28);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint13, stroke28);
        boolean boolean31 = stackedAreaRenderer4.equals((java.lang.Object) stroke28);
        piePlot1.setLabelOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNull(categoryURLGenerator23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D7.setLabelFont(font8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis3D7.getStandardTickUnits();
        numberAxis3D7.centerRange((double) (short) 0);
        numberAxis3D7.setAutoRangeStickyZero(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font21 = categoryAxis19.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer17.setBaseItemLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font21);
        numberAxis3D7.setLabelFont(font21);
        boolean boolean25 = taskSeriesCollection0.equals((java.lang.Object) numberAxis3D7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent26);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("TextAnchor.BOTTOM_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name TextAnchor.BOTTOM_RIGHT, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int18 = taskSeriesCollection16.getColumnIndex((java.lang.Comparable) (short) -1);
        boolean boolean19 = taskSeriesCollection0.hasListener((java.util.EventListener) taskSeriesCollection16);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int21 = taskSeriesCollection0.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.lang.Boolean boolean4 = lineRenderer3D0.getSeriesVisible((int) (short) 0);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setBaseShapesFilled(false);
        java.awt.Stroke stroke9 = lineRenderer3D0.getBaseStroke();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        xYPlot30.setRangeCrosshairValue((double) (byte) 10, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot30.getRenderer(9);
        java.awt.geom.Point2D point2D37 = null;
        try {
            xYPlot30.setQuadrantOrigin(point2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNull(xYItemRenderer36);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation10, false);
        categoryPlot4.clearDomainMarkers();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection15 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int17 = taskSeriesCollection15.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection15, true);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes((double) (-1), plotRenderingInfo26, point2D27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot24.getRenderer();
        taskSeriesCollection15.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot24);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection31 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int33 = taskSeriesCollection31.getColumnIndex((java.lang.Comparable) (short) -1);
        boolean boolean34 = taskSeriesCollection15.hasListener((java.util.EventListener) taskSeriesCollection31);
        int int36 = taskSeriesCollection31.getRowIndex((java.lang.Comparable) (-15.0d));
        categoryPlot4.setDataset(2958465, (org.jfree.data.category.CategoryDataset) taskSeriesCollection31);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.text.NumberFormat numberFormat5 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat5);
        java.awt.Shape shape7 = numberAxis3D1.getRightArrow();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection10);
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot11.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot11.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot11.getDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity17 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "rect", "VerticalAlignment.BOTTOM", categoryDataset14, (java.lang.Comparable) "VerticalAlignment.BOTTOM", (java.lang.Comparable) (-36L));
        java.lang.Comparable comparable18 = categoryItemEntity17.getColumnKey();
        java.lang.String str19 = categoryItemEntity17.getToolTipText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (-36L) + "'", comparable18.equals((-36L)));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "rect" + "'", str19.equals("rect"));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        segment3.moveIndexToStart();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int6 = segmentedTimeline5.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline5.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segment8.copy();
        boolean boolean10 = segment3.contains(segment8);
        long long11 = segment8.getSegmentStart();
        long long13 = segment8.calculateSegmentNumber((long) 12);
        boolean boolean16 = segment8.contains(86400000L, 455057983088L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 68 + "'", int6 == 68);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-899990L) + "'", long11 == (-899990L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-36L) + "'", long13 == (-36L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Color color4 = java.awt.Color.pink;
        java.awt.Color color5 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", color4);
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.setAutoTickUnitSelection(true, true);
        dateAxis2.configure();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot9.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = polarPlot9.getRenderer();
        java.awt.Paint paint12 = polarPlot9.getAngleLabelPaint();
        polarPlot9.clearCornerTextItems();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("{0}", font8, (org.jfree.chart.plot.Plot) polarPlot9, false);
        dateAxis2.setPlot((org.jfree.chart.plot.Plot) polarPlot9);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNull(polarItemRenderer11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double1 = layeredBarRenderer0.getItemMargin();
        java.awt.Paint paint4 = layeredBarRenderer0.getItemLabelPaint((int) (byte) 100, (int) (byte) -1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = layeredBarRenderer0.getToolTipGenerator((int) (short) 1, 1900);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot30.setRenderer(0, xYItemRenderer34, true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D37 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D37.setDrawOutlines(true);
        boolean boolean40 = lineRenderer3D37.getBaseShapesVisible();
        java.awt.Font font42 = lineRenderer3D37.getSeriesItemLabelFont(3);
        org.jfree.chart.LegendItem legendItem45 = lineRenderer3D37.getLegendItem((int) ' ', 100);
        java.awt.Stroke stroke47 = lineRenderer3D37.lookupSeriesStroke(10);
        xYPlot30.setDomainCrosshairStroke(stroke47);
        xYPlot30.setDomainCrosshairVisible(true);
        java.awt.Paint paint51 = xYPlot30.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(font42);
        org.junit.Assert.assertNull(legendItem45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(paint51);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.pink;
        java.lang.String str3 = color2.toString();
        java.awt.Color color4 = color2.darker();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        int int7 = polarPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str3.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        java.awt.Color color1 = java.awt.Color.getColor("JFreeChart");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        java.util.List list3 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = color5.darker();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke8);
        valueMarker9.setAlpha((float) 0L);
        java.awt.Stroke stroke12 = valueMarker9.getStroke();
        lineRenderer3D0.setBaseOutlineStroke(stroke12, false);
        lineRenderer3D0.setXOffset((double) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        java.awt.Stroke stroke22 = null;
        categoryPlot21.setOutlineStroke(stroke22);
        java.awt.Paint paint24 = categoryPlot21.getBackgroundPaint();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot21.getFixedLegendItems();
        lineRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(legendItemCollection25);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray4 = new java.lang.Comparable[] { (short) 10, 2958465, (short) -1 };
        double[][] doubleArray5 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray4, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray4);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot4.getOrientation();
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo(entityCollection16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Point2D point2D19 = null;
        polarPlot14.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock23.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot29.zoomRangeAxes((double) (-1), plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot29.setRangeAxisLocation((int) ' ', axisLocation35, false);
        float float38 = categoryPlot29.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot29.getRangeMarkers((int) (byte) 0, layer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot29.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D43 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D43.setDrawOutlines(true);
        boolean boolean46 = lineRenderer3D43.getBaseShapesVisible();
        java.awt.Font font48 = lineRenderer3D43.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = null;
        lineRenderer3D43.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator50, false);
        boolean boolean53 = rectangleEdge42.equals((java.lang.Object) categoryItemLabelGenerator50);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline54 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long55 = segmentedTimeline54.getSegmentSize();
        long long57 = segmentedTimeline54.toTimelineValue((long) (short) 0);
        long long60 = segmentedTimeline54.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean61 = rectangleEdge42.equals((java.lang.Object) segmentedTimeline54);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        java.awt.geom.Rectangle2D rectangle2D63 = axisSpace21.reserved(rectangle2D24, rectangleEdge42);
        plotRenderingInfo18.setDataArea(rectangle2D63);
        categoryPlot4.handleClick(2, 5, plotRenderingInfo18);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState66 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = categoryItemRendererState66.getInfo();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(font48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 900000L + "'", long55 == 900000L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-32400010L) + "'", long57 == (-32400010L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(plotRenderingInfo67);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("");
        taskSeries1.setKey((java.lang.Comparable) 0.5f);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Paint paint1 = stackedBarRenderer3D0.getWallPaint();
        boolean boolean3 = stackedBarRenderer3D0.equals((java.lang.Object) 0.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        boolean boolean7 = stackedBarRenderer3D0.equals((java.lang.Object) sortOrder6);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo4, point2D5);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        polarPlot0.setNoDataMessagePaint(paint7);
        polarPlot0.setRadiusGridlinesVisible(true);
        try {
            double double11 = polarPlot0.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.Object obj2 = dataPackageResources0.getObject("java.awt.Color[r=255,g=175,b=175]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key java.awt.Color[r=255,g=175,b=175]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener28 = null;
        jFreeChart27.removeProgressListener(chartProgressListener28);
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer30 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double31 = layeredBarRenderer30.getItemMargin();
        java.awt.Paint paint34 = layeredBarRenderer30.getItemLabelPaint((int) (byte) 100, (int) (byte) -1);
        jFreeChart27.setBorderPaint(paint34);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.2d + "'", double31 == 0.2d);
        org.junit.Assert.assertNotNull(paint34);
    }
}

