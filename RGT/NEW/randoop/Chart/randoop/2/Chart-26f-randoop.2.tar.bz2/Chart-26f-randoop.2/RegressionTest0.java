import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 1L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {2}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_BLUE;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", shape4, stroke5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) '4', (double) '4', rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        org.jfree.data.Range range5 = null;
        try {
            numberAxis3D1.setRange(range5, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) (short) 10, shape1, "({0}, {1}) = {2}", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        java.awt.Shape shape4 = null;
        try {
            numberAxis3D1.setUpArrow(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            stackedAreaRenderer1.drawBackground(graphics2D7, categoryPlot12, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double[][] doubleArray0 = new double[][] {};
        double[] doubleArray4 = new double[] { 1.0f, 1.0E-8d, 9 };
        double[] doubleArray8 = new double[] { 1.0f, 1.0E-8d, 9 };
        double[] doubleArray12 = new double[] { 1.0f, 1.0E-8d, 9 };
        double[] doubleArray16 = new double[] { 1.0f, 1.0E-8d, 9 };
        double[] doubleArray20 = new double[] { 1.0f, 1.0E-8d, 9 };
        double[][] doubleArray21 = new double[][] { doubleArray4, doubleArray8, doubleArray12, doubleArray16, doubleArray20 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset22 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray0, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = null;
        org.jfree.chart.text.TextAnchor textAnchor20 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick22 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1L, textBlock18, textBlockAnchor19, textAnchor20, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", graphics2D1, (float) (short) 10, (float) 9, textAnchor4, (double) (byte) 1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        java.awt.Paint paint7 = null;
        try {
            stackedAreaRenderer1.setBaseItemLabelPaint(paint7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            org.jfree.data.Range range11 = stackedAreaRenderer1.findRangeBounds(categoryDataset10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        boolean boolean9 = categoryPlot4.equals((java.lang.Object) 12.0d);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, 0.0f, (float) (byte) 100, textAnchor4, (double) 2958465, textAnchor6);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = color1.darker();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        valueMarker5.setAlpha((float) 0L);
        java.lang.Class class8 = null;
        try {
            java.util.EventListener[] eventListenerArray9 = valueMarker5.getListeners(class8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = null;
        try {
            java.awt.Shape shape25 = textBlock17.calculateBounds(graphics2D18, (float) 2958465, (float) '#', textBlockAnchor21, (float) 6, (float) 100, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1, (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Shape shape0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        try {
            lineRenderer3D0.setSeriesURLGenerator((int) (byte) -1, categoryURLGenerator2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit((int) '4', (int) (short) 10, (int) (byte) 100, (int) '#', dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        boolean boolean9 = numberAxis3D1.getAutoRangeStickyZero();
        numberAxis3D1.setAutoRangeMinimumSize((double) '#');
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("ERROR : Relative To String", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100, (int) (short) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            boolean boolean13 = categoryPlot6.removeAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets5.createAdjustedRectangle(rectangle2D6, lengthAdjustmentType7, lengthAdjustmentType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        boolean boolean16 = stackedAreaRenderer1.getItemCreateEntity((int) '4', (-1));
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font23 = categoryAxis21.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer19.setBaseItemLabelFont(font23);
        stackedAreaRenderer1.setSeriesItemLabelFont((int) (short) 0, font23, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), plotRenderingInfo18, point2D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot16.setRangeAxisLocation((int) ' ', axisLocation22, false);
        float float25 = categoryPlot16.getBackgroundAlpha();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            lineRenderer3D0.drawOutline(graphics2D11, categoryPlot16, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) plot2, jFreeChart3, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.0d));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("TextAnchor.BOTTOM_RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.0d));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        boolean boolean9 = numberAxis3D1.getAutoRangeStickyZero();
        numberAxis3D1.resizeRange(1.0E-8d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, (int) (short) 0, 6);
        java.util.Date date4 = null;
        try {
            long long5 = segmentedTimeline3.getTime(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, (int) (short) 0, 6);
        java.util.Date date4 = null;
        java.util.Date date5 = null;
        try {
            boolean boolean6 = segmentedTimeline3.containsDomainRange(date4, date5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        java.awt.Paint paint11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            stackedAreaRenderer8.setSeriesFillPaint((-1), paint11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            float float4 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getMiddleMillisecond();
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(1900, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation10, false);
        categoryPlot4.clearDomainMarkers();
        categoryPlot4.clearAnnotations();
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0E-8d, (byte) -1, (short) 0, (short) 1, 1L };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray5 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 9, (short) 1 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 9, (short) 1 };
        java.lang.Number[][] numberArray13 = new java.lang.Number[][] { numberArray9, numberArray12 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset14 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray6, numberArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray13);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100L, true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis11 };
        categoryPlot10.setDomainAxes(categoryAxisArray12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState16 = stackedBarRenderer3D3.initialise(graphics2D4, rectangle2D5, categoryPlot10, 2, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.String[] strArray6 = new java.lang.String[] { "", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", "", "({0}, {1}) = {2}", "java.awt.Color[r=255,g=175,b=175]" };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0L, (short) -1, Double.NaN, Double.NaN, (-1) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0L, (short) -1, Double.NaN, Double.NaN, (-1) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0L, (short) -1, Double.NaN, Double.NaN, (-1) };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0L, (short) -1, Double.NaN, Double.NaN, (-1) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0L, (short) -1, Double.NaN, Double.NaN, (-1) };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray13, numberArray19, numberArray25, numberArray31, numberArray37 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset39 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray6, numberArray7, numberArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        org.jfree.data.Range range3 = null;
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range3, (double) 1);
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range3);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        java.lang.String str10 = axisLocation9.toString();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str10.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = flowArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Comparable comparable1 = null;
        try {
            java.lang.Number number3 = taskSeriesCollection0.getStartValue(comparable1, (java.lang.Comparable) "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double7 = rectangleInsets5.calculateRightOutset((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets5.createOutsetRectangle(rectangle2D8, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        try {
            java.awt.Shape shape25 = textBlock17.calculateBounds(graphics2D18, (float) '#', 0.0f, textBlockAnchor21, (float) 10, (float) '4', (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor2 = itemLabelPosition1.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor3, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = null;
        projectInfo0.setContributors(list1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12 };
        categoryPlot11.setDomainAxes(categoryAxisArray13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent15);
        numberAxis3D4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double18 = numberAxis3D4.getAutoRangeMinimumSize();
        boolean boolean19 = projectInfo0.equals((java.lang.Object) numberAxis3D4);
        try {
            numberAxis3D4.setRange((double) 9, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (9.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.lang.Boolean boolean4 = lineRenderer3D0.getSeriesVisible((int) (short) 0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Stroke stroke13 = null;
        categoryPlot12.setOutlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot12.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getRangeAxisEdge(0);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot12.setOutlineStroke(stroke19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font24 = categoryAxis22.getTickLabelFont((java.lang.Comparable) 100.0f);
        categoryAxis22.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D28.setLabelFont(font29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray37 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis36 };
        categoryPlot35.setDomainAxes(categoryAxisArray37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        numberAxis3D28.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        numberAxis3D28.configure();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        try {
            lineRenderer3D0.drawItem(graphics2D5, categoryItemRendererState6, rectangle2D7, categoryPlot12, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, categoryDataset43, (int) (short) -1, 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(categoryAxisArray37);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = new org.jfree.chart.axis.SegmentedTimeline(1L, (int) (short) 0, 6);
        try {
            segmentedTimeline0.setBaseTimeline(segmentedTimeline4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getSegmentSize() is smaller than segmentSize");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("HorizontalAlignment.CENTER");
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible(10, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis3D1.configure();
        numberAxis3D1.setNegativeArrowVisible(true);
        try {
            numberAxis3D1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = color5.darker();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor13 = itemLabelPosition12.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str15 = textAnchor14.toString();
        org.jfree.chart.axis.NumberTick numberTick17 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor13, textAnchor14, 1.0d);
        valueMarker9.setLabelTextAnchor(textAnchor14);
        org.jfree.chart.text.TextAnchor textAnchor20 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.BOTTOM_RIGHT", graphics2D1, (float) (byte) 100, (float) 2, textAnchor14, (double) 10L, textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str15.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        float float9 = categoryPlot4.getForegroundAlpha();
        boolean boolean10 = categoryPlot4.isDomainZoomable();
        java.awt.Paint paint11 = null;
        try {
            categoryPlot4.setRangeGridlinePaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = stackedAreaRenderer1.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, keyToGroupMap2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        java.awt.Shape shape32 = null;
        try {
            org.jfree.chart.entity.AxisLabelEntity axisLabelEntity35 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis3D1, shape32, "HorizontalAlignment.CENTER", "({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor3, textAnchor4, 1.0d);
        java.lang.Number number8 = numberTick7.getNumber();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str5.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 1 + "'", number8.equals((short) 1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        java.lang.Boolean boolean13 = stackedAreaRenderer1.getSeriesVisible(0);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.geom.Point2D point2D0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (short) -1, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        java.lang.Object obj32 = jFreeChart27.clone();
        org.jfree.chart.event.ChartChangeListener chartChangeListener33 = null;
        try {
            jFreeChart27.removeChangeListener(chartChangeListener33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        java.lang.Object obj32 = jFreeChart27.clone();
        org.jfree.chart.title.Title title33 = null;
        try {
            jFreeChart27.addSubtitle(title33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        java.awt.Color color14 = java.awt.Color.pink;
        java.lang.String str15 = color14.toString();
        java.awt.Color color16 = color14.darker();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke17);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color14.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font11, (java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        java.awt.Stroke stroke31 = null;
        categoryPlot30.setOutlineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font11, (org.jfree.chart.plot.Plot) categoryPlot30, false);
        jFreeChart34.setBackgroundImageAlignment(100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D1, jFreeChart34);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent37.setType(chartChangeEventType38);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str15.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1546329600000L, paint1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double7 = rectangleInsets5.calculateRightOutset((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            rectangleInsets5.trim(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot12.setRangeAxisLocation((int) ' ', axisLocation18, false);
        categoryPlot4.setDomainAxisLocation((int) (short) 10, axisLocation18, true);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(3, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D5 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D5.setDrawOutlines(true);
        java.lang.Boolean boolean9 = lineRenderer3D5.getSeriesVisible((int) (short) 0);
        lineRenderer3D5.setBaseShapesFilled(false);
        boolean boolean12 = categoryPlot4.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        categoryPlot4.setOutlinePaint(paint12);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        stackedAreaRenderer1.setBaseShape(shape18, false);
        stackedAreaRenderer1.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("Range[1.0,1.0]");
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        stackedAreaRenderer1.setBaseShape(shape18, false);
        stackedAreaRenderer1.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.addOptionalLibrary("Range[1.0,1.0]");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (byte) 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.awt.Color color0 = java.awt.Color.pink;
        java.lang.String str1 = color0.toString();
        java.awt.Color color2 = color0.darker();
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            blockBorder3.draw(graphics2D4, rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets5.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        double double3 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = color1.darker();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        int int6 = color1.getRed();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getRowKey((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        java.awt.Stroke stroke11 = null;
        categoryPlot10.setOutlineStroke(stroke11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot10.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer5.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        stackedAreaRenderer5.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer5.setBaseShape(shape20, true);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray29 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot27.setDomainAxes(categoryAxisArray29);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        categoryPlot27.datasetChanged(datasetChangeEvent31);
        categoryPlot27.setBackgroundAlpha((float) 0);
        java.awt.Color color35 = java.awt.Color.pink;
        java.lang.String str36 = color35.toString();
        java.awt.Color color37 = color35.darker();
        categoryPlot27.setOutlinePaint((java.awt.Paint) color37);
        java.awt.Stroke stroke39 = categoryPlot27.getRangeGridlineStroke();
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_RED;
        try {
            org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem(attributedString0, "", "({0}, {1}) = {2}", "HorizontalAlignment.CENTER", shape20, stroke39, (java.awt.Paint) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(categoryAxisArray29);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str36.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            multiplePiePlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 61200000L + "'", long1 == 61200000L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Font font3 = lineRenderer3D0.getItemLabelFont((int) (byte) 10, 6);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        java.awt.Stroke stroke10 = null;
        categoryPlot9.setOutlineStroke(stroke10);
        java.awt.Font font12 = categoryPlot9.getNoDataMessageFont();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            lineRenderer3D0.drawOutline(graphics2D4, categoryPlot9, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays((int) (short) 10, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            java.lang.Number number8 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) date5, (java.lang.Comparable) 1562097599999L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        stackedAreaRenderer1.setBaseToolTipGenerator(categoryToolTipGenerator14, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject((int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        try {
            java.lang.Comparable comparable7 = taskSeriesCollection0.getRowKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = null;
        try {
            categoryPlot4.setRangeAxes(valueAxisArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot4.getRenderer();
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertNull(categoryItemRenderer9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Stroke stroke6 = null;
        categoryPlot5.setOutlineStroke(stroke6);
        java.awt.Font font8 = categoryPlot5.getNoDataMessageFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=175,b=175]", font8, (java.awt.Paint) color9, 0.0f, (int) 'a', textMeasurer12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        int int14 = stackedAreaRenderer1.getRowCount();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        numberAxis3D1.setUpperMargin(1.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer1.setBaseStroke(stroke14);
        java.lang.Boolean boolean17 = stackedAreaRenderer1.getSeriesCreateEntities((-1));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Comparable[] comparableArray0 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 9);
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 1, Double.NaN, 9 };
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[] numberArray8 = new java.lang.Number[] {};
        java.lang.Number[] numberArray9 = new java.lang.Number[] {};
        java.lang.Number[] numberArray10 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray11 = new java.lang.Number[][] { numberArray6, numberArray7, numberArray8, numberArray9, numberArray10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 2, 3, 9, (short) 100, (-4.0d), (-1.0d) };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 2, 3, 9, (short) 100, (-4.0d), (-1.0d) };
        java.lang.Number[][] numberArray26 = new java.lang.Number[][] { numberArray18, numberArray25 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset27 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray0, comparableArray5, numberArray11, numberArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray26);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        boolean boolean19 = lengthConstraintType0.equals((java.lang.Object) textBlock18);
        java.awt.Graphics2D graphics2D20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = textBlock18.calculateDimensions(graphics2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        boolean boolean9 = categoryPlot4.equals((java.lang.Object) 12.0d);
        java.awt.Stroke stroke10 = categoryPlot4.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int18 = taskSeriesCollection16.getColumnIndex((java.lang.Comparable) (short) -1);
        boolean boolean19 = taskSeriesCollection0.hasListener((java.util.EventListener) taskSeriesCollection16);
        try {
            taskSeriesCollection16.remove((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        java.awt.Paint paint15 = numberAxis3D1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot4.getDomainMarkers((int) (byte) -1, layer8);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        boolean boolean16 = stackedAreaRenderer1.getItemCreateEntity((int) '4', (-1));
        java.awt.Stroke stroke17 = null;
        try {
            stackedAreaRenderer1.setBaseStroke(stroke17, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace15);
        categoryPlot8.clearAnnotations();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        lineRenderer3D0.setBaseLinesVisible(true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        java.awt.Paint paint7 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D11.setLabelFont(font12);
        java.awt.Color color15 = java.awt.Color.pink;
        java.lang.String str16 = color15.toString();
        java.awt.Color color17 = color15.darker();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke18);
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color15.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font12, (java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        java.awt.Stroke stroke32 = null;
        categoryPlot31.setOutlineStroke(stroke32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font12, (org.jfree.chart.plot.Plot) categoryPlot31, false);
        jFreeChart35.setBackgroundImageAlignment(100);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart35.setBackgroundPaint((java.awt.Paint) color38);
        categoryPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot4.setRangeCrosshairStroke(stroke41);
        java.util.List list43 = categoryPlot4.getAnnotations();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str16.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double8 = categoryAxis1.getLowerMargin();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        java.awt.Stroke stroke18 = null;
        categoryPlot17.setOutlineStroke(stroke18);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot17.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot17.getRangeAxisEdge(0);
        boolean boolean25 = rectangleEdge23.equals((java.lang.Object) false);
        org.jfree.chart.entity.EntityCollection entityCollection26 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo(entityCollection26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        try {
            org.jfree.chart.axis.AxisState axisState29 = categoryAxis1.draw(graphics2D9, 0.2d, rectangle2D11, rectangle2D12, rectangleEdge23, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        double double10 = categoryPlot4.getAnchorValue();
        int int11 = categoryPlot4.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot4.notifyListeners(plotChangeEvent9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D11 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D11.setDrawOutlines(true);
        boolean boolean14 = lineRenderer3D11.getBaseShapesVisible();
        java.awt.Font font16 = lineRenderer3D11.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        lineRenderer3D11.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        lineRenderer3D11.setBaseShapesVisible(false);
        int int23 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineRenderer3D11);
        java.awt.Paint paint24 = null;
        try {
            lineRenderer3D11.setBaseItemLabelPaint(paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String[] strArray2 = dataPackageResources0.getStringArray("org.jfree.data.UnknownKeyException: ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.lang.String str8 = legendItem7.getDescription();
        java.awt.Stroke stroke9 = legendItem7.getLineStroke();
        java.awt.Paint paint10 = legendItem7.getLinePaint();
        java.awt.Shape shape11 = legendItem7.getShape();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str8.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getStartValue((int) (byte) 0, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10L, (double) (byte) 0);
        java.lang.Object obj3 = null;
        boolean boolean4 = stackedBarRenderer3D2.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        boolean boolean21 = lineRenderer3D0.getItemShapeVisible(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint24 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis23.setTickMarkPaint(paint24);
        lineRenderer3D0.setBaseOutlinePaint(paint24);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener27 = null;
        try {
            lineRenderer3D0.removeChangeListener(rendererChangeListener27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        long long2 = segmentedTimeline0.getSegmentsIncludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25200000L + "'", long2 == 25200000L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        int int3 = taskSeriesCollection0.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        numberAxis3D1.setTickMarkOutsideLength((float) 100);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot4.getFixedRangeAxisSpace();
        java.awt.Color color15 = java.awt.Color.pink;
        java.lang.String str16 = color15.toString();
        java.awt.Color color17 = color15.darker();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke18);
        valueMarker19.setAlpha((float) 0L);
        categoryPlot4.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        java.awt.Stroke stroke23 = valueMarker19.getStroke();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str16.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int18 = taskSeriesCollection16.getColumnIndex((java.lang.Comparable) (short) -1);
        boolean boolean19 = taskSeriesCollection0.hasListener((java.util.EventListener) taskSeriesCollection16);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.0d));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = categoryLabelPosition2.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryLabelPosition2.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition2);
        double double6 = categoryLabelPosition2.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setWeight((int) (byte) 0);
        java.util.List list14 = categoryPlot4.getAnnotations();
        java.util.Collection collection15 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list14);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(collection15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            int int3 = taskSeriesCollection0.getSubIntervalCount((int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape19, stroke20, (java.awt.Paint) color21);
        numberAxis3D1.setUpArrow(shape19);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        categoryPlot10.setBackgroundAlpha((float) 6);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font18 = categoryAxis16.getTickLabelFont((java.lang.Comparable) 100.0f);
        categoryAxis16.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D22.setLabelFont(font23);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray31 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis30 };
        categoryPlot29.setDomainAxes(categoryAxisArray31);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent33 = null;
        categoryPlot29.datasetChanged(datasetChangeEvent33);
        numberAxis3D22.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        numberAxis3D22.configure();
        numberAxis3D22.setNegativeArrowVisible(true);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection39 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int41 = taskSeriesCollection39.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection39, true);
        java.lang.Number number44 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection39);
        try {
            statisticalLineAndShapeRenderer2.drawItem(graphics2D3, categoryItemRendererState4, rectangle2D5, categoryPlot10, categoryAxis16, (org.jfree.chart.axis.ValueAxis) numberAxis3D22, (org.jfree.data.category.CategoryDataset) taskSeriesCollection39, (int) (byte) 10, 255, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(categoryAxisArray31);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.0d + "'", number44.equals(0.0d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        jFreeChart27.setTextAntiAlias(true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent35 = null;
        try {
            jFreeChart27.titleChanged(titleChangeEvent35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D7.setLabelFont(font8);
        java.awt.Color color11 = java.awt.Color.pink;
        java.lang.String str12 = color11.toString();
        java.awt.Color color13 = color11.darker();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color11.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font8, (java.awt.Paint) color11);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        java.awt.Stroke stroke28 = null;
        categoryPlot27.setOutlineStroke(stroke28);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font8, (org.jfree.chart.plot.Plot) categoryPlot27, false);
        java.awt.Shape shape36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape36, stroke37, (java.awt.Paint) color38);
        java.lang.String str40 = legendItem39.getDescription();
        java.awt.Stroke stroke41 = legendItem39.getLineStroke();
        categoryPlot27.setDomainGridlineStroke(stroke41);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, paint1, stroke2, (java.awt.Paint) color3, stroke41, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str12.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNotNull(textBlock22);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str40.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Range[1.0,1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer1.setBaseStroke(stroke14);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer1.setSeriesStroke(0, stroke17, false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.TRUNCATE" + "'", str1.equals("AreaRendererEndType.TRUNCATE"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        categoryAxis16.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot21);
        boolean boolean23 = categoryPlot21.isRangeZoomable();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            lineRenderer3D0.drawBackground(graphics2D14, categoryPlot21, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot19.addChangeListener(plotChangeListener20);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer23);
        java.awt.Color color26 = java.awt.Color.pink;
        java.lang.String str27 = color26.toString();
        java.awt.Color color28 = color26.darker();
        org.jfree.chart.block.BlockBorder blockBorder29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color26);
        java.awt.Color color31 = java.awt.Color.pink;
        java.lang.String str32 = color31.toString();
        java.awt.Color color33 = color31.darker();
        java.awt.Stroke stroke34 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color31, stroke34);
        valueMarker35.setAlpha((float) 0L);
        java.awt.Stroke stroke38 = valueMarker35.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color26, stroke38);
        categoryPlot19.addDomainMarker(categoryMarker39);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D42.setLabelFont(font43);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis47, categoryItemRenderer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray51 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis50 };
        categoryPlot49.setDomainAxes(categoryAxisArray51);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent53 = null;
        categoryPlot49.datasetChanged(datasetChangeEvent53);
        numberAxis3D42.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot49);
        java.awt.Color color57 = java.awt.Color.pink;
        java.lang.String str58 = color57.toString();
        java.awt.Color color59 = color57.darker();
        java.awt.Stroke stroke60 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color57, stroke60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        try {
            stackedAreaRenderer1.drawRangeMarker(graphics2D14, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, (org.jfree.chart.plot.Marker) valueMarker61, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str27.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str32.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(categoryAxisArray51);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str58.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock17.setLineAlignment(horizontalAlignment18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        try {
            textBlock17.draw(graphics2D20, (float) 9, (float) 2, textBlockAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.Rotation rotation1 = null;
        try {
            piePlot3D0.setDirection(rotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        java.lang.Boolean boolean7 = lineRenderer3D0.getSeriesCreateEntities(2958465);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Comparable comparable6 = taskSeriesCollection0.getColumnKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 100, 0.2d, (double) (-1.0f), (double) 2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("ERROR : Relative To String");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.String str3 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: ERROR : Relative To String" + "'", str2.equals("org.jfree.data.UnknownKeyException: ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: ERROR : Relative To String" + "'", str3.equals("org.jfree.data.UnknownKeyException: ERROR : Relative To String"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.lang.Object obj4 = null;
        boolean boolean5 = lineRenderer3D0.equals(obj4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        double double14 = categoryPlot8.getAnchorValue();
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D17 = labelBlock16.getBounds();
        try {
            stackedBarRenderer3D2.drawDomainGridline(graphics2D3, categoryPlot8, rectangle2D17, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("AxisLocation.BOTTOM_OR_LEFT");
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long4 = segmentedTimeline3.getSegmentSize();
        long long6 = segmentedTimeline3.toTimelineValue((long) (short) 0);
        long long9 = segmentedTimeline3.getExceptionSegmentCount((long) ' ', (long) 0);
        try {
            int int10 = simpleTimePeriod2.compareTo((java.lang.Object) segmentedTimeline3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.SegmentedTimeline cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 900000L + "'", long4 == 900000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 644288400000L + "'", long6 == 644288400000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        boolean boolean16 = stackedAreaRenderer1.getItemCreateEntity((int) '4', (-1));
        java.awt.Paint paint19 = stackedAreaRenderer1.getItemPaint(100, 255);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock23.getBounds();
        try {
            stackedAreaRenderer1.drawOutline(graphics2D20, categoryPlot21, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangle2D24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        size2D2.setWidth((double) 0.5f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        java.lang.Object obj1 = null;
        boolean boolean2 = itemLabelAnchor0.equals(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        categoryPlot4.clearRangeMarkers();
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset(2.0d);
        double double4 = rectangleInsets0.calculateLeftOutset((double) (short) 0);
        double double6 = rectangleInsets0.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        float float33 = jFreeChart27.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.5f + "'", float33 == 0.5f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        numberAxis3D1.setAutoRange(false);
        java.awt.Shape shape34 = numberAxis3D1.getLeftArrow();
        java.io.ObjectOutputStream objectOutputStream35 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape34, objectOutputStream35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D15 = labelBlock14.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes((double) (-1), plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setRangeAxisLocation((int) ' ', axisLocation26, false);
        float float29 = categoryPlot20.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot20.getRangeMarkers((int) (byte) 0, layer31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot20.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D34 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D34.setDrawOutlines(true);
        boolean boolean37 = lineRenderer3D34.getBaseShapesVisible();
        java.awt.Font font39 = lineRenderer3D34.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        lineRenderer3D34.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator41, false);
        boolean boolean44 = rectangleEdge33.equals((java.lang.Object) categoryItemLabelGenerator41);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline45 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long46 = segmentedTimeline45.getSegmentSize();
        long long48 = segmentedTimeline45.toTimelineValue((long) (short) 0);
        long long51 = segmentedTimeline45.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean52 = rectangleEdge33.equals((java.lang.Object) segmentedTimeline45);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge33);
        java.awt.geom.Rectangle2D rectangle2D54 = axisSpace12.reserved(rectangle2D15, rectangleEdge33);
        org.jfree.chart.entity.EntityCollection entityCollection55 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo(entityCollection55);
        java.lang.Object obj57 = chartRenderingInfo56.clone();
        try {
            jFreeChart10.draw(graphics2D11, rectangle2D54, chartRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(font39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 900000L + "'", long46 == 900000L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 644288400000L + "'", long48 == 644288400000L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        boolean boolean10 = numberAxis3D1.isTickLabelsVisible();
        java.awt.Color color11 = java.awt.Color.pink;
        numberAxis3D1.setLabelPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font16 = categoryAxis14.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D1.setTickLabelFont(font16);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setShadowYOffset((double) 10.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) '4', (float) 2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape2, rectangleAnchor3, 100.0d, 0.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        try {
            jFreeChart10.plotChanged(plotChangeEvent27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        java.awt.Stroke stroke11 = null;
        categoryPlot10.setOutlineStroke(stroke11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot10.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer5.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        stackedAreaRenderer5.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer5.setBaseShape(shape20, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D24.setLabelFont(font25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis3D24.getStandardTickUnits();
        numberAxis3D24.centerRange((double) (short) 0);
        numberAxis3D24.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D38 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D38.setLabelFont(font39);
        java.awt.Color color42 = java.awt.Color.pink;
        java.lang.String str43 = color42.toString();
        java.awt.Color color44 = color42.darker();
        java.awt.Stroke stroke45 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color42, stroke45);
        java.awt.image.ColorModel colorModel47 = null;
        java.awt.Rectangle rectangle48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.geom.AffineTransform affineTransform50 = null;
        java.awt.RenderingHints renderingHints51 = null;
        java.awt.PaintContext paintContext52 = color42.createContext(colorModel47, rectangle48, rectangle2D49, affineTransform50, renderingHints51);
        org.jfree.chart.text.TextBlock textBlock53 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font39, (java.awt.Paint) color42);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D24, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font39);
        numberAxis3D24.setAutoRange(false);
        org.jfree.data.RangeType rangeType57 = numberAxis3D24.getRangeType();
        java.awt.Stroke stroke58 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean59 = rangeType57.equals((java.lang.Object) stroke58);
        java.awt.Color color61 = java.awt.Color.pink;
        java.awt.Color color62 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", color61);
        try {
            org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem(attributedString0, "HorizontalAlignment.CENTER", "Range[1.0,1.0]", "HorizontalAlignment.CENTER", shape20, stroke58, (java.awt.Paint) color62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str43.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paintContext52);
        org.junit.Assert.assertNotNull(textBlock53);
        org.junit.Assert.assertNotNull(rangeType57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str2 = textAnchor1.toString();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font11 = categoryAxis9.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer7.setBaseItemLabelFont(font11);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = stackedAreaRenderer7.getLegendItems();
        java.lang.Object obj14 = legendItemCollection13.clone();
        boolean boolean15 = segmentedTimeline4.equals(obj14);
        boolean boolean16 = itemLabelAnchor0.equals(obj14);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str2.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        java.lang.Boolean boolean5 = lineRenderer3D0.getSeriesLinesVisible(1900);
        lineRenderer3D0.setSeriesShapesFilled((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot14.getOrientation();
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D21 = labelBlock20.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes((double) (-1), plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot26.setRangeAxisLocation((int) ' ', axisLocation32, false);
        float float35 = categoryPlot26.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot26.getRangeMarkers((int) (byte) 0, layer37);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot26.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D40 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D40.setDrawOutlines(true);
        boolean boolean43 = lineRenderer3D40.getBaseShapesVisible();
        java.awt.Font font45 = lineRenderer3D40.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = null;
        lineRenderer3D40.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator47, false);
        boolean boolean50 = rectangleEdge39.equals((java.lang.Object) categoryItemLabelGenerator47);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline51 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long52 = segmentedTimeline51.getSegmentSize();
        long long54 = segmentedTimeline51.toTimelineValue((long) (short) 0);
        long long57 = segmentedTimeline51.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean58 = rectangleEdge39.equals((java.lang.Object) segmentedTimeline51);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge39);
        java.awt.geom.Rectangle2D rectangle2D60 = axisSpace18.reserved(rectangle2D21, rectangleEdge39);
        try {
            lineRenderer3D0.drawDomainGridline(graphics2D9, categoryPlot14, rectangle2D21, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(font45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 900000L + "'", long52 == 900000L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 644288400000L + "'", long54 == 644288400000L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(rectangle2D60);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        java.lang.Boolean boolean5 = lineRenderer3D0.getSeriesLinesVisible(1900);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            lineRenderer3D0.setSeriesOutlineStroke((int) (byte) -1, stroke7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        org.jfree.chart.util.Rotation rotation2 = null;
        try {
            piePlot3D0.setDirection(rotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = null;
        projectInfo0.setContributors(list1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12 };
        categoryPlot11.setDomainAxes(categoryAxisArray13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent15);
        numberAxis3D4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double18 = numberAxis3D4.getAutoRangeMinimumSize();
        boolean boolean19 = projectInfo0.equals((java.lang.Object) numberAxis3D4);
        java.awt.Shape shape20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        numberAxis3D4.setRightArrow(shape20);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        boolean boolean21 = lineRenderer3D0.getItemCreateEntity(0, 0);
        java.awt.Font font23 = lineRenderer3D0.getSeriesItemLabelFont(1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.UnknownKeyException: ERROR : Relative To String");
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("AreaRendererEndType.TRUNCATE", "HorizontalAlignment.CENTER", "TextAnchor.BOTTOM_RIGHT", "Pie 3D Plot", "hi!");
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        boolean boolean19 = lengthConstraintType0.equals((java.lang.Object) textBlock18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        try {
            textBlock18.draw(graphics2D20, (float) 10L, (float) 2, textBlockAnchor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        lineRenderer3D0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint8 = lineRenderer3D0.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D32 = labelBlock31.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot37.zoomRangeAxes((double) (-1), plotRenderingInfo39, point2D40);
        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot37.setRangeAxisLocation((int) ' ', axisLocation43, false);
        float float46 = categoryPlot37.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot37.getRangeMarkers((int) (byte) 0, layer48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot37.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D51 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D51.setDrawOutlines(true);
        boolean boolean54 = lineRenderer3D51.getBaseShapesVisible();
        java.awt.Font font56 = lineRenderer3D51.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator58 = null;
        lineRenderer3D51.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator58, false);
        boolean boolean61 = rectangleEdge50.equals((java.lang.Object) categoryItemLabelGenerator58);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline62 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long63 = segmentedTimeline62.getSegmentSize();
        long long65 = segmentedTimeline62.toTimelineValue((long) (short) 0);
        long long68 = segmentedTimeline62.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean69 = rectangleEdge50.equals((java.lang.Object) segmentedTimeline62);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge50);
        java.awt.geom.Rectangle2D rectangle2D71 = axisSpace29.reserved(rectangle2D32, rectangleEdge50);
        org.jfree.chart.entity.EntityCollection entityCollection72 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = new org.jfree.chart.ChartRenderingInfo(entityCollection72);
        try {
            jFreeChart27.draw(graphics2D28, rectangle2D32, chartRenderingInfo73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 1.0f + "'", float46 == 1.0f);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(font56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 900000L + "'", long63 == 900000L);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 644288400000L + "'", long65 == 644288400000L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(rectangle2D71);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = java.awt.Color.getColor("({0}, {1}) = {2}", color1);
        float[] floatArray4 = new float[] {};
        try {
            float[] floatArray5 = color1.getColorComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.util.Locale locale1 = null;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass3 = stroke2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("Range[1.0,1.0]", locale1, classLoader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            java.lang.Number number8 = taskSeriesCollection0.getStartValue(1, 68, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int0 = org.jfree.chart.axis.DateTickUnit.MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "({0}, {1}) = {2}", "java.awt.Color[r=255,g=175,b=175]", "AreaRendererEndType.TRUNCATE");
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.util.SortOrder sortOrder16 = null;
        try {
            categoryPlot4.setRowRenderingOrder(sortOrder16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot4.markerChanged(markerChangeEvent12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot4.notifyListeners(plotChangeEvent14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis11.setTickMarkPaint(paint12);
        int int14 = numberTickUnit9.compareTo((java.lang.Object) categoryAxis11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = null;
        try {
            categoryAxis11.setCategoryLabelPositions(categoryLabelPositions15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = java.awt.Color.black;
        piePlot3D0.setLabelPaint((java.awt.Paint) color1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D6 = labelBlock5.getBounds();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getIgnoreNullValues();
        boolean boolean9 = piePlot3D7.getLabelLinksVisible();
        java.awt.Paint paint10 = piePlot3D7.getBaseSectionOutlinePaint();
        java.awt.Paint paint11 = piePlot3D7.getLabelOutlinePaint();
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo16);
        java.awt.geom.Point2D point2D18 = null;
        polarPlot13.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo17, point2D18);
        try {
            org.jfree.chart.plot.PiePlotState piePlotState20 = piePlot3D0.initialise(graphics2D3, rectangle2D6, (org.jfree.chart.plot.PiePlot) piePlot3D7, (java.lang.Integer) 1, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) 'a', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = numberAxis3D15.getStandardTickUnits();
        numberAxis3D15.centerRange((double) (short) 0);
        numberAxis3D15.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D29.setLabelFont(font30);
        java.awt.Color color33 = java.awt.Color.pink;
        java.lang.String str34 = color33.toString();
        java.awt.Color color35 = color33.darker();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color33, stroke36);
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = color33.createContext(colorModel38, rectangle39, rectangle2D40, affineTransform41, renderingHints42);
        org.jfree.chart.text.TextBlock textBlock44 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font30, (java.awt.Paint) color33);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D15, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font30);
        numberAxis3D15.setAutoRange(false);
        org.jfree.data.RangeType rangeType48 = numberAxis3D15.getRangeType();
        java.awt.Stroke stroke49 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        boolean boolean50 = rangeType48.equals((java.lang.Object) stroke49);
        categoryPlot4.setRangeGridlineStroke(stroke49);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str34.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paintContext43);
        org.junit.Assert.assertNotNull(textBlock44);
        org.junit.Assert.assertNotNull(rangeType48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint8 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis7.setTickMarkPaint(paint8);
        lineRenderer3D0.setBaseFillPaint(paint8, false);
        java.awt.Stroke stroke12 = null;
        try {
            lineRenderer3D0.setBaseStroke(stroke12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset1.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0f), (org.jfree.data.KeyedValues) pieDataset10);
        double double12 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset10);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        java.awt.Shape shape10 = numberAxis3D1.getDownArrow();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (short) 0, (int) ' ', 5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        java.awt.Font font14 = stackedAreaRenderer1.getItemLabelFont(10, 255);
        boolean boolean15 = stackedAreaRenderer1.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        lineRenderer3D0.setBaseShapesFilled(false);
        org.jfree.chart.LegendItem legendItem7 = lineRenderer3D0.getLegendItem(0, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        java.lang.Comparable comparable10 = null;
        java.lang.Comparable comparable11 = null;
        try {
            java.lang.Number number12 = defaultCategoryDataset0.getValue(comparable10, comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        java.lang.Boolean boolean5 = statisticalLineAndShapeRenderer2.getSeriesItemLabelsVisible(68);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot4.setRenderer(categoryItemRenderer11, true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.util.Date date1 = null;
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod(date2, date3);
        try {
            org.jfree.data.gantt.Task task5 = new org.jfree.data.gantt.Task("CategoryAnchor.MIDDLE", date1, date3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.mapDatasetToRangeAxis((int) (short) 10, 5);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        categoryPlot4.notifyListeners(plotChangeEvent9);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D11 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D11.setDrawOutlines(true);
        boolean boolean14 = lineRenderer3D11.getBaseShapesVisible();
        java.awt.Font font16 = lineRenderer3D11.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        lineRenderer3D11.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator18, false);
        lineRenderer3D11.setBaseShapesVisible(false);
        int int23 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineRenderer3D11);
        org.jfree.chart.LegendItemCollection legendItemCollection24 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(font16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNull(legendItemCollection24);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.KeyedObjects2D keyedObjects2D1 = new org.jfree.data.KeyedObjects2D();
        boolean boolean2 = blockContainer0.equals((java.lang.Object) keyedObjects2D1);
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer6.setBaseItemLabelFont(font10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = stackedAreaRenderer6.getURLGenerator(0, 3);
        stackedAreaRenderer6.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        boolean boolean21 = stackedAreaRenderer6.getItemCreateEntity((int) '4', (-1));
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font27 = categoryAxis25.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer23.setBaseItemLabelFont(font27);
        stackedAreaRenderer6.setBaseItemLabelFont(font27);
        try {
            blockContainer0.add((org.jfree.chart.block.Block) labelBlock4, (java.lang.Object) stackedAreaRenderer6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.renderer.category.StackedAreaRenderer cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRed();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        boolean boolean4 = blockBorder2.equals((java.lang.Object) itemLabelAnchor3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Font font3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        polarPlot0.setNoDataMessageFont(font3);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        java.lang.String str4 = piePlot3D0.getPlotType();
        java.awt.Paint paint5 = piePlot3D0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot31.zoomRangeAxes((double) (-1), plotRenderingInfo33, point2D34);
        java.awt.Paint paint36 = categoryPlot31.getDomainGridlinePaint();
        valueMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot31);
        categoryPlot31.setForegroundAlpha((float) 255);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        java.awt.Stroke stroke28 = jFreeChart27.getBorderStroke();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D32 = labelBlock31.getBounds();
        try {
            jFreeChart27.draw(graphics2D29, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangle2D32);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection12 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int14 = taskSeriesCollection12.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection12, true);
        java.util.List list17 = taskSeriesCollection12.getColumnKeys();
        org.jfree.data.Range range18 = stackedAreaRenderer1.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection12);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertNull(range18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list5 = null;
        projectInfo4.setContributors(list5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D8.setLabelFont(font9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16 };
        categoryPlot15.setDomainAxes(categoryAxisArray17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent19);
        numberAxis3D8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        double double22 = numberAxis3D8.getAutoRangeMinimumSize();
        boolean boolean23 = projectInfo4.equals((java.lang.Object) numberAxis3D8);
        org.jfree.data.Range range24 = numberAxis3D8.getRange();
        boolean boolean25 = lineRenderer3D0.equals((java.lang.Object) numberAxis3D8);
        numberAxis3D8.setTickMarkOutsideLength((float) 10L);
        numberAxis3D8.setVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 2958465);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        java.awt.Font font14 = stackedAreaRenderer1.getItemLabelFont(10, 255);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedAreaRenderer1.getSeriesToolTipGenerator((-1));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = null;
        stackedAreaRenderer1.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator18, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Stroke stroke12 = null;
        categoryPlot11.setOutlineStroke(stroke12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot11.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getRangeAxisEdge(0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot11.setOutlineStroke(stroke18);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke18, false);
        java.awt.Paint paint22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        lineRenderer3D0.setWallPaint(paint22);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceName();
        java.lang.String str2 = projectInfo0.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LGPL" + "'", str1.equals("LGPL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart" + "'", str2.equals("JFreeChart"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart10.removeProgressListener(chartProgressListener27);
        org.jfree.chart.title.Title title29 = null;
        try {
            jFreeChart10.addSubtitle(title29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight(2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        try {
            taskSeriesCollection0.remove((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: TaskSeriesCollection.remove(): index outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot8.zoomRangeAxes((double) (-1), plotRenderingInfo10, point2D11);
        java.awt.Paint paint13 = categoryPlot8.getDomainGridlinePaint();
        lineRenderer3D0.setSeriesFillPaint(3, paint13);
        lineRenderer3D0.setItemLabelAnchorOffset((double) 10.0f);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = null;
        blockResult0.setEntityCollection(entityCollection1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, 0.0d, true);
        boolean boolean4 = stackedBarRenderer3D3.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass1 = stroke0.getClass();
        java.lang.ClassLoader classLoader2 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass1);
        boolean boolean3 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(stroke0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(classLoader2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, 0.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((double) 4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        boolean boolean14 = stackedAreaRenderer1.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = null;
        projectInfo0.setContributors(list1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12 };
        categoryPlot11.setDomainAxes(categoryAxisArray13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent15);
        numberAxis3D4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double18 = numberAxis3D4.getAutoRangeMinimumSize();
        boolean boolean19 = projectInfo0.equals((java.lang.Object) numberAxis3D4);
        org.jfree.data.Range range20 = numberAxis3D4.getRange();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        java.awt.Stroke stroke28 = null;
        categoryPlot27.setOutlineStroke(stroke28);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot27.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer22.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        stackedAreaRenderer22.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer22.setBaseShape(shape37, true);
        numberAxis3D4.setUpArrow(shape37);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity43 = new org.jfree.chart.entity.TickLabelEntity(shape37, "CategoryAnchor.MIDDLE", "AreaRendererEndType.TRUNCATE");
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(shape37);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        piePlot3D0.markerChanged(markerChangeEvent4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        double double8 = categoryPlot6.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType10 = categoryLabelPosition9.getWidthType();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        boolean boolean12 = categoryLabelWidthType10.equals((java.lang.Object) color11);
        categoryPlot6.setOutlinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelWidthType10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double5 = rectangleInsets3.calculateTopOutset(2.0d);
        double double7 = rectangleInsets3.calculateLeftOutset((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str13 = textAnchor12.toString();
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor11, textAnchor12, 1.0d);
        boolean boolean16 = rectangleInsets3.equals((java.lang.Object) textAnchor12);
        org.jfree.chart.axis.NumberTick numberTick18 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 25200000L, "AxisLocation.BOTTOM_OR_LEFT", textAnchor2, textAnchor12, (double) 2958465);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str13.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("({0}, {1}) = {2}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.awt.Color color0 = java.awt.Color.pink;
        java.lang.String str1 = color0.toString();
        java.awt.Color color2 = color0.darker();
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean5 = blockBorder3.equals((java.lang.Object) projectInfo4);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection6 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int8 = taskSeriesCollection6.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection6, true);
        org.jfree.data.general.DatasetGroup datasetGroup11 = taskSeriesCollection6.getGroup();
        java.util.List list12 = taskSeriesCollection6.getRowKeys();
        boolean boolean13 = blockBorder3.equals((java.lang.Object) list12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(datasetGroup11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        categoryPlot4.mapDatasetToDomainAxis((int) 'a', (int) ' ');
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(10L);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        piePlot3D0.setCircular(true, false);
        boolean boolean12 = piePlot3D0.getLabelLinksVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("HorizontalAlignment.CENTER", "Range[1.0,1.0]", "Range[1.0,1.0]", "AxisLocation.BOTTOM_OR_LEFT", "CategoryAnchor.MIDDLE");
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        lineRenderer3D0.setBaseSeriesVisibleInLegend(true, true);
        lineRenderer3D0.setSeriesShapesVisible((int) (short) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.KeyedObjects2D keyedObjects2D1 = new org.jfree.data.KeyedObjects2D();
        boolean boolean2 = blockContainer0.equals((java.lang.Object) keyedObjects2D1);
        org.jfree.chart.block.BlockFrame blockFrame3 = null;
        try {
            blockContainer0.setFrame(blockFrame3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'frame' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = lineRenderer3D0.getItemLabelGenerator((int) (byte) -1, 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineRenderer3D0.setBasePaint((java.awt.Paint) color7, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 10L;
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        boolean boolean9 = numberAxis3D1.getAutoRangeStickyZero();
        boolean boolean10 = numberAxis3D1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "org.jfree.data.UnknownKeyException: ERROR : Relative To String" + "'", str0.equals("org.jfree.data.UnknownKeyException: ERROR : Relative To String"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryAxis3.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        flowArrangement0.add(block1, (java.lang.Object) categoryAxis3);
        categoryAxis3.setUpperMargin((double) 2);
        categoryAxis3.setFixedDimension((double) 'a');
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) (short) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-15.0d) + "'", double2 == (-15.0d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        try {
            textBlock17.draw(graphics2D18, (float) (byte) 0, (float) (-2208960000000L), textBlockAnchor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Paint paint30 = jFreeChart27.getBorderPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        projectInfo0.setName("AreaRendererEndType.TRUNCATE");
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        try {
            java.lang.Comparable comparable4 = defaultStatisticalCategoryDataset0.getColumnKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        try {
            defaultCategoryDataset0.removeRow(68);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 68, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = stackedAreaRenderer8.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.BOTTOM_RIGHT", "", "({0}, {1}) = {2}", "TextAnchor.BOTTOM_RIGHT", "ERROR : Relative To String");
        java.lang.String str6 = basicProjectInfo5.getLicenceName();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean8 = piePlot3D7.getIgnoreNullValues();
        boolean boolean9 = basicProjectInfo5.equals((java.lang.Object) piePlot3D7);
        java.awt.Paint paint10 = piePlot3D7.getShadowPaint();
        float float11 = piePlot3D7.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ERROR : Relative To String" + "'", str6.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener28 = null;
        try {
            jFreeChart27.addChangeListener(chartChangeListener28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Color color2 = java.awt.Color.getColor("CategoryAnchor.MIDDLE", 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.text.TextUtilities.drawAlignedString("TextAnchor.BOTTOM_RIGHT", graphics2D1, 0.0f, 1.0f, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str5.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D12.setLabelFont(font13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray21 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis20 };
        categoryPlot19.setDomainAxes(categoryAxisArray21);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
        categoryPlot19.datasetChanged(datasetChangeEvent23);
        numberAxis3D12.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        numberAxis3D12.setAutoRangeStickyZero(true);
        boolean boolean28 = range10.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(categoryAxisArray21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        java.lang.String str2 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str2.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, (int) (short) 0, 6);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long5 = segmentedTimeline4.getSegmentSize();
        long long7 = segmentedTimeline4.toTimelineValue((long) (short) 0);
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: baseTimeline.getStartTime() is after startTime");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 900000L + "'", long5 == 900000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-32400010L) + "'", long7 == (-32400010L));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.lang.Number[] numberArray0 = new java.lang.Number[] {};
        java.lang.Number[] numberArray1 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] { numberArray0, numberArray1 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) 10, 0.05d, (-2208960000000L), (-2208960000000L), 5, (-15.0d) };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { (short) 10, 0.05d, (-2208960000000L), (-2208960000000L), 5, (-15.0d) };
        java.lang.Number[] numberArray23 = new java.lang.Number[] { (short) 10, 0.05d, (-2208960000000L), (-2208960000000L), 5, (-15.0d) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { (short) 10, 0.05d, (-2208960000000L), (-2208960000000L), 5, (-15.0d) };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { (short) 10, 0.05d, (-2208960000000L), (-2208960000000L), 5, (-15.0d) };
        java.lang.Number[][] numberArray38 = new java.lang.Number[][] { numberArray9, numberArray16, numberArray23, numberArray30, numberArray37 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset39 = new org.jfree.data.category.DefaultIntervalCategoryDataset(numberArray2, numberArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberArray0);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray23);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray38);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer21);
        java.awt.Color color24 = java.awt.Color.pink;
        java.lang.String str25 = color24.toString();
        java.awt.Color color26 = color24.darker();
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Color color29 = java.awt.Color.pink;
        java.lang.String str30 = color29.toString();
        java.awt.Color color31 = color29.darker();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke32);
        valueMarker33.setAlpha((float) 0L);
        java.awt.Stroke stroke36 = valueMarker33.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color24, stroke36);
        categoryPlot17.addDomainMarker(categoryMarker37);
        categoryPlot4.addDomainMarker(categoryMarker37);
        categoryPlot4.setRangeCrosshairValue(100.0d, true);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str25.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str30.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        piePlot3D0.setShadowYOffset((double) 1.0f);
        java.lang.String str7 = piePlot3D0.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Pie 3D Plot" + "'", str7.equals("Pie 3D Plot"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setWeight((int) (byte) 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation14 = null;
        try {
            boolean boolean15 = categoryPlot4.removeAnnotation(categoryAnnotation14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        java.lang.String str4 = piePlot3D0.getPlotType();
        java.lang.Object obj5 = null;
        boolean boolean6 = piePlot3D0.equals(obj5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 1);
        axisState1.cursorUp((double) 1546329600000L);
        axisState1.cursorRight((double) '4');
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection16 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int18 = taskSeriesCollection16.getColumnIndex((java.lang.Comparable) (short) -1);
        boolean boolean19 = taskSeriesCollection0.hasListener((java.util.EventListener) taskSeriesCollection16);
        try {
            java.lang.Comparable comparable21 = taskSeriesCollection16.getSeriesKey(68);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 68, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color5 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean6 = stackedBarRenderer3D2.equals((java.lang.Object) 0);
        boolean boolean7 = stackedBarRenderer3D2.getAutoPopulateSeriesOutlinePaint();
        double double8 = stackedBarRenderer3D2.getItemMargin();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("Range[1.0,1.0]", "hi!", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineRenderer3D0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator7, false);
        lineRenderer3D0.setBaseShapesVisible(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator12, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.lang.Object obj9 = null;
        boolean boolean10 = legendItemEntity8.equals(obj9);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        boolean boolean21 = lineRenderer3D0.getItemShapeVisible(100, (int) (byte) 10);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot27.addChangeListener(plotChangeListener28);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot27.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        java.awt.Paint paint33 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        java.awt.geom.Point2D point2D40 = null;
        polarPlot35.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo39, point2D40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock44.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, categoryItemRenderer49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot50.zoomRangeAxes((double) (-1), plotRenderingInfo52, point2D53);
        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot50.setRangeAxisLocation((int) ' ', axisLocation56, false);
        float float59 = categoryPlot50.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer61 = null;
        java.util.Collection collection62 = categoryPlot50.getRangeMarkers((int) (byte) 0, layer61);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot50.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D64 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D64.setDrawOutlines(true);
        boolean boolean67 = lineRenderer3D64.getBaseShapesVisible();
        java.awt.Font font69 = lineRenderer3D64.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator71 = null;
        lineRenderer3D64.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator71, false);
        boolean boolean74 = rectangleEdge63.equals((java.lang.Object) categoryItemLabelGenerator71);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline75 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long76 = segmentedTimeline75.getSegmentSize();
        long long78 = segmentedTimeline75.toTimelineValue((long) (short) 0);
        long long81 = segmentedTimeline75.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean82 = rectangleEdge63.equals((java.lang.Object) segmentedTimeline75);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge63);
        java.awt.geom.Rectangle2D rectangle2D84 = axisSpace42.reserved(rectangle2D45, rectangleEdge63);
        plotRenderingInfo39.setDataArea(rectangle2D84);
        try {
            lineRenderer3D0.drawRangeGridline(graphics2D22, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, rectangle2D84, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 1.0f + "'", float59 == 1.0f);
        org.junit.Assert.assertNull(collection62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(font69);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 900000L + "'", long76 == 900000L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-32400010L) + "'", long78 == (-32400010L));
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertNotNull(rectangle2D84);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.lang.Boolean boolean4 = lineRenderer3D0.getSeriesVisible((int) (short) 0);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setYOffset((-4.0d));
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getMaximumBarWidth();
        barRenderer3D0.setMinimumBarLength(0.05d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        java.awt.Graphics2D graphics2D32 = null;
        double double33 = markerAxisBand31.getHeight(graphics2D32);
        java.awt.Graphics2D graphics2D34 = null;
        double double35 = markerAxisBand31.getHeight(graphics2D34);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Paint paint4 = piePlot3D0.getLabelOutlinePaint();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D5 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D5.setDrawOutlines(true);
        java.awt.Color color9 = java.awt.Color.pink;
        java.lang.String str10 = color9.toString();
        java.awt.Color color11 = color9.darker();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke12);
        lineRenderer3D5.setBaseOutlineStroke(stroke12, true);
        org.jfree.chart.LegendItem legendItem18 = lineRenderer3D5.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor21 = itemLabelPosition20.getRotationAnchor();
        lineRenderer3D5.setSeriesNegativeItemLabelPosition(10, itemLabelPosition20, false);
        boolean boolean26 = lineRenderer3D5.getItemShapeVisible(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint29 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis28.setTickMarkPaint(paint29);
        lineRenderer3D5.setBaseOutlinePaint(paint29);
        piePlot3D0.setNoDataMessagePaint(paint29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str10.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(legendItem18);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = null;
        projectInfo0.setContributors(list1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12 };
        categoryPlot11.setDomainAxes(categoryAxisArray13);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
        categoryPlot11.datasetChanged(datasetChangeEvent15);
        numberAxis3D4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        double double18 = numberAxis3D4.getAutoRangeMinimumSize();
        boolean boolean19 = projectInfo0.equals((java.lang.Object) numberAxis3D4);
        projectInfo0.setLicenceText("Pie 3D Plot");
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0E-8d + "'", double18 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        stackedAreaRenderer1.setBaseShape(shape18, false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator24 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj25 = standardCategoryURLGenerator24.clone();
        java.lang.Object obj26 = standardCategoryURLGenerator24.clone();
        stackedAreaRenderer1.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator24, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = itemLabelPosition0.getRotationAnchor();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset3.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset3.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, 0);
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0f), (org.jfree.data.KeyedValues) pieDataset12);
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryAxis17.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        flowArrangement14.add(block15, (java.lang.Object) categoryAxis17);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection25 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int27 = taskSeriesCollection25.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection25, true);
        org.jfree.data.general.DatasetGroup datasetGroup30 = taskSeriesCollection25.getGroup();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D32.setLabelFont(font33);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = numberAxis3D32.getStandardTickUnits();
        numberAxis3D32.centerRange((double) (short) 0);
        numberAxis3D32.setAutoRangeStickyZero(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font46 = categoryAxis44.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer42.setBaseItemLabelFont(font46);
        org.jfree.chart.text.TextLine textLine48 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font46);
        numberAxis3D32.setLabelFont(font46);
        boolean boolean50 = taskSeriesCollection25.equals((java.lang.Object) numberAxis3D32);
        java.lang.String str51 = numberAxis3D32.getLabelToolTip();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D52 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D52.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection55 = lineRenderer3D52.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineRenderer3D52);
        boolean boolean57 = itemLabelPosition0.equals((java.lang.Object) categoryDataset13);
        org.jfree.chart.text.TextAnchor textAnchor58 = itemLabelPosition0.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetGroup30);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(legendItemCollection55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(textAnchor58);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.util.List list2 = blockContainer1.getBlocks();
        projectInfo0.setContributors(list2);
        java.awt.Image image4 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(image4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        boolean boolean15 = stackedAreaRenderer1.isSeriesVisibleInLegend(3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedAreaRenderer1.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis7 };
        categoryPlot6.setDomainAxes(categoryAxisArray8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent10);
        categoryPlot6.setBackgroundAlpha((float) 0);
        categoryPlot6.setWeight((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("CategoryAnchor.MIDDLE", font1, (org.jfree.chart.plot.Plot) categoryPlot6, false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot6.getRangeAxis(1900);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        size2D2.height = (byte) 1;
        java.lang.String str5 = size2D2.toString();
        double double6 = size2D2.getWidth();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Size2D[width=0.0, height=1.0]" + "'", str5.equals("Size2D[width=0.0, height=1.0]"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = color1.darker();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        valueMarker5.setAlpha((float) 0L);
        java.awt.Stroke stroke8 = valueMarker5.getStroke();
        valueMarker5.setValue((double) 2);
        java.awt.Paint paint11 = valueMarker5.getOutlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        java.lang.Boolean boolean5 = lineRenderer3D0.getSeriesLinesVisible(1900);
        lineRenderer3D0.setSeriesShapesFilled((int) (byte) 10, (java.lang.Boolean) true);
        boolean boolean9 = lineRenderer3D0.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineRenderer3D0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.Font font2 = textFragment1.getFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition3.getRotationAnchor();
        boolean boolean5 = textFragment1.equals((java.lang.Object) itemLabelPosition3);
        java.awt.Graphics2D graphics2D6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textFragment1.calculateDimensions(graphics2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Paint paint1 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod(date3, date4);
        keyedObjects2D0.addObject((java.lang.Object) paint1, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date3);
        java.lang.Object obj7 = keyedObjects2D0.clone();
        java.lang.Comparable comparable8 = null;
        int int9 = keyedObjects2D0.getRowIndex(comparable8);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.lang.Boolean boolean4 = lineRenderer3D0.getSeriesVisible((int) (short) 0);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setBaseShapesFilled(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        lineRenderer3D0.setSeriesURLGenerator(1900, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10, true);
        lineRenderer3D0.setSeriesLinesVisible(100, true);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        flowArrangement1.add(block2, (java.lang.Object) categoryAxis4);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.util.List list13 = blockContainer12.getBlocks();
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        flowArrangement1.add((org.jfree.chart.block.Block) blockContainer12, (java.lang.Object) "");
        java.awt.Color color24 = java.awt.Color.pink;
        java.lang.String str25 = color24.toString();
        java.awt.Color color26 = color24.darker();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke27);
        valueMarker28.setAlpha((float) 0L);
        org.jfree.chart.text.TextAnchor textAnchor31 = valueMarker28.getLabelTextAnchor();
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) blockContainer12, (java.lang.Object) valueMarker28);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.ValueMarker cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str25.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart10.createBufferedImage((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 900000L, 0.0f, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getMiddleMillisecond();
        long long19 = year17.getFirstMillisecond();
        try {
            java.lang.Number number20 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 8.0d, (java.lang.Comparable) long19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        categoryPlot4.setAnchorValue(0.0d, true);
        boolean boolean16 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot8.zoomRangeAxes((double) (-1), plotRenderingInfo10, point2D11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot8.setRangeAxisLocation((int) ' ', axisLocation14, false);
        float float17 = categoryPlot8.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot8.getRangeMarkers((int) (byte) 0, layer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot8.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D22 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D22.setDrawOutlines(true);
        boolean boolean25 = lineRenderer3D22.getBaseShapesVisible();
        java.awt.Font font27 = lineRenderer3D22.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
        lineRenderer3D22.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator29, false);
        boolean boolean32 = rectangleEdge21.equals((java.lang.Object) categoryItemLabelGenerator29);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long34 = segmentedTimeline33.getSegmentSize();
        long long36 = segmentedTimeline33.toTimelineValue((long) (short) 0);
        long long39 = segmentedTimeline33.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean40 = rectangleEdge21.equals((java.lang.Object) segmentedTimeline33);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge21);
        java.awt.geom.Rectangle2D rectangle2D42 = axisSpace0.reserved(rectangle2D3, rectangleEdge21);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement44 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        categoryAxis47.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot52);
        flowArrangement44.add(block45, (java.lang.Object) categoryAxis47);
        org.jfree.chart.block.BlockContainer blockContainer55 = new org.jfree.chart.block.BlockContainer();
        java.util.List list56 = blockContainer55.getBlocks();
        java.awt.Shape shape61 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color63 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape61, stroke62, (java.awt.Paint) color63);
        flowArrangement44.add((org.jfree.chart.block.Block) blockContainer55, (java.lang.Object) "");
        org.jfree.chart.block.LabelBlock labelBlock67 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D68 = labelBlock67.getBounds();
        blockContainer55.setBounds(rectangle2D68);
        try {
            java.awt.geom.Rectangle2D rectangle2D70 = axisSpace0.shrink(rectangle2D43, rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 900000L + "'", long34 == 900000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-32400010L) + "'", long36 == (-32400010L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(rectangle2D68);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer18);
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        boolean boolean23 = stackedAreaRenderer1.getItemCreateEntity(255, (int) (short) 0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        double double4 = piePlot3D0.getExplodePercent((java.lang.Comparable) 2958465);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D0.getURLGenerator();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = piePlot3D0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNull(pieToolTipGenerator6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = stackedAreaRenderer1.getDrawingSupplier();
        java.awt.Paint paint17 = stackedAreaRenderer1.getSeriesItemLabelPaint((int) ' ');
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        categoryAxis21.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        flowArrangement18.add(block19, (java.lang.Object) categoryAxis21);
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        java.util.List list30 = blockContainer29.getBlocks();
        java.awt.Shape shape35 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape35, stroke36, (java.awt.Paint) color37);
        flowArrangement18.add((org.jfree.chart.block.Block) blockContainer29, (java.lang.Object) "");
        boolean boolean40 = stackedAreaRenderer1.equals((java.lang.Object) flowArrangement18);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(drawingSupplier15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int7 = segmentedTimeline6.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segmentedTimeline6.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int11 = segmentedTimeline10.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline10.getSegment(10L);
        try {
            java.lang.Number number14 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) segment9, (java.lang.Comparable) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 68 + "'", int7 == 68);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertNotNull(segmentedTimeline10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 68 + "'", int11 == 68);
        org.junit.Assert.assertNotNull(segment13);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint8 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis7.setTickMarkPaint(paint8);
        lineRenderer3D0.setBaseFillPaint(paint8, false);
        java.awt.Paint paint13 = lineRenderer3D0.getSeriesItemLabelPaint((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer18);
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        stackedAreaRenderer1.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(68, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate4);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.setAutoTickUnitSelection(true, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        try {
            java.util.Date date7 = dateAxis2.calculateHighestVisibleTickValue(dateTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        flowArrangement1.add(block2, (java.lang.Object) categoryAxis4);
        org.jfree.chart.block.BlockContainer blockContainer12 = new org.jfree.chart.block.BlockContainer();
        java.util.List list13 = blockContainer12.getBlocks();
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        flowArrangement1.add((org.jfree.chart.block.Block) blockContainer12, (java.lang.Object) "");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D24.setLabelFont(font25);
        centerArrangement0.add((org.jfree.chart.block.Block) blockContainer12, (java.lang.Object) numberAxis3D24);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        java.awt.Shape shape4 = null;
        try {
            lineRenderer3D0.setBaseShape(shape4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis3D2.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis3D2.java2DToValue((double) 0, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis3D2.getTickUnit();
        tickUnits0.add((org.jfree.chart.axis.TickUnit) numberTickUnit10);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit10);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D6.setLabelFont(font7);
        java.awt.Color color10 = java.awt.Color.pink;
        java.lang.String str11 = color10.toString();
        java.awt.Color color12 = color10.darker();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke13);
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color10.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        java.awt.Stroke stroke27 = null;
        categoryPlot26.setOutlineStroke(stroke27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font7, (org.jfree.chart.plot.Plot) categoryPlot26, false);
        jFreeChart30.setBackgroundImageAlignment(100);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart30.setBackgroundPaint((java.awt.Paint) color33);
        jFreeChart30.removeLegend();
        jFreeChart30.setTextAntiAlias(true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType38 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean40 = chartChangeEventType38.equals((java.lang.Object) 0.0d);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) range2, jFreeChart30, chartChangeEventType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(chartChangeEventType38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        java.lang.Object obj32 = jFreeChart27.clone();
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D40 = labelBlock39.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, categoryItemRenderer44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        categoryPlot45.zoomRangeAxes((double) (-1), plotRenderingInfo47, point2D48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setRangeAxisLocation((int) ' ', axisLocation51, false);
        float float54 = categoryPlot45.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer56 = null;
        java.util.Collection collection57 = categoryPlot45.getRangeMarkers((int) (byte) 0, layer56);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot45.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D59 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D59.setDrawOutlines(true);
        boolean boolean62 = lineRenderer3D59.getBaseShapesVisible();
        java.awt.Font font64 = lineRenderer3D59.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator66 = null;
        lineRenderer3D59.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator66, false);
        boolean boolean69 = rectangleEdge58.equals((java.lang.Object) categoryItemLabelGenerator66);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline70 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long71 = segmentedTimeline70.getSegmentSize();
        long long73 = segmentedTimeline70.toTimelineValue((long) (short) 0);
        long long76 = segmentedTimeline70.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean77 = rectangleEdge58.equals((java.lang.Object) segmentedTimeline70);
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge58);
        java.awt.geom.Rectangle2D rectangle2D79 = axisSpace37.reserved(rectangle2D40, rectangleEdge58);
        chartRenderingInfo36.setChartArea(rectangle2D79);
        try {
            java.awt.image.BufferedImage bufferedImage81 = jFreeChart27.createBufferedImage(0, 0, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 1.0f + "'", float54 == 1.0f);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(font64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 900000L + "'", long71 == 900000L);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-32400010L) + "'", long73 == (-32400010L));
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 0L + "'", long76 == 0L);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertNotNull(rectangle2D79);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        numberAxis3D1.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font37 = categoryAxis35.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D1.setLabelFont(font37);
        numberAxis3D1.resizeRange((double) (byte) 10, 0.0d);
        org.jfree.chart.util.UnitType unitType42 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = new org.jfree.chart.util.RectangleInsets(unitType42, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double49 = rectangleInsets47.calculateRightOutset((double) (-1));
        numberAxis3D1.setLabelInsets(rectangleInsets47);
        double double51 = rectangleInsets47.getLeft();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(unitType42);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.title.Title title11 = null;
        try {
            jFreeChart10.addSubtitle(title11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.Size2D size2D3 = blockContainer1.arrange(graphics2D2);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D5.setLabelFont(font6);
        org.jfree.chart.axis.TickUnitSource tickUnitSource8 = numberAxis3D5.getStandardTickUnits();
        numberAxis3D5.centerRange((double) (short) 0);
        numberAxis3D5.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D19.setLabelFont(font20);
        java.awt.Color color23 = java.awt.Color.pink;
        java.lang.String str24 = color23.toString();
        java.awt.Color color25 = color23.darker();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke26);
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color23.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        org.jfree.chart.text.TextBlock textBlock34 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font20, (java.awt.Paint) color23);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D5, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font20);
        numberAxis3D5.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font41 = categoryAxis39.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D5.setLabelFont(font41);
        numberAxis3D5.resizeRange((double) (byte) 10, 0.0d);
        org.jfree.chart.util.UnitType unitType46 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = new org.jfree.chart.util.RectangleInsets(unitType46, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double53 = rectangleInsets51.calculateRightOutset((double) (-1));
        numberAxis3D5.setLabelInsets(rectangleInsets51);
        blockContainer1.setPadding(rectangleInsets51);
        java.lang.Object obj56 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) blockContainer1, obj56);
        org.junit.Assert.assertNotNull(size2D3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(tickUnitSource8);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str24.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNotNull(textBlock34);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(unitType46);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        lineRenderer3D0.setSeriesLinesVisible(0, false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addException(0L, (long) '#');
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        categoryPlot4.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long1 = segmentedTimeline0.getSegmentSize();
        long long3 = segmentedTimeline0.toTimelineValue((long) (short) 0);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection4 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int6 = taskSeriesCollection4.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection4, true);
        org.jfree.data.general.DatasetGroup datasetGroup9 = taskSeriesCollection4.getGroup();
        java.util.List list10 = taskSeriesCollection4.getRowKeys();
        segmentedTimeline0.addExceptions(list10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-32400010L) + "'", long3 == (-32400010L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font33 = categoryAxis31.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer29.setBaseItemLabelFont(font33);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator37 = stackedAreaRenderer29.getURLGenerator(0, 3);
        java.awt.Paint paint39 = stackedAreaRenderer29.lookupSeriesPaint((int) (short) 1);
        java.awt.Color color41 = java.awt.Color.pink;
        java.lang.String str42 = color41.toString();
        stackedAreaRenderer29.setSeriesFillPaint((int) '#', (java.awt.Paint) color41, false);
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(categoryURLGenerator37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str42.equals("java.awt.Color[r=255,g=175,b=175]"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis3D1.configure();
        numberAxis3D1.setNegativeArrowVisible(true);
        boolean boolean18 = numberAxis3D1.isAxisLineVisible();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat19);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis3D1.getStandardTickUnits();
        java.lang.Object obj24 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) tickUnitSource23);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER" + "'", str1.equals("TextBlockAnchor.CENTER"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        double double5 = multiplePiePlot1.getLimit();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) 'a', (double) 2958465);
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range2, (-2.0d), (double) 644288400000L);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot10.zoomRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot10.setRangeAxisLocation((int) ' ', axisLocation16, false);
        float float19 = categoryPlot10.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot10.getRangeMarkers((int) (byte) 0, layer21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot10.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D24 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D24.setDrawOutlines(true);
        boolean boolean27 = lineRenderer3D24.getBaseShapesVisible();
        java.awt.Font font29 = lineRenderer3D24.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = null;
        lineRenderer3D24.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator31, false);
        boolean boolean34 = rectangleEdge23.equals((java.lang.Object) categoryItemLabelGenerator31);
        try {
            double double35 = categoryAxis1.getCategoryEnd((int) (short) 100, 2, rectangle2D5, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(font29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo4, point2D5);
        boolean boolean7 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Range[1.0,1.0]", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis3D1.configure();
        numberAxis3D1.setNegativeArrowVisible(true);
        boolean boolean18 = numberAxis3D1.isAxisLineVisible();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat19);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.jfree.data.Range range23 = null;
        try {
            numberAxis3D1.setRangeWithMargins(range23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D1.setDrawOutlines(true);
        lineRenderer3D1.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Stroke stroke13 = null;
        categoryPlot12.setOutlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot12.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getRangeAxisEdge(0);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot12.setOutlineStroke(stroke19);
        lineRenderer3D1.setSeriesOutlineStroke(3, stroke19, false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes((double) (-1), plotRenderingInfo29, point2D30);
        float float32 = categoryPlot27.getForegroundAlpha();
        lineRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        boolean boolean34 = blockContainer0.equals((java.lang.Object) lineRenderer3D1);
        blockContainer0.setHeight(Double.NaN);
        org.jfree.chart.block.BlockContainer blockContainer37 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.KeyedObjects2D keyedObjects2D38 = new org.jfree.data.KeyedObjects2D();
        boolean boolean39 = blockContainer37.equals((java.lang.Object) keyedObjects2D38);
        org.jfree.chart.block.BlockFrame blockFrame40 = blockContainer37.getFrame();
        blockContainer0.setFrame(blockFrame40);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(blockFrame40);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segment3.copy();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segment3.intersect((long) (byte) 10, (long) 68);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNull(segment7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        categoryAxis1.setMaximumCategoryLabelWidthRatio(100.0f);
        categoryAxis1.setMaximumCategoryLabelLines(10);
        org.junit.Assert.assertNull(plot2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("HorizontalAlignment.CENTER", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint4 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis3.setTickMarkPaint(paint4);
        multiplePiePlot1.setNoDataMessagePaint(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String str2 = dataPackageResources0.getString("AreaRendererEndType.TRUNCATE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key AreaRendererEndType.TRUNCATE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 255, (double) (-1));
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        boolean boolean12 = categoryPlot10.isRangeZoomable();
        org.jfree.data.general.WaferMapDataset waferMapDataset13 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer14 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot15 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset13, waferMapRenderer14);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        waferMapPlot15.rendererChanged(rendererChangeEvent16);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock23.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot29.zoomRangeAxes((double) (-1), plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot29.setRangeAxisLocation((int) ' ', axisLocation35, false);
        float float38 = categoryPlot29.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot29.getRangeMarkers((int) (byte) 0, layer40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot29.getRangeAxisEdge();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D43 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D43.setDrawOutlines(true);
        boolean boolean46 = lineRenderer3D43.getBaseShapesVisible();
        java.awt.Font font48 = lineRenderer3D43.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator50 = null;
        lineRenderer3D43.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator50, false);
        boolean boolean53 = rectangleEdge42.equals((java.lang.Object) categoryItemLabelGenerator50);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline54 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long55 = segmentedTimeline54.getSegmentSize();
        long long57 = segmentedTimeline54.toTimelineValue((long) (short) 0);
        long long60 = segmentedTimeline54.getExceptionSegmentCount((long) (byte) 1, 61200000L);
        boolean boolean61 = rectangleEdge42.equals((java.lang.Object) segmentedTimeline54);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge42);
        java.awt.geom.Rectangle2D rectangle2D63 = axisSpace21.reserved(rectangle2D24, rectangleEdge42);
        chartRenderingInfo20.setChartArea(rectangle2D63);
        java.awt.geom.Point2D point2D65 = null;
        org.jfree.chart.plot.PlotState plotState66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        waferMapPlot15.draw(graphics2D18, rectangle2D63, point2D65, plotState66, plotRenderingInfo67);
        try {
            barRenderer3D2.drawDomainGridline(graphics2D3, categoryPlot10, rectangle2D63, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(font48);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 900000L + "'", long55 == 900000L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-32400010L) + "'", long57 == (-32400010L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("TextAnchor.BOTTOM_RIGHT", "", "({0}, {1}) = {2}", "TextAnchor.BOTTOM_RIGHT", "ERROR : Relative To String");
        java.lang.String str6 = basicProjectInfo5.getLicenceName();
        java.lang.String str7 = basicProjectInfo5.getName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ERROR : Relative To String" + "'", str6.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str7.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        java.lang.String str4 = piePlot3D0.getPlotType();
        double double5 = piePlot3D0.getLabelLinkMargin();
        double double6 = piePlot3D0.getDepthFactor();
        org.jfree.chart.plot.Plot plot7 = piePlot3D0.getRootPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(plot7);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segment3.copy();
        boolean boolean5 = segment4.inExcludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        double double15 = numberAxis3D1.getAutoRangeMinimumSize();
        java.awt.Stroke stroke16 = numberAxis3D1.getAxisLineStroke();
        float float17 = numberAxis3D1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        org.jfree.chart.axis.NumberTick numberTick7 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor3, textAnchor4, 1.0d);
        double double8 = numberTick7.getValue();
        java.lang.String str9 = numberTick7.toString();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str5.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "({0}, {1}) = {2}" + "'", str9.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-4.0d), (double) 3, true);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone5);
//        dateAxis6.setAutoTickUnitSelection(true, true);
//        dateAxis6.configure();
//        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
//        java.awt.geom.Point2D point2D18 = null;
//        categoryPlot15.zoomRangeAxes((double) (-1), plotRenderingInfo17, point2D18);
//        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot15.setRangeAxisLocation((int) ' ', axisLocation21, false);
//        float float24 = categoryPlot15.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer26 = null;
//        java.util.Collection collection27 = categoryPlot15.getRangeMarkers((int) (byte) 0, layer26);
//        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot15.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D29 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D29.setDrawOutlines(true);
//        boolean boolean32 = lineRenderer3D29.getBaseShapesVisible();
//        java.awt.Font font34 = lineRenderer3D29.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = null;
//        lineRenderer3D29.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator36, false);
//        boolean boolean39 = rectangleEdge28.equals((java.lang.Object) categoryItemLabelGenerator36);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline40 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long41 = segmentedTimeline40.getSegmentSize();
//        long long43 = segmentedTimeline40.toTimelineValue((long) (short) 0);
//        long long46 = segmentedTimeline40.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean47 = rectangleEdge28.equals((java.lang.Object) segmentedTimeline40);
//        org.jfree.data.KeyedObjects2D keyedObjects2D48 = new org.jfree.data.KeyedObjects2D();
//        java.awt.Paint paint49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.util.Date date51 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date51, date52);
//        keyedObjects2D48.addObject((java.lang.Object) paint49, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date51);
//        long long55 = segmentedTimeline40.toTimelineValue(date51);
//        dateAxis6.setMinimumDate(date51);
//        defaultCategoryDataset0.removeColumn((java.lang.Comparable) date51);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(axisLocation21);
//        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 1.0f + "'", float24 == 1.0f);
//        org.junit.Assert.assertNull(collection27);
//        org.junit.Assert.assertNotNull(rectangleEdge28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNull(font34);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 900000L + "'", long41 == 900000L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-32400010L) + "'", long43 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(paint49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 455057983088L + "'", long55 == 455057983088L);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 900000L, (double) 5, (double) 10L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(10L);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        piePlot3D0.setShadowXOffset((double) 1546329600000L);
        piePlot3D0.setLabelGap((double) 5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertNotNull(segment6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        piePlot3D0.setShadowYOffset((double) 1.0f);
        piePlot3D0.setPieIndex(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.lang.String str8 = legendItem7.getDescription();
        java.awt.Stroke stroke9 = legendItem7.getLineStroke();
        java.awt.Paint paint10 = legendItem7.getLinePaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection11.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, true);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes((double) (-1), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot20.getRenderer();
        taskSeriesCollection11.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot20);
        legendItem7.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection11);
        java.util.List list28 = taskSeriesCollection11.getColumnKeys();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str8.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        double double15 = numberAxis3D1.getAutoRangeMinimumSize();
        java.awt.Stroke stroke16 = numberAxis3D1.getAxisLineStroke();
        numberAxis3D1.setTickMarkOutsideLength((float) 255);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(stroke16);
    }
}

