import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = java.awt.Color.getColor("({0}, {1}) = {2}", color5);
        boolean boolean8 = defaultCategoryDataset0.equals((java.lang.Object) color7);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        defaultCategoryDataset0.setValue(Double.NaN, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) year11);
        org.jfree.data.general.DatasetGroup datasetGroup13 = null;
        try {
            defaultCategoryDataset0.setGroup(datasetGroup13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Image image11 = null;
        jFreeChart10.setBackgroundImage(image11);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = color1.darker();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        valueMarker5.setAlpha((float) 0L);
        java.awt.Stroke stroke8 = valueMarker5.getStroke();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean10 = valueMarker5.equals((java.lang.Object) color9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge(0);
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.lang.Object obj2 = chartRenderingInfo1.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = chartRenderingInfo1.getPlotInfo();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        try {
            java.lang.Number number19 = taskSeriesCollection0.getStartValue((java.lang.Comparable) 2.0d, (java.lang.Comparable) "ThreadContext", (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        jFreeChart27.setTextAntiAlias(true);
        boolean boolean35 = jFreeChart27.isBorderVisible();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.0d));
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.0d));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = categoryLabelPosition4.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = categoryLabelPosition4.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions3, categoryLabelPosition4);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition4);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color5 = java.awt.Color.black;
        piePlot3D4.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot3D4.getLegendItems();
        boolean boolean8 = piePlot3D4.getLabelLinksVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) piePlot3D4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        try {
            piePlot3D4.setLegendLabelGenerator(pieSectionLabelGenerator10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Font font3 = lineRenderer3D0.getItemLabelFont((int) (byte) 10, 6);
        lineRenderer3D0.setBaseLinesVisible(false);
        double double6 = lineRenderer3D0.getXOffset();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.0d + "'", double6 == 12.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        java.awt.Paint paint7 = categoryPlot4.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D11.setLabelFont(font12);
        java.awt.Color color15 = java.awt.Color.pink;
        java.lang.String str16 = color15.toString();
        java.awt.Color color17 = color15.darker();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke18);
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.AffineTransform affineTransform23 = null;
        java.awt.RenderingHints renderingHints24 = null;
        java.awt.PaintContext paintContext25 = color15.createContext(colorModel20, rectangle21, rectangle2D22, affineTransform23, renderingHints24);
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font12, (java.awt.Paint) color15);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        java.awt.Stroke stroke32 = null;
        categoryPlot31.setOutlineStroke(stroke32);
        org.jfree.chart.JFreeChart jFreeChart35 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font12, (org.jfree.chart.plot.Plot) categoryPlot31, false);
        jFreeChart35.setBackgroundImageAlignment(100);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart35.setBackgroundPaint((java.awt.Paint) color38);
        categoryPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart35);
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot4.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str16.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paintContext25);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(axisSpace41);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = stackedAreaRenderer1.getDrawingSupplier();
        java.awt.Paint paint17 = stackedAreaRenderer1.lookupSeriesFillPaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis3D1.configure();
        numberAxis3D1.setNegativeArrowVisible(true);
        boolean boolean18 = numberAxis3D1.isAxisLineVisible();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat19);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis3D1.getStandardTickUnits();
        try {
            numberAxis3D1.setRangeWithMargins((double) (short) 0, (double) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-2.20896E12).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        java.lang.Object obj3 = size2D2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        boolean boolean15 = stackedAreaRenderer1.isSeriesVisibleInLegend(3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = stackedAreaRenderer1.getSeriesPositiveItemLabelPosition((int) (short) 0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ThreadContext, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer1.setBaseShape(shape16, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = stackedAreaRenderer1.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(categoryToolTipGenerator19);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        boolean boolean19 = lineRenderer3D0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.block.BlockFrame blockFrame3 = blockContainer0.getFrame();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(blockFrame3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot4.addChangeListener(plotChangeListener8);
        categoryPlot4.clearDomainAxes();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection11.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, true);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes((double) (-1), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot20.getRenderer();
        taskSeriesCollection11.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot20);
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot27.getOrientation();
        categoryPlot20.setOrientation(plotOrientation28);
        categoryPlot4.setOrientation(plotOrientation28);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryItemRenderer25);
        org.junit.Assert.assertNotNull(plotOrientation28);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 10L, (double) (byte) 0);
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
//        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
//        categoryPlot8.addChangeListener(plotChangeListener9);
//        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//        categoryPlot8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
//        java.awt.Color color15 = java.awt.Color.pink;
//        java.lang.String str16 = color15.toString();
//        java.awt.Color color17 = color15.darker();
//        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color15);
//        java.awt.Color color20 = java.awt.Color.pink;
//        java.lang.String str21 = color20.toString();
//        java.awt.Color color22 = color20.darker();
//        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke23);
//        valueMarker24.setAlpha((float) 0L);
//        java.awt.Stroke stroke27 = valueMarker24.getStroke();
//        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color15, stroke27);
//        categoryPlot8.addDomainMarker(categoryMarker28);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D31.setLabelFont(font32);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = numberAxis3D31.getStandardTickUnits();
//        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D31);
//        org.jfree.chart.axis.AxisSpace axisSpace36 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock38 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D39 = labelBlock38.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
//        java.awt.geom.Point2D point2D47 = null;
//        categoryPlot44.zoomRangeAxes((double) (-1), plotRenderingInfo46, point2D47);
//        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot44.setRangeAxisLocation((int) ' ', axisLocation50, false);
//        float float53 = categoryPlot44.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer55 = null;
//        java.util.Collection collection56 = categoryPlot44.getRangeMarkers((int) (byte) 0, layer55);
//        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot44.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D58 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D58.setDrawOutlines(true);
//        boolean boolean61 = lineRenderer3D58.getBaseShapesVisible();
//        java.awt.Font font63 = lineRenderer3D58.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator65 = null;
//        lineRenderer3D58.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator65, false);
//        boolean boolean68 = rectangleEdge57.equals((java.lang.Object) categoryItemLabelGenerator65);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline69 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long70 = segmentedTimeline69.getSegmentSize();
//        long long72 = segmentedTimeline69.toTimelineValue((long) (short) 0);
//        long long75 = segmentedTimeline69.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean76 = rectangleEdge57.equals((java.lang.Object) segmentedTimeline69);
//        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge57);
//        java.awt.geom.Rectangle2D rectangle2D78 = axisSpace36.reserved(rectangle2D39, rectangleEdge57);
//        stackedBarRenderer3D2.drawRangeGridline(graphics2D3, categoryPlot8, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, rectangle2D78, (double) (byte) 10);
//        org.junit.Assert.assertNotNull(color15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str16.equals("java.awt.Color[r=255,g=175,b=175]"));
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str21.equals("java.awt.Color[r=255,g=175,b=175]"));
//        org.junit.Assert.assertNotNull(color22);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertNotNull(stroke27);
//        org.junit.Assert.assertNotNull(font32);
//        org.junit.Assert.assertNotNull(tickUnitSource34);
//        org.junit.Assert.assertNotNull(rectangle2D39);
//        org.junit.Assert.assertNotNull(axisLocation50);
//        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 1.0f + "'", float53 == 1.0f);
//        org.junit.Assert.assertNull(collection56);
//        org.junit.Assert.assertNotNull(rectangleEdge57);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNull(font63);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 900000L + "'", long70 == 900000L);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-32400010L) + "'", long72 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge77);
//        org.junit.Assert.assertNotNull(rectangle2D78);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        float float9 = categoryPlot4.getForegroundAlpha();
        boolean boolean10 = categoryPlot4.isDomainZoomable();
        boolean boolean11 = categoryPlot4.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "December" + "'", str1.equals("December"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.data.gantt.TaskSeries taskSeries17 = taskSeriesCollection0.getSeries((java.lang.Comparable) Double.NaN);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNull(taskSeries17);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list5 = null;
        projectInfo4.setContributors(list5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D8.setLabelFont(font9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16 };
        categoryPlot15.setDomainAxes(categoryAxisArray17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent19);
        numberAxis3D8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        double double22 = numberAxis3D8.getAutoRangeMinimumSize();
        boolean boolean23 = projectInfo4.equals((java.lang.Object) numberAxis3D8);
        org.jfree.data.Range range24 = numberAxis3D8.getRange();
        boolean boolean25 = lineRenderer3D0.equals((java.lang.Object) numberAxis3D8);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = new org.jfree.chart.axis.NumberTickUnit((double) 9);
        int int29 = numberTickUnit27.compareTo((java.lang.Object) "org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        numberAxis3D8.setTickUnit(numberTickUnit27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        java.text.AttributedString attributedString0 = null;
//        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D7 = labelBlock6.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
//        java.awt.geom.Point2D point2D15 = null;
//        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D15);
//        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot12.setRangeAxisLocation((int) ' ', axisLocation18, false);
//        float float21 = categoryPlot12.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer23 = null;
//        java.util.Collection collection24 = categoryPlot12.getRangeMarkers((int) (byte) 0, layer23);
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot12.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D26.setDrawOutlines(true);
//        boolean boolean29 = lineRenderer3D26.getBaseShapesVisible();
//        java.awt.Font font31 = lineRenderer3D26.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator33 = null;
//        lineRenderer3D26.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator33, false);
//        boolean boolean36 = rectangleEdge25.equals((java.lang.Object) categoryItemLabelGenerator33);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long38 = segmentedTimeline37.getSegmentSize();
//        long long40 = segmentedTimeline37.toTimelineValue((long) (short) 0);
//        long long43 = segmentedTimeline37.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean44 = rectangleEdge25.equals((java.lang.Object) segmentedTimeline37);
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge25);
//        java.awt.geom.Rectangle2D rectangle2D46 = axisSpace4.reserved(rectangle2D7, rectangleEdge25);
//        java.awt.Stroke stroke47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
//        org.jfree.chart.event.PlotChangeListener plotChangeListener53 = null;
//        categoryPlot52.addChangeListener(plotChangeListener53);
//        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer56 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
//        categoryPlot52.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer56);
//        java.awt.Color color58 = java.awt.Color.GRAY;
//        stackedAreaRenderer56.setBaseItemLabelPaint((java.awt.Paint) color58, true);
//        try {
//            org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem(attributedString0, "CategoryAnchor.MIDDLE", "VerticalAlignment.BOTTOM", "ChartChangeEventType.DATASET_UPDATED", (java.awt.Shape) rectangle2D7, stroke47, (java.awt.Paint) color58);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(rectangle2D7);
//        org.junit.Assert.assertNotNull(axisLocation18);
//        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
//        org.junit.Assert.assertNull(collection24);
//        org.junit.Assert.assertNotNull(rectangleEdge25);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNull(font31);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 900000L + "'", long38 == 900000L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-32400010L) + "'", long40 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge45);
//        org.junit.Assert.assertNotNull(rectangle2D46);
//        org.junit.Assert.assertNotNull(stroke47);
//        org.junit.Assert.assertNotNull(color58);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
//        java.awt.geom.Point2D point2D8 = null;
//        categoryPlot5.zoomRangeAxes((double) (-1), plotRenderingInfo7, point2D8);
//        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot5.setRangeAxisLocation((int) ' ', axisLocation11, false);
//        float float14 = categoryPlot5.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer16 = null;
//        java.util.Collection collection17 = categoryPlot5.getRangeMarkers((int) (byte) 0, layer16);
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot5.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D19.setDrawOutlines(true);
//        boolean boolean22 = lineRenderer3D19.getBaseShapesVisible();
//        java.awt.Font font24 = lineRenderer3D19.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
//        lineRenderer3D19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator26, false);
//        boolean boolean29 = rectangleEdge18.equals((java.lang.Object) categoryItemLabelGenerator26);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long31 = segmentedTimeline30.getSegmentSize();
//        long long33 = segmentedTimeline30.toTimelineValue((long) (short) 0);
//        long long36 = segmentedTimeline30.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean37 = rectangleEdge18.equals((java.lang.Object) segmentedTimeline30);
//        org.jfree.data.KeyedObjects2D keyedObjects2D38 = new org.jfree.data.KeyedObjects2D();
//        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date41, date42);
//        keyedObjects2D38.addObject((java.lang.Object) paint39, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date41);
//        long long45 = segmentedTimeline30.toTimelineValue(date41);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline49 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
//        boolean boolean51 = segmentedTimeline49.containsDomainValue(1562097599999L);
//        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean53 = segmentedTimeline49.containsDomainValue(date52);
//        org.jfree.data.gantt.Task task54 = new org.jfree.data.gantt.Task("ThreadContext", date41, date52);
//        java.lang.Object obj55 = task54.clone();
//        try {
//            org.jfree.data.gantt.Task task57 = task54.getSubtask(10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(axisLocation11);
//        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
//        org.junit.Assert.assertNull(collection17);
//        org.junit.Assert.assertNotNull(rectangleEdge18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(font24);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 900000L + "'", long31 == 900000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-32400010L) + "'", long33 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 455057983088L + "'", long45 == 455057983088L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(obj55);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = lineRenderer3D0.getLegendItems();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineRenderer3D0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Paint paint6 = lineRenderer3D0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        float float9 = categoryPlot4.getForegroundAlpha();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D13.setLabelFont(font14);
        java.awt.Color color17 = java.awt.Color.pink;
        java.lang.String str18 = color17.toString();
        java.awt.Color color19 = color17.darker();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke20);
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color17.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        org.jfree.chart.text.TextBlock textBlock28 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font14, (java.awt.Paint) color17);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis31, categoryItemRenderer32);
        java.awt.Stroke stroke34 = null;
        categoryPlot33.setOutlineStroke(stroke34);
        org.jfree.chart.JFreeChart jFreeChart37 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font14, (org.jfree.chart.plot.Plot) categoryPlot33, false);
        java.awt.Shape shape42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape42, stroke43, (java.awt.Paint) color44);
        java.lang.String str46 = legendItem45.getDescription();
        java.awt.Stroke stroke47 = legendItem45.getLineStroke();
        categoryPlot33.setDomainGridlineStroke(stroke47);
        categoryPlot4.setRangeCrosshairStroke(stroke47);
        categoryPlot4.clearDomainMarkers((int) '4');
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str18.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertNotNull(textBlock28);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str46.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font13 = categoryAxis11.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer9.setBaseItemLabelFont(font13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = stackedAreaRenderer9.getURLGenerator(0, 3);
        stackedAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer9.setBaseStroke(stroke22);
        categoryAxis1.setTickMarkStroke(stroke22);
        categoryAxis1.setTickMarkOutsideLength((float) 1562097599999L);
        double double27 = categoryAxis1.getLowerMargin();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font34 = categoryAxis32.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer30.setBaseItemLabelFont(font34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = stackedAreaRenderer30.getURLGenerator(0, 3);
        java.awt.Paint paint40 = stackedAreaRenderer30.lookupSeriesPaint((int) (short) 1);
        java.awt.Font font43 = stackedAreaRenderer30.getItemLabelFont(10, 255);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1.0d, font43);
        double double45 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(categoryURLGenerator38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot4.setRenderer((int) (short) 0, categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot4.getDomainAxis(0);
        categoryPlot4.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart10.removeProgressListener(chartProgressListener27);
        java.awt.RenderingHints renderingHints29 = jFreeChart10.getRenderingHints();
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(renderingHints29);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray5);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(shapeArray5);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
//        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
//        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
//        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
//        java.lang.Object obj10 = defaultCategoryDataset0.clone();
//        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
//        java.awt.geom.Point2D point2D19 = null;
//        categoryPlot16.zoomRangeAxes((double) (-1), plotRenderingInfo18, point2D19);
//        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot16.setRangeAxisLocation((int) ' ', axisLocation22, false);
//        float float25 = categoryPlot16.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer27 = null;
//        java.util.Collection collection28 = categoryPlot16.getRangeMarkers((int) (byte) 0, layer27);
//        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot16.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D30.setDrawOutlines(true);
//        boolean boolean33 = lineRenderer3D30.getBaseShapesVisible();
//        java.awt.Font font35 = lineRenderer3D30.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
//        lineRenderer3D30.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
//        boolean boolean40 = rectangleEdge29.equals((java.lang.Object) categoryItemLabelGenerator37);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long42 = segmentedTimeline41.getSegmentSize();
//        long long44 = segmentedTimeline41.toTimelineValue((long) (short) 0);
//        long long47 = segmentedTimeline41.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean48 = rectangleEdge29.equals((java.lang.Object) segmentedTimeline41);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline52 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
//        boolean boolean54 = segmentedTimeline52.containsDomainValue(1562097599999L);
//        java.util.Date date55 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean56 = segmentedTimeline52.containsDomainValue(date55);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment57 = segmentedTimeline41.getSegment(date55);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline58 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int59 = segmentedTimeline58.getSegmentsExcluded();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment61 = segmentedTimeline58.getSegment(10L);
//        try {
//            defaultCategoryDataset0.incrementValue((-2.0d), (java.lang.Comparable) segment57, (java.lang.Comparable) 10L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 10");
//        } catch (org.jfree.data.UnknownKeyException e) {
//        }
//        org.junit.Assert.assertNotNull(pieDataset9);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(axisLocation22);
//        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
//        org.junit.Assert.assertNull(collection28);
//        org.junit.Assert.assertNotNull(rectangleEdge29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(font35);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 900000L + "'", long42 == 900000L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-32400010L) + "'", long44 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(segment57);
//        org.junit.Assert.assertNotNull(segmentedTimeline58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 68 + "'", int59 == 68);
//        org.junit.Assert.assertNotNull(segment61);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        java.awt.Shape shape32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape32, stroke33, (java.awt.Paint) color34);
        java.lang.String str36 = legendItem35.getDescription();
        java.awt.Stroke stroke37 = legendItem35.getLineStroke();
        categoryPlot23.setDomainGridlineStroke(stroke37);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot23.getDataset((-1));
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str36.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(categoryDataset40);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation10, false);
        float float13 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot4.getRangeMarkers((int) (byte) 0, layer15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D18.setLabelFont(font19);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = numberAxis3D18.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis3D18.java2DToValue((double) 0, rectangle2D23, rectangleEdge24);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = numberAxis3D18.getTickUnit();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint29 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis28.setTickMarkPaint(paint29);
        int int31 = numberTickUnit26.compareTo((java.lang.Object) categoryAxis28);
        categoryPlot4.setDomainAxis(categoryAxis28);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis28.getLabelInsets();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(rectangleInsets33);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.data.Range range9 = null;
        try {
            numberAxis3D1.setRangeWithMargins(range9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.lang.String str8 = legendItem7.getDescription();
        java.awt.Stroke stroke9 = legendItem7.getLineStroke();
        java.awt.Paint paint10 = legendItem7.getLinePaint();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection11 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int13 = taskSeriesCollection11.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection11, true);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes((double) (-1), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot20.getRenderer();
        taskSeriesCollection11.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot20);
        legendItem7.setDataset((org.jfree.data.general.Dataset) taskSeriesCollection11);
        legendItem7.setDatasetIndex(4);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str8.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryItemRenderer25);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.xy.XYDataset xYDataset0 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
//        java.lang.Object obj5 = lineRenderer3D2.clone();
//        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
//        java.util.List list7 = null;
//        projectInfo6.setContributors(list7);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D10.setLabelFont(font11);
//        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
//        categoryPlot17.setDomainAxes(categoryAxisArray19);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
//        categoryPlot17.datasetChanged(datasetChangeEvent21);
//        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
//        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
//        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
//        org.jfree.data.Range range26 = numberAxis3D10.getRange();
//        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
//        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
//        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
//        xYPlot30.setRangeCrosshairLockedOnData(false);
//        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
//        java.awt.geom.Point2D point2D40 = null;
//        polarPlot35.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo39, point2D40);
//        org.jfree.chart.axis.AxisSpace axisSpace42 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D45 = labelBlock44.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, categoryItemRenderer49);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
//        java.awt.geom.Point2D point2D53 = null;
//        categoryPlot50.zoomRangeAxes((double) (-1), plotRenderingInfo52, point2D53);
//        org.jfree.chart.axis.AxisLocation axisLocation56 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot50.setRangeAxisLocation((int) ' ', axisLocation56, false);
//        float float59 = categoryPlot50.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer61 = null;
//        java.util.Collection collection62 = categoryPlot50.getRangeMarkers((int) (byte) 0, layer61);
//        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot50.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D64 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D64.setDrawOutlines(true);
//        boolean boolean67 = lineRenderer3D64.getBaseShapesVisible();
//        java.awt.Font font69 = lineRenderer3D64.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator71 = null;
//        lineRenderer3D64.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator71, false);
//        boolean boolean74 = rectangleEdge63.equals((java.lang.Object) categoryItemLabelGenerator71);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline75 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long76 = segmentedTimeline75.getSegmentSize();
//        long long78 = segmentedTimeline75.toTimelineValue((long) (short) 0);
//        long long81 = segmentedTimeline75.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean82 = rectangleEdge63.equals((java.lang.Object) segmentedTimeline75);
//        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge63);
//        java.awt.geom.Rectangle2D rectangle2D84 = axisSpace42.reserved(rectangle2D45, rectangleEdge63);
//        plotRenderingInfo39.setDataArea(rectangle2D84);
//        java.awt.geom.Point2D point2D86 = null;
//        try {
//            xYPlot30.zoomRangeAxes((double) (byte) 1, 0.0d, plotRenderingInfo39, point2D86);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.05) <= upper (0.0).");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(obj5);
//        org.junit.Assert.assertNotNull(font11);
//        org.junit.Assert.assertNotNull(categoryAxisArray19);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(range26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
//        org.junit.Assert.assertNotNull(rectangle2D45);
//        org.junit.Assert.assertNotNull(axisLocation56);
//        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 1.0f + "'", float59 == 1.0f);
//        org.junit.Assert.assertNull(collection62);
//        org.junit.Assert.assertNotNull(rectangleEdge63);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNull(font69);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline75);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 900000L + "'", long76 == 900000L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-32400010L) + "'", long78 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge83);
//        org.junit.Assert.assertNotNull(rectangle2D84);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType1 = categoryLabelPosition0.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean4 = categoryLabelPosition0.equals((java.lang.Object) textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        try {
            defaultCategoryDataset0.removeColumn(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
        boolean boolean8 = segmentedTimeline6.containsDomainValue(1562097599999L);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean10 = segmentedTimeline6.containsDomainValue(date9);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
        boolean boolean16 = segmentedTimeline14.containsDomainValue(1562097599999L);
        java.util.Date date17 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean18 = segmentedTimeline14.containsDomainValue(date17);
        try {
            dateAxis2.setRange(date9, date17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        polarPlot0.setRenderer(polarItemRenderer3);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        jFreeChart27.setTextAntiAlias(true);
        java.lang.Object obj35 = null;
        boolean boolean36 = jFreeChart27.equals(obj35);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.Object obj1 = null;
        boolean boolean2 = verticalAlignment0.equals(obj1);
        java.lang.String str3 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str3.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(10L);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        java.lang.Object obj9 = piePlot3D0.clone();
        double double10 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-5d + "'", double10 == 1.0E-5d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset1.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0f), (org.jfree.data.KeyedValues) pieDataset10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        java.awt.Stroke stroke13 = null;
        try {
            piePlot3D12.setLabelLinkStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D0.setDrawOutlines(true);
//        java.awt.Color color4 = java.awt.Color.pink;
//        java.lang.String str5 = color4.toString();
//        java.awt.Color color6 = color4.darker();
//        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
//        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
//        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
//        java.awt.Graphics2D graphics2D14 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
//        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray21 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis20 };
//        categoryPlot19.setDomainAxes(categoryAxisArray21);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = null;
//        categoryPlot19.datasetChanged(datasetChangeEvent23);
//        categoryPlot19.setBackgroundAlpha((float) 0);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
//        categoryPlot19.markerChanged(markerChangeEvent27);
//        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = null;
//        categoryPlot19.notifyListeners(plotChangeEvent29);
//        org.jfree.chart.axis.AxisSpace axisSpace31 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D34 = labelBlock33.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
//        java.awt.geom.Point2D point2D42 = null;
//        categoryPlot39.zoomRangeAxes((double) (-1), plotRenderingInfo41, point2D42);
//        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot39.setRangeAxisLocation((int) ' ', axisLocation45, false);
//        float float48 = categoryPlot39.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer50 = null;
//        java.util.Collection collection51 = categoryPlot39.getRangeMarkers((int) (byte) 0, layer50);
//        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot39.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D53 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D53.setDrawOutlines(true);
//        boolean boolean56 = lineRenderer3D53.getBaseShapesVisible();
//        java.awt.Font font58 = lineRenderer3D53.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator60 = null;
//        lineRenderer3D53.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator60, false);
//        boolean boolean63 = rectangleEdge52.equals((java.lang.Object) categoryItemLabelGenerator60);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline64 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long65 = segmentedTimeline64.getSegmentSize();
//        long long67 = segmentedTimeline64.toTimelineValue((long) (short) 0);
//        long long70 = segmentedTimeline64.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean71 = rectangleEdge52.equals((java.lang.Object) segmentedTimeline64);
//        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
//        java.awt.geom.Rectangle2D rectangle2D73 = axisSpace31.reserved(rectangle2D34, rectangleEdge52);
//        try {
//            lineRenderer3D0.drawBackground(graphics2D14, categoryPlot19, rectangle2D73);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertNull(legendItem13);
//        org.junit.Assert.assertNotNull(categoryAxisArray21);
//        org.junit.Assert.assertNotNull(rectangle2D34);
//        org.junit.Assert.assertNotNull(axisLocation45);
//        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
//        org.junit.Assert.assertNull(collection51);
//        org.junit.Assert.assertNotNull(rectangleEdge52);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNull(font58);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline64);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 900000L + "'", long65 == 900000L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-32400010L) + "'", long67 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge72);
//        org.junit.Assert.assertNotNull(rectangle2D73);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = color5.darker();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke8);
        valueMarker9.setAlpha((float) 0L);
        java.awt.Stroke stroke12 = valueMarker9.getStroke();
        lineRenderer3D0.setBaseOutlineStroke(stroke12, false);
        lineRenderer3D0.setXOffset((double) (byte) 0);
        lineRenderer3D0.setBaseSeriesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        java.awt.Font font14 = stackedAreaRenderer1.getItemLabelFont(10, 255);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D16.setLabelFont(font17);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = numberAxis3D16.getStandardTickUnits();
        numberAxis3D16.centerRange((double) (short) 0);
        numberAxis3D16.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D30.setLabelFont(font31);
        java.awt.Color color34 = java.awt.Color.pink;
        java.lang.String str35 = color34.toString();
        java.awt.Color color36 = color34.darker();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color34, stroke37);
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color34.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        org.jfree.chart.text.TextBlock textBlock45 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font31, (java.awt.Paint) color34);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D16, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font31);
        numberAxis3D16.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font52 = categoryAxis50.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D16.setLabelFont(font52);
        java.awt.Stroke stroke54 = numberAxis3D16.getAxisLineStroke();
        stackedAreaRenderer1.setBaseStroke(stroke54);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str35.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertNotNull(textBlock45);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        categoryPlot23.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.pink;
        java.lang.String str3 = color2.toString();
        java.awt.Color color4 = color2.darker();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        org.jfree.chart.entity.EntityCollection entityCollection9 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo(entityCollection9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Point2D point2D13 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 1, 0.2d, plotRenderingInfo12, point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str3.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Color color4 = java.awt.Color.blue;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) ' ', (double) 10L, Double.NaN, 4.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        java.awt.Paint paint9 = numberAxis3D1.getAxisLinePaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer21);
        java.awt.Color color24 = java.awt.Color.pink;
        java.lang.String str25 = color24.toString();
        java.awt.Color color26 = color24.darker();
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Color color29 = java.awt.Color.pink;
        java.lang.String str30 = color29.toString();
        java.awt.Color color31 = color29.darker();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke32);
        valueMarker33.setAlpha((float) 0L);
        java.awt.Stroke stroke36 = valueMarker33.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color24, stroke36);
        categoryPlot17.addDomainMarker(categoryMarker37);
        categoryPlot4.addDomainMarker(categoryMarker37);
        java.awt.Paint paint40 = categoryMarker37.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType41 = categoryMarker37.getLabelOffsetType();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str25.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str30.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(lengthAdjustmentType41);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long1 = segmentedTimeline0.getSegmentSize();
//        long long3 = segmentedTimeline0.toTimelineValue((long) (short) 0);
//        long long6 = segmentedTimeline0.getExceptionSegmentCount((long) ' ', (long) 0);
//        java.lang.Object obj7 = segmentedTimeline0.clone();
//        long long8 = segmentedTimeline0.getSegmentsGroupSize();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-32400010L) + "'", long3 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 86400000L + "'", long8 == 86400000L);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        boolean boolean21 = lineRenderer3D0.getItemCreateEntity(0, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        lineRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#', (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.lang.Object obj9 = legendItemEntity8.clone();
        java.lang.String str10 = legendItemEntity8.getShapeType();
        org.jfree.data.general.Dataset dataset11 = legendItemEntity8.getDataset();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "rect" + "'", str10.equals("rect"));
        org.junit.Assert.assertNull(dataset11);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D(2.0d, (double) 100L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.pink;
        java.lang.String str3 = color2.toString();
        java.awt.Color color4 = color2.darker();
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        polarPlot0.setAngleLabelPaint((java.awt.Paint) color2);
        java.awt.Paint paint7 = null;
        try {
            polarPlot0.setNoDataMessagePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str3.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
//        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
//        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
//        java.awt.Paint paint3 = piePlot3D0.getBaseSectionOutlinePaint();
//        java.awt.Paint paint4 = piePlot3D0.getLabelOutlinePaint();
//        java.lang.String str5 = piePlot3D0.getPlotType();
//        java.awt.Graphics2D graphics2D6 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
//        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12 };
//        categoryPlot11.setDomainAxes(categoryAxisArray13);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent15 = null;
//        categoryPlot11.datasetChanged(datasetChangeEvent15);
//        categoryPlot11.setBackgroundAlpha((float) 0);
//        java.awt.Color color19 = java.awt.Color.pink;
//        java.lang.String str20 = color19.toString();
//        java.awt.Color color21 = color19.darker();
//        categoryPlot11.setOutlinePaint((java.awt.Paint) color21);
//        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        categoryPlot11.setInsets(rectangleInsets23);
//        double double25 = rectangleInsets23.getRight();
//        org.jfree.chart.axis.AxisSpace axisSpace26 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D29 = labelBlock28.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
//        java.awt.geom.Point2D point2D37 = null;
//        categoryPlot34.zoomRangeAxes((double) (-1), plotRenderingInfo36, point2D37);
//        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot34.setRangeAxisLocation((int) ' ', axisLocation40, false);
//        float float43 = categoryPlot34.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer45 = null;
//        java.util.Collection collection46 = categoryPlot34.getRangeMarkers((int) (byte) 0, layer45);
//        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot34.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D48 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D48.setDrawOutlines(true);
//        boolean boolean51 = lineRenderer3D48.getBaseShapesVisible();
//        java.awt.Font font53 = lineRenderer3D48.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator55 = null;
//        lineRenderer3D48.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator55, false);
//        boolean boolean58 = rectangleEdge47.equals((java.lang.Object) categoryItemLabelGenerator55);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline59 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long60 = segmentedTimeline59.getSegmentSize();
//        long long62 = segmentedTimeline59.toTimelineValue((long) (short) 0);
//        long long65 = segmentedTimeline59.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean66 = rectangleEdge47.equals((java.lang.Object) segmentedTimeline59);
//        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge47);
//        java.awt.geom.Rectangle2D rectangle2D68 = axisSpace26.reserved(rectangle2D29, rectangleEdge47);
//        java.awt.Color color70 = java.awt.Color.pink;
//        java.lang.String str71 = color70.toString();
//        java.awt.Color color72 = color70.darker();
//        java.awt.Stroke stroke73 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker74 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color70, stroke73);
//        java.awt.Color color76 = java.awt.Color.pink;
//        java.lang.String str77 = color76.toString();
//        java.awt.Color color78 = color76.darker();
//        java.awt.Stroke stroke79 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color76, stroke79);
//        valueMarker80.setAlpha((float) 0L);
//        java.awt.Stroke stroke83 = valueMarker80.getStroke();
//        valueMarker80.setValue((double) 2);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType86 = valueMarker80.getLabelOffsetType();
//        valueMarker74.setLabelOffsetType(lengthAdjustmentType86);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType88 = null;
//        java.awt.geom.Rectangle2D rectangle2D89 = rectangleInsets23.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType86, lengthAdjustmentType88);
//        piePlot3D0.drawBackgroundImage(graphics2D6, rectangle2D89);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertNotNull(paint4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
//        org.junit.Assert.assertNotNull(categoryAxisArray13);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
//        org.junit.Assert.assertNotNull(color21);
//        org.junit.Assert.assertNotNull(rectangleInsets23);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.0d + "'", double25 == 4.0d);
//        org.junit.Assert.assertNotNull(rectangle2D29);
//        org.junit.Assert.assertNotNull(axisLocation40);
//        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
//        org.junit.Assert.assertNull(collection46);
//        org.junit.Assert.assertNotNull(rectangleEdge47);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(font53);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 900000L + "'", long60 == 900000L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + (-32400010L) + "'", long62 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge67);
//        org.junit.Assert.assertNotNull(rectangle2D68);
//        org.junit.Assert.assertNotNull(color70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str71.equals("java.awt.Color[r=255,g=175,b=175]"));
//        org.junit.Assert.assertNotNull(color72);
//        org.junit.Assert.assertNotNull(stroke73);
//        org.junit.Assert.assertNotNull(color76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str77.equals("java.awt.Color[r=255,g=175,b=175]"));
//        org.junit.Assert.assertNotNull(color78);
//        org.junit.Assert.assertNotNull(stroke79);
//        org.junit.Assert.assertNotNull(stroke83);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType86);
//        org.junit.Assert.assertNotNull(rectangle2D89);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = polarPlot0.getAxis();
        java.awt.Stroke stroke3 = polarPlot0.getRadiusGridlineStroke();
        boolean boolean4 = polarPlot0.isAngleLabelsVisible();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.data.KeyedObjects2D keyedObjects2D15 = new org.jfree.data.KeyedObjects2D();
        java.awt.Paint paint16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.util.Date date18 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date18, date19);
        keyedObjects2D15.addObject((java.lang.Object) paint16, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date18);
        lineRenderer3D0.setSeriesOutlinePaint(68, paint16);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        int int31 = xYPlot30.getWeight();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        xYPlot30.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis32);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.Plot plot2 = categoryAxis1.getPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font16 = categoryAxis14.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer12.setBaseItemLabelFont(font16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = stackedAreaRenderer12.getURLGenerator(0, 3);
        stackedAreaRenderer12.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer12.setBaseStroke(stroke25);
        categoryAxis4.setTickMarkStroke(stroke25);
        categoryAxis1.setTickMarkStroke(stroke25);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        try {
            java.lang.Number number9 = taskSeriesCollection0.getPercentComplete(0, (int) (byte) -1, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock17.setLineAlignment(horizontalAlignment18);
        java.lang.String str20 = horizontalAlignment18.toString();
        java.lang.String str21 = horizontalAlignment18.toString();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "HorizontalAlignment.CENTER" + "'", str20.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "HorizontalAlignment.CENTER" + "'", str21.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        org.junit.Assert.assertNotNull(tableOrder2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer1.setBaseShape(shape16, true);
        java.awt.Shape shape20 = stackedAreaRenderer1.getSeriesShape((int) (short) 0);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType21 = stackedAreaRenderer1.getEndType();
        java.lang.Object obj22 = null;
        boolean boolean23 = stackedAreaRenderer1.equals(obj22);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertNotNull(areaRendererEndType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        java.awt.Color color11 = java.awt.Color.pink;
        java.lang.String str12 = color11.toString();
        java.awt.Color color13 = color11.darker();
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color11);
        java.awt.Color color16 = java.awt.Color.pink;
        java.lang.String str17 = color16.toString();
        java.awt.Color color18 = color16.darker();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke19);
        valueMarker20.setAlpha((float) 0L);
        java.awt.Stroke stroke23 = valueMarker20.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color11, stroke23);
        categoryPlot4.addDomainMarker(categoryMarker24);
        org.jfree.chart.axis.ValueAxis valueAxis27 = categoryPlot4.getRangeAxisForDataset((int) (short) 10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str12.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str17.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(valueAxis27);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        double double15 = numberAxis3D1.getAutoRangeMinimumSize();
        org.jfree.data.Range range16 = null;
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range16, (double) 1);
        java.lang.String str19 = range18.toString();
        java.lang.String str20 = range18.toString();
        numberAxis3D1.setRangeWithMargins(range18);
        numberAxis3D1.zoomRange((double) (byte) 1, 8.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[1.0,1.0]" + "'", str19.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Range[1.0,1.0]" + "'", str20.equals("Range[1.0,1.0]"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list5 = null;
        projectInfo4.setContributors(list5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D8.setLabelFont(font9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16 };
        categoryPlot15.setDomainAxes(categoryAxisArray17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent19);
        numberAxis3D8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        double double22 = numberAxis3D8.getAutoRangeMinimumSize();
        boolean boolean23 = projectInfo4.equals((java.lang.Object) numberAxis3D8);
        org.jfree.data.Range range24 = numberAxis3D8.getRange();
        boolean boolean25 = lineRenderer3D0.equals((java.lang.Object) numberAxis3D8);
        float float26 = numberAxis3D8.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        double double10 = categoryPlot4.getAnchorValue();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot4.getRangeAxisLocation(1900);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3D4.getStandardTickUnits();
        numberAxis3D4.centerRange((double) (short) 0);
        numberAxis3D4.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D18.setLabelFont(font19);
        java.awt.Color color22 = java.awt.Color.pink;
        java.lang.String str23 = color22.toString();
        java.awt.Color color24 = color22.darker();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke25);
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color22.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font19, (java.awt.Paint) color22);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D4, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font19);
        numberAxis3D4.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font40 = categoryAxis38.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D4.setLabelFont(font40);
        numberAxis3D4.resizeRange((double) (byte) 10, 0.0d);
        org.jfree.chart.util.UnitType unitType45 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets(unitType45, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double52 = rectangleInsets50.calculateRightOutset((double) (-1));
        numberAxis3D4.setLabelInsets(rectangleInsets50);
        blockContainer0.setPadding(rectangleInsets50);
        java.util.List list55 = blockContainer0.getBlocks();
        org.jfree.chart.block.Block block56 = null;
        blockContainer0.add(block56);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str23.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(list55);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Color color1 = java.awt.Color.pink;
        java.awt.Color color2 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", color1);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset(2.0d);
        double double4 = rectangleInsets0.calculateLeftOutset((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str10 = textAnchor9.toString();
        org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor8, textAnchor9, 1.0d);
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) textAnchor9);
        double double15 = rectangleInsets0.trimWidth((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str10.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-7.0d) + "'", double15 == (-7.0d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = polarPlot0.getOrientation();
        java.awt.Paint paint2 = polarPlot0.getRadiusGridlinePaint();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone4);
        dateAxis5.setAutoTickUnitSelection(true, true);
        org.jfree.data.Range range9 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Paint paint10 = dateAxis5.getLabelPaint();
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("ERROR : Relative To String");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass3 = stroke2.getClass();
        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass3);
        java.io.InputStream inputStream5 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass3);
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("LGPL", (java.lang.Class) wildcardClass3);
        boolean boolean7 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass3);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(classLoader4);
        org.junit.Assert.assertNull(inputStream5);
        org.junit.Assert.assertNull(uRL6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis7 };
        categoryPlot6.setDomainAxes(categoryAxisArray8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent10);
        categoryPlot6.setBackgroundAlpha((float) 0);
        categoryPlot6.setWeight((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("CategoryAnchor.MIDDLE", font1, (org.jfree.chart.plot.Plot) categoryPlot6, false);
        jFreeChart17.fireChartChanged();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font16 = categoryAxis14.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer12.setBaseItemLabelFont(font16);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = stackedAreaRenderer12.getURLGenerator(0, 3);
        stackedAreaRenderer12.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer12.setBaseStroke(stroke25);
        stackedAreaRenderer8.setSeriesStroke(2958465, stroke25, false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getMiddleMillisecond();
        long long3 = year1.getFirstMillisecond();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (byte) -1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        stackedAreaRenderer1.setBaseShape(shape18, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = stackedAreaRenderer1.getPlot();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(categoryPlot24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis11.setTickMarkPaint(paint12);
        int int14 = numberTickUnit9.compareTo((java.lang.Object) categoryAxis11);
        java.lang.String str16 = categoryAxis11.getCategoryLabelToolTip((java.lang.Comparable) 2019);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot4.getRangeAxisForDataset(5);
        java.awt.Stroke stroke15 = categoryPlot4.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 255);
        java.lang.Comparable comparable3 = null;
        int int4 = taskSeriesCollection0.indexOf(comparable3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        boolean boolean28 = jFreeChart27.isBorderVisible();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        categoryPlot4.setRangeGridlinesVisible(false);
        categoryPlot4.clearDomainMarkers(3);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = java.awt.Color.black;
        piePlot3D0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot3D0.getLegendItems();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator4);
        java.lang.Comparable comparable6 = null;
        try {
            piePlot3D0.setExplodePercent(comparable6, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        try {
            categoryPlot4.setRangeCrosshairStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double[] doubleArray1 = new double[] { 1.0f };
        double[] doubleArray3 = new double[] { 1.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        double[] doubleArray9 = new double[] { 10.0d, 455057983088L, 2958465, 68 };
        double[] doubleArray14 = new double[] { 10.0d, 455057983088L, 2958465, 68 };
        double[][] doubleArray15 = new double[][] { doubleArray9, doubleArray14 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset16 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray4, doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of categories in the start value dataset does not match the number of categories in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(10L);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        int int9 = piePlot3D0.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D10 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D10.setDrawOutlines(true);
        java.awt.Color color14 = java.awt.Color.pink;
        java.lang.String str15 = color14.toString();
        java.awt.Color color16 = color14.darker();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke17);
        lineRenderer3D10.setBaseOutlineStroke(stroke17, true);
        org.jfree.chart.LegendItem legendItem23 = lineRenderer3D10.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor26 = itemLabelPosition25.getRotationAnchor();
        lineRenderer3D10.setSeriesNegativeItemLabelPosition(10, itemLabelPosition25, false);
        stackedAreaRenderer8.setBaseNegativeItemLabelPosition(itemLabelPosition25, false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str15.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(legendItem23);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = java.awt.Color.getColor("({0}, {1}) = {2}", color5);
        boolean boolean8 = defaultCategoryDataset0.equals((java.lang.Object) color7);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        defaultCategoryDataset0.setValue(Double.NaN, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) year11);
        long long13 = year11.getLastMillisecond();
        long long14 = year11.getSerialIndex();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2019L + "'", long14 == 2019L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.removeAll();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color5 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean6 = stackedBarRenderer3D2.equals((java.lang.Object) 0);
        stackedBarRenderer3D2.setItemMargin((double) 'a');
        java.awt.Font font11 = stackedBarRenderer3D2.getItemLabelFont(2019, (int) (byte) -1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.UnknownKeyException: ERROR : Relative To String" + "'", str3.equals("org.jfree.data.UnknownKeyException: ERROR : Relative To String"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer1.setBaseShape(shape16, true);
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Paint paint23 = stackedAreaRenderer1.getSeriesItemLabelPaint(0);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        numberAxis3D1.setAutoRangeMinimumSize((double) 9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        java.awt.Stroke stroke17 = null;
        categoryPlot16.setOutlineStroke(stroke17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        categoryPlot16.drawOutline(graphics2D19, rectangle2D20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot16.getInsets();
        numberAxis3D1.setLabelInsets(rectangleInsets22);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) 2, shape1, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "");
        java.lang.String str5 = categoryLabelEntity4.toString();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryLabelEntity: category=2, tooltip=null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull, url=" + "'", str5.equals("CategoryLabelEntity: category=2, tooltip=null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull, url="));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color9);
        float[] floatArray11 = new float[] {};
        try {
            float[] floatArray12 = color9.getRGBComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100L, true);
        int int4 = stackedBarRenderer3D3.getColumnCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double7 = rectangleInsets5.calculateRightOutset((double) (-1));
        double double8 = rectangleInsets5.getTop();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets5.createInsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRed();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = blockBorder2.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        size2D2.setWidth((double) 0.0f);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = null;
        try {
            jFreeChart27.setPadding(rectangleInsets33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        java.awt.Font font12 = lineRenderer3D0.getSeriesItemLabelFont((int) (short) 0);
        lineRenderer3D0.setBaseShapesVisible(false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0.2d, obj1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        numberAxis3D1.setAutoRange(false);
        org.jfree.data.RangeType rangeType34 = numberAxis3D1.getRangeType();
        java.awt.Stroke stroke35 = numberAxis3D1.getTickMarkStroke();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        java.awt.Stroke stroke6 = null;
        categoryPlot5.setOutlineStroke(stroke6);
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot5.getRangeAxisForDataset((int) ' ');
        categoryPlot5.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font18 = categoryAxis16.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer14.setBaseItemLabelFont(font18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = stackedAreaRenderer14.getURLGenerator(0, 3);
        java.awt.Paint paint24 = stackedAreaRenderer14.lookupSeriesPaint((int) (short) 1);
        java.awt.Font font27 = stackedAreaRenderer14.getItemLabelFont(10, 255);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("Range[1.0,1.0]", font27);
        categoryPlot5.setNoDataMessageFont(font27);
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font27);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font13 = categoryAxis11.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer9.setBaseItemLabelFont(font13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = stackedAreaRenderer9.getURLGenerator(0, 3);
        stackedAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer9.setBaseStroke(stroke22);
        categoryAxis1.setTickMarkStroke(stroke22);
        categoryAxis1.setTickMarkOutsideLength((float) 1562097599999L);
        double double27 = categoryAxis1.getLowerMargin();
        double double28 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.2d + "'", double28 == 0.2d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segment3.copy();
        boolean boolean7 = segment4.contains((long) '4', 1577865599999L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        java.lang.String str3 = range2.toString();
        org.jfree.data.Range range4 = null;
        org.jfree.data.Range range6 = org.jfree.data.Range.expandToInclude(range4, (double) 1);
        java.lang.String str7 = range6.toString();
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range6, (double) (byte) 100);
        boolean boolean11 = range6.contains((double) 9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range2, range6);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range6, 8.0d, false);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[1.0,1.0]" + "'", str3.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Range[1.0,1.0]" + "'", str7.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot3D0.getURLGenerator();
        piePlot3D0.setPieIndex(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        double double15 = numberAxis3D1.getAutoRangeMinimumSize();
        java.awt.Stroke stroke16 = numberAxis3D1.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = numberAxis3D1.getLabelInsets();
        double double19 = rectangleInsets17.calculateBottomInset((double) 455057983088L);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0E-8d + "'", double15 == 1.0E-8d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.0d + "'", double19 == 3.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
//        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
//        double double7 = rectangleInsets5.calculateRightOutset((double) (-1));
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D9.setLabelFont(font10);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = numberAxis3D9.getStandardTickUnits();
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        double double16 = numberAxis3D9.java2DToValue((double) 0, rectangle2D14, rectangleEdge15);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis3D9.getTickUnit();
//        boolean boolean18 = numberAxis3D9.isTickLabelsVisible();
//        org.jfree.chart.entity.EntityCollection entityCollection20 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo(entityCollection20);
//        org.jfree.chart.axis.AxisSpace axisSpace22 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D25 = labelBlock24.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
//        java.awt.geom.Point2D point2D33 = null;
//        categoryPlot30.zoomRangeAxes((double) (-1), plotRenderingInfo32, point2D33);
//        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot30.setRangeAxisLocation((int) ' ', axisLocation36, false);
//        float float39 = categoryPlot30.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer41 = null;
//        java.util.Collection collection42 = categoryPlot30.getRangeMarkers((int) (byte) 0, layer41);
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot30.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D44 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D44.setDrawOutlines(true);
//        boolean boolean47 = lineRenderer3D44.getBaseShapesVisible();
//        java.awt.Font font49 = lineRenderer3D44.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator51 = null;
//        lineRenderer3D44.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator51, false);
//        boolean boolean54 = rectangleEdge43.equals((java.lang.Object) categoryItemLabelGenerator51);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline55 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long56 = segmentedTimeline55.getSegmentSize();
//        long long58 = segmentedTimeline55.toTimelineValue((long) (short) 0);
//        long long61 = segmentedTimeline55.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean62 = rectangleEdge43.equals((java.lang.Object) segmentedTimeline55);
//        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge43);
//        java.awt.geom.Rectangle2D rectangle2D64 = axisSpace22.reserved(rectangle2D25, rectangleEdge43);
//        chartRenderingInfo21.setChartArea(rectangle2D64);
//        org.jfree.chart.util.RectangleEdge rectangleEdge66 = null;
//        double double67 = numberAxis3D9.lengthToJava2D(1.0E-5d, rectangle2D64, rectangleEdge66);
//        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets5.createOutsetRectangle(rectangle2D64);
//        org.junit.Assert.assertNotNull(unitType0);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertNotNull(font10);
//        org.junit.Assert.assertNotNull(tickUnitSource12);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(numberTickUnit17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(rectangle2D25);
//        org.junit.Assert.assertNotNull(axisLocation36);
//        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
//        org.junit.Assert.assertNull(collection42);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNull(font49);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 900000L + "'", long56 == 900000L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-32400010L) + "'", long58 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge63);
//        org.junit.Assert.assertNotNull(rectangle2D64);
//        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangle2D68);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
//        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
//        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
//        waferMapPlot2.rendererChanged(rendererChangeEvent3);
//        java.awt.Graphics2D graphics2D5 = null;
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        java.awt.geom.Point2D point2D7 = null;
//        org.jfree.chart.plot.PlotState plotState8 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot9.getOrientation();
//        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = polarPlot9.getRenderer();
//        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
//        java.awt.Stroke stroke18 = null;
//        categoryPlot17.setOutlineStroke(stroke18);
//        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot17.getRangeAxisForDataset((int) ' ');
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot17.getRangeAxisEdge(0);
//        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot17.getOrientation();
//        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection29 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo(entityCollection29);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo30);
//        java.awt.geom.Point2D point2D32 = null;
//        polarPlot27.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo31, point2D32);
//        org.jfree.chart.axis.AxisSpace axisSpace34 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock36 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D37 = labelBlock36.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
//        java.awt.geom.Point2D point2D45 = null;
//        categoryPlot42.zoomRangeAxes((double) (-1), plotRenderingInfo44, point2D45);
//        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot42.setRangeAxisLocation((int) ' ', axisLocation48, false);
//        float float51 = categoryPlot42.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer53 = null;
//        java.util.Collection collection54 = categoryPlot42.getRangeMarkers((int) (byte) 0, layer53);
//        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot42.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D56 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D56.setDrawOutlines(true);
//        boolean boolean59 = lineRenderer3D56.getBaseShapesVisible();
//        java.awt.Font font61 = lineRenderer3D56.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator63 = null;
//        lineRenderer3D56.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator63, false);
//        boolean boolean66 = rectangleEdge55.equals((java.lang.Object) categoryItemLabelGenerator63);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline67 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long68 = segmentedTimeline67.getSegmentSize();
//        long long70 = segmentedTimeline67.toTimelineValue((long) (short) 0);
//        long long73 = segmentedTimeline67.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean74 = rectangleEdge55.equals((java.lang.Object) segmentedTimeline67);
//        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge55);
//        java.awt.geom.Rectangle2D rectangle2D76 = axisSpace34.reserved(rectangle2D37, rectangleEdge55);
//        plotRenderingInfo31.setDataArea(rectangle2D76);
//        categoryPlot17.handleClick(2, 5, plotRenderingInfo31);
//        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState79 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo31);
//        java.awt.geom.Point2D point2D80 = null;
//        polarPlot9.zoomDomainAxes(0.0d, plotRenderingInfo31, point2D80);
//        try {
//            waferMapPlot2.draw(graphics2D5, rectangle2D6, point2D7, plotState8, plotRenderingInfo31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(plotOrientation10);
//        org.junit.Assert.assertNull(polarItemRenderer11);
//        org.junit.Assert.assertNull(valueAxis21);
//        org.junit.Assert.assertNotNull(rectangleEdge23);
//        org.junit.Assert.assertNotNull(plotOrientation24);
//        org.junit.Assert.assertNotNull(rectangle2D37);
//        org.junit.Assert.assertNotNull(axisLocation48);
//        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 1.0f + "'", float51 == 1.0f);
//        org.junit.Assert.assertNull(collection54);
//        org.junit.Assert.assertNotNull(rectangleEdge55);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNull(font61);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 900000L + "'", long68 == 900000L);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-32400010L) + "'", long70 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge75);
//        org.junit.Assert.assertNotNull(rectangle2D76);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType1 = categoryLabelPosition0.getWidthType();
        java.lang.String str2 = categoryLabelWidthType1.toString();
        org.junit.Assert.assertNotNull(categoryLabelWidthType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str2.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone34);
        dateAxis35.setAutoTickUnitSelection(true, true);
        dateAxis35.configure();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D41.setLabelFont(font42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis3D41.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis3D41.java2DToValue((double) 0, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { dateAxis35, numberAxis3D41 };
        xYPlot30.setRangeAxes(valueAxisArray49);
        java.awt.Color color52 = java.awt.Color.pink;
        java.lang.String str53 = color52.toString();
        java.awt.Color color54 = color52.darker();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color52, stroke55);
        valueMarker56.setAlpha((float) 0L);
        java.awt.Stroke stroke59 = valueMarker56.getStroke();
        java.awt.Paint paint60 = valueMarker56.getPaint();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker56);
        xYPlot30.setDomainZeroBaselineVisible(true);
        xYPlot30.setRangeCrosshairVisible(false);
        double double66 = xYPlot30.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str53.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot31.addChangeListener(plotChangeListener32);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = categoryPlot31.getOrientation();
        valueMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot31);
        org.jfree.chart.LegendItemCollection legendItemCollection36 = null;
        categoryPlot31.setFixedLegendItems(legendItemCollection36);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot31.getDomainAxisForDataset((int) '4');
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNull(categoryAxis39);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3D4.getStandardTickUnits();
        numberAxis3D4.centerRange((double) (short) 0);
        numberAxis3D4.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D18.setLabelFont(font19);
        java.awt.Color color22 = java.awt.Color.pink;
        java.lang.String str23 = color22.toString();
        java.awt.Color color24 = color22.darker();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke25);
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color22.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font19, (java.awt.Paint) color22);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D4, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font19);
        numberAxis3D4.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font40 = categoryAxis38.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D4.setLabelFont(font40);
        numberAxis3D4.resizeRange((double) (byte) 10, 0.0d);
        org.jfree.chart.util.UnitType unitType45 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets(unitType45, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double52 = rectangleInsets50.calculateRightOutset((double) (-1));
        numberAxis3D4.setLabelInsets(rectangleInsets50);
        blockContainer0.setPadding(rectangleInsets50);
        blockContainer0.setPadding((double) (byte) 0, (double) 0.0f, (double) 0.5f, (double) 100);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str23.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getBaseSectionOutlinePaint();
        try {
            double double3 = piePlot1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        boolean boolean10 = numberAxis3D1.isTickLabelsVisible();
        java.awt.Color color11 = java.awt.Color.pink;
        numberAxis3D1.setLabelPaint((java.awt.Paint) color11);
        boolean boolean13 = numberAxis3D1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        float float9 = categoryPlot4.getForegroundAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        java.awt.Stroke stroke15 = null;
        categoryPlot14.setOutlineStroke(stroke15);
        java.awt.Paint paint17 = categoryPlot14.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D21.setLabelFont(font22);
        java.awt.Color color25 = java.awt.Color.pink;
        java.lang.String str26 = color25.toString();
        java.awt.Color color27 = color25.darker();
        java.awt.Stroke stroke28 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke28);
        java.awt.image.ColorModel colorModel30 = null;
        java.awt.Rectangle rectangle31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.geom.AffineTransform affineTransform33 = null;
        java.awt.RenderingHints renderingHints34 = null;
        java.awt.PaintContext paintContext35 = color25.createContext(colorModel30, rectangle31, rectangle2D32, affineTransform33, renderingHints34);
        org.jfree.chart.text.TextBlock textBlock36 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font22, (java.awt.Paint) color25);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        java.awt.Stroke stroke42 = null;
        categoryPlot41.setOutlineStroke(stroke42);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font22, (org.jfree.chart.plot.Plot) categoryPlot41, false);
        jFreeChart45.setBackgroundImageAlignment(100);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart45.setBackgroundPaint((java.awt.Paint) color48);
        categoryPlot14.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart45);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot14.setRangeCrosshairStroke(stroke51);
        java.awt.Color color55 = java.awt.Color.pink;
        java.lang.String str56 = color55.toString();
        java.awt.Color color57 = color55.darker();
        java.awt.Stroke stroke58 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color55, stroke58);
        valueMarker59.setAlpha((float) 0L);
        java.awt.Stroke stroke62 = valueMarker59.getStroke();
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot14.addRangeMarker(9, (org.jfree.chart.plot.Marker) valueMarker59, layer63);
        java.util.Collection collection65 = categoryPlot4.getRangeMarkers(layer63);
        int int66 = categoryPlot4.getDatasetCount();
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str26.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paintContext35);
        org.junit.Assert.assertNotNull(textBlock36);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str56.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertNotNull(collection65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        categoryPlot23.configureRangeAxes();
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot23.zoomDomainAxes((double) 0.5f, (double) (byte) 10, plotRenderingInfo34, point2D35);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        java.lang.String str3 = range2.toString();
        java.lang.String str4 = range2.toString();
        boolean boolean6 = range2.contains((double) 0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[1.0,1.0]" + "'", str3.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Range[1.0,1.0]" + "'", str4.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.awt.Paint paint0 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        java.awt.Stroke stroke8 = null;
        categoryPlot7.setOutlineStroke(stroke8);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot7.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot7);
        stackedAreaRenderer2.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Paint paint19 = stackedAreaRenderer2.getItemFillPaint(0, 3);
        boolean boolean20 = org.jfree.chart.util.PaintUtilities.equal(paint0, paint19);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        java.lang.Comparable comparable4 = null;
        try {
            defaultCategoryDataset0.removeValue(comparable4, (java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.lang.Boolean boolean4 = lineRenderer3D0.getSeriesVisible((int) (short) 0);
        lineRenderer3D0.setSeriesCreateEntities(100, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.lang.Object obj9 = legendItemEntity8.clone();
        java.lang.String str10 = legendItemEntity8.getURLText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        labelBlock1.setPadding(100.0d, (double) 0, (double) (-32400010L), (double) 3);
        java.awt.Paint paint7 = labelBlock1.getPaint();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = org.jfree.data.Range.expandToInclude(range9, (double) 1);
        java.lang.String str12 = range11.toString();
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range13, (double) 1);
        java.lang.String str16 = range15.toString();
        org.jfree.data.Range range18 = org.jfree.data.Range.expandToInclude(range15, (double) (byte) 100);
        boolean boolean20 = range15.contains((double) 9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range11, range15);
        try {
            org.jfree.chart.util.Size2D size2D22 = labelBlock1.arrange(graphics2D8, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Range[1.0,1.0]" + "'", str12.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Range[1.0,1.0]" + "'", str16.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = java.awt.Color.black;
        piePlot3D0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot3D0.getLegendItems();
        java.awt.Paint paint4 = piePlot3D0.getShadowPaint();
        piePlot3D0.setSectionOutlinesVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Range[1.0,1.0]", graphics2D1, (float) 2, 10.0f, (double) (short) 100, (float) 0L, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer1.setBaseShape(shape16, true);
        java.awt.Shape shape20 = stackedAreaRenderer1.getSeriesShape((int) (short) 0);
        boolean boolean21 = stackedAreaRenderer1.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = stackedAreaRenderer1.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator22);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        java.lang.String str3 = range2.toString();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) (byte) 100);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range2);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[1.0,1.0]" + "'", str3.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D8.setLabelFont(font9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = numberAxis3D8.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis3D8.java2DToValue((double) 0, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis3D8.getTickUnit();
        boolean boolean17 = numberAxis3D8.isTickLabelsVisible();
        numberAxis3D8.setUpperMargin((double) (short) 1);
        numberAxis3D8.setPositiveArrowVisible(true);
        org.jfree.data.Range range22 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        int int23 = categoryPlot4.getDatasetCount();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        float float9 = numberAxis3D1.getTickMarkInsideLength();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis3D1.getMarkerBand();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNull(markerAxisBand10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        piePlot3D0.setShadowYOffset((double) 1.0f);
        piePlot3D0.setMinimumArcAngleToDraw((double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        numberAxis3D1.setAutoRange(false);
        org.jfree.data.RangeType rangeType34 = numberAxis3D1.getRangeType();
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D38 = labelBlock37.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        java.awt.Stroke stroke44 = null;
        categoryPlot43.setOutlineStroke(stroke44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot43.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot43.getRangeAxisEdge(0);
        boolean boolean51 = rectangleEdge49.equals((java.lang.Object) false);
        double double52 = numberAxis3D1.java2DToValue(90.0d, rectangle2D38, rectangleEdge49);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertNotNull(rangeType34);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + Double.POSITIVE_INFINITY + "'", double52 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100L, true);
//        java.awt.Graphics2D graphics2D4 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
//        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
//        categoryPlot9.addChangeListener(plotChangeListener10);
//        categoryPlot9.setBackgroundAlpha((float) 6);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
//        categoryPlot9.rendererChanged(rendererChangeEvent14);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D17.setLabelFont(font18);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = numberAxis3D17.getStandardTickUnits();
//        java.awt.geom.Rectangle2D rectangle2D22 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
//        double double24 = numberAxis3D17.java2DToValue((double) 0, rectangle2D22, rectangleEdge23);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = numberAxis3D17.getTickUnit();
//        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        java.awt.Paint paint28 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
//        categoryAxis27.setTickMarkPaint(paint28);
//        int int30 = numberTickUnit25.compareTo((java.lang.Object) categoryAxis27);
//        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
//        org.jfree.chart.axis.AxisSpace axisSpace33 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D36 = labelBlock35.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
//        java.awt.geom.Point2D point2D44 = null;
//        categoryPlot41.zoomRangeAxes((double) (-1), plotRenderingInfo43, point2D44);
//        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot41.setRangeAxisLocation((int) ' ', axisLocation47, false);
//        float float50 = categoryPlot41.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer52 = null;
//        java.util.Collection collection53 = categoryPlot41.getRangeMarkers((int) (byte) 0, layer52);
//        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot41.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D55 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D55.setDrawOutlines(true);
//        boolean boolean58 = lineRenderer3D55.getBaseShapesVisible();
//        java.awt.Font font60 = lineRenderer3D55.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
//        lineRenderer3D55.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator62, false);
//        boolean boolean65 = rectangleEdge54.equals((java.lang.Object) categoryItemLabelGenerator62);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline66 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long67 = segmentedTimeline66.getSegmentSize();
//        long long69 = segmentedTimeline66.toTimelineValue((long) (short) 0);
//        long long72 = segmentedTimeline66.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean73 = rectangleEdge54.equals((java.lang.Object) segmentedTimeline66);
//        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge54);
//        java.awt.geom.Rectangle2D rectangle2D75 = axisSpace33.reserved(rectangle2D36, rectangleEdge54);
//        chartRenderingInfo32.setChartArea(rectangle2D75);
//        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity79 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis27, (java.awt.Shape) rectangle2D75, "{0}", "Pie 3D Plot");
//        try {
//            stackedBarRenderer3D3.drawOutline(graphics2D4, categoryPlot9, rectangle2D75);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(font18);
//        org.junit.Assert.assertNotNull(tickUnitSource20);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(numberTickUnit25);
//        org.junit.Assert.assertNotNull(paint28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(rectangle2D36);
//        org.junit.Assert.assertNotNull(axisLocation47);
//        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 1.0f + "'", float50 == 1.0f);
//        org.junit.Assert.assertNull(collection53);
//        org.junit.Assert.assertNotNull(rectangleEdge54);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNull(font60);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 900000L + "'", long67 == 900000L);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-32400010L) + "'", long69 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge74);
//        org.junit.Assert.assertNotNull(rectangle2D75);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
//        boolean boolean2 = tickUnits0.equals((java.lang.Object) 10.0f);
//        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
//        java.awt.Stroke stroke8 = null;
//        categoryPlot7.setOutlineStroke(stroke8);
//        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot7.getRangeAxisForDataset((int) ' ');
//        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getRangeAxisEdge(0);
//        org.jfree.chart.plot.PlotOrientation plotOrientation14 = categoryPlot7.getOrientation();
//        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo(entityCollection19);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
//        java.awt.geom.Point2D point2D22 = null;
//        polarPlot17.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo21, point2D22);
//        org.jfree.chart.axis.AxisSpace axisSpace24 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D27 = labelBlock26.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
//        java.awt.geom.Point2D point2D35 = null;
//        categoryPlot32.zoomRangeAxes((double) (-1), plotRenderingInfo34, point2D35);
//        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot32.setRangeAxisLocation((int) ' ', axisLocation38, false);
//        float float41 = categoryPlot32.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer43 = null;
//        java.util.Collection collection44 = categoryPlot32.getRangeMarkers((int) (byte) 0, layer43);
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot32.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D46 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D46.setDrawOutlines(true);
//        boolean boolean49 = lineRenderer3D46.getBaseShapesVisible();
//        java.awt.Font font51 = lineRenderer3D46.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator53 = null;
//        lineRenderer3D46.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator53, false);
//        boolean boolean56 = rectangleEdge45.equals((java.lang.Object) categoryItemLabelGenerator53);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline57 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long58 = segmentedTimeline57.getSegmentSize();
//        long long60 = segmentedTimeline57.toTimelineValue((long) (short) 0);
//        long long63 = segmentedTimeline57.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean64 = rectangleEdge45.equals((java.lang.Object) segmentedTimeline57);
//        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge45);
//        java.awt.geom.Rectangle2D rectangle2D66 = axisSpace24.reserved(rectangle2D27, rectangleEdge45);
//        plotRenderingInfo21.setDataArea(rectangle2D66);
//        categoryPlot7.handleClick(2, 5, plotRenderingInfo21);
//        boolean boolean69 = tickUnits0.equals((java.lang.Object) plotRenderingInfo21);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(valueAxis11);
//        org.junit.Assert.assertNotNull(rectangleEdge13);
//        org.junit.Assert.assertNotNull(plotOrientation14);
//        org.junit.Assert.assertNotNull(rectangle2D27);
//        org.junit.Assert.assertNotNull(axisLocation38);
//        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 1.0f + "'", float41 == 1.0f);
//        org.junit.Assert.assertNull(collection44);
//        org.junit.Assert.assertNotNull(rectangleEdge45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNull(font51);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 900000L + "'", long58 == 900000L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-32400010L) + "'", long60 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge65);
//        org.junit.Assert.assertNotNull(rectangle2D66);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis1.setTickMarkPaint(paint2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis1.getLabelInsets();
        double double6 = rectangleInsets4.calculateBottomOutset((double) 455057983088L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = stackedAreaRenderer1.getLegendItems();
        org.jfree.chart.LegendItem legendItem10 = stackedAreaRenderer1.getLegendItem((int) '#', 2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(legendItem10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        java.lang.Object obj32 = jFreeChart27.clone();
        org.jfree.chart.util.UnitType unitType33 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets(unitType33, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double40 = rectangleInsets38.calculateRightOutset((double) (-1));
        double double41 = rectangleInsets38.getTop();
        double double43 = rectangleInsets38.calculateTopOutset((double) 1.0f);
        double double45 = rectangleInsets38.trimWidth((double) 6);
        jFreeChart27.setPadding(rectangleInsets38);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(unitType33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.03333333333333333d + "'", double43 == 0.03333333333333333d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.2000000000000002d) + "'", double45 == (-1.2000000000000002d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone34);
        dateAxis35.setAutoTickUnitSelection(true, true);
        dateAxis35.configure();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D41.setLabelFont(font42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis3D41.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis3D41.java2DToValue((double) 0, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { dateAxis35, numberAxis3D41 };
        xYPlot30.setRangeAxes(valueAxisArray49);
        java.awt.Color color52 = java.awt.Color.pink;
        java.lang.String str53 = color52.toString();
        java.awt.Color color54 = color52.darker();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color52, stroke55);
        valueMarker56.setAlpha((float) 0L);
        java.awt.Stroke stroke59 = valueMarker56.getStroke();
        java.awt.Paint paint60 = valueMarker56.getPaint();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker56);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = xYPlot30.getAxisOffset();
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        xYPlot30.setDataset((int) 'a', xYDataset64);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str53.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot8.setFixedDomainAxisSpace(axisSpace15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot8.getDomainAxisLocation(15);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineRenderer3D0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator7, false);
        lineRenderer3D0.setBaseShapesVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean13 = piePlot3D12.getIgnoreNullValues();
        boolean boolean14 = piePlot3D12.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int16 = segmentedTimeline15.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline15.getSegment(10L);
        piePlot3D12.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = piePlot3D12.getToolTipGenerator();
        java.awt.Color color23 = java.awt.Color.pink;
        java.lang.String str24 = color23.toString();
        java.awt.Color color25 = color23.darker();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke26);
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color23.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        piePlot3D12.setShadowPaint((java.awt.Paint) color23);
        lineRenderer3D0.setBaseOutlinePaint((java.awt.Paint) color23);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        java.awt.Stroke stroke42 = null;
        categoryPlot41.setOutlineStroke(stroke42);
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot41.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent46 = null;
        categoryPlot41.notifyListeners(plotChangeEvent46);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D48 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D48.setDrawOutlines(true);
        boolean boolean51 = lineRenderer3D48.getBaseShapesVisible();
        java.awt.Font font53 = lineRenderer3D48.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator55 = null;
        lineRenderer3D48.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator55, false);
        lineRenderer3D48.setBaseShapesVisible(false);
        int int60 = categoryPlot41.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineRenderer3D48);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator63 = lineRenderer3D48.getToolTipGenerator((int) '4', (int) (short) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = lineRenderer3D48.getNegativeItemLabelPosition(2, 0);
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(15, itemLabelPosition66);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 68 + "'", int16 == 68);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertNull(pieToolTipGenerator21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str24.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNull(valueAxis45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(font53);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNull(categoryToolTipGenerator63);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        boolean boolean2 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        jFreeChart27.removeLegend();
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = new org.jfree.chart.ChartRenderingInfo(entityCollection35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        try {
            java.awt.image.BufferedImage bufferedImage38 = jFreeChart27.createBufferedImage((int) (short) 0, 255, chartRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (255) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineRenderer3D0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator7, false);
        lineRenderer3D0.setBaseShapesVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean13 = piePlot3D12.getIgnoreNullValues();
        boolean boolean14 = piePlot3D12.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int16 = segmentedTimeline15.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline15.getSegment(10L);
        piePlot3D12.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = piePlot3D12.getToolTipGenerator();
        java.awt.Color color23 = java.awt.Color.pink;
        java.lang.String str24 = color23.toString();
        java.awt.Color color25 = color23.darker();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke26);
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color23.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        piePlot3D12.setShadowPaint((java.awt.Paint) color23);
        lineRenderer3D0.setBaseOutlinePaint((java.awt.Paint) color23);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = lineRenderer3D0.getSeriesToolTipGenerator((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 68 + "'", int16 == 68);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertNull(pieToolTipGenerator21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str24.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paintContext33);
        org.junit.Assert.assertNull(categoryToolTipGenerator37);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getBaseSectionOutlinePaint();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getMiddleMillisecond();
        long long6 = year4.getMiddleMillisecond();
        java.lang.Object obj7 = null;
        int int8 = year4.compareTo(obj7);
        int int9 = year4.getYear();
        java.awt.Paint paint10 = null;
        piePlot3D0.setSectionOutlinePaint((java.lang.Comparable) year4, paint10);
        java.awt.Paint paint13 = piePlot3D0.getSectionPaint((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        java.util.List list6 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (java.lang.Comparable) true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 455057983088L, (double) 9, rectangleAnchor3);
        size2D0.height = 90.0d;
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        java.lang.Object obj2 = polarPlot0.clone();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D3 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D3.setDrawOutlines(true);
        lineRenderer3D3.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = null;
        lineRenderer3D3.setLegendItemURLGenerator(categorySeriesLabelGenerator9);
        boolean boolean13 = lineRenderer3D3.getItemShapeVisible(2, (int) '#');
        java.awt.Paint paint16 = lineRenderer3D3.getItemPaint(6, 0);
        polarPlot0.setRadiusGridlinePaint(paint16);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration2 = dataPackageResources0.getKeys();
        try {
            java.lang.String[] strArray4 = dataPackageResources0.getStringArray("({0}, {1}) = {2}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key ({0}, {1}) = {2}");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis11.setTickMarkPaint(paint12);
        int int14 = numberTickUnit9.compareTo((java.lang.Object) categoryAxis11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
        categoryAxis11.setCategoryLabelPositions(categoryLabelPositions16);
        boolean boolean18 = categoryAxis11.isTickMarksVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Color color0 = java.awt.Color.pink;
        java.lang.String str1 = color0.toString();
        java.awt.Color color2 = color0.darker();
        java.awt.Color color3 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double3 = rectangleInsets1.calculateTopOutset(2.0d);
        double double5 = rectangleInsets1.calculateLeftOutset((double) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition8.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str11 = textAnchor10.toString();
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor9, textAnchor10, 1.0d);
        boolean boolean14 = rectangleInsets1.equals((java.lang.Object) textAnchor10);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str11.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
//        java.awt.geom.Point2D point2D8 = null;
//        categoryPlot5.zoomRangeAxes((double) (-1), plotRenderingInfo7, point2D8);
//        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot5.setRangeAxisLocation((int) ' ', axisLocation11, false);
//        float float14 = categoryPlot5.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer16 = null;
//        java.util.Collection collection17 = categoryPlot5.getRangeMarkers((int) (byte) 0, layer16);
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot5.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D19.setDrawOutlines(true);
//        boolean boolean22 = lineRenderer3D19.getBaseShapesVisible();
//        java.awt.Font font24 = lineRenderer3D19.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
//        lineRenderer3D19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator26, false);
//        boolean boolean29 = rectangleEdge18.equals((java.lang.Object) categoryItemLabelGenerator26);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long31 = segmentedTimeline30.getSegmentSize();
//        long long33 = segmentedTimeline30.toTimelineValue((long) (short) 0);
//        long long36 = segmentedTimeline30.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean37 = rectangleEdge18.equals((java.lang.Object) segmentedTimeline30);
//        org.jfree.data.KeyedObjects2D keyedObjects2D38 = new org.jfree.data.KeyedObjects2D();
//        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date41, date42);
//        keyedObjects2D38.addObject((java.lang.Object) paint39, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date41);
//        long long45 = segmentedTimeline30.toTimelineValue(date41);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline49 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
//        boolean boolean51 = segmentedTimeline49.containsDomainValue(1562097599999L);
//        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean53 = segmentedTimeline49.containsDomainValue(date52);
//        org.jfree.data.gantt.Task task54 = new org.jfree.data.gantt.Task("ThreadContext", date41, date52);
//        task54.setPercentComplete((java.lang.Double) 20.0d);
//        boolean boolean58 = task54.equals((java.lang.Object) 68);
//        org.junit.Assert.assertNotNull(axisLocation11);
//        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
//        org.junit.Assert.assertNull(collection17);
//        org.junit.Assert.assertNotNull(rectangleEdge18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(font24);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 900000L + "'", long31 == 900000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-32400010L) + "'", long33 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 455057983088L + "'", long45 == 455057983088L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis1.setTickMarkPaint(paint2);
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes((double) (-1), plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot20.setRangeAxisLocation((int) ' ', axisLocation26, false);
        categoryPlot20.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot20.setDomainAxisLocation((int) (byte) 100, axisLocation31, false);
        categoryPlot4.setDomainAxisLocation(axisLocation31, true);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.awt.Color color0 = java.awt.Color.pink;
        java.lang.String str1 = color0.toString();
        java.awt.Color color2 = color0.darker();
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.ui.ProjectInfo projectInfo4 = new org.jfree.chart.ui.ProjectInfo();
        boolean boolean5 = blockBorder3.equals((java.lang.Object) projectInfo4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder3.getInsets();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str1.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) 0.0d, (double) (byte) 100, 5);
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        categoryPlot4.setBackgroundAlpha((float) 6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent9);
        categoryPlot4.clearDomainAxes();
        categoryPlot4.clearRangeAxes();
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Font font3 = lineRenderer3D0.getItemLabelFont((int) (byte) 10, 6);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        lineRenderer3D0.setBaseToolTipGenerator(categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        java.lang.String str4 = piePlot3D0.getPlotType();
        double double5 = piePlot3D0.getLabelLinkMargin();
        double double6 = piePlot3D0.getDepthFactor();
        double double7 = piePlot3D0.getLabelGap();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) year1, (java.lang.Comparable) 68);
        java.util.Date date4 = year1.getStart();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D8 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 1L, 0.0d, true);
        double double9 = stackedBarRenderer3D8.getUpperClip();
        int int10 = year1.compareTo((java.lang.Object) double9);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        categoryAxis3.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        flowArrangement0.add(block1, (java.lang.Object) categoryAxis3);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer();
        java.util.List list12 = blockContainer11.getBlocks();
        java.awt.Shape shape17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape17, stroke18, (java.awt.Paint) color19);
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer11, (java.lang.Object) "");
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D24 = labelBlock23.getBounds();
        blockContainer11.setBounds(rectangle2D24);
        java.lang.Object obj26 = blockContainer11.clone();
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        stackedAreaRenderer1.setBaseShape(shape18, false);
        java.awt.Paint paint25 = stackedAreaRenderer1.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays(68, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(4, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = serialDate5.getNearestDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation31 = null;
        try {
            boolean boolean32 = xYPlot30.removeAnnotation(xYAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D7.setLabelFont(font8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis3D7.getStandardTickUnits();
        numberAxis3D7.centerRange((double) (short) 0);
        numberAxis3D7.setAutoRangeStickyZero(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font21 = categoryAxis19.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer17.setBaseItemLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font21);
        numberAxis3D7.setLabelFont(font21);
        boolean boolean25 = taskSeriesCollection0.equals((java.lang.Object) numberAxis3D7);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(range27);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
        java.awt.Paint paint3 = stackedBarRenderer3D1.getSeriesOutlinePaint(255);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = categoryLabelPosition2.getWidthType();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        boolean boolean5 = categoryLabelWidthType3.equals((java.lang.Object) color4);
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType3, (float) (-36L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        segmentedTimeline0.addException(date1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font6 = categoryAxis4.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer2.setBaseItemLabelFont(font6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            textLine8.draw(graphics2D9, (float) 10, 0.0f, textAnchor12, 0.0f, (float) 3, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = polarPlot0.getLegendItems();
        int int2 = legendItemCollection1.getItemCount();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        xYPlot30.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) xYPlot30);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
        java.awt.Font font4 = labelBlock2.getFont();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("CategoryAnchor.MIDDLE", font4);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) (byte) 10);
        java.util.List list3 = keyedObjects0.getKeys();
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3D4.getStandardTickUnits();
        numberAxis3D4.centerRange((double) (short) 0);
        numberAxis3D4.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D18.setLabelFont(font19);
        java.awt.Color color22 = java.awt.Color.pink;
        java.lang.String str23 = color22.toString();
        java.awt.Color color24 = color22.darker();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke25);
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color22.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font19, (java.awt.Paint) color22);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D4, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font19);
        numberAxis3D4.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font40 = categoryAxis38.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D4.setLabelFont(font40);
        numberAxis3D4.resizeRange((double) (byte) 10, 0.0d);
        org.jfree.chart.util.UnitType unitType45 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets(unitType45, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double52 = rectangleInsets50.calculateRightOutset((double) (-1));
        numberAxis3D4.setLabelInsets(rectangleInsets50);
        blockContainer0.setPadding(rectangleInsets50);
        java.util.List list55 = blockContainer0.getBlocks();
        java.lang.Object obj56 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str23.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(obj56);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int3 = java.awt.Color.HSBtoRGB((float) 2958465, (float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        java.util.List list8 = defaultCategoryDataset0.getColumnKeys();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.chart.axis.TickUnitSource tickUnitSource13 = numberAxis3D10.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis3D10.java2DToValue((double) 0, rectangle2D15, rectangleEdge16);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = numberAxis3D10.getTickUnit();
        boolean boolean19 = numberAxis3D10.isTickLabelsVisible();
        numberAxis3D10.setFixedAutoRange((double) (short) 1);
        boolean boolean22 = defaultCategoryDataset0.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(tickUnitSource13);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart10.removeProgressListener(chartProgressListener27);
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        jFreeChart10.handleClick((int) 'a', (int) '4', chartRenderingInfo32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo32);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        try {
            numberAxis3D1.setRangeWithMargins((double) 6, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        java.awt.Font font12 = stackedAreaRenderer1.getBaseItemLabelFont();
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color5 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean6 = stackedBarRenderer3D2.equals((java.lang.Object) 0);
        stackedBarRenderer3D2.setItemMargin((double) 'a');
        stackedBarRenderer3D2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) false, false);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        stackedBarRenderer3D2.setBaseStroke(stroke13);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = categoryPlot4.getDataRange(valueAxis7);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = java.awt.Color.getColor("({0}, {1}) = {2}", color1);
        float[] floatArray4 = new float[] {};
        try {
            float[] floatArray5 = color1.getRGBColorComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 255);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font17 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer13.setBaseItemLabelFont(font17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedAreaRenderer13.getURLGenerator(0, 3);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer13.setBaseStroke(stroke26);
        categoryAxis5.setTickMarkStroke(stroke26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D31.setLabelFont(font32);
        java.awt.Color color35 = java.awt.Color.pink;
        java.lang.String str36 = color35.toString();
        java.awt.Color color37 = color35.darker();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color35, stroke38);
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color35.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font32, (java.awt.Paint) color35);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        boolean boolean49 = textBlock46.equals((java.lang.Object) numberAxis48);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer51 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font55 = categoryAxis53.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer51.setBaseItemLabelFont(font55);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator59 = stackedAreaRenderer51.getURLGenerator(0, 3);
        stackedAreaRenderer51.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape68, stroke69, (java.awt.Paint) color70);
        stackedAreaRenderer51.setBaseShape(shape68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer51);
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot74.getRangeAxisForDataset((int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset78 = categoryPlot74.getDataset((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str36.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(categoryURLGenerator59);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(valueAxis76);
        org.junit.Assert.assertNull(categoryDataset78);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = java.awt.Color.black;
        piePlot3D0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.util.Rotation rotation3 = null;
        try {
            piePlot3D0.setDirection(rotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer3 = null;
        waferMapPlot2.setRenderer(waferMapRenderer3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        java.awt.Stroke stroke7 = null;
        categoryPlot6.setOutlineStroke(stroke7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot6.getRangeAxisForDataset((int) ' ');
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot6);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true, true);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        stackedAreaRenderer1.setBaseShape(shape16, true);
        java.awt.Shape shape20 = stackedAreaRenderer1.getSeriesShape((int) (short) 0);
        boolean boolean21 = stackedAreaRenderer1.getAutoPopulateSeriesShape();
        stackedAreaRenderer1.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart27.setBackgroundPaint((java.awt.Paint) color30);
        java.lang.Object obj32 = jFreeChart27.clone();
        try {
            java.awt.image.BufferedImage bufferedImage35 = jFreeChart27.createBufferedImage((int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        xYPlot30.setRangeCrosshairValue((double) (byte) 10, true);
        xYPlot30.clearRangeMarkers((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D1.setLabelFont(font2);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
//        java.awt.geom.Rectangle2D rectangle2D6 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
//        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        java.awt.Paint paint12 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
//        categoryAxis11.setTickMarkPaint(paint12);
//        int int14 = numberTickUnit9.compareTo((java.lang.Object) categoryAxis11);
//        org.jfree.chart.entity.EntityCollection entityCollection15 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo(entityCollection15);
//        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D20 = labelBlock19.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
//        java.awt.geom.Point2D point2D28 = null;
//        categoryPlot25.zoomRangeAxes((double) (-1), plotRenderingInfo27, point2D28);
//        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot25.setRangeAxisLocation((int) ' ', axisLocation31, false);
//        float float34 = categoryPlot25.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer36 = null;
//        java.util.Collection collection37 = categoryPlot25.getRangeMarkers((int) (byte) 0, layer36);
//        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot25.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D39 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D39.setDrawOutlines(true);
//        boolean boolean42 = lineRenderer3D39.getBaseShapesVisible();
//        java.awt.Font font44 = lineRenderer3D39.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
//        lineRenderer3D39.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator46, false);
//        boolean boolean49 = rectangleEdge38.equals((java.lang.Object) categoryItemLabelGenerator46);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline50 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long51 = segmentedTimeline50.getSegmentSize();
//        long long53 = segmentedTimeline50.toTimelineValue((long) (short) 0);
//        long long56 = segmentedTimeline50.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean57 = rectangleEdge38.equals((java.lang.Object) segmentedTimeline50);
//        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge38);
//        java.awt.geom.Rectangle2D rectangle2D59 = axisSpace17.reserved(rectangle2D20, rectangleEdge38);
//        chartRenderingInfo16.setChartArea(rectangle2D59);
//        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity63 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis11, (java.awt.Shape) rectangle2D59, "{0}", "Pie 3D Plot");
//        org.jfree.chart.axis.Axis axis64 = axisLabelEntity63.getAxis();
//        java.lang.String str65 = axisLabelEntity63.getShapeCoords();
//        org.junit.Assert.assertNotNull(font2);
//        org.junit.Assert.assertNotNull(tickUnitSource4);
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(numberTickUnit9);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(rectangle2D20);
//        org.junit.Assert.assertNotNull(axisLocation31);
//        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
//        org.junit.Assert.assertNull(collection37);
//        org.junit.Assert.assertNotNull(rectangleEdge38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNull(font44);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline50);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 900000L + "'", long51 == 900000L);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-32400010L) + "'", long53 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge58);
//        org.junit.Assert.assertNotNull(rectangle2D59);
//        org.junit.Assert.assertNull(axis64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "0,0,1,1" + "'", str65.equals("0,0,1,1"));
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        java.util.List list6 = taskSeriesCollection0.getRowKeys();
        try {
            java.lang.Comparable comparable8 = taskSeriesCollection0.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.lang.String str8 = legendItem7.getDescription();
        java.awt.Stroke stroke9 = legendItem7.getLineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = legendItem7.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str8.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        java.lang.Object obj10 = defaultCategoryDataset0.clone();
        java.lang.Object obj11 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
//        boolean boolean5 = segmentedTimeline3.containsDomainValue(1562097599999L);
//        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
//        java.awt.geom.Point2D point2D13 = null;
//        categoryPlot10.zoomRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
//        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot10.setRangeAxisLocation((int) ' ', axisLocation16, false);
//        float float19 = categoryPlot10.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer21 = null;
//        java.util.Collection collection22 = categoryPlot10.getRangeMarkers((int) (byte) 0, layer21);
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot10.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D24 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D24.setDrawOutlines(true);
//        boolean boolean27 = lineRenderer3D24.getBaseShapesVisible();
//        java.awt.Font font29 = lineRenderer3D24.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = null;
//        lineRenderer3D24.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator31, false);
//        boolean boolean34 = rectangleEdge23.equals((java.lang.Object) categoryItemLabelGenerator31);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline35 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long36 = segmentedTimeline35.getSegmentSize();
//        long long38 = segmentedTimeline35.toTimelineValue((long) (short) 0);
//        long long41 = segmentedTimeline35.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean42 = rectangleEdge23.equals((java.lang.Object) segmentedTimeline35);
//        org.jfree.data.KeyedObjects2D keyedObjects2D43 = new org.jfree.data.KeyedObjects2D();
//        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date46, date47);
//        keyedObjects2D43.addObject((java.lang.Object) paint44, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date46);
//        long long50 = segmentedTimeline35.toTimelineValue(date46);
//        segmentedTimeline3.addException(date46);
//        int int52 = segmentedTimeline3.getSegmentsIncluded();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(axisLocation16);
//        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
//        org.junit.Assert.assertNull(collection22);
//        org.junit.Assert.assertNotNull(rectangleEdge23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(font29);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 900000L + "'", long36 == 900000L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-32400010L) + "'", long38 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(paint44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 455057983088L + "'", long50 == 455057983088L);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, (int) (short) 0, 6);
        java.util.Date date5 = segmentedTimeline3.getDate((long) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = segmentedTimeline3.getBaseTimeline();
        try {
            org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = segmentedTimeline6.getBaseTimeline();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(segmentedTimeline6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape12, stroke13, (java.awt.Paint) color14);
        boolean boolean16 = legendItem7.equals((java.lang.Object) legendItem15);
        java.awt.Paint paint17 = legendItem7.getLinePaint();
        org.jfree.data.general.Dataset dataset18 = legendItem7.getDataset();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(dataset18);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        jFreeChart3.setBackgroundImageAlpha((float) 100);
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot9.getRenderer();
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot9);
        org.jfree.chart.block.BlockContainer blockContainer16 = new org.jfree.chart.block.BlockContainer();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = categoryPlot21.getOrientation();
        boolean boolean25 = blockContainer16.equals((java.lang.Object) plotOrientation24);
        categoryPlot9.setOrientation(plotOrientation24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.05d, (double) '#');
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineRenderer3D0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator7, false);
        lineRenderer3D0.setBaseShapesVisible(false);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean13 = piePlot3D12.getIgnoreNullValues();
        boolean boolean14 = piePlot3D12.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int16 = segmentedTimeline15.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline15.getSegment(10L);
        piePlot3D12.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator21 = piePlot3D12.getToolTipGenerator();
        java.awt.Color color23 = java.awt.Color.pink;
        java.lang.String str24 = color23.toString();
        java.awt.Color color25 = color23.darker();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke26);
        java.awt.image.ColorModel colorModel28 = null;
        java.awt.Rectangle rectangle29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.awt.geom.AffineTransform affineTransform31 = null;
        java.awt.RenderingHints renderingHints32 = null;
        java.awt.PaintContext paintContext33 = color23.createContext(colorModel28, rectangle29, rectangle2D30, affineTransform31, renderingHints32);
        piePlot3D12.setShadowPaint((java.awt.Paint) color23);
        lineRenderer3D0.setBaseOutlinePaint((java.awt.Paint) color23);
        lineRenderer3D0.setUseOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 68 + "'", int16 == 68);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertNull(pieToolTipGenerator21);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str24.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paintContext33);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer21);
        java.awt.Color color24 = java.awt.Color.pink;
        java.lang.String str25 = color24.toString();
        java.awt.Color color26 = color24.darker();
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Color color29 = java.awt.Color.pink;
        java.lang.String str30 = color29.toString();
        java.awt.Color color31 = color29.darker();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke32);
        valueMarker33.setAlpha((float) 0L);
        java.awt.Stroke stroke36 = valueMarker33.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color24, stroke36);
        categoryPlot17.addDomainMarker(categoryMarker37);
        categoryPlot4.addDomainMarker(categoryMarker37);
        categoryMarker37.setDrawAsLine(false);
        boolean boolean42 = categoryMarker37.getDrawAsLine();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str25.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str30.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        piePlot3D0.setLabelLinksVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        piePlot3D0.setShadowYOffset((double) 1.0f);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D7 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D7.setDrawOutlines(true);
        lineRenderer3D7.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = null;
        lineRenderer3D7.setLegendItemURLGenerator(categorySeriesLabelGenerator13);
        boolean boolean17 = lineRenderer3D7.getItemShapeVisible(2, (int) '#');
        java.awt.Paint paint20 = lineRenderer3D7.getItemPaint(6, 0);
        piePlot3D0.setBaseSectionPaint(paint20);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D15 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D15.setLabelFont(font16);
        java.awt.Color color19 = java.awt.Color.pink;
        java.lang.String str20 = color19.toString();
        java.awt.Color color21 = color19.darker();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke22);
        java.awt.image.ColorModel colorModel24 = null;
        java.awt.Rectangle rectangle25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        java.awt.geom.AffineTransform affineTransform27 = null;
        java.awt.RenderingHints renderingHints28 = null;
        java.awt.PaintContext paintContext29 = color19.createContext(colorModel24, rectangle25, rectangle2D26, affineTransform27, renderingHints28);
        org.jfree.chart.text.TextBlock textBlock30 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font16, (java.awt.Paint) color19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D1, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font16);
        java.awt.Graphics2D graphics2D32 = null;
        double double33 = markerAxisBand31.getHeight(graphics2D32);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 0, (double) (short) 10);
        double double37 = intervalMarker36.getEndValue();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer38 = intervalMarker36.getGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = null;
        intervalMarker36.setGradientPaintTransformer(gradientPaintTransformer39);
        markerAxisBand31.addMarker(intervalMarker36);
        java.lang.Object obj42 = intervalMarker36.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str20.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paintContext29);
        org.junit.Assert.assertNotNull(textBlock30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertNull(gradientPaintTransformer38);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D8.setLabelFont(font9);
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = numberAxis3D8.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis3D8.java2DToValue((double) 0, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis3D8.getTickUnit();
        boolean boolean17 = numberAxis3D8.isTickLabelsVisible();
        numberAxis3D8.setUpperMargin((double) (short) 1);
        numberAxis3D8.setPositiveArrowVisible(true);
        org.jfree.data.Range range22 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot4.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.LegendItem legendItem8 = lineRenderer3D0.getLegendItem((int) ' ', 100);
        java.awt.Stroke stroke10 = lineRenderer3D0.lookupSeriesStroke(10);
        try {
            lineRenderer3D0.setSeriesVisible((-16777216), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getMiddleMillisecond();
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        int int5 = year0.getYear();
        long long6 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        java.awt.Color color14 = java.awt.Color.pink;
        java.lang.String str15 = color14.toString();
        java.awt.Color color16 = color14.darker();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke17);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color14.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font11, (java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        java.awt.Stroke stroke31 = null;
        categoryPlot30.setOutlineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font11, (org.jfree.chart.plot.Plot) categoryPlot30, false);
        jFreeChart34.setBackgroundImageAlignment(100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D1, jFreeChart34);
        java.awt.Font font38 = numberAxis3D1.getLabelFont();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str15.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        java.awt.Color color27 = java.awt.Color.GRAY;
        jFreeChart10.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.title.Title title29 = null;
        try {
            jFreeChart10.addSubtitle(title29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color2 = color1.darker();
        boolean boolean3 = sortOrder0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 0, (double) (short) 10);
//        double double3 = intervalMarker2.getEndValue();
//        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
//        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
//        java.awt.geom.Point2D point2D17 = null;
//        categoryPlot14.zoomRangeAxes((double) (-1), plotRenderingInfo16, point2D17);
//        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot14.setRangeAxisLocation((int) ' ', axisLocation20, false);
//        float float23 = categoryPlot14.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer25 = null;
//        java.util.Collection collection26 = categoryPlot14.getRangeMarkers((int) (byte) 0, layer25);
//        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D28 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D28.setDrawOutlines(true);
//        boolean boolean31 = lineRenderer3D28.getBaseShapesVisible();
//        java.awt.Font font33 = lineRenderer3D28.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = null;
//        lineRenderer3D28.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator35, false);
//        boolean boolean38 = rectangleEdge27.equals((java.lang.Object) categoryItemLabelGenerator35);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline39 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long40 = segmentedTimeline39.getSegmentSize();
//        long long42 = segmentedTimeline39.toTimelineValue((long) (short) 0);
//        long long45 = segmentedTimeline39.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean46 = rectangleEdge27.equals((java.lang.Object) segmentedTimeline39);
//        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
//        java.awt.geom.Rectangle2D rectangle2D48 = axisSpace6.reserved(rectangle2D9, rectangleEdge27);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP;
//        java.lang.Object obj50 = null;
//        boolean boolean51 = rectangleAnchor49.equals(obj50);
//        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D9, rectangleAnchor49, 0.0d, (double) (short) 1);
//        boolean boolean55 = intervalMarker2.equals((java.lang.Object) rectangle2D9);
//        intervalMarker2.setEndValue((double) (-2208960000000L));
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
//        org.junit.Assert.assertNull(gradientPaintTransformer4);
//        org.junit.Assert.assertNotNull(rectangle2D9);
//        org.junit.Assert.assertNotNull(axisLocation20);
//        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
//        org.junit.Assert.assertNull(collection26);
//        org.junit.Assert.assertNotNull(rectangleEdge27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(font33);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 900000L + "'", long40 == 900000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-32400010L) + "'", long42 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge47);
//        org.junit.Assert.assertNotNull(rectangle2D48);
//        org.junit.Assert.assertNotNull(rectangleAnchor49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(shape54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        boolean boolean2 = strokeList0.equals((java.lang.Object) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays(68, serialDate3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate4);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.text.NumberFormat numberFormat5 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-16777216));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.LegendItem legendItem8 = lineRenderer3D0.getLegendItem((int) ' ', 100);
        boolean boolean9 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean10 = lineRenderer3D0.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        boolean boolean2 = tickUnits0.equals((java.lang.Object) 10.0f);
        try {
            org.jfree.chart.axis.TickUnit tickUnit4 = tickUnits0.get((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 255);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Comparable comparable5 = taskSeriesCollection0.getColumnKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = java.awt.Color.black;
        piePlot3D0.setLabelPaint((java.awt.Paint) color1);
        piePlot3D0.setPieIndex(68);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot30.getRenderer();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = xYPlot30.getRenderer(255);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        categoryPlot39.addChangeListener(plotChangeListener40);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot39.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer43);
        java.awt.Color color46 = java.awt.Color.pink;
        java.lang.String str47 = color46.toString();
        java.awt.Color color48 = color46.darker();
        org.jfree.chart.block.BlockBorder blockBorder49 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color46);
        java.awt.Color color51 = java.awt.Color.pink;
        java.lang.String str52 = color51.toString();
        java.awt.Color color53 = color51.darker();
        java.awt.Stroke stroke54 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color51, stroke54);
        valueMarker55.setAlpha((float) 0L);
        java.awt.Stroke stroke58 = valueMarker55.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker59 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color46, stroke58);
        categoryPlot39.addDomainMarker(categoryMarker59);
        org.jfree.chart.util.Layer layer61 = null;
        try {
            xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker59, layer61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNull(xYItemRenderer34);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str47.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str52.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(9, (int) (short) 100, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo1);
        java.lang.Object obj3 = plotRenderingInfo2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.Font font3 = textFragment2.getFont();
        java.awt.Paint paint4 = textFragment2.getPaint();
        java.awt.Font font5 = textFragment2.getFont();
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font5);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer18);
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        java.awt.Paint paint21 = categoryPlot14.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder22 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot14.setColumnRenderingOrder(sortOrder22);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(sortOrder22);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        boolean boolean9 = numberAxis3D1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = null;
        numberAxis3D1.setMarkerBand(markerAxisBand10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        boolean boolean2 = tickUnits0.equals((java.lang.Object) 10.0f);
        try {
            org.jfree.chart.axis.TickUnit tickUnit4 = tickUnits0.get(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        lineRenderer3D0.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator7, false);
        lineRenderer3D0.setBaseShapesVisible(false);
        boolean boolean13 = lineRenderer3D0.isSeriesVisibleInLegend(0);
        boolean boolean15 = lineRenderer3D0.equals((java.lang.Object) "0,0,1,1");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Paint paint4 = piePlot3D0.getLabelOutlinePaint();
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator7 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str22 = textAnchor21.toString();
        org.jfree.chart.axis.NumberTick numberTick24 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor20, textAnchor21, 1.0d);
        valueMarker16.setLabelTextAnchor(textAnchor21);
        boolean boolean26 = jFreeChart10.equals((java.lang.Object) valueMarker16);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart10.removeProgressListener(chartProgressListener27);
        try {
            org.jfree.chart.title.Title title30 = jFreeChart10.getSubtitle(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str22.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) year1, (java.lang.Comparable) 68);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(68, serialDate6);
        java.lang.String str8 = serialDate7.getDescription();
        java.lang.Number number10 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) str8, (java.lang.Comparable) 2.0d);
        try {
            java.lang.Number number13 = defaultStatisticalCategoryDataset0.getValue((int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation10, false);
        categoryPlot4.clearDomainMarkers();
        java.util.List list14 = categoryPlot4.getCategories();
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNull(list14);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Color color12 = java.awt.Color.pink;
        java.lang.String str13 = color12.toString();
        java.awt.Color color14 = color12.darker();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot4.setInsets(rectangleInsets16);
        double double18 = rectangleInsets16.getRight();
        double double20 = rectangleInsets16.calculateTopInset(4.0d);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str13.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot4.getFixedRangeAxisSpace();
        int int14 = categoryPlot4.getWeight();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int3 = java.awt.Color.HSBtoRGB((float) 455057983088L, (float) '4', 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D1);
        numberAxis3D1.setLabelURL("");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
        java.awt.Paint paint3 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color5 = java.awt.Color.black;
        piePlot3D4.setLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = piePlot3D4.getLegendItems();
        boolean boolean8 = piePlot3D4.getLabelLinksVisible();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) piePlot3D4);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer6.setBaseItemLabelFont(font10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = stackedAreaRenderer6.getURLGenerator(0, 3);
        java.awt.Paint paint16 = stackedAreaRenderer6.lookupSeriesPaint((int) (short) 1);
        piePlot3D0.setLabelPaint(paint16);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape22, stroke23, (java.awt.Paint) color24);
        piePlot3D0.setBaseSectionOutlineStroke(stroke23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D28.setLabelFont(font29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis33, categoryItemRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray37 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis36 };
        categoryPlot35.setDomainAxes(categoryAxisArray37);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent39 = null;
        categoryPlot35.datasetChanged(datasetChangeEvent39);
        numberAxis3D28.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = numberAxis3D28.valueToJava2D(1.0E-8d, rectangle2D43, rectangleEdge44);
        java.awt.Stroke stroke46 = numberAxis3D28.getAxisLineStroke();
        piePlot3D0.setOutlineStroke(stroke46);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(categoryAxisArray37);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(stroke46);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection6 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo(entityCollection6);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
//        java.awt.geom.Point2D point2D9 = null;
//        polarPlot4.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo8, point2D9);
//        org.jfree.chart.axis.AxisSpace axisSpace11 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D14 = labelBlock13.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
//        java.awt.geom.Point2D point2D22 = null;
//        categoryPlot19.zoomRangeAxes((double) (-1), plotRenderingInfo21, point2D22);
//        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot19.setRangeAxisLocation((int) ' ', axisLocation25, false);
//        float float28 = categoryPlot19.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer30 = null;
//        java.util.Collection collection31 = categoryPlot19.getRangeMarkers((int) (byte) 0, layer30);
//        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot19.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D33 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D33.setDrawOutlines(true);
//        boolean boolean36 = lineRenderer3D33.getBaseShapesVisible();
//        java.awt.Font font38 = lineRenderer3D33.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator40 = null;
//        lineRenderer3D33.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator40, false);
//        boolean boolean43 = rectangleEdge32.equals((java.lang.Object) categoryItemLabelGenerator40);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline44 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long45 = segmentedTimeline44.getSegmentSize();
//        long long47 = segmentedTimeline44.toTimelineValue((long) (short) 0);
//        long long50 = segmentedTimeline44.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean51 = rectangleEdge32.equals((java.lang.Object) segmentedTimeline44);
//        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge32);
//        java.awt.geom.Rectangle2D rectangle2D53 = axisSpace11.reserved(rectangle2D14, rectangleEdge32);
//        plotRenderingInfo8.setDataArea(rectangle2D53);
//        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection57 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo(entityCollection57);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
//        java.awt.geom.Point2D point2D60 = null;
//        polarPlot55.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo59, point2D60);
//        java.awt.Paint paint62 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
//        polarPlot55.setNoDataMessagePaint(paint62);
//        java.awt.Stroke stroke64 = null;
//        org.jfree.chart.plot.PolarPlot polarPlot65 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection67 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = new org.jfree.chart.ChartRenderingInfo(entityCollection67);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo68);
//        java.awt.geom.Point2D point2D70 = null;
//        polarPlot65.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo69, point2D70);
//        java.awt.Paint paint72 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
//        polarPlot65.setNoDataMessagePaint(paint72);
//        try {
//            org.jfree.chart.LegendItem legendItem74 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=175,b=175]", "ERROR : Relative To String", "Pie 3D Plot", "DateTickMarkPosition.MIDDLE", (java.awt.Shape) rectangle2D53, paint62, stroke64, paint72);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlineStroke' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(rectangle2D14);
//        org.junit.Assert.assertNotNull(axisLocation25);
//        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
//        org.junit.Assert.assertNull(collection31);
//        org.junit.Assert.assertNotNull(rectangleEdge32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNull(font38);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 900000L + "'", long45 == 900000L);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-32400010L) + "'", long47 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge52);
//        org.junit.Assert.assertNotNull(rectangle2D53);
//        org.junit.Assert.assertNotNull(paint62);
//        org.junit.Assert.assertNotNull(paint72);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.configure();
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer21);
        java.awt.Color color24 = java.awt.Color.pink;
        java.lang.String str25 = color24.toString();
        java.awt.Color color26 = color24.darker();
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color24);
        java.awt.Color color29 = java.awt.Color.pink;
        java.lang.String str30 = color29.toString();
        java.awt.Color color31 = color29.darker();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke32);
        valueMarker33.setAlpha((float) 0L);
        java.awt.Stroke stroke36 = valueMarker33.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color24, stroke36);
        categoryPlot17.addDomainMarker(categoryMarker37);
        categoryPlot4.addDomainMarker(categoryMarker37);
        java.awt.Paint paint40 = categoryMarker37.getLabelPaint();
        java.lang.Object obj41 = categoryMarker37.clone();
        java.lang.Object obj42 = categoryMarker37.clone();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str25.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str30.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        lineRenderer3D0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        java.awt.Stroke stroke12 = null;
        categoryPlot11.setOutlineStroke(stroke12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot11.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getRangeAxisEdge(0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot11.setOutlineStroke(stroke18);
        lineRenderer3D0.setSeriesOutlineStroke(3, stroke18, false);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes((double) (-1), plotRenderingInfo28, point2D29);
        float float31 = categoryPlot26.getForegroundAlpha();
        lineRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot26);
        lineRenderer3D0.setBaseShapesFilled(true);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        jFreeChart3.setBackgroundImageAlignment((-459));
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        float float7 = categoryPlot4.getForegroundAlpha();
        double double8 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (byte) -1, (double) 100L, true);
        java.awt.Font font4 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        stackedBarRenderer3D3.setBaseItemLabelFont(font4);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot30.getRenderer();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = xYPlot30.getRenderer(255);
        xYPlot30.setDomainZeroBaselineVisible(false);
        xYPlot30.setDomainCrosshairValue((double) 0L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNull(xYItemRenderer34);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        ganttRenderer0.setEndPercent((double) 455057983088L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D4 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D4.setDrawOutlines(true);
        java.awt.Color color8 = java.awt.Color.pink;
        java.lang.String str9 = color8.toString();
        java.awt.Color color10 = color8.darker();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke11);
        lineRenderer3D4.setBaseOutlineStroke(stroke11, true);
        org.jfree.chart.LegendItem legendItem17 = lineRenderer3D4.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition19.getRotationAnchor();
        lineRenderer3D4.setSeriesNegativeItemLabelPosition(10, itemLabelPosition19, false);
        boolean boolean25 = lineRenderer3D4.getItemShapeVisible(100, (int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint28 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis27.setTickMarkPaint(paint28);
        lineRenderer3D4.setBaseOutlinePaint(paint28);
        lineRenderer3D0.setBasePaint(paint28, true);
        boolean boolean33 = lineRenderer3D0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str9.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(legendItem17);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.data.general.Dataset dataset9 = legendItemEntity8.getDataset();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(dataset9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.KeyedObjects2D keyedObjects2D2 = new org.jfree.data.KeyedObjects2D();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod(date5, date6);
        keyedObjects2D2.addObject((java.lang.Object) paint3, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date5);
        keyedObjects2D2.removeObject((java.lang.Comparable) 4, (java.lang.Comparable) 100.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D13.setLabelFont(font14);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = numberAxis3D13.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis3D13.java2DToValue((double) 0, rectangle2D18, rectangleEdge19);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis3D13.getTickUnit();
        int int22 = keyedObjects2D2.getRowIndex((java.lang.Comparable) numberTickUnit21);
        java.lang.Number number23 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) "java.awt.Color[r=255,g=175,b=175]", (java.lang.Comparable) int22);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(number23);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        size2D2.height = (byte) 1;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer6.setBaseItemLabelFont(font10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = stackedAreaRenderer6.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot18.setDomainAxes(categoryAxisArray20);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot18.datasetChanged(datasetChangeEvent22);
        categoryPlot18.setBackgroundAlpha((float) 0);
        java.awt.Color color26 = java.awt.Color.pink;
        java.lang.String str27 = color26.toString();
        java.awt.Color color28 = color26.darker();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color28);
        stackedAreaRenderer6.setSeriesFillPaint((int) (short) 0, (java.awt.Paint) color28, true);
        boolean boolean32 = size2D2.equals((java.lang.Object) stackedAreaRenderer6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator34 = stackedAreaRenderer6.getSeriesURLGenerator(1900);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str27.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryURLGenerator34);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long1 = segmentedTimeline0.getSegmentSize();
//        long long3 = segmentedTimeline0.toTimelineValue((long) (short) 0);
//        long long6 = segmentedTimeline0.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        long long9 = segmentedTimeline0.getExceptionSegmentCount((long) 1900, (long) 9);
//        boolean boolean10 = segmentedTimeline0.getAdjustForDaylightSaving();
//        segmentedTimeline0.addBaseTimelineException((long) 12);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 900000L + "'", long1 == 900000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-32400010L) + "'", long3 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        categoryPlot4.setBackgroundAlpha((float) 6);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot4.zoomDomainAxes((double) 3, plotRenderingInfo12, point2D13);
        categoryPlot4.mapDatasetToDomainAxis(12, 1900);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset1.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0f), (org.jfree.data.KeyedValues) pieDataset10);
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryAxis15.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        flowArrangement12.add(block13, (java.lang.Object) categoryAxis15);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection23 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int25 = taskSeriesCollection23.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection23, true);
        org.jfree.data.general.DatasetGroup datasetGroup28 = taskSeriesCollection23.getGroup();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D30.setLabelFont(font31);
        org.jfree.chart.axis.TickUnitSource tickUnitSource33 = numberAxis3D30.getStandardTickUnits();
        numberAxis3D30.centerRange((double) (short) 0);
        numberAxis3D30.setAutoRangeStickyZero(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer40 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font44 = categoryAxis42.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer40.setBaseItemLabelFont(font44);
        org.jfree.chart.text.TextLine textLine46 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font44);
        numberAxis3D30.setLabelFont(font44);
        boolean boolean48 = taskSeriesCollection23.equals((java.lang.Object) numberAxis3D30);
        java.lang.String str49 = numberAxis3D30.getLabelToolTip();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D50 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D50.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = lineRenderer3D50.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis3D30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineRenderer3D50);
        lineRenderer3D50.setBaseShapesFilled(false);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(datasetGroup28);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(tickUnitSource33);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(legendItemCollection53);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 255);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font17 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer13.setBaseItemLabelFont(font17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedAreaRenderer13.getURLGenerator(0, 3);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer13.setBaseStroke(stroke26);
        categoryAxis5.setTickMarkStroke(stroke26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D31.setLabelFont(font32);
        java.awt.Color color35 = java.awt.Color.pink;
        java.lang.String str36 = color35.toString();
        java.awt.Color color37 = color35.darker();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color35, stroke38);
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color35.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font32, (java.awt.Paint) color35);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        boolean boolean49 = textBlock46.equals((java.lang.Object) numberAxis48);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer51 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font55 = categoryAxis53.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer51.setBaseItemLabelFont(font55);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator59 = stackedAreaRenderer51.getURLGenerator(0, 3);
        stackedAreaRenderer51.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape68, stroke69, (java.awt.Paint) color70);
        stackedAreaRenderer51.setBaseShape(shape68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer51);
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot74.getRangeAxisForDataset((int) (byte) 10);
        categoryPlot74.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str36.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(categoryURLGenerator59);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(valueAxis76);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset2.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset2.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        java.util.List list10 = defaultCategoryDataset2.getColumnKeys();
        axisState1.setTicks(list10);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        try {
            java.lang.String str3 = dataPackageResources0.getString("DateTickMarkPosition.MIDDLE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key DateTickMarkPosition.MIDDLE");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass4 = stroke3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass4);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass9 = stroke8.getClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass9);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("({0}, {1}) = {2}", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass9);
        java.lang.Object obj13 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("AreaRendererEndType.TRUNCATE", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.setAutoTickUnitSelection(true, true);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color6);
        boolean boolean10 = dateAxis2.equals((java.lang.Object) color6);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
//        java.awt.geom.Point2D point2D7 = null;
//        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
//        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation10, false);
//        float float13 = categoryPlot4.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer15 = null;
//        java.util.Collection collection16 = categoryPlot4.getRangeMarkers((int) (byte) 0, layer15);
//        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot4.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D18 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D18.setDrawOutlines(true);
//        boolean boolean21 = lineRenderer3D18.getBaseShapesVisible();
//        java.awt.Font font23 = lineRenderer3D18.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
//        lineRenderer3D18.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator25, false);
//        boolean boolean28 = rectangleEdge17.equals((java.lang.Object) categoryItemLabelGenerator25);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long30 = segmentedTimeline29.getSegmentSize();
//        long long32 = segmentedTimeline29.toTimelineValue((long) (short) 0);
//        long long35 = segmentedTimeline29.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean36 = rectangleEdge17.equals((java.lang.Object) segmentedTimeline29);
//        segmentedTimeline29.setStartTime(1L);
//        org.junit.Assert.assertNotNull(axisLocation10);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
//        org.junit.Assert.assertNull(collection16);
//        org.junit.Assert.assertNotNull(rectangleEdge17);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(font23);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 900000L + "'", long30 == 900000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-32400010L) + "'", long32 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = polarPlot2.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = polarPlot2.getRenderer();
        java.awt.Paint paint5 = polarPlot2.getAngleLabelPaint();
        polarPlot2.clearCornerTextItems();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart("{0}", font1, (org.jfree.chart.plot.Plot) polarPlot2, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        polarPlot2.rendererChanged(rendererChangeEvent9);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNull(polarItemRenderer4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape12, stroke13, (java.awt.Paint) color14);
        boolean boolean16 = legendItem7.equals((java.lang.Object) legendItem15);
        java.awt.Paint paint17 = legendItem7.getLinePaint();
        java.awt.Paint paint18 = legendItem7.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis3D1.java2DToValue((double) 0, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = numberAxis3D1.getTickUnit();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint12 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis11.setTickMarkPaint(paint12);
        int int14 = numberTickUnit9.compareTo((java.lang.Object) categoryAxis11);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape19, stroke20, (java.awt.Paint) color21);
        java.lang.String str23 = legendItem22.getDescription();
        boolean boolean24 = legendItem22.isShapeFilled();
        int int25 = numberTickUnit9.compareTo((java.lang.Object) legendItem22);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str23.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
//        lineRenderer3D0.setBaseShapesFilled(false);
//        java.awt.Graphics2D graphics2D5 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
//        java.awt.Stroke stroke11 = null;
//        categoryPlot10.setOutlineStroke(stroke11);
//        java.awt.Font font13 = categoryPlot10.getNoDataMessageFont();
//        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot10.getFixedRangeAxisSpace();
//        categoryPlot10.mapDatasetToDomainAxis((int) (short) 0, (int) (byte) 100);
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D19.setLabelFont(font20);
//        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
//        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray28 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis27 };
//        categoryPlot26.setDomainAxes(categoryAxisArray28);
//        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
//        categoryPlot26.datasetChanged(datasetChangeEvent30);
//        numberAxis3D19.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
//        java.awt.Font font33 = numberAxis3D19.getLabelFont();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("");
//        java.awt.Font font36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
//        numberAxis3D35.setLabelFont(font36);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis3D35.getStandardTickUnits();
//        java.awt.geom.Rectangle2D rectangle2D40 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
//        double double42 = numberAxis3D35.java2DToValue((double) 0, rectangle2D40, rectangleEdge41);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit43 = numberAxis3D35.getTickUnit();
//        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//        java.awt.Paint paint46 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
//        categoryAxis45.setTickMarkPaint(paint46);
//        int int48 = numberTickUnit43.compareTo((java.lang.Object) categoryAxis45);
//        org.jfree.chart.entity.EntityCollection entityCollection49 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = new org.jfree.chart.ChartRenderingInfo(entityCollection49);
//        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock53 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D54 = labelBlock53.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, valueAxis57, categoryItemRenderer58);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
//        java.awt.geom.Point2D point2D62 = null;
//        categoryPlot59.zoomRangeAxes((double) (-1), plotRenderingInfo61, point2D62);
//        org.jfree.chart.axis.AxisLocation axisLocation65 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot59.setRangeAxisLocation((int) ' ', axisLocation65, false);
//        float float68 = categoryPlot59.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer70 = null;
//        java.util.Collection collection71 = categoryPlot59.getRangeMarkers((int) (byte) 0, layer70);
//        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot59.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D73 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D73.setDrawOutlines(true);
//        boolean boolean76 = lineRenderer3D73.getBaseShapesVisible();
//        java.awt.Font font78 = lineRenderer3D73.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator80 = null;
//        lineRenderer3D73.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator80, false);
//        boolean boolean83 = rectangleEdge72.equals((java.lang.Object) categoryItemLabelGenerator80);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline84 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long85 = segmentedTimeline84.getSegmentSize();
//        long long87 = segmentedTimeline84.toTimelineValue((long) (short) 0);
//        long long90 = segmentedTimeline84.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean91 = rectangleEdge72.equals((java.lang.Object) segmentedTimeline84);
//        org.jfree.chart.util.RectangleEdge rectangleEdge92 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge72);
//        java.awt.geom.Rectangle2D rectangle2D93 = axisSpace51.reserved(rectangle2D54, rectangleEdge72);
//        chartRenderingInfo50.setChartArea(rectangle2D93);
//        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity97 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) categoryAxis45, (java.awt.Shape) rectangle2D93, "{0}", "Pie 3D Plot");
//        try {
//            lineRenderer3D0.drawRangeGridline(graphics2D5, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D93, (double) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(font13);
//        org.junit.Assert.assertNull(axisSpace14);
//        org.junit.Assert.assertNotNull(font20);
//        org.junit.Assert.assertNotNull(categoryAxisArray28);
//        org.junit.Assert.assertNotNull(font33);
//        org.junit.Assert.assertNotNull(font36);
//        org.junit.Assert.assertNotNull(tickUnitSource38);
//        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(numberTickUnit43);
//        org.junit.Assert.assertNotNull(paint46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertNotNull(rectangle2D54);
//        org.junit.Assert.assertNotNull(axisLocation65);
//        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 1.0f + "'", float68 == 1.0f);
//        org.junit.Assert.assertNull(collection71);
//        org.junit.Assert.assertNotNull(rectangleEdge72);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNull(font78);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline84);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 900000L + "'", long85 == 900000L);
//        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-32400010L) + "'", long87 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 0L + "'", long90 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge92);
//        org.junit.Assert.assertNotNull(rectangle2D93);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot4.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset1.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (-1.0f), (org.jfree.data.KeyedValues) pieDataset10);
        org.jfree.chart.plot.RingPlot ringPlot12 = new org.jfree.chart.plot.RingPlot(pieDataset10);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) year1, (java.lang.Comparable) 68);
        try {
            java.lang.Comparable comparable5 = defaultStatisticalCategoryDataset0.getColumnKey(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis3D1.configure();
        numberAxis3D1.setNegativeArrowVisible(true);
        boolean boolean18 = numberAxis3D1.isAxisLineVisible();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat19);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        numberAxis3D1.setInverted(false);
        try {
            numberAxis3D1.zoomRange((double) (short) 10, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        java.util.List list4 = segmentedTimeline0.getExceptionSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D4.setLabelFont(font5);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3D4.getStandardTickUnits();
        numberAxis3D4.centerRange((double) (short) 0);
        numberAxis3D4.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D18.setLabelFont(font19);
        java.awt.Color color22 = java.awt.Color.pink;
        java.lang.String str23 = color22.toString();
        java.awt.Color color24 = color22.darker();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke25);
        java.awt.image.ColorModel colorModel27 = null;
        java.awt.Rectangle rectangle28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.geom.AffineTransform affineTransform30 = null;
        java.awt.RenderingHints renderingHints31 = null;
        java.awt.PaintContext paintContext32 = color22.createContext(colorModel27, rectangle28, rectangle2D29, affineTransform30, renderingHints31);
        org.jfree.chart.text.TextBlock textBlock33 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font19, (java.awt.Paint) color22);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D4, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font19);
        numberAxis3D4.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font40 = categoryAxis38.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D4.setLabelFont(font40);
        numberAxis3D4.resizeRange((double) (byte) 10, 0.0d);
        org.jfree.chart.util.UnitType unitType45 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets(unitType45, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double52 = rectangleInsets50.calculateRightOutset((double) (-1));
        numberAxis3D4.setLabelInsets(rectangleInsets50);
        blockContainer0.setPadding(rectangleInsets50);
        java.util.List list55 = blockContainer0.getBlocks();
        java.lang.Object obj56 = blockContainer0.clone();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str23.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paintContext32);
        org.junit.Assert.assertNotNull(textBlock33);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNotNull(obj56);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot30.setRenderer(0, xYItemRenderer34, true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D37 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D37.setDrawOutlines(true);
        boolean boolean40 = lineRenderer3D37.getBaseShapesVisible();
        java.awt.Font font42 = lineRenderer3D37.getSeriesItemLabelFont(3);
        org.jfree.chart.LegendItem legendItem45 = lineRenderer3D37.getLegendItem((int) ' ', 100);
        java.awt.Stroke stroke47 = lineRenderer3D37.lookupSeriesStroke(10);
        xYPlot30.setDomainCrosshairStroke(stroke47);
        xYPlot30.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(font42);
        org.junit.Assert.assertNull(legendItem45);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = blockContainer0.arrange(graphics2D1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = blockContainer0.arrange(graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        double double4 = piePlot3D0.getExplodePercent((java.lang.Comparable) 2958465);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D0.getURLGenerator();
        double double6 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-5d + "'", double6 == 1.0E-5d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis33 };
        categoryPlot32.setDomainAxes(categoryAxisArray34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        categoryPlot32.datasetChanged(datasetChangeEvent36);
        categoryPlot32.setBackgroundAlpha((float) 0);
        java.awt.Color color40 = java.awt.Color.pink;
        java.lang.String str41 = color40.toString();
        java.awt.Color color42 = color40.darker();
        categoryPlot32.setOutlinePaint((java.awt.Paint) color42);
        java.awt.Stroke stroke44 = categoryPlot32.getRangeGridlineStroke();
        jFreeChart27.setBorderStroke(stroke44);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str41.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font13 = categoryAxis11.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer9.setBaseItemLabelFont(font13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = stackedAreaRenderer9.getURLGenerator(0, 3);
        stackedAreaRenderer9.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer9.setBaseStroke(stroke22);
        categoryAxis1.setTickMarkStroke(stroke22);
        double double25 = categoryAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(categoryURLGenerator17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
//        defaultKeyedValues2D1.setValue((java.lang.Number) 0.0d, (java.lang.Comparable) 100, (java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int8 = segmentedTimeline7.getSegmentsExcluded();
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline7.getSegment(10L);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segment10.copy();
//        long long12 = segment10.getSegmentStart();
//        defaultKeyedValues2D1.setValue((java.lang.Number) 20.0d, (java.lang.Comparable) segment10, (java.lang.Comparable) (-1.0d));
//        org.junit.Assert.assertNotNull(segmentedTimeline7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 68 + "'", int8 == 68);
//        org.junit.Assert.assertNotNull(segment10);
//        org.junit.Assert.assertNotNull(segment11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-899990L) + "'", long12 == (-899990L));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font6 = categoryAxis4.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer2.setBaseItemLabelFont(font6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font6);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        java.awt.Font font11 = textFragment10.getFont();
        java.awt.Paint paint12 = textFragment10.getPaint();
        java.awt.Font font13 = textFragment10.getFont();
        java.awt.Font font14 = textFragment10.getFont();
        textLine8.addFragment(textFragment10);
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D19.setLabelFont(font20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray28 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis27 };
        categoryPlot26.setDomainAxes(categoryAxisArray28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        categoryPlot26.datasetChanged(datasetChangeEvent30);
        numberAxis3D19.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        java.awt.Font font33 = numberAxis3D19.getTickLabelFont();
        boolean boolean34 = numberAxis3D19.getAutoRangeIncludesZero();
        boolean boolean35 = textFragment17.equals((java.lang.Object) numberAxis3D19);
        textLine8.addFragment(textFragment17);
        org.jfree.chart.text.TextFragment textFragment37 = textLine8.getLastTextFragment();
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(categoryAxisArray28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(textFragment37);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis3D1.valueToJava2D(1.0E-8d, rectangle2D16, rectangleEdge17);
        java.awt.Stroke stroke19 = numberAxis3D1.getAxisLineStroke();
        numberAxis3D1.setLowerMargin((double) 86400000L);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = polarPlot0.getOrientation();
        java.awt.Paint paint2 = polarPlot0.getRadiusGridlinePaint();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone4);
        dateAxis5.setAutoTickUnitSelection(true, true);
        org.jfree.data.Range range9 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis5);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 1);
        java.lang.String str13 = range12.toString();
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range12, (double) (byte) 100);
        dateAxis5.setRange(range12);
        boolean boolean18 = range12.contains((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[1.0,1.0]" + "'", str13.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset1.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 0);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset10, (java.lang.Comparable) 0.0d, (double) (byte) 100, 5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int16 = segmentedTimeline15.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment18 = segmentedTimeline15.getSegment(10L);
        segment18.moveIndexToStart();
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset14, (java.lang.Comparable) segment18, (double) (-2208960000000L));
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 900000L, (org.jfree.data.KeyedValues) pieDataset14);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNotNull(segmentedTimeline15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 68 + "'", int16 == 68);
        org.junit.Assert.assertNotNull(segment18);
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNotNull(categoryDataset22);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
        boolean boolean5 = segmentedTimeline3.containsDomainValue(1562097599999L);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        boolean boolean7 = segmentedTimeline3.containsDomainValue(date6);
        long long10 = segmentedTimeline3.getExceptionSegmentCount((long) 15, (long) (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.fireChartChanged();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Paint paint31 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        categoryAxis30.setTickMarkPaint(paint31);
        jFreeChart27.setBackgroundPaint(paint31);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D1.setDrawOutlines(true);
        lineRenderer3D1.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Stroke stroke13 = null;
        categoryPlot12.setOutlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot12.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getRangeAxisEdge(0);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot12.setOutlineStroke(stroke19);
        lineRenderer3D1.setSeriesOutlineStroke(3, stroke19, false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes((double) (-1), plotRenderingInfo29, point2D30);
        float float32 = categoryPlot27.getForegroundAlpha();
        lineRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        boolean boolean34 = blockContainer0.equals((java.lang.Object) lineRenderer3D1);
        blockContainer0.setHeight(Double.NaN);
        java.lang.Object obj37 = blockContainer0.clone();
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape4, stroke5, (java.awt.Paint) color6);
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape12, stroke13, (java.awt.Paint) color14);
        boolean boolean16 = legendItem7.equals((java.lang.Object) legendItem15);
        int int17 = legendItem15.getDatasetIndex();
        boolean boolean18 = legendItem15.isShapeFilled();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        double double4 = piePlot3D0.getExplodePercent((java.lang.Comparable) 2958465);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D0.getURLGenerator();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot3D0.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(9, 0, (int) (byte) 0, (int) (short) 0, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = color1.darker();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke4);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font11 = categoryAxis9.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer7.setBaseItemLabelFont(font11);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = stackedAreaRenderer7.getURLGenerator(0, 3);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot20.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer24);
        stackedAreaRenderer7.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        java.awt.Paint paint27 = categoryPlot20.getOutlinePaint();
        valueMarker5.setOutlinePaint(paint27);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 1);
        java.lang.String str3 = range2.toString();
        org.jfree.data.Range range5 = org.jfree.data.Range.expandToInclude(range2, (double) (byte) 100);
        boolean boolean7 = range2.contains((double) 9);
        boolean boolean9 = range2.contains((double) (-459));
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Range[1.0,1.0]" + "'", str3.equals("Range[1.0,1.0]"));
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.setMargin((double) (short) 1, (-7.0d), 1.0d, (double) 255);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis7 };
        categoryPlot6.setDomainAxes(categoryAxisArray8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent10);
        categoryPlot6.setBackgroundAlpha((float) 0);
        categoryPlot6.setWeight((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("CategoryAnchor.MIDDLE", font1, (org.jfree.chart.plot.Plot) categoryPlot6, false);
        java.awt.Paint paint18 = jFreeChart17.getBorderPaint();
        java.util.List list19 = jFreeChart17.getSubtitles();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.setAutoTickUnitSelection(true, true);
        java.lang.String str6 = dateAxis2.getLabelURL();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = null;
        dateAxis2.setTickUnit(dateTickUnit7, true, true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color6.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font3, (java.awt.Paint) color6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock17.setLineAlignment(horizontalAlignment18);
        java.util.List list20 = textBlock17.getLines();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNotNull(textBlock17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer2 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font6 = categoryAxis4.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer2.setBaseItemLabelFont(font6);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = stackedAreaRenderer2.getURLGenerator(0, 3);
        stackedAreaRenderer2.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer2.setBaseStroke(stroke15);
        piePlot3D0.setLabelLinkStroke(stroke15);
        java.lang.Object obj18 = piePlot3D0.clone();
        java.awt.Paint paint20 = piePlot3D0.getSectionPaint((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        xYPlot30.setRangeCrosshairValue((double) (byte) 10, true);
        xYPlot30.mapDatasetToDomainAxis((int) (short) 10, 0);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        java.awt.Stroke stroke44 = null;
        categoryPlot43.setOutlineStroke(stroke44);
        java.awt.Paint paint46 = categoryPlot43.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D50 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D50.setLabelFont(font51);
        java.awt.Color color54 = java.awt.Color.pink;
        java.lang.String str55 = color54.toString();
        java.awt.Color color56 = color54.darker();
        java.awt.Stroke stroke57 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color54, stroke57);
        java.awt.image.ColorModel colorModel59 = null;
        java.awt.Rectangle rectangle60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        java.awt.geom.AffineTransform affineTransform62 = null;
        java.awt.RenderingHints renderingHints63 = null;
        java.awt.PaintContext paintContext64 = color54.createContext(colorModel59, rectangle60, rectangle2D61, affineTransform62, renderingHints63);
        org.jfree.chart.text.TextBlock textBlock65 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font51, (java.awt.Paint) color54);
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer69 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset66, categoryAxis67, valueAxis68, categoryItemRenderer69);
        java.awt.Stroke stroke71 = null;
        categoryPlot70.setOutlineStroke(stroke71);
        org.jfree.chart.JFreeChart jFreeChart74 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font51, (org.jfree.chart.plot.Plot) categoryPlot70, false);
        jFreeChart74.setBackgroundImageAlignment(100);
        java.awt.Color color77 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart74.setBackgroundPaint((java.awt.Paint) color77);
        categoryPlot43.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart74);
        java.awt.Stroke stroke80 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot43.setRangeCrosshairStroke(stroke80);
        java.awt.Color color84 = java.awt.Color.pink;
        java.lang.String str85 = color84.toString();
        java.awt.Color color86 = color84.darker();
        java.awt.Stroke stroke87 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker88 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color84, stroke87);
        valueMarker88.setAlpha((float) 0L);
        java.awt.Stroke stroke91 = valueMarker88.getStroke();
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot43.addRangeMarker(9, (org.jfree.chart.plot.Marker) valueMarker88, layer92);
        boolean boolean95 = layer92.equals((java.lang.Object) 1.0E-5d);
        java.util.Collection collection96 = xYPlot30.getDomainMarkers((int) (byte) 10, layer92);
        java.lang.String str97 = layer92.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str55.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(paintContext64);
        org.junit.Assert.assertNotNull(textBlock65);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str85.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNull(collection96);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "Layer.BACKGROUND" + "'", str97.equals("Layer.BACKGROUND"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date0, timeZone2);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        xYPlot30.setRangeCrosshairValue((double) (byte) 10, true);
        xYPlot30.mapDatasetToDomainAxis((int) (short) 10, 0);
        java.awt.Paint paint38 = xYPlot30.getRangeCrosshairPaint();
        xYPlot30.setRangeZeroBaselineVisible(false);
        double double41 = xYPlot30.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 10.0d + "'", double41 == 10.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock18.setLineAlignment(horizontalAlignment19);
        java.lang.String str21 = horizontalAlignment19.toString();
        boolean boolean22 = itemLabelAnchor0.equals((java.lang.Object) str21);
        java.lang.String str23 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "HorizontalAlignment.CENTER" + "'", str21.equals("HorizontalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "ItemLabelAnchor.INSIDE8" + "'", str23.equals("ItemLabelAnchor.INSIDE8"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        java.lang.String str6 = rectangleInsets5.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=-1.0,l=1.0,b=32.0,r=0.2]" + "'", str6.equals("RectangleInsets[t=-1.0,l=1.0,b=32.0,r=0.2]"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D6.setLabelFont(font7);
        java.awt.Color color10 = java.awt.Color.pink;
        java.lang.String str11 = color10.toString();
        java.awt.Color color12 = color10.darker();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke13);
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color10.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        java.awt.Stroke stroke27 = null;
        categoryPlot26.setOutlineStroke(stroke27);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font7, (org.jfree.chart.plot.Plot) categoryPlot26, false);
        jFreeChart30.setBackgroundImageAlignment(100);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart30.setBackgroundPaint((java.awt.Paint) color33);
        float[] floatArray40 = new float[] { (short) 100, ' ', (-1.0f), (-2208960000000L), 6 };
        float[] floatArray41 = color33.getColorComponents(floatArray40);
        float[] floatArray42 = color2.getColorComponents(floatArray41);
        try {
            float[] floatArray43 = color0.getComponents(colorSpace1, floatArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str11.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        java.util.List list2 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D3 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean5 = lineRenderer3D3.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj6 = lineRenderer3D3.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list8 = null;
        projectInfo7.setContributors(list8);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D11.setLabelFont(font12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot18.setDomainAxes(categoryAxisArray20);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        categoryPlot18.datasetChanged(datasetChangeEvent22);
        numberAxis3D11.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        double double25 = numberAxis3D11.getAutoRangeMinimumSize();
        boolean boolean26 = projectInfo7.equals((java.lang.Object) numberAxis3D11);
        org.jfree.data.Range range27 = numberAxis3D11.getRange();
        boolean boolean28 = lineRenderer3D3.equals((java.lang.Object) numberAxis3D11);
        double double29 = numberAxis3D11.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer30);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = xYPlot31.getDatasetRenderingOrder();
        boolean boolean33 = tickUnits0.equals((java.lang.Object) datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0E-8d + "'", double25 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0E-8d + "'", double29 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.awt.Color color4 = java.awt.Color.pink;
        java.lang.String str5 = color4.toString();
        java.awt.Color color6 = color4.darker();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke7);
        lineRenderer3D0.setBaseOutlineStroke(stroke7, true);
        org.jfree.chart.LegendItem legendItem13 = lineRenderer3D0.getLegendItem(6, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getRotationAnchor();
        lineRenderer3D0.setSeriesNegativeItemLabelPosition(10, itemLabelPosition15, false);
        double double19 = itemLabelPosition15.getAngle();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str5.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("VerticalAlignment.BOTTOM");
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        segment3.moveIndexToStart();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int6 = segmentedTimeline5.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline5.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segment8.copy();
        boolean boolean10 = segment3.contains(segment8);
        segment8.inc();
        segment8.moveIndexToEnd();
        segment8.inc((long) (byte) 0);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segmentedTimeline5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 68 + "'", int6 == 68);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertNotNull(segment9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot1.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis11 };
        categoryPlot10.setDomainAxes(categoryAxisArray12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot10.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        java.awt.Color color18 = java.awt.Color.pink;
        java.lang.String str19 = color18.toString();
        java.awt.Color color20 = color18.darker();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color18, stroke21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor26 = itemLabelPosition25.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str28 = textAnchor27.toString();
        org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor26, textAnchor27, 1.0d);
        valueMarker22.setLabelTextAnchor(textAnchor27);
        boolean boolean32 = jFreeChart16.equals((java.lang.Object) valueMarker22);
        org.jfree.chart.event.ChartProgressListener chartProgressListener33 = null;
        jFreeChart16.removeProgressListener(chartProgressListener33);
        java.awt.image.BufferedImage bufferedImage37 = jFreeChart16.createBufferedImage((int) ' ', 1);
        multiplePiePlot1.setBackgroundImage((java.awt.Image) bufferedImage37);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) (-1L));
        org.jfree.data.category.CategoryDataset categoryDataset41 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(categoryAxisArray12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str19.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str28.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(bufferedImage37);
        org.junit.Assert.assertNotNull(categoryDataset41);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.0d);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = categoryLabelPosition2.getWidthType();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition2);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays(68, serialDate7);
        java.lang.String str9 = serialDate8.getDescription();
        boolean boolean10 = categoryLabelPosition2.equals((java.lang.Object) str9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D13 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean15 = lineRenderer3D13.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj16 = lineRenderer3D13.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo17 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list18 = null;
        projectInfo17.setContributors(list18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D21.setLabelFont(font22);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray30 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis29 };
        categoryPlot28.setDomainAxes(categoryAxisArray30);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        categoryPlot28.datasetChanged(datasetChangeEvent32);
        numberAxis3D21.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        double double35 = numberAxis3D21.getAutoRangeMinimumSize();
        boolean boolean36 = projectInfo17.equals((java.lang.Object) numberAxis3D21);
        org.jfree.data.Range range37 = numberAxis3D21.getRange();
        boolean boolean38 = lineRenderer3D13.equals((java.lang.Object) numberAxis3D21);
        double double39 = numberAxis3D21.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, xYItemRenderer40);
        xYPlot41.setRangeCrosshairLockedOnData(false);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone45);
        dateAxis46.setAutoTickUnitSelection(true, true);
        dateAxis46.configure();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D52 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font53 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D52.setLabelFont(font53);
        org.jfree.chart.axis.TickUnitSource tickUnitSource55 = numberAxis3D52.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = numberAxis3D52.java2DToValue((double) 0, rectangle2D57, rectangleEdge58);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray60 = new org.jfree.chart.axis.ValueAxis[] { dateAxis46, numberAxis3D52 };
        xYPlot41.setRangeAxes(valueAxisArray60);
        java.awt.Color color63 = java.awt.Color.pink;
        java.lang.String str64 = color63.toString();
        java.awt.Color color65 = color63.darker();
        java.awt.Stroke stroke66 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color63, stroke66);
        valueMarker67.setAlpha((float) 0L);
        java.awt.Stroke stroke70 = valueMarker67.getStroke();
        java.awt.Paint paint71 = valueMarker67.getPaint();
        xYPlot41.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker67);
        java.awt.Color color74 = java.awt.Color.pink;
        java.lang.String str75 = color74.toString();
        java.awt.Color color76 = java.awt.Color.getColor("({0}, {1}) = {2}", color74);
        xYPlot41.setRangeZeroBaselinePaint((java.awt.Paint) color76);
        boolean boolean78 = categoryLabelPosition2.equals((java.lang.Object) color76);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(categoryAxisArray30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0E-8d + "'", double35 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0E-8d + "'", double39 == 1.0E-8d);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(tickUnitSource55);
        org.junit.Assert.assertEquals((double) double59, Double.NaN, 0);
        org.junit.Assert.assertNotNull(valueAxisArray60);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str64.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str75.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass4 = stroke3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass4);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass9 = stroke8.getClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass9);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("({0}, {1}) = {2}", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Range[1.0,1.0]", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(inputStream13);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(1L, (int) (short) 0, 6);
        java.util.Date date5 = segmentedTimeline3.getDate((long) (byte) 10);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = segmentedTimeline3.getBaseTimeline();
        try {
            long long7 = segmentedTimeline6.getSegmentSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(segmentedTimeline6);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.text.NumberFormat numberFormat5 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat5);
        java.awt.Shape shape7 = numberAxis3D1.getRightArrow();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection10 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot11 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection10);
        org.jfree.chart.JFreeChart jFreeChart12 = multiplePiePlot11.getPieChart();
        org.jfree.chart.util.TableOrder tableOrder13 = multiplePiePlot11.getDataExtractOrder();
        org.jfree.data.category.CategoryDataset categoryDataset14 = multiplePiePlot11.getDataset();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity17 = new org.jfree.chart.entity.CategoryItemEntity(shape7, "rect", "VerticalAlignment.BOTTOM", categoryDataset14, (java.lang.Comparable) "VerticalAlignment.BOTTOM", (java.lang.Comparable) (-36L));
        java.lang.Comparable comparable18 = categoryItemEntity17.getRowKey();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color20 = java.awt.Color.pink;
        int int21 = color20.getRed();
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color20);
        statisticalBarRenderer19.setErrorIndicatorPaint((java.awt.Paint) color20);
        boolean boolean24 = categoryItemEntity17.equals((java.lang.Object) color20);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(jFreeChart12);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "VerticalAlignment.BOTTOM" + "'", comparable18.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
//        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
//        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.entity.EntityCollection entityCollection4 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
//        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D9 = labelBlock8.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
//        java.awt.geom.Point2D point2D17 = null;
//        categoryPlot14.zoomRangeAxes((double) (-1), plotRenderingInfo16, point2D17);
//        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot14.setRangeAxisLocation((int) ' ', axisLocation20, false);
//        float float23 = categoryPlot14.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer25 = null;
//        java.util.Collection collection26 = categoryPlot14.getRangeMarkers((int) (byte) 0, layer25);
//        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot14.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D28 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D28.setDrawOutlines(true);
//        boolean boolean31 = lineRenderer3D28.getBaseShapesVisible();
//        java.awt.Font font33 = lineRenderer3D28.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = null;
//        lineRenderer3D28.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator35, false);
//        boolean boolean38 = rectangleEdge27.equals((java.lang.Object) categoryItemLabelGenerator35);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline39 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long40 = segmentedTimeline39.getSegmentSize();
//        long long42 = segmentedTimeline39.toTimelineValue((long) (short) 0);
//        long long45 = segmentedTimeline39.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean46 = rectangleEdge27.equals((java.lang.Object) segmentedTimeline39);
//        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
//        java.awt.geom.Rectangle2D rectangle2D48 = axisSpace6.reserved(rectangle2D9, rectangleEdge27);
//        chartRenderingInfo5.setChartArea(rectangle2D48);
//        org.jfree.chart.entity.EntityCollection entityCollection50 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo(entityCollection50);
//        org.jfree.chart.entity.EntityCollection entityCollection52 = null;
//        chartRenderingInfo51.setEntityCollection(entityCollection52);
//        try {
//            jFreeChart2.draw(graphics2D3, rectangle2D48, chartRenderingInfo51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jFreeChart2);
//        org.junit.Assert.assertNotNull(rectangle2D9);
//        org.junit.Assert.assertNotNull(axisLocation20);
//        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
//        org.junit.Assert.assertNull(collection26);
//        org.junit.Assert.assertNotNull(rectangleEdge27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(font33);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 900000L + "'", long40 == 900000L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-32400010L) + "'", long42 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge47);
//        org.junit.Assert.assertNotNull(rectangle2D48);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D7.setLabelFont(font8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis3D7.getStandardTickUnits();
        numberAxis3D7.centerRange((double) (short) 0);
        numberAxis3D7.setAutoRangeStickyZero(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font21 = categoryAxis19.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer17.setBaseItemLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font21);
        numberAxis3D7.setLabelFont(font21);
        boolean boolean25 = taskSeriesCollection0.equals((java.lang.Object) numberAxis3D7);
        java.lang.String str26 = numberAxis3D7.getLabelToolTip();
        java.awt.Color color28 = java.awt.Color.pink;
        java.lang.String str29 = color28.toString();
        java.awt.Color color30 = java.awt.Color.getColor("({0}, {1}) = {2}", color28);
        numberAxis3D7.setLabelPaint((java.awt.Paint) color28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str29.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color30);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
//        dateAxis2.setAutoTickUnitSelection(true, true);
//        dateAxis2.configure();
//        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
//        java.awt.geom.Point2D point2D14 = null;
//        categoryPlot11.zoomRangeAxes((double) (-1), plotRenderingInfo13, point2D14);
//        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot11.setRangeAxisLocation((int) ' ', axisLocation17, false);
//        float float20 = categoryPlot11.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer22 = null;
//        java.util.Collection collection23 = categoryPlot11.getRangeMarkers((int) (byte) 0, layer22);
//        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot11.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D25 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D25.setDrawOutlines(true);
//        boolean boolean28 = lineRenderer3D25.getBaseShapesVisible();
//        java.awt.Font font30 = lineRenderer3D25.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = null;
//        lineRenderer3D25.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator32, false);
//        boolean boolean35 = rectangleEdge24.equals((java.lang.Object) categoryItemLabelGenerator32);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long37 = segmentedTimeline36.getSegmentSize();
//        long long39 = segmentedTimeline36.toTimelineValue((long) (short) 0);
//        long long42 = segmentedTimeline36.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean43 = rectangleEdge24.equals((java.lang.Object) segmentedTimeline36);
//        org.jfree.data.KeyedObjects2D keyedObjects2D44 = new org.jfree.data.KeyedObjects2D();
//        java.awt.Paint paint45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.util.Date date47 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date48 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date47, date48);
//        keyedObjects2D44.addObject((java.lang.Object) paint45, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date47);
//        long long51 = segmentedTimeline36.toTimelineValue(date47);
//        dateAxis2.setMinimumDate(date47);
//        dateAxis2.configure();
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(axisLocation17);
//        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
//        org.junit.Assert.assertNull(collection23);
//        org.junit.Assert.assertNotNull(rectangleEdge24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNull(font30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 900000L + "'", long37 == 900000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-32400010L) + "'", long39 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(paint45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 455057983088L + "'", long51 == 455057983088L);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 255);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font17 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer13.setBaseItemLabelFont(font17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedAreaRenderer13.getURLGenerator(0, 3);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer13.setBaseStroke(stroke26);
        categoryAxis5.setTickMarkStroke(stroke26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D31.setLabelFont(font32);
        java.awt.Color color35 = java.awt.Color.pink;
        java.lang.String str36 = color35.toString();
        java.awt.Color color37 = color35.darker();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color35, stroke38);
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color35.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font32, (java.awt.Paint) color35);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        boolean boolean49 = textBlock46.equals((java.lang.Object) numberAxis48);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer51 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font55 = categoryAxis53.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer51.setBaseItemLabelFont(font55);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator59 = stackedAreaRenderer51.getURLGenerator(0, 3);
        stackedAreaRenderer51.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape68, stroke69, (java.awt.Paint) color70);
        stackedAreaRenderer51.setBaseShape(shape68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer51);
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot74.getRangeAxisForDataset((int) (byte) 10);
        java.awt.Stroke stroke77 = categoryPlot74.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str36.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(categoryURLGenerator59);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(valueAxis76);
        org.junit.Assert.assertNotNull(stroke77);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        categoryAxis7.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        flowArrangement4.add(block5, (java.lang.Object) categoryAxis7);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer();
        java.util.List list16 = blockContainer15.getBlocks();
        java.awt.Shape shape21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape21, stroke22, (java.awt.Paint) color23);
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer15, (java.lang.Object) "");
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
        java.awt.geom.Rectangle2D rectangle2D28 = labelBlock27.getBounds();
        blockContainer15.setBounds(rectangle2D28);
        org.jfree.chart.plot.PiePlot3D piePlot3D30 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean31 = piePlot3D30.getIgnoreNullValues();
        boolean boolean32 = piePlot3D30.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = null;
        piePlot3D30.setLegendLabelURLGenerator(pieURLGenerator33);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer36 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font40 = categoryAxis38.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer36.setBaseItemLabelFont(font40);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = stackedAreaRenderer36.getURLGenerator(0, 3);
        java.awt.Paint paint46 = stackedAreaRenderer36.lookupSeriesPaint((int) (short) 1);
        piePlot3D30.setLabelPaint(paint46);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color54 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean55 = stackedBarRenderer3D51.equals((java.lang.Object) 0);
        java.awt.Paint paint56 = stackedBarRenderer3D51.getBaseOutlinePaint();
        piePlot3D30.setSectionPaint((java.lang.Comparable) 1900, paint56);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font63 = categoryAxis61.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer59.setBaseItemLabelFont(font63);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = stackedAreaRenderer59.getURLGenerator(0, 3);
        stackedAreaRenderer59.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke72 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer59.setBaseStroke(stroke72);
        java.awt.Color color74 = java.awt.Color.pink;
        int int75 = color74.getRed();
        org.jfree.chart.block.BlockBorder blockBorder76 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color74);
        try {
            org.jfree.chart.LegendItem legendItem77 = new org.jfree.chart.LegendItem(attributedString0, "AxisLocation.BOTTOM_OR_LEFT", "TextBlockAnchor.CENTER", "ChartChangeEventType.DATASET_UPDATED", (java.awt.Shape) rectangle2D28, paint56, stroke72, (java.awt.Paint) color74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNull(categoryURLGenerator44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNull(categoryURLGenerator67);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 255 + "'", int75 == 255);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = ringPlot0.getNoDataMessagePaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator2 = null;
        ringPlot0.setURLGenerator(pieURLGenerator2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        java.text.NumberFormat numberFormat5 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat5);
        java.awt.Shape shape7 = numberAxis3D1.getRightArrow();
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo4, point2D5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        polarPlot0.setDataset(xYDataset7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = xYPlot30.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot30.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        java.awt.Stroke stroke38 = null;
        categoryPlot37.setOutlineStroke(stroke38);
        java.awt.Paint paint40 = categoryPlot37.getBackgroundPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D44 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D44.setLabelFont(font45);
        java.awt.Color color48 = java.awt.Color.pink;
        java.lang.String str49 = color48.toString();
        java.awt.Color color50 = color48.darker();
        java.awt.Stroke stroke51 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color48, stroke51);
        java.awt.image.ColorModel colorModel53 = null;
        java.awt.Rectangle rectangle54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        java.awt.geom.AffineTransform affineTransform56 = null;
        java.awt.RenderingHints renderingHints57 = null;
        java.awt.PaintContext paintContext58 = color48.createContext(colorModel53, rectangle54, rectangle2D55, affineTransform56, renderingHints57);
        org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font45, (java.awt.Paint) color48);
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, categoryItemRenderer63);
        java.awt.Stroke stroke65 = null;
        categoryPlot64.setOutlineStroke(stroke65);
        org.jfree.chart.JFreeChart jFreeChart68 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font45, (org.jfree.chart.plot.Plot) categoryPlot64, false);
        jFreeChart68.setBackgroundImageAlignment(100);
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        jFreeChart68.setBackgroundPaint((java.awt.Paint) color71);
        categoryPlot37.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart68);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot37.setRangeCrosshairStroke(stroke74);
        java.awt.Color color78 = java.awt.Color.pink;
        java.lang.String str79 = color78.toString();
        java.awt.Color color80 = color78.darker();
        java.awt.Stroke stroke81 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color78, stroke81);
        valueMarker82.setAlpha((float) 0L);
        java.awt.Stroke stroke85 = valueMarker82.getStroke();
        org.jfree.chart.util.Layer layer86 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot37.addRangeMarker(9, (org.jfree.chart.plot.Marker) valueMarker82, layer86);
        boolean boolean89 = layer86.equals((java.lang.Object) 1.0E-5d);
        java.util.Collection collection90 = xYPlot30.getDomainMarkers(layer86);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D91 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D91.setDrawOutlines(true);
        org.jfree.chart.LegendItemCollection legendItemCollection94 = lineRenderer3D91.getLegendItems();
        xYPlot30.setFixedLegendItems(legendItemCollection94);
        org.jfree.chart.axis.AxisLocation axisLocation96 = xYPlot30.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str49.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paintContext58);
        org.junit.Assert.assertNotNull(textBlock59);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str79.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(layer86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNull(collection90);
        org.junit.Assert.assertNotNull(legendItemCollection94);
        org.junit.Assert.assertNotNull(axisLocation96);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-1.0d));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = categoryLabelPosition2.getWidthType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = categoryLabelPosition2.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition2);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.Block block7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot14);
        flowArrangement6.add(block7, (java.lang.Object) categoryAxis9);
        double double17 = categoryAxis9.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        categoryAxis9.setCategoryLabelPositions(categoryLabelPositions18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        java.awt.Stroke stroke25 = null;
        categoryPlot24.setOutlineStroke(stroke25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot24.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot24.getRangeAxisEdge(0);
        boolean boolean32 = rectangleEdge30.equals((java.lang.Object) false);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = categoryLabelPositions18.getLabelPosition(rectangleEdge30);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions34 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions5, categoryLabelPosition33);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition33);
        org.junit.Assert.assertNotNull(categoryLabelPositions34);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        java.awt.Shape shape32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape32, stroke33, (java.awt.Paint) color34);
        java.lang.String str36 = legendItem35.getDescription();
        java.awt.Stroke stroke37 = legendItem35.getLineStroke();
        categoryPlot23.setDomainGridlineStroke(stroke37);
        boolean boolean39 = categoryPlot23.isDomainZoomable();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str36.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        long long2 = year0.getMiddleMillisecond();
        java.lang.Object obj3 = null;
        int int4 = year0.compareTo(obj3);
        long long5 = year0.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getPositiveBarPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "CategoryLabelWidthType.CATEGORY");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        boolean boolean9 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryPlot4.setDomainAxis(100, categoryAxis12);
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean2 = lineRenderer3D0.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj3 = lineRenderer3D0.clone();
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = color5.darker();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke8);
        valueMarker9.setAlpha((float) 0L);
        java.awt.Stroke stroke12 = valueMarker9.getStroke();
        lineRenderer3D0.setBaseOutlineStroke(stroke12, false);
        lineRenderer3D0.setXOffset((double) (byte) 0);
        java.lang.Boolean boolean18 = lineRenderer3D0.getSeriesShapesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer6.setBaseItemLabelFont(font10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = stackedAreaRenderer6.getURLGenerator(0, 3);
        java.awt.Paint paint16 = stackedAreaRenderer6.lookupSeriesPaint((int) (short) 1);
        piePlot3D0.setLabelPaint(paint16);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color24 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean25 = stackedBarRenderer3D21.equals((java.lang.Object) 0);
        java.awt.Paint paint26 = stackedBarRenderer3D21.getBaseOutlinePaint();
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1900, paint26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = piePlot3D0.getLegendItems();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(legendItemCollection28);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) (byte) 10);
        java.lang.Object obj4 = null;
        keyedObjects0.addObject((java.lang.Comparable) (-1.0d), obj4);
        java.lang.Object obj6 = keyedObjects0.clone();
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test408");
//        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D3 = labelBlock2.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
//        java.awt.geom.Point2D point2D11 = null;
//        categoryPlot8.zoomRangeAxes((double) (-1), plotRenderingInfo10, point2D11);
//        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot8.setRangeAxisLocation((int) ' ', axisLocation14, false);
//        float float17 = categoryPlot8.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer19 = null;
//        java.util.Collection collection20 = categoryPlot8.getRangeMarkers((int) (byte) 0, layer19);
//        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot8.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D22 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D22.setDrawOutlines(true);
//        boolean boolean25 = lineRenderer3D22.getBaseShapesVisible();
//        java.awt.Font font27 = lineRenderer3D22.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator29 = null;
//        lineRenderer3D22.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator29, false);
//        boolean boolean32 = rectangleEdge21.equals((java.lang.Object) categoryItemLabelGenerator29);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline33 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long34 = segmentedTimeline33.getSegmentSize();
//        long long36 = segmentedTimeline33.toTimelineValue((long) (short) 0);
//        long long39 = segmentedTimeline33.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean40 = rectangleEdge21.equals((java.lang.Object) segmentedTimeline33);
//        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge21);
//        java.awt.geom.Rectangle2D rectangle2D42 = axisSpace0.reserved(rectangle2D3, rectangleEdge21);
//        org.jfree.chart.entity.EntityCollection entityCollection43 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo(entityCollection43);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
//        boolean boolean47 = rectangleEdge21.equals((java.lang.Object) plotRenderingInfo46);
//        java.lang.Object obj48 = plotRenderingInfo46.clone();
//        org.junit.Assert.assertNotNull(rectangle2D3);
//        org.junit.Assert.assertNotNull(axisLocation14);
//        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
//        org.junit.Assert.assertNull(collection20);
//        org.junit.Assert.assertNotNull(rectangleEdge21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNull(font27);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 900000L + "'", long34 == 900000L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-32400010L) + "'", long36 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge41);
//        org.junit.Assert.assertNotNull(rectangle2D42);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(obj48);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D1.setDrawOutlines(true);
        lineRenderer3D1.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Stroke stroke13 = null;
        categoryPlot12.setOutlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot12.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getRangeAxisEdge(0);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot12.setOutlineStroke(stroke19);
        lineRenderer3D1.setSeriesOutlineStroke(3, stroke19, false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes((double) (-1), plotRenderingInfo29, point2D30);
        float float32 = categoryPlot27.getForegroundAlpha();
        lineRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        boolean boolean34 = blockContainer0.equals((java.lang.Object) lineRenderer3D1);
        double double35 = blockContainer0.getContentYOffset();
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer18);
        stackedAreaRenderer1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot14);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot14.getRangeAxisForDataset(0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font25 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D24.setLabelFont(font25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis3D24.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = numberAxis3D24.java2DToValue((double) 0, rectangle2D29, rectangleEdge30);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit32 = numberAxis3D24.getTickUnit();
        boolean boolean33 = numberAxis3D24.isTickLabelsVisible();
        numberAxis3D24.setUpperMargin((double) (short) 1);
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D24);
        java.text.NumberFormat numberFormat37 = null;
        numberAxis3D24.setNumberFormatOverride(numberFormat37);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        int int31 = xYPlot30.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot30.getDomainAxisLocation((int) '#');
        xYPlot30.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.toString();
        projectInfo0.addOptionalLibrary("TextAnchor.BOTTOM_RIGHT");
        java.util.List list4 = projectInfo0.getContributors();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str1.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        boolean boolean3 = lineRenderer3D0.getBaseShapesVisible();
        java.awt.Font font5 = lineRenderer3D0.getSeriesItemLabelFont(3);
        org.jfree.chart.LegendItem legendItem8 = lineRenderer3D0.getLegendItem((int) ' ', 100);
        boolean boolean9 = lineRenderer3D0.getBaseShapesFilled();
        boolean boolean12 = lineRenderer3D0.isItemLabelVisible((int) (byte) 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue(comparable0, (java.lang.Number) 6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone34);
        dateAxis35.setAutoTickUnitSelection(true, true);
        dateAxis35.configure();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D41.setLabelFont(font42);
        org.jfree.chart.axis.TickUnitSource tickUnitSource44 = numberAxis3D41.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis3D41.java2DToValue((double) 0, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray49 = new org.jfree.chart.axis.ValueAxis[] { dateAxis35, numberAxis3D41 };
        xYPlot30.setRangeAxes(valueAxisArray49);
        java.awt.Color color52 = java.awt.Color.pink;
        java.lang.String str53 = color52.toString();
        java.awt.Color color54 = color52.darker();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color52, stroke55);
        valueMarker56.setAlpha((float) 0L);
        java.awt.Stroke stroke59 = valueMarker56.getStroke();
        java.awt.Paint paint60 = valueMarker56.getPaint();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker56);
        xYPlot30.setDomainZeroBaselineVisible(true);
        xYPlot30.setRangeCrosshairVisible(false);
        xYPlot30.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(tickUnitSource44);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertNotNull(valueAxisArray49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str53.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setDrawOutlines(true);
        java.lang.Boolean boolean4 = lineRenderer3D0.getSeriesVisible((int) (short) 0);
        lineRenderer3D0.setBaseShapesFilled(false);
        lineRenderer3D0.setBaseShapesFilled(false);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        lineRenderer3D0.setSeriesURLGenerator(1900, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10, true);
        double double13 = lineRenderer3D0.getXOffset();
        boolean boolean14 = lineRenderer3D0.getUseOutlinePaint();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 12.0d + "'", double13 == 12.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj1 = standardCategoryURLGenerator0.clone();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int4 = taskSeriesCollection2.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, true);
        org.jfree.data.general.DatasetGroup datasetGroup7 = taskSeriesCollection2.getGroup();
        java.util.List list8 = taskSeriesCollection2.getRowKeys();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D9 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D9.setDrawOutlines(true);
        lineRenderer3D9.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0);
        taskSeriesCollection2.seriesChanged(seriesChangeEvent15);
        java.lang.Object obj17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) taskSeriesCollection2);
        try {
            java.lang.String str20 = standardCategoryURLGenerator0.generateURL((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, 12, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(datasetGroup7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        try {
            java.lang.String[] strArray3 = dataPackageResources0.getStringArray("Range[1.0,1.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key Range[1.0,1.0]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int12 = segmentedTimeline11.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment14 = segmentedTimeline11.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segment14.copy();
        segment15.moveIndexToEnd();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) segment15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(segmentedTimeline11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(segment14);
        org.junit.Assert.assertNotNull(segment15);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray8 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis7 };
        categoryPlot6.setDomainAxes(categoryAxisArray8);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot6.datasetChanged(datasetChangeEvent10);
        categoryPlot6.setBackgroundAlpha((float) 0);
        categoryPlot6.setWeight((int) (byte) 0);
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart("CategoryAnchor.MIDDLE", font1, (org.jfree.chart.plot.Plot) categoryPlot6, false);
        org.jfree.chart.title.Title title18 = null;
        jFreeChart17.removeSubtitle(title18);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(categoryAxisArray8);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (-1L), 1.0d, (double) ' ', 0.2d);
        double double7 = rectangleInsets5.calculateRightOutset((double) (-1));
        double double8 = rectangleInsets5.getTop();
        double double10 = rectangleInsets5.trimHeight((double) 68);
        double double12 = rectangleInsets5.trimWidth((double) 4);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-2040.0d) + "'", double10 == (-2040.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.8d) + "'", double12 == (-0.8d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, (float) 10);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.setAutoTickUnitSelection(true, true);
        dateAxis2.configure();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis2.getTimeline();
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis2.getTickUnit();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) 255);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        categoryAxis5.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font17 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer13.setBaseItemLabelFont(font17);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedAreaRenderer13.getURLGenerator(0, 3);
        stackedAreaRenderer13.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer13.setBaseStroke(stroke26);
        categoryAxis5.setTickMarkStroke(stroke26);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D31.setLabelFont(font32);
        java.awt.Color color35 = java.awt.Color.pink;
        java.lang.String str36 = color35.toString();
        java.awt.Color color37 = color35.darker();
        java.awt.Stroke stroke38 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color35, stroke38);
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color35.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font32, (java.awt.Paint) color35);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String");
        boolean boolean49 = textBlock46.equals((java.lang.Object) numberAxis48);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer51 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font55 = categoryAxis53.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer51.setBaseItemLabelFont(font55);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator59 = stackedAreaRenderer51.getURLGenerator(0, 3);
        stackedAreaRenderer51.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape68 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape68, stroke69, (java.awt.Paint) color70);
        stackedAreaRenderer51.setBaseShape(shape68, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer51);
        int int75 = categoryPlot74.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str36.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertNotNull(textBlock46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(categoryURLGenerator59);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 0, (float) (short) -1);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation34 = xYPlot30.getRangeAxisLocation((int) (short) 100);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        java.awt.Stroke stroke40 = null;
        categoryPlot39.setOutlineStroke(stroke40);
        java.awt.Paint paint42 = categoryPlot39.getBackgroundPaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot39);
        xYPlot30.notifyListeners(plotChangeEvent43);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        java.awt.Color color5 = java.awt.Color.pink;
        java.lang.String str6 = color5.toString();
        java.awt.Color color7 = java.awt.Color.getColor("({0}, {1}) = {2}", color5);
        boolean boolean8 = defaultCategoryDataset0.equals((java.lang.Object) color7);
        defaultCategoryDataset0.removeColumn((java.lang.Comparable) 86400000L);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str6.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = stackedAreaRenderer1.getDrawingSupplier();
        java.awt.Paint paint17 = stackedAreaRenderer1.getSeriesItemLabelPaint((int) ' ');
        java.lang.Boolean boolean19 = stackedAreaRenderer1.getSeriesItemLabelsVisible(3);
        java.lang.Boolean boolean21 = stackedAreaRenderer1.getSeriesVisible((int) (short) 1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(drawingSupplier15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNull(boolean21);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        boolean boolean3 = piePlot3D0.getIgnoreNullValues();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = piePlot3D0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(drawingSupplier4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int2 = taskSeriesCollection0.getColumnIndex((java.lang.Comparable) (short) -1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.jfree.data.general.DatasetGroup datasetGroup5 = taskSeriesCollection0.getGroup();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D7.setLabelFont(font8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis3D7.getStandardTickUnits();
        numberAxis3D7.centerRange((double) (short) 0);
        numberAxis3D7.setAutoRangeStickyZero(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font21 = categoryAxis19.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer17.setBaseItemLabelFont(font21);
        org.jfree.chart.text.TextLine textLine23 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=175,b=175]", font21);
        numberAxis3D7.setLabelFont(font21);
        boolean boolean25 = taskSeriesCollection0.equals((java.lang.Object) numberAxis3D7);
        boolean boolean26 = numberAxis3D7.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getBaseSectionOutlinePaint();
        java.awt.Paint paint4 = piePlot3D0.getLabelOutlinePaint();
        java.lang.String str5 = piePlot3D0.getPlotType();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = piePlot3D0.getDrawingSupplier();
        java.awt.Paint paint7 = piePlot3D0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Pie 3D Plot" + "'", str5.equals("Pie 3D Plot"));
        org.junit.Assert.assertNotNull(drawingSupplier6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Color color1 = java.awt.Color.black;
        piePlot3D0.setLabelPaint((java.awt.Paint) color1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = piePlot3D0.getLegendItems();
        java.awt.Paint paint4 = piePlot3D0.getShadowPaint();
        double double5 = piePlot3D0.getLabelGap();
        piePlot3D0.setPieIndex(4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.JFreeChart jFreeChart2 = multiplePiePlot1.getPieChart();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot1.getPieChart();
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = multiplePiePlot1.getDataset();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray12 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis11 };
        categoryPlot10.setDomainAxes(categoryAxisArray12);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = null;
        categoryPlot10.datasetChanged(datasetChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot10);
        java.awt.Color color18 = java.awt.Color.pink;
        java.lang.String str19 = color18.toString();
        java.awt.Color color20 = color18.darker();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color18, stroke21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor26 = itemLabelPosition25.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.String str28 = textAnchor27.toString();
        org.jfree.chart.axis.NumberTick numberTick30 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 1, "({0}, {1}) = {2}", textAnchor26, textAnchor27, 1.0d);
        valueMarker22.setLabelTextAnchor(textAnchor27);
        boolean boolean32 = jFreeChart16.equals((java.lang.Object) valueMarker22);
        org.jfree.chart.event.ChartProgressListener chartProgressListener33 = null;
        jFreeChart16.removeProgressListener(chartProgressListener33);
        java.awt.image.BufferedImage bufferedImage37 = jFreeChart16.createBufferedImage((int) ' ', 1);
        multiplePiePlot1.setBackgroundImage((java.awt.Image) bufferedImage37);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) (-1L));
        java.awt.Paint paint41 = multiplePiePlot1.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(jFreeChart2);
        org.junit.Assert.assertNotNull(jFreeChart3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(categoryAxisArray12);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str19.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str28.equals("TextAnchor.BOTTOM_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(bufferedImage37);
        org.junit.Assert.assertNotNull(paint41);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
//        org.jfree.chart.plot.PolarPlot polarPlot1 = new org.jfree.chart.plot.PolarPlot();
//        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
//        java.awt.geom.Point2D point2D6 = null;
//        polarPlot1.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo5, point2D6);
//        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D11 = labelBlock10.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
//        java.awt.geom.Point2D point2D19 = null;
//        categoryPlot16.zoomRangeAxes((double) (-1), plotRenderingInfo18, point2D19);
//        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot16.setRangeAxisLocation((int) ' ', axisLocation22, false);
//        float float25 = categoryPlot16.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer27 = null;
//        java.util.Collection collection28 = categoryPlot16.getRangeMarkers((int) (byte) 0, layer27);
//        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot16.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D30.setDrawOutlines(true);
//        boolean boolean33 = lineRenderer3D30.getBaseShapesVisible();
//        java.awt.Font font35 = lineRenderer3D30.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = null;
//        lineRenderer3D30.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator37, false);
//        boolean boolean40 = rectangleEdge29.equals((java.lang.Object) categoryItemLabelGenerator37);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long42 = segmentedTimeline41.getSegmentSize();
//        long long44 = segmentedTimeline41.toTimelineValue((long) (short) 0);
//        long long47 = segmentedTimeline41.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean48 = rectangleEdge29.equals((java.lang.Object) segmentedTimeline41);
//        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge29);
//        java.awt.geom.Rectangle2D rectangle2D50 = axisSpace8.reserved(rectangle2D11, rectangleEdge29);
//        plotRenderingInfo5.setDataArea(rectangle2D50);
//        boolean boolean52 = strokeList0.equals((java.lang.Object) plotRenderingInfo5);
//        org.junit.Assert.assertNotNull(rectangle2D11);
//        org.junit.Assert.assertNotNull(axisLocation22);
//        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
//        org.junit.Assert.assertNull(collection28);
//        org.junit.Assert.assertNotNull(rectangleEdge29);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(font35);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 900000L + "'", long42 == 900000L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-32400010L) + "'", long44 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge49);
//        org.junit.Assert.assertNotNull(rectangle2D50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        java.awt.Color color14 = java.awt.Color.pink;
        java.lang.String str15 = color14.toString();
        java.awt.Color color16 = color14.darker();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke17);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color14.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font11, (java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        java.awt.Stroke stroke31 = null;
        categoryPlot30.setOutlineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font11, (org.jfree.chart.plot.Plot) categoryPlot30, false);
        jFreeChart34.setBackgroundImageAlignment(100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D1, jFreeChart34);
        numberAxis3D1.setTickLabelsVisible(true);
        numberAxis3D1.setLabelAngle((double) 4);
        numberAxis3D1.setAutoRangeMinimumSize((double) 1577865599999L, true);
        numberAxis3D1.setNegativeArrowVisible(true);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset47 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset47.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset47.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47, 0);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset47);
        numberAxis3D1.setRange(range57, false, false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str15.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNotNull(range57);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone1);
        dateAxis2.setAutoTickUnitSelection(true, true);
        dateAxis2.configure();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis2.getTimeline();
        dateAxis2.setPositiveArrowVisible(true);
        java.lang.Object obj10 = dateAxis2.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
        boolean boolean16 = segmentedTimeline14.containsDomainValue(1562097599999L);
        dateAxis2.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline14);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        categoryPlot4.markerChanged(markerChangeEvent12);
        double double14 = categoryPlot4.getAnchorValue();
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = categoryPlot5.getOrientation();
        java.lang.String str9 = plotOrientation8.toString();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PlotOrientation.VERTICAL" + "'", str9.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis3D1.configure();
        numberAxis3D1.setNegativeArrowVisible(true);
        boolean boolean18 = numberAxis3D1.isAxisLineVisible();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat19);
        numberAxis3D1.setAutoRangeIncludesZero(false);
        org.jfree.data.RangeType rangeType23 = org.jfree.data.RangeType.FULL;
        numberAxis3D1.setRangeType(rangeType23);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D26.setLabelFont(font27);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = numberAxis3D26.getStandardTickUnits();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis3D26.java2DToValue((double) 0, rectangle2D31, rectangleEdge32);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = numberAxis3D26.getTickUnit();
        numberAxis3D1.setTickUnit(numberTickUnit34);
        java.awt.Color color36 = java.awt.Color.pink;
        java.lang.String str37 = color36.toString();
        boolean boolean38 = numberTickUnit34.equals((java.lang.Object) str37);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rangeType23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(numberTickUnit34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str37.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        stackedAreaRenderer1.setSeriesVisible(9, (java.lang.Boolean) true, false);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape18, stroke19, (java.awt.Paint) color20);
        stackedAreaRenderer1.setBaseShape(shape18, false);
        java.awt.Stroke stroke26 = stackedAreaRenderer1.getItemOutlineStroke((int) ' ', (-459));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(255);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D1);
        boolean boolean6 = numberAxis3D1.isInverted();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color5 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean6 = stackedBarRenderer3D2.equals((java.lang.Object) 0);
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "AxisLocation.BOTTOM_OR_LEFT", "AxisLocation.BOTTOM_OR_LEFT", "ERROR : Relative To String", shape12, stroke13, (java.awt.Paint) color14);
        java.awt.Color color16 = java.awt.Color.getColor("Pie 3D Plot", color14);
        stackedBarRenderer3D2.setWallPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test453");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
//        java.awt.geom.Point2D point2D7 = null;
//        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
//        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot4.setRangeAxisLocation((int) ' ', axisLocation10, false);
//        float float13 = categoryPlot4.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer15 = null;
//        java.util.Collection collection16 = categoryPlot4.getRangeMarkers((int) (byte) 0, layer15);
//        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot4.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D18 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D18.setDrawOutlines(true);
//        boolean boolean21 = lineRenderer3D18.getBaseShapesVisible();
//        java.awt.Font font23 = lineRenderer3D18.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
//        lineRenderer3D18.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator25, false);
//        boolean boolean28 = rectangleEdge17.equals((java.lang.Object) categoryItemLabelGenerator25);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline29 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long30 = segmentedTimeline29.getSegmentSize();
//        long long32 = segmentedTimeline29.toTimelineValue((long) (short) 0);
//        long long35 = segmentedTimeline29.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean36 = rectangleEdge17.equals((java.lang.Object) segmentedTimeline29);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline37 = segmentedTimeline29.getBaseTimeline();
//        long long38 = segmentedTimeline37.getSegmentSize();
//        java.util.List list39 = segmentedTimeline37.getExceptionSegments();
//        org.junit.Assert.assertNotNull(axisLocation10);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
//        org.junit.Assert.assertNull(collection16);
//        org.junit.Assert.assertNotNull(rectangleEdge17);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(font23);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 900000L + "'", long30 == 900000L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-32400010L) + "'", long32 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 86400000L + "'", long38 == 86400000L);
//        org.junit.Assert.assertNotNull(list39);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int4 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(10L);
        piePlot3D0.setExplodePercent((java.lang.Comparable) 10L, (double) 1900);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator9 = piePlot3D0.getToolTipGenerator();
        java.awt.Color color11 = java.awt.Color.pink;
        java.lang.String str12 = color11.toString();
        java.awt.Color color13 = color11.darker();
        java.awt.Stroke stroke14 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke14);
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color11.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        piePlot3D0.setShadowPaint((java.awt.Paint) color11);
        int int23 = color11.getTransparency();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(segmentedTimeline3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
        org.junit.Assert.assertNotNull(segment6);
        org.junit.Assert.assertNull(pieToolTipGenerator9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str12.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(68, serialDate5);
        java.lang.Comparable[] comparableArray7 = new java.lang.Comparable[] { "GradientPaintTransformType.CENTER_VERTICAL", "CategoryLabelEntity: category=2, tooltip=null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull, url=", "AreaRendererEndType.TRUNCATE", serialDate5 };
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getMiddleMillisecond();
        long long12 = year10.getMiddleMillisecond();
        java.lang.Object obj13 = null;
        int int14 = year10.compareTo(obj13);
        int int15 = year10.getYear();
        long long16 = year10.getMiddleMillisecond();
        java.lang.Comparable[] comparableArray19 = new java.lang.Comparable[] { "org.jfree.data.UnknownKeyException: ERROR : Relative To String", "AxisLocation.BOTTOM_OR_LEFT", long16, "CategoryAnchor.MIDDLE", 2.0f };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.03333333333333333d, 900000L, 100, 0.03333333333333333d, (byte) 100 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 0.03333333333333333d, 900000L, 100, 0.03333333333333333d, (byte) 100 };
        java.lang.Number[] numberArray37 = new java.lang.Number[] { 0.03333333333333333d, 900000L, 100, 0.03333333333333333d, (byte) 100 };
        java.lang.Number[] numberArray43 = new java.lang.Number[] { 0.03333333333333333d, 900000L, 100, 0.03333333333333333d, (byte) 100 };
        java.lang.Number[] numberArray49 = new java.lang.Number[] { 0.03333333333333333d, 900000L, 100, 0.03333333333333333d, (byte) 100 };
        java.lang.Number[] numberArray55 = new java.lang.Number[] { 0.03333333333333333d, 900000L, 100, 0.03333333333333333d, (byte) 100 };
        java.lang.Number[][] numberArray56 = new java.lang.Number[][] { numberArray25, numberArray31, numberArray37, numberArray43, numberArray49, numberArray55 };
        java.lang.Number[] numberArray59 = new java.lang.Number[] { 1577865599999L, (-899990L) };
        java.lang.Number[] numberArray62 = new java.lang.Number[] { 1577865599999L, (-899990L) };
        java.lang.Number[] numberArray65 = new java.lang.Number[] { 1577865599999L, (-899990L) };
        java.lang.Number[][] numberArray66 = new java.lang.Number[][] { numberArray59, numberArray62, numberArray65 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset67 = new org.jfree.data.category.DefaultIntervalCategoryDataset(comparableArray7, comparableArray19, numberArray56, numberArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(comparableArray7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertNotNull(comparableArray19);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray37);
        org.junit.Assert.assertNotNull(numberArray43);
        org.junit.Assert.assertNotNull(numberArray49);
        org.junit.Assert.assertNotNull(numberArray55);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray59);
        org.junit.Assert.assertNotNull(numberArray62);
        org.junit.Assert.assertNotNull(numberArray65);
        org.junit.Assert.assertNotNull(numberArray66);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D3.setLabelFont(font4);
        java.awt.Color color7 = java.awt.Color.pink;
        java.lang.String str8 = color7.toString();
        java.awt.Color color9 = color7.darker();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke10);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.AffineTransform affineTransform15 = null;
        java.awt.RenderingHints renderingHints16 = null;
        java.awt.PaintContext paintContext17 = color7.createContext(colorModel12, rectangle13, rectangle2D14, affineTransform15, renderingHints16);
        org.jfree.chart.text.TextBlock textBlock18 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font4, (java.awt.Paint) color7);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        java.awt.Stroke stroke24 = null;
        categoryPlot23.setOutlineStroke(stroke24);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font4, (org.jfree.chart.plot.Plot) categoryPlot23, false);
        jFreeChart27.setBackgroundImageAlignment(100);
        org.jfree.chart.title.LegendTitle legendTitle30 = jFreeChart27.getLegend();
        jFreeChart27.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str8.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paintContext17);
        org.junit.Assert.assertNotNull(textBlock18);
        org.junit.Assert.assertNull(legendTitle30);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        blockResult0.setEntityCollection(entityCollection2);
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D0.setLegendLabelURLGenerator(pieURLGenerator3);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer6.setBaseItemLabelFont(font10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = stackedAreaRenderer6.getURLGenerator(0, 3);
        java.awt.Paint paint16 = stackedAreaRenderer6.lookupSeriesPaint((int) (short) 1);
        piePlot3D0.setLabelPaint(paint16);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, (double) 10);
        java.awt.Color color24 = java.awt.Color.getColor("TextAnchor.BOTTOM_RIGHT", 0);
        boolean boolean25 = stackedBarRenderer3D21.equals((java.lang.Object) 0);
        java.awt.Paint paint26 = stackedBarRenderer3D21.getBaseOutlinePaint();
        piePlot3D0.setSectionPaint((java.lang.Comparable) 1900, paint26);
        java.awt.Stroke stroke29 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) (-0.8d));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(stroke29);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) (-1), plotRenderingInfo6, point2D7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot4.getDomainAxisLocation();
        categoryPlot4.setRangeCrosshairValue((double) 1.0f, false);
        categoryPlot4.setAnchorValue(0.0d, true);
        java.awt.Paint paint17 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font23 = categoryAxis21.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer19.setBaseItemLabelFont(font23);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = stackedAreaRenderer19.getURLGenerator(0, 3);
        stackedAreaRenderer19.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        stackedAreaRenderer19.setBaseStroke(stroke32);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100, paint17, stroke32);
        categoryPlot4.setDomainGridlineStroke(stroke32);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(categoryURLGenerator27);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Color color1 = java.awt.Color.pink;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = color1.darker();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        java.awt.Color color6 = java.awt.Color.pink;
        java.lang.String str7 = color6.toString();
        java.awt.Color color8 = color6.darker();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke9);
        valueMarker10.setAlpha((float) 0L);
        java.awt.Stroke stroke13 = valueMarker10.getStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 10, (java.awt.Paint) color1, stroke13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        java.awt.Stroke stroke20 = null;
        categoryPlot19.setOutlineStroke(stroke20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot19.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent24 = null;
        categoryPlot19.notifyListeners(plotChangeEvent24);
        boolean boolean26 = categoryMarker14.equals((java.lang.Object) plotChangeEvent24);
        categoryMarker14.setDrawAsLine(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str2.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str7.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = polarPlot0.getOrientation();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = polarPlot0.getRenderer();
        polarPlot0.setAngleGridlinesVisible(false);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNull(polarItemRenderer2);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean1 = piePlot3D0.getIgnoreNullValues();
        boolean boolean2 = piePlot3D0.getLabelLinksVisible();
        java.awt.Paint paint3 = piePlot3D0.getLabelPaint();
        java.lang.String str4 = piePlot3D0.getPlotType();
        double double5 = piePlot3D0.getLabelLinkMargin();
        piePlot3D0.setCircular(true, false);
        piePlot3D0.setMaximumLabelWidth((double) (-1));
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getMiddleMillisecond();
        long long13 = year11.getFirstMillisecond();
        java.awt.Stroke stroke14 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) long13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie 3D Plot" + "'", str4.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("HorizontalAlignment.CENTER");
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segment3.copy();
        segment4.moveIndexToEnd();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segment4.intersect((long) 12, (long) (short) -1);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNull(segment8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.awt.Stroke stroke3 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass4 = stroke3.getClass();
        java.lang.ClassLoader classLoader5 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass4);
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass4);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        java.lang.Class<?> wildcardClass9 = stroke8.getClass();
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", (java.lang.Class) wildcardClass9);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("({0}, {1}) = {2}", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass9);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(classLoader5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(classLoader10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        taskSeriesCollection0.validateObject();
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        java.awt.Color color14 = java.awt.Color.pink;
        java.lang.String str15 = color14.toString();
        java.awt.Color color16 = color14.darker();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke17);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.AffineTransform affineTransform22 = null;
        java.awt.RenderingHints renderingHints23 = null;
        java.awt.PaintContext paintContext24 = color14.createContext(colorModel19, rectangle20, rectangle2D21, affineTransform22, renderingHints23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font11, (java.awt.Paint) color14);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, categoryItemRenderer29);
        java.awt.Stroke stroke31 = null;
        categoryPlot30.setOutlineStroke(stroke31);
        org.jfree.chart.JFreeChart jFreeChart34 = new org.jfree.chart.JFreeChart("org.jfree.data.UnknownKeyException: ERROR : Relative To String", font11, (org.jfree.chart.plot.Plot) categoryPlot30, false);
        jFreeChart34.setBackgroundImageAlignment(100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis3D1, jFreeChart34);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) numberAxis3D1);
        numberAxis3D1.setRangeAboutValue(10.0d, (double) 644288400000L);
        java.awt.Color color43 = java.awt.Color.pink;
        java.lang.String str44 = color43.toString();
        java.awt.Color color45 = color43.darker();
        java.awt.Stroke stroke46 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color43, stroke46);
        valueMarker47.setAlpha((float) 0L);
        java.awt.Stroke stroke50 = valueMarker47.getStroke();
        numberAxis3D1.setAxisLineStroke(stroke50);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str15.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paintContext24);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str44.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        double double3 = size2D2.width;
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("rect");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test472");
//        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
//        java.awt.geom.Point2D point2D8 = null;
//        categoryPlot5.zoomRangeAxes((double) (-1), plotRenderingInfo7, point2D8);
//        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot5.setRangeAxisLocation((int) ' ', axisLocation11, false);
//        float float14 = categoryPlot5.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer16 = null;
//        java.util.Collection collection17 = categoryPlot5.getRangeMarkers((int) (byte) 0, layer16);
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot5.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D19 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D19.setDrawOutlines(true);
//        boolean boolean22 = lineRenderer3D19.getBaseShapesVisible();
//        java.awt.Font font24 = lineRenderer3D19.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
//        lineRenderer3D19.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator26, false);
//        boolean boolean29 = rectangleEdge18.equals((java.lang.Object) categoryItemLabelGenerator26);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long31 = segmentedTimeline30.getSegmentSize();
//        long long33 = segmentedTimeline30.toTimelineValue((long) (short) 0);
//        long long36 = segmentedTimeline30.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean37 = rectangleEdge18.equals((java.lang.Object) segmentedTimeline30);
//        org.jfree.data.KeyedObjects2D keyedObjects2D38 = new org.jfree.data.KeyedObjects2D();
//        java.awt.Paint paint39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date42 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date41, date42);
//        keyedObjects2D38.addObject((java.lang.Object) paint39, (java.lang.Comparable) (short) -1, (java.lang.Comparable) date41);
//        long long45 = segmentedTimeline30.toTimelineValue(date41);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline49 = new org.jfree.chart.axis.SegmentedTimeline(61200000L, (int) (short) 10, 2958465);
//        boolean boolean51 = segmentedTimeline49.containsDomainValue(1562097599999L);
//        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        boolean boolean53 = segmentedTimeline49.containsDomainValue(date52);
//        org.jfree.data.gantt.Task task54 = new org.jfree.data.gantt.Task("ThreadContext", date41, date52);
//        task54.setPercentComplete((java.lang.Double) 20.0d);
//        java.util.Date date57 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.Date date58 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date57, date58);
//        task54.setDuration((org.jfree.data.time.TimePeriod) simpleTimePeriod59);
//        org.junit.Assert.assertNotNull(axisLocation11);
//        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
//        org.junit.Assert.assertNull(collection17);
//        org.junit.Assert.assertNotNull(rectangleEdge18);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNull(font24);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 900000L + "'", long31 == 900000L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-32400010L) + "'", long33 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(paint39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 455057983088L + "'", long45 == 455057983088L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo4, point2D5);
        java.awt.Paint paint7 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        polarPlot0.setNoDataMessagePaint(paint7);
        polarPlot0.setRadiusGridlinesVisible(true);
        java.awt.Font font11 = polarPlot0.getAngleLabelFont();
        boolean boolean12 = polarPlot0.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        xYPlot30.datasetChanged(datasetChangeEvent31);
        java.awt.Color color34 = java.awt.Color.pink;
        java.awt.Color color35 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", color34);
        xYPlot30.setDomainTickBandPaint((java.awt.Paint) color34);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value((int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis3D1.getStandardTickUnits();
        numberAxis3D1.centerRange((double) (short) 0);
        numberAxis3D1.setAutoRangeStickyZero(true);
        float float9 = numberAxis3D1.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D11.setLabelFont(font12);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = numberAxis3D11.getStandardTickUnits();
        numberAxis3D1.setStandardTickUnits(tickUnitSource14);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(tickUnitSource14);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list1 = null;
        projectInfo0.setContributors(list1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.lang.String str5 = projectInfo0.toString();
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull" + "'", str5.equals("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer1.setBaseItemLabelFont(font5);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = stackedAreaRenderer1.getURLGenerator(0, 3);
        java.awt.Paint paint11 = stackedAreaRenderer1.lookupSeriesPaint((int) (short) 1);
        stackedAreaRenderer1.setSeriesCreateEntities((int) '#', (java.lang.Boolean) true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = stackedAreaRenderer1.getDrawingSupplier();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        java.awt.Stroke stroke22 = null;
        categoryPlot21.setOutlineStroke(stroke22);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot21.getRangeAxisForDataset((int) ' ');
        categoryPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer30 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font34 = categoryAxis32.getTickLabelFont((java.lang.Comparable) 100.0f);
        stackedAreaRenderer30.setBaseItemLabelFont(font34);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator38 = stackedAreaRenderer30.getURLGenerator(0, 3);
        java.awt.Paint paint40 = stackedAreaRenderer30.lookupSeriesPaint((int) (short) 1);
        java.awt.Font font43 = stackedAreaRenderer30.getItemLabelFont(10, 255);
        org.jfree.chart.text.TextFragment textFragment44 = new org.jfree.chart.text.TextFragment("Range[1.0,1.0]", font43);
        categoryPlot21.setNoDataMessageFont(font43);
        stackedAreaRenderer1.setSeriesItemLabelFont((int) ' ', font43, false);
        java.awt.Shape shape49 = stackedAreaRenderer1.getSeriesShape((int) (byte) 100);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(drawingSupplier15);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(categoryURLGenerator38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNull(shape49);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.data.Range range17 = new org.jfree.data.Range((double) 'a', (double) 2958465);
        numberAxis3D1.setRangeWithMargins(range17);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (byte) -1, (float) 5, (float) (-32400010L));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D2 = new org.jfree.chart.renderer.category.LineRenderer3D();
        boolean boolean4 = lineRenderer3D2.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj5 = lineRenderer3D2.clone();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = new org.jfree.chart.ui.ProjectInfo();
        java.util.List list7 = null;
        projectInfo6.setContributors(list7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D10.setLabelFont(font11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray19 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis18 };
        categoryPlot17.setDomainAxes(categoryAxisArray19);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = null;
        categoryPlot17.datasetChanged(datasetChangeEvent21);
        numberAxis3D10.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot17);
        double double24 = numberAxis3D10.getAutoRangeMinimumSize();
        boolean boolean25 = projectInfo6.equals((java.lang.Object) numberAxis3D10);
        org.jfree.data.Range range26 = numberAxis3D10.getRange();
        boolean boolean27 = lineRenderer3D2.equals((java.lang.Object) numberAxis3D10);
        double double28 = numberAxis3D10.getAutoRangeMinimumSize();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer29);
        xYPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        xYPlot30.setRenderer(0, xYItemRenderer34, true);
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D37 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D37.setDrawOutlines(true);
        boolean boolean40 = lineRenderer3D37.getBaseShapesVisible();
        java.awt.Font font42 = lineRenderer3D37.getSeriesItemLabelFont(3);
        org.jfree.chart.LegendItem legendItem45 = lineRenderer3D37.getLegendItem((int) ' ', 100);
        java.awt.Stroke stroke47 = lineRenderer3D37.lookupSeriesStroke(10);
        xYPlot30.setDomainCrosshairStroke(stroke47);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot30.getRangeAxisForDataset((int) (short) 0);
        valueAxis50.setAutoTickUnitSelection(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryAxisArray19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0E-8d + "'", double28 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(font42);
        org.junit.Assert.assertNull(legendItem45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(valueAxis50);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot4.setRangeAxisLocation((int) (short) 10, axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D1 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D1.setDrawOutlines(true);
        lineRenderer3D1.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        java.awt.Stroke stroke13 = null;
        categoryPlot12.setOutlineStroke(stroke13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot12.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getRangeAxisEdge(0);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot12.setOutlineStroke(stroke19);
        lineRenderer3D1.setSeriesOutlineStroke(3, stroke19, false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes((double) (-1), plotRenderingInfo29, point2D30);
        float float32 = categoryPlot27.getForegroundAlpha();
        lineRenderer3D1.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        boolean boolean34 = blockContainer0.equals((java.lang.Object) lineRenderer3D1);
        blockContainer0.setHeight(Double.NaN);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.util.Size2D size2D38 = blockContainer0.arrange(graphics2D37);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(size2D38);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot4.setDomainAxes(categoryAxisArray6);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent8);
        java.awt.Stroke stroke10 = categoryPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY(0.05d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo(entityCollection2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        polarPlot0.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo4, point2D5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D8.setLabelFont(font9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray17 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis16 };
        categoryPlot15.setDomainAxes(categoryAxisArray17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        categoryPlot15.datasetChanged(datasetChangeEvent19);
        numberAxis3D8.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot15);
        double double22 = numberAxis3D8.getAutoRangeMinimumSize();
        numberAxis3D8.resizeRange((double) 9);
        double double25 = numberAxis3D8.getLowerBound();
        org.jfree.data.Range range26 = polarPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D8);
        java.lang.Object obj27 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(categoryAxisArray17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-4.0d) + "'", double25 == (-4.0d));
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(obj27);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test488");
//        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 1);
//        axisState1.cursorUp((double) 1546329600000L);
//        axisState1.cursorLeft(1.0E-5d);
//        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
//        java.awt.geom.Point2D point2D14 = null;
//        categoryPlot11.zoomRangeAxes((double) (-1), plotRenderingInfo13, point2D14);
//        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot11.setRangeAxisLocation((int) ' ', axisLocation17, false);
//        float float20 = categoryPlot11.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer22 = null;
//        java.util.Collection collection23 = categoryPlot11.getRangeMarkers((int) (byte) 0, layer22);
//        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot11.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D25 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D25.setDrawOutlines(true);
//        boolean boolean28 = lineRenderer3D25.getBaseShapesVisible();
//        java.awt.Font font30 = lineRenderer3D25.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator32 = null;
//        lineRenderer3D25.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator32, false);
//        boolean boolean35 = rectangleEdge24.equals((java.lang.Object) categoryItemLabelGenerator32);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long37 = segmentedTimeline36.getSegmentSize();
//        long long39 = segmentedTimeline36.toTimelineValue((long) (short) 0);
//        long long42 = segmentedTimeline36.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean43 = rectangleEdge24.equals((java.lang.Object) segmentedTimeline36);
//        axisState1.moveCursor((double) (byte) 0, rectangleEdge24);
//        axisState1.setCursor(0.0d);
//        org.junit.Assert.assertNotNull(axisLocation17);
//        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
//        org.junit.Assert.assertNull(collection23);
//        org.junit.Assert.assertNotNull(rectangleEdge24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNull(font30);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 900000L + "'", long37 == 900000L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-32400010L) + "'", long39 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = piePlot1.getBaseSectionOutlinePaint();
        java.awt.Paint paint3 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D2.setLabelFont(font3);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis3D2.getStandardTickUnits();
        numberAxis3D2.centerRange((double) (short) 0);
        numberAxis3D2.setAutoRangeStickyZero(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D16.setLabelFont(font17);
        java.awt.Color color20 = java.awt.Color.pink;
        java.lang.String str21 = color20.toString();
        java.awt.Color color22 = color20.darker();
        java.awt.Stroke stroke23 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke23);
        java.awt.image.ColorModel colorModel25 = null;
        java.awt.Rectangle rectangle26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.AffineTransform affineTransform28 = null;
        java.awt.RenderingHints renderingHints29 = null;
        java.awt.PaintContext paintContext30 = color20.createContext(colorModel25, rectangle26, rectangle2D27, affineTransform28, renderingHints29);
        org.jfree.chart.text.TextBlock textBlock31 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", font17, (java.awt.Paint) color20);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D2, (double) (short) 1, (double) (byte) 10, (double) 1900, (double) (byte) 1, font17);
        numberAxis3D2.setAutoRange(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Font font38 = categoryAxis36.getTickLabelFont((java.lang.Comparable) 100.0f);
        numberAxis3D2.setLabelFont(font38);
        java.awt.Paint paint40 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        numberAxis3D2.setAxisLinePaint(paint40);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("org.jfree.data.UnknownKeyException: ERROR : Relative To String", timeZone43);
        dateAxis44.setAutoTickUnitSelection(true, true);
        dateAxis44.configure();
        org.jfree.chart.axis.Timeline timeline49 = dateAxis44.getTimeline();
        dateAxis44.setPositiveArrowVisible(true);
        java.text.DateFormat dateFormat52 = null;
        dateAxis44.setDateFormatOverride(dateFormat52);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer54);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=255,g=175,b=175]" + "'", str21.equals("java.awt.Color[r=255,g=175,b=175]"));
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paintContext30);
        org.junit.Assert.assertNotNull(textBlock31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(timeline49);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D1.setLabelFont(font2);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis9 };
        categoryPlot8.setDomainAxes(categoryAxisArray10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        categoryPlot8.datasetChanged(datasetChangeEvent12);
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = numberAxis3D1.getTickLabelInsets();
        double double17 = rectangleInsets15.calculateLeftOutset((double) 10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.0d, (double) 1L);
        size2D2.height = (byte) 1;
        double double5 = size2D2.height;
        double double6 = size2D2.height;
        double double7 = size2D2.getHeight();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.renderer.category.BoxAndWhiskerRenderer boxAndWhiskerRenderer0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
        boxAndWhiskerRenderer0.setFillBox(false);
        double double3 = boxAndWhiskerRenderer0.getItemMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        boolean boolean7 = piePlot3D6.getIgnoreNullValues();
        boolean boolean8 = piePlot3D6.getLabelLinksVisible();
        java.awt.Paint paint9 = piePlot3D6.getBaseSectionOutlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem(attributedString0, "TextAnchor.BOTTOM_RIGHT", "hi!", "DateTickMarkPosition.MIDDLE", shape4, stroke5, paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1L), (java.lang.Comparable) 2.0d);
        defaultCategoryDataset0.setValue((double) (short) -1, (java.lang.Comparable) '4', (java.lang.Comparable) 0.0d);
        java.util.List list8 = defaultCategoryDataset0.getColumnKeys();
        try {
            java.util.Collection collection9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list8);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        java.awt.Stroke stroke5 = null;
        categoryPlot4.setOutlineStroke(stroke5);
        org.jfree.chart.axis.ValueAxis valueAxis8 = categoryPlot4.getRangeAxisForDataset((int) ' ');
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot4.getRangeAxisEdge(0);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot4.setOutlineStroke(stroke11);
        java.util.List list13 = categoryPlot4.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot4.getDomainAxisEdge();
        categoryPlot4.clearRangeAxes();
        org.junit.Assert.assertNull(valueAxis8);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test498");
//        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
//        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
//        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
//        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("Range[1.0,1.0]");
//        java.awt.geom.Rectangle2D rectangle2D5 = labelBlock4.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
//        java.awt.geom.Point2D point2D13 = null;
//        categoryPlot10.zoomRangeAxes((double) (-1), plotRenderingInfo12, point2D13);
//        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        categoryPlot10.setRangeAxisLocation((int) ' ', axisLocation16, false);
//        float float19 = categoryPlot10.getBackgroundAlpha();
//        org.jfree.chart.util.Layer layer21 = null;
//        java.util.Collection collection22 = categoryPlot10.getRangeMarkers((int) (byte) 0, layer21);
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot10.getRangeAxisEdge();
//        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D24 = new org.jfree.chart.renderer.category.LineRenderer3D();
//        lineRenderer3D24.setDrawOutlines(true);
//        boolean boolean27 = lineRenderer3D24.getBaseShapesVisible();
//        java.awt.Font font29 = lineRenderer3D24.getSeriesItemLabelFont(3);
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = null;
//        lineRenderer3D24.setSeriesItemLabelGenerator((int) 'a', categoryItemLabelGenerator31, false);
//        boolean boolean34 = rectangleEdge23.equals((java.lang.Object) categoryItemLabelGenerator31);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline35 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        long long36 = segmentedTimeline35.getSegmentSize();
//        long long38 = segmentedTimeline35.toTimelineValue((long) (short) 0);
//        long long41 = segmentedTimeline35.getExceptionSegmentCount((long) (byte) 1, 61200000L);
//        boolean boolean42 = rectangleEdge23.equals((java.lang.Object) segmentedTimeline35);
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge23);
//        java.awt.geom.Rectangle2D rectangle2D44 = axisSpace2.reserved(rectangle2D5, rectangleEdge23);
//        chartRenderingInfo1.setChartArea(rectangle2D44);
//        org.jfree.chart.entity.EntityCollection entityCollection46 = null;
//        chartRenderingInfo1.setEntityCollection(entityCollection46);
//        org.junit.Assert.assertNotNull(rectangle2D5);
//        org.junit.Assert.assertNotNull(axisLocation16);
//        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
//        org.junit.Assert.assertNull(collection22);
//        org.junit.Assert.assertNotNull(rectangleEdge23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNull(font29);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(segmentedTimeline35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 900000L + "'", long36 == 900000L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-32400010L) + "'", long38 == (-32400010L));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertNotNull(rectangle2D44);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setTickMarkOutsideLength(1.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset(2.0d);
        double double4 = rectangleInsets0.calculateLeftOutset((double) (short) 0);
        double double6 = rectangleInsets0.extendWidth(12.0d);
        double double8 = rectangleInsets0.trimWidth((double) 86400000L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 20.0d + "'", double6 == 20.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.6399992E7d + "'", double8 == 8.6399992E7d);
    }
}

