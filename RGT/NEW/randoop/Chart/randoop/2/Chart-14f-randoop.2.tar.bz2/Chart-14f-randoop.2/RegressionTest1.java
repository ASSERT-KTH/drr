import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource6);
        numberAxis1.setAutoRange(false);
        double double10 = numberAxis1.getFixedDimension();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis1);
        java.lang.String str12 = chartChangeEvent11.toString();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        chartChangeEvent11.setChart(jFreeChart13);
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        chartChangeEvent11.setChart(jFreeChart15);
        java.lang.Object obj17 = chartChangeEvent11.getSource();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        java.awt.Paint paint33 = xYPlot29.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot29.getRangeAxisLocation((int) (byte) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot29.zoomDomainAxes((double) (byte) -1, (double) (byte) 10, plotRenderingInfo38, point2D39);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        valueMarker1.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint6 = valueMarker1.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke9 = numberAxis8.getTickMarkStroke();
        valueMarker1.setOutlineStroke(stroke9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        numberAxis12.setPositiveArrowVisible(true);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis12.setTickMarkStroke(stroke18);
        valueMarker1.setStroke(stroke18);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str23 = numberAxis22.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        double double26 = numberAxis22.getLowerMargin();
        java.awt.Font font27 = numberAxis22.getLabelFont();
        valueMarker1.setLabelFont(font27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = valueMarker1.getLabelAnchor();
        double double30 = valueMarker1.getValue();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 10.0d + "'", double30 == 10.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        boolean boolean6 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis1.setMarkerBand(markerAxisBand7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        java.awt.Color color13 = java.awt.Color.orange;
        java.awt.Color color14 = java.awt.Color.getColor("", color13);
        numberAxis10.setLabelPaint((java.awt.Paint) color14);
        numberAxis10.resizeRange(0.0d);
        numberAxis10.setRangeAboutValue((double) (short) 100, (double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str23 = numberAxis22.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        double double26 = numberAxis22.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis22.setStandardTickUnits(tickUnitSource27);
        numberAxis22.setAutoRange(false);
        org.jfree.data.Range range31 = numberAxis22.getDefaultAutoRange();
        org.jfree.data.Range range32 = numberAxis22.getRange();
        numberAxis10.setRange(range32, true, false);
        java.awt.Shape shape36 = numberAxis10.getDownArrow();
        numberAxis1.setRightArrow(shape36);
        double double38 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        double double4 = categoryAxis0.getLowerMargin();
        double double5 = categoryAxis0.getCategoryMargin();
        float float6 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        boolean boolean64 = xYPlot29.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot29.getRangeAxisEdge((int) (short) -1);
        xYPlot29.configureDomainAxes();
        xYPlot29.mapDatasetToDomainAxis(4, (int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = valueMarker73.getLabelAnchor();
        java.lang.String str75 = valueMarker73.getLabel();
        valueMarker73.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint78 = valueMarker73.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke81 = numberAxis80.getTickMarkStroke();
        valueMarker73.setOutlineStroke(stroke81);
        valueMarker73.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker73.setLabelAnchor(rectangleAnchor85);
        org.jfree.chart.util.Layer layer87 = null;
        boolean boolean89 = xYPlot29.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) valueMarker73, layer87, false);
        xYPlot29.setRangeCrosshairValue((double) (short) 10);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder44);
        categoryPlot19.setColumnRenderingOrder(sortOrder44);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot19.setDomainAxis(2019, categoryAxis48, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        java.util.List list52 = categoryPlot19.getCategoriesForAxis(categoryAxis51);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str55 = numberAxis54.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis54.setMarkerBand(markerAxisBand56);
        double double58 = numberAxis54.getLowerMargin();
        java.lang.Object obj59 = numberAxis54.clone();
        numberAxis54.setNegativeArrowVisible(false);
        numberAxis54.setVisible(false);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str67 = numberAxis66.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand68 = null;
        numberAxis66.setMarkerBand(markerAxisBand68);
        numberAxis66.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis66.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        org.jfree.chart.axis.AxisSpace axisSpace76 = null;
        org.jfree.chart.axis.AxisSpace axisSpace77 = numberAxis54.reserveSpace(graphics2D64, (org.jfree.chart.plot.Plot) categoryPlot72, rectangle2D74, rectangleEdge75, axisSpace76);
        categoryPlot72.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = categoryPlot72.getRenderer();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot72);
        boolean boolean81 = categoryPlot19.isDomainZoomable();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(axisSpace77);
        org.junit.Assert.assertNull(categoryItemRenderer79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        java.awt.Paint paint64 = xYPlot29.getRangeCrosshairPaint();
        java.awt.Paint paint65 = xYPlot29.getDomainGridlinePaint();
        float float66 = xYPlot29.getBackgroundAlpha();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 1.0f + "'", float66 == 1.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = xYPlot29.getDatasetRenderingOrder();
        boolean boolean31 = xYPlot29.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        boolean boolean64 = xYPlot29.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot29.getRangeAxisEdge((int) (short) -1);
        xYPlot29.configureDomainAxes();
        xYPlot29.mapDatasetToDomainAxis(4, (int) (short) 0);
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = valueMarker73.getLabelAnchor();
        java.lang.String str75 = valueMarker73.getLabel();
        valueMarker73.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint78 = valueMarker73.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke81 = numberAxis80.getTickMarkStroke();
        valueMarker73.setOutlineStroke(stroke81);
        valueMarker73.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker73.setLabelAnchor(rectangleAnchor85);
        org.jfree.chart.util.Layer layer87 = null;
        boolean boolean89 = xYPlot29.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) valueMarker73, layer87, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        java.awt.geom.Point2D point2D92 = null;
        xYPlot29.zoomRangeAxes((double) (-1L), plotRenderingInfo91, point2D92, false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = valueMarker17.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor19 = valueMarker17.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker17.setLabelOffset(rectangleInsets20);
        java.awt.Stroke stroke22 = valueMarker17.getStroke();
        boolean boolean23 = categoryPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker17);
        categoryPlot7.setWeight(200);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Stroke stroke63 = xYPlot29.getRangeGridlineStroke();
        java.awt.Stroke stroke64 = xYPlot29.getRangeZeroBaselineStroke();
        int int65 = xYPlot29.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 15 + "'", int65 == 15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        double double11 = numberAxis7.getLowerMargin();
        java.lang.Object obj12 = numberAxis7.clone();
        java.lang.String str13 = numberAxis7.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit14, true, false);
        numberAxis1.setTickUnit(numberTickUnit14, false, true);
        float float21 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis1.setMarkerBand(markerAxisBand22);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = valueMarker25.getLabelAnchor();
        java.lang.String str27 = valueMarker25.getLabel();
        valueMarker25.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker25.setLabelOffset(rectangleInsets30);
        numberAxis1.setTickLabelInsets(rectangleInsets30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str38 = numberAxis37.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis37.setMarkerBand(markerAxisBand39);
        double double41 = numberAxis37.getLowerMargin();
        java.lang.Object obj42 = numberAxis37.clone();
        java.text.NumberFormat numberFormat43 = null;
        numberAxis37.setNumberFormatOverride(numberFormat43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str47 = numberAxis46.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        numberAxis46.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis46.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        categoryPlot52.setDataset(categoryDataset54);
        org.jfree.data.category.CategoryDataset categoryDataset57 = categoryPlot52.getDataset(0);
        categoryPlot52.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean60 = numberAxis37.hasListener((java.util.EventListener) categoryPlot52);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer61);
        xYPlot62.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str69 = numberAxis68.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = null;
        numberAxis68.setMarkerBand(markerAxisBand70);
        double double72 = numberAxis68.getLowerMargin();
        java.lang.Object obj73 = numberAxis68.clone();
        numberAxis68.setNegativeArrowVisible(false);
        numberAxis68.setVisible(false);
        java.awt.Graphics2D graphics2D78 = null;
        org.jfree.chart.axis.NumberAxis numberAxis80 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str81 = numberAxis80.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand82 = null;
        numberAxis80.setMarkerBand(markerAxisBand82);
        numberAxis80.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot86 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis80.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot86);
        java.awt.geom.Rectangle2D rectangle2D88 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge89 = null;
        org.jfree.chart.axis.AxisSpace axisSpace90 = null;
        org.jfree.chart.axis.AxisSpace axisSpace91 = numberAxis68.reserveSpace(graphics2D78, (org.jfree.chart.plot.Plot) categoryPlot86, rectangle2D88, rectangleEdge89, axisSpace90);
        categoryPlot86.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis93 = null;
        java.util.List list94 = categoryPlot86.getCategoriesForAxis(categoryAxis93);
        xYPlot62.drawDomainTickBands(graphics2D65, rectangle2D66, list94);
        org.jfree.chart.axis.ValueAxis valueAxis96 = xYPlot62.getRangeAxis();
        java.awt.Paint paint97 = xYPlot62.getRangeCrosshairPaint();
        java.awt.Paint paint98 = xYPlot62.getDomainGridlinePaint();
        boolean boolean99 = rectangleInsets30.equals((java.lang.Object) xYPlot62);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.05d + "'", double72 == 0.05d);
        org.junit.Assert.assertNotNull(obj73);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(axisSpace91);
        org.junit.Assert.assertNotNull(list94);
        org.junit.Assert.assertNotNull(valueAxis96);
        org.junit.Assert.assertNotNull(paint97);
        org.junit.Assert.assertNotNull(paint98);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        boolean boolean64 = xYPlot29.isRangeGridlinesVisible();
        java.awt.Paint paint65 = xYPlot29.getDomainGridlinePaint();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
//        categoryAxis0.setCategoryLabelPositionOffset(5);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.lang.String str5 = day4.toString();
//        long long6 = day4.getFirstMillisecond();
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = dateAxis7.getTickUnit();
//        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
//        boolean boolean10 = dateAxis7.equals((java.lang.Object) font9);
//        categoryAxis0.setTickLabelFont((java.lang.Comparable) long6, font9);
//        org.junit.Assert.assertNotNull(categoryLabelPositions1);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(dateTickUnit8);
//        org.junit.Assert.assertNotNull(font9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot7.setRenderer(categoryItemRenderer16);
        categoryPlot7.setAnchorValue(4.0d);
        float float20 = categoryPlot7.getBackgroundAlpha();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis10.setMarkerBand(markerAxisBand12);
        numberAxis10.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot16.setDataset(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot16.getDataset(0);
        categoryPlot16.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean24 = numberAxis1.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = valueMarker27.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        java.awt.Color color33 = java.awt.Color.orange;
        java.awt.Color color34 = java.awt.Color.getColor("", color33);
        numberAxis30.setLabelPaint((java.awt.Paint) color34);
        valueMarker27.setOutlinePaint((java.awt.Paint) color34);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean39 = categoryPlot16.removeDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker27, layer37, false);
        org.jfree.chart.text.TextAnchor textAnchor40 = valueMarker27.getLabelTextAnchor();
        java.lang.Object obj41 = valueMarker27.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double44 = rectangleInsets42.calculateTopInset(1.0E-8d);
        org.jfree.chart.util.UnitType unitType45 = rectangleInsets42.getUnitType();
        org.jfree.chart.util.UnitType unitType46 = rectangleInsets42.getUnitType();
        valueMarker27.setLabelOffset(rectangleInsets42);
        double double49 = rectangleInsets42.calculateBottomInset((double) (-1L));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(unitType45);
        org.junit.Assert.assertNotNull(unitType46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int3 = java.awt.Color.HSBtoRGB((float) 12, (float) 5, (float) 100L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3695) + "'", int3 == (-3695));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.CrosshairState crosshairState34 = null;
        boolean boolean35 = xYPlot29.render(graphics2D30, rectangle2D31, 8, plotRenderingInfo33, crosshairState34);
        xYPlot29.setDomainZeroBaselineVisible(false);
        double double38 = xYPlot29.getDomainCrosshairValue();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = valueMarker32.getLabelAnchor();
        java.lang.String str34 = valueMarker32.getLabel();
        valueMarker32.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str37 = valueMarker32.getLabel();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot29.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker32, layer38, true);
        java.awt.Stroke stroke41 = xYPlot29.getDomainGridlineStroke();
        xYPlot29.mapDatasetToDomainAxis(0, (int) (byte) 1);
        try {
            xYPlot29.setBackgroundImageAlpha((float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str37.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset(100);
        double double3 = categoryAxis0.getCategoryMargin();
        categoryAxis0.setCategoryMargin(0.0d);
        int int6 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis31.setMarkerBand(markerAxisBand33);
        double double35 = numberAxis31.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str38 = numberAxis37.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis37.setMarkerBand(markerAxisBand39);
        double double41 = numberAxis37.getLowerMargin();
        java.lang.Object obj42 = numberAxis37.clone();
        java.lang.String str43 = numberAxis37.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis37.setTickUnit(numberTickUnit44, true, false);
        numberAxis31.setTickUnit(numberTickUnit44, false, true);
        java.awt.Shape shape51 = numberAxis31.getLeftArrow();
        numberAxis4.setUpArrow(shape51);
        boolean boolean53 = numberAxis4.isInverted();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0L, 0.0d);
        intervalMarker2.setEndValue((double) (short) 10);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke7);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis1.setMarkerBand(markerAxisBand9);
        numberAxis1.setLabelAngle((double) 100);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        double double18 = numberAxis14.getLowerMargin();
        java.lang.Object obj19 = numberAxis14.clone();
        numberAxis14.setNegativeArrowVisible(false);
        numberAxis14.setVisible(false);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis26.setMarkerBand(markerAxisBand28);
        numberAxis26.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis26.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot32);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        org.jfree.chart.axis.AxisSpace axisSpace37 = numberAxis14.reserveSpace(graphics2D24, (org.jfree.chart.plot.Plot) categoryPlot32, rectangle2D34, rectangleEdge35, axisSpace36);
        float float38 = categoryPlot32.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        categoryPlot32.setRenderer(categoryItemRenderer39, false);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis43.setMarkerBand(markerAxisBand45);
        numberAxis43.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis43.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        categoryPlot49.setDataset(categoryDataset51);
        org.jfree.data.category.CategoryDataset categoryDataset54 = categoryPlot49.getDataset(0);
        categoryPlot49.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder57 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot49.setRowRenderingOrder(sortOrder57);
        categoryPlot32.setRowRenderingOrder(sortOrder57);
        org.jfree.chart.axis.ValueAxis valueAxis60 = categoryPlot32.getRangeAxis();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot32);
        org.jfree.chart.axis.ValueAxis valueAxis62 = categoryPlot32.getRangeAxis();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(axisSpace37);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.5f + "'", float38 == 0.5f);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(categoryDataset54);
        org.junit.Assert.assertNotNull(sortOrder57);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNull(valueAxis62);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        double double21 = numberAxis17.getLowerMargin();
        java.lang.Object obj22 = numberAxis17.clone();
        numberAxis17.setNegativeArrowVisible(false);
        numberAxis17.setVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        org.jfree.chart.axis.AxisSpace axisSpace40 = numberAxis17.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot35, rectangle2D37, rectangleEdge38, axisSpace39);
        categoryPlot7.setFixedRangeAxisSpace(axisSpace40, true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot7.getRangeAxis();
        java.awt.Color color44 = java.awt.Color.orange;
        java.awt.Color color45 = color44.darker();
        java.awt.Color color46 = color44.darker();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color46);
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str53 = numberAxis52.getLabelURL();
        java.awt.Color color55 = java.awt.Color.orange;
        java.awt.Color color56 = java.awt.Color.getColor("", color55);
        numberAxis52.setLabelPaint((java.awt.Paint) color56);
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor60 = valueMarker59.getLabelAnchor();
        java.lang.String str61 = valueMarker59.getLabel();
        valueMarker59.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str64 = valueMarker59.getLabel();
        java.awt.Stroke stroke65 = valueMarker59.getStroke();
        java.awt.Color color66 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker68 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = valueMarker68.getLabelAnchor();
        java.lang.String str70 = valueMarker68.getLabel();
        valueMarker68.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint73 = valueMarker68.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis75 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke76 = numberAxis75.getTickMarkStroke();
        valueMarker68.setOutlineStroke(stroke76);
        org.jfree.chart.plot.IntervalMarker intervalMarker79 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color56, stroke65, (java.awt.Paint) color66, stroke76, 0.0f);
        java.awt.Color color80 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        intervalMarker79.setLabelPaint((java.awt.Paint) color80);
        double double82 = intervalMarker79.getEndValue();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType83 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.Object obj84 = null;
        boolean boolean85 = lengthAdjustmentType83.equals(obj84);
        intervalMarker79.setLabelOffsetType(lengthAdjustmentType83);
        boolean boolean87 = categoryPlot7.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker79);
        org.jfree.chart.axis.CategoryAxis categoryAxis88 = categoryPlot7.getDomainAxis();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(axisSpace40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(rectangleAnchor60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str64.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(rectangleAnchor69);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNull(categoryAxis88);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        numberAxis4.setNegativeArrowVisible(false);
        numberAxis4.setVisible(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis16.setMarkerBand(markerAxisBand18);
        numberAxis16.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        org.jfree.chart.axis.AxisSpace axisSpace27 = numberAxis4.reserveSpace(graphics2D14, (org.jfree.chart.plot.Plot) categoryPlot22, rectangle2D24, rectangleEdge25, axisSpace26);
        float float28 = categoryPlot22.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot22.setRenderer(categoryItemRenderer29, false);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis33.setMarkerBand(markerAxisBand35);
        numberAxis33.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        categoryPlot39.setDataset(categoryDataset41);
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot39.getDataset(0);
        categoryPlot39.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder47 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot39.setRowRenderingOrder(sortOrder47);
        categoryPlot22.setColumnRenderingOrder(sortOrder47);
        org.jfree.chart.LegendItemCollection legendItemCollection50 = categoryPlot22.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot22.setDomainAxis(12, categoryAxis52);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double57 = rectangleInsets55.calculateTopInset(1.0E-8d);
        org.jfree.chart.util.UnitType unitType58 = rectangleInsets55.getUnitType();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color60 = java.awt.Color.orange;
        java.awt.Color color61 = color60.darker();
        java.awt.color.ColorSpace colorSpace62 = color60.getColorSpace();
        float[] floatArray67 = new float[] { (-1L), 1.0f, (-1.0f), (short) 1 };
        float[] floatArray68 = color59.getColorComponents(colorSpace62, floatArray67);
        boolean boolean69 = rectangleInsets55.equals((java.lang.Object) color59);
        double double71 = rectangleInsets55.calculateTopOutset((double) 2019);
        double double73 = rectangleInsets55.calculateLeftOutset((double) 100L);
        categoryPlot22.setInsets(rectangleInsets55, true);
        double double77 = rectangleInsets55.trimWidth(1.05d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertNotNull(sortOrder47);
        org.junit.Assert.assertNotNull(legendItemCollection50);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertNotNull(unitType58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(colorSpace62);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 2.0d + "'", double71 == 2.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 4.0d + "'", double73 == 4.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + (-6.95d) + "'", double77 == (-6.95d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        java.awt.Paint paint64 = xYPlot29.getRangeCrosshairPaint();
        java.awt.Stroke stroke65 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot29.setDomainZeroBaselineStroke(stroke65);
        java.awt.Paint paint67 = xYPlot29.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = valueMarker17.getLabelAnchor();
        java.lang.String str19 = valueMarker17.getLabel();
        valueMarker17.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker17.setLabelOffset(rectangleInsets22);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker17, layer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot7.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot7.getRangeAxisLocation();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYItemRenderer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis10.setMarkerBand(markerAxisBand12);
        numberAxis10.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot16.setDataset(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot16.getDataset(0);
        categoryPlot16.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean24 = numberAxis1.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = valueMarker27.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        java.awt.Color color33 = java.awt.Color.orange;
        java.awt.Color color34 = java.awt.Color.getColor("", color33);
        numberAxis30.setLabelPaint((java.awt.Paint) color34);
        valueMarker27.setOutlinePaint((java.awt.Paint) color34);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean39 = categoryPlot16.removeDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker27, layer37, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        try {
            categoryPlot16.handleClick(200, (int) (short) 100, plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot7.setRenderer(categoryItemRenderer16);
        categoryPlot7.setAnchorValue(4.0d);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot7.getRangeAxisLocation((int) (short) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        dateAxis0.configure();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getEnd();
//        dateAxis0.setMinimumDate(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        long long6 = day5.getSerialIndex();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43629L + "'", long6 == 43629L);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 1, 0, (int) ' ');
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(1.0E-8d);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets0.getUnitType();
        double double6 = rectangleInsets0.calculateLeftOutset((double) 11);
        double double8 = rectangleInsets0.calculateRightInset(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        numberAxis3.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        java.lang.String str12 = valueMarker10.getLabel();
        valueMarker10.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str15 = valueMarker10.getLabel();
        java.awt.Stroke stroke16 = valueMarker10.getStroke();
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        java.lang.String str21 = valueMarker19.getLabel();
        valueMarker19.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint24 = valueMarker19.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke27 = numberAxis26.getTickMarkStroke();
        valueMarker19.setOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color7, stroke16, (java.awt.Paint) color17, stroke27, 0.0f);
        intervalMarker30.setEndValue((double) (-1));
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = intervalMarker30.getGradientPaintTransformer();
        java.lang.String str34 = intervalMarker30.getLabel();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str15.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(gradientPaintTransformer33);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer8);
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        numberAxis14.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot20.zoomDomainAxes((double) (short) 100, plotRenderingInfo23, point2D24, true);
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot20.getFixedDomainAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker30.getLabelAnchor();
        java.lang.String str32 = valueMarker30.getLabel();
        valueMarker30.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint35 = valueMarker30.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke38 = numberAxis37.getTickMarkStroke();
        valueMarker30.setOutlineStroke(stroke38);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str42 = numberAxis41.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand43 = null;
        numberAxis41.setMarkerBand(markerAxisBand43);
        numberAxis41.setPositiveArrowVisible(true);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis41.setTickMarkStroke(stroke47);
        valueMarker30.setStroke(stroke47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean52 = categoryPlot20.removeRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker30, layer50, true);
        boolean boolean53 = categoryPlot9.removeRangeMarker(1, (org.jfree.chart.plot.Marker) valueMarker12, layer50);
        float float54 = valueMarker12.getAlpha();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 0.8f + "'", float54 == 0.8f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot29.getRangeMarkers((int) (byte) 10, layer35);
        xYPlot29.setDomainZeroBaselineVisible(false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = valueMarker17.getLabelAnchor();
        java.lang.String str19 = valueMarker17.getLabel();
        valueMarker17.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker17.setLabelOffset(rectangleInsets22);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker17, layer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot7.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker29.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor31 = valueMarker29.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker29.setLabelOffset(rectangleInsets32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str39 = numberAxis38.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = null;
        numberAxis38.setMarkerBand(markerAxisBand40);
        double double42 = numberAxis38.getLowerMargin();
        java.lang.Object obj43 = numberAxis38.clone();
        java.text.NumberFormat numberFormat44 = null;
        numberAxis38.setNumberFormatOverride(numberFormat44);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        categoryPlot53.setDataset(categoryDataset55);
        org.jfree.data.category.CategoryDataset categoryDataset58 = categoryPlot53.getDataset(0);
        categoryPlot53.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean61 = numberAxis38.hasListener((java.util.EventListener) categoryPlot53);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis38, xYItemRenderer62);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder64 = xYPlot63.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = valueMarker67.getLabelAnchor();
        java.lang.String str69 = valueMarker67.getLabel();
        valueMarker67.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.Layer layer72 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean73 = xYPlot63.removeRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker67, layer72);
        java.lang.String str74 = layer72.toString();
        categoryPlot7.addRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker29, layer72, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder77 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str78 = datasetRenderingOrder77.toString();
        categoryPlot7.setDatasetRenderingOrder(datasetRenderingOrder77);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.05d + "'", double42 == 0.05d);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder64);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertNotNull(layer72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "Layer.FOREGROUND" + "'", str74.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(datasetRenderingOrder77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str78.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        boolean boolean63 = xYPlot29.isOutlineVisible();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.lengthToJava2D((double) (short) 100, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis12.getLowerMargin();
        org.jfree.data.Range range17 = numberAxis12.getRange();
        numberAxis1.setRange(range17, true, false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.lang.String str8 = valueMarker6.getLabel();
        valueMarker6.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint11 = valueMarker6.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke14 = numberAxis13.getTickMarkStroke();
        valueMarker6.setOutlineStroke(stroke14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        numberAxis17.setPositiveArrowVisible(true);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis17.setTickMarkStroke(stroke23);
        valueMarker6.setStroke(stroke23);
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] { stroke4, stroke23 };
        java.awt.Stroke[] strokeArray27 = null;
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray26, strokeArray27, shapeArray28);
        java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextStroke();
        java.awt.Paint paint31 = defaultDrawingSupplier29.getNextPaint();
        java.awt.Paint paint32 = defaultDrawingSupplier29.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke7);
        boolean boolean9 = numberAxis1.isInverted();
        numberAxis1.setRange((double) 0, (double) 0L);
        double double13 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        java.awt.Paint paint64 = xYPlot29.getRangeCrosshairPaint();
        java.awt.Paint paint65 = xYPlot29.getDomainGridlinePaint();
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        xYPlot29.drawBackgroundImage(graphics2D66, rectangle2D67);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis31.setMarkerBand(markerAxisBand33);
        double double35 = numberAxis31.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str38 = numberAxis37.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis37.setMarkerBand(markerAxisBand39);
        double double41 = numberAxis37.getLowerMargin();
        java.lang.Object obj42 = numberAxis37.clone();
        java.lang.String str43 = numberAxis37.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis37.setTickUnit(numberTickUnit44, true, false);
        numberAxis31.setTickUnit(numberTickUnit44, false, true);
        java.awt.Shape shape51 = numberAxis31.getLeftArrow();
        numberAxis4.setUpArrow(shape51);
        java.awt.Shape shape53 = numberAxis4.getLeftArrow();
        numberAxis4.setRangeAboutValue(0.05d, 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = numberAxis4.getTickLabelInsets();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit44);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        numberAxis1.setLowerMargin(1.0d);
        boolean boolean8 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis1.setLabelFont(font10);
        boolean boolean12 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        org.jfree.chart.LegendItemCollection legendItemCollection64 = xYPlot29.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot29.getRangeAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNull(legendItemCollection64);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        numberAxis36.setNegativeArrowVisible(false);
        numberAxis36.setVisible(false);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        numberAxis48.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis36.reserveSpace(graphics2D46, (org.jfree.chart.plot.Plot) categoryPlot54, rectangle2D56, rectangleEdge57, axisSpace58);
        categoryPlot54.clearRangeMarkers();
        boolean boolean61 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot54.setRangeAxisLocation(10, axisLocation63, false);
        xYPlot29.setDomainAxisLocation((int) (short) 0, axisLocation63);
        java.awt.Paint paint67 = xYPlot29.getDomainGridlinePaint();
        java.awt.Stroke stroke68 = xYPlot29.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(axisSpace59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        double double6 = numberAxis2.getLowerMargin();
        java.lang.Object obj7 = numberAxis2.clone();
        numberAxis2.setNegativeArrowVisible(false);
        numberAxis2.setVisible(false);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        numberAxis14.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        org.jfree.chart.axis.AxisSpace axisSpace25 = numberAxis2.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot20, rectangle2D22, rectangleEdge23, axisSpace24);
        boolean boolean26 = objectList0.equals((java.lang.Object) axisSpace25);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = org.jfree.chart.axis.CategoryAnchor.END;
        objectList0.set(100, (java.lang.Object) categoryAnchor28);
        java.lang.Object obj30 = null;
        boolean boolean31 = objectList0.equals(obj30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis33.setMarkerBand(markerAxisBand35);
        double double37 = numberAxis33.getLowerMargin();
        java.lang.Object obj38 = numberAxis33.clone();
        numberAxis33.setNegativeArrowVisible(false);
        numberAxis33.setVisible(false);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str46 = numberAxis45.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis45.setMarkerBand(markerAxisBand47);
        numberAxis45.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis45.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot51);
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = null;
        org.jfree.chart.axis.AxisSpace axisSpace56 = numberAxis33.reserveSpace(graphics2D43, (org.jfree.chart.plot.Plot) categoryPlot51, rectangle2D53, rectangleEdge54, axisSpace55);
        float float57 = categoryPlot51.getBackgroundImageAlpha();
        float float58 = categoryPlot51.getForegroundAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = categoryPlot51.getDomainAxis(10);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str64 = numberAxis63.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = null;
        numberAxis63.setMarkerBand(markerAxisBand65);
        numberAxis63.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis63.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot69);
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        categoryPlot69.setDataset(categoryDataset71);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo75 = null;
        java.awt.geom.Point2D point2D76 = null;
        categoryPlot69.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo75, point2D76);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        categoryPlot69.setRenderer(categoryItemRenderer78);
        org.jfree.chart.plot.ValueMarker valueMarker81 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = valueMarker81.getLabelAnchor();
        java.lang.String str83 = valueMarker81.getLabel();
        java.awt.Color color85 = java.awt.Color.orange;
        java.awt.Color color86 = java.awt.Color.getColor("", color85);
        java.awt.Color color87 = color86.brighter();
        valueMarker81.setLabelPaint((java.awt.Paint) color86);
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot69.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker81, layer89);
        java.util.Collection collection91 = categoryPlot51.getRangeMarkers(3, layer89);
        categoryPlot51.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation95 = null;
        categoryPlot51.setRangeAxisLocation(2, axisLocation95, false);
        boolean boolean98 = objectList0.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(axisSpace25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(axisSpace56);
        org.junit.Assert.assertTrue("'" + float57 + "' != '" + 0.5f + "'", float57 == 0.5f);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 1.0f + "'", float58 == 1.0f);
        org.junit.Assert.assertNull(categoryAxis60);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertNotNull(layer89);
        org.junit.Assert.assertNull(collection91);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        double double7 = numberAxis3.getLowerMargin();
        java.lang.Object obj8 = numberAxis3.clone();
        java.lang.String str9 = numberAxis3.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3.setTickUnit(numberTickUnit10, true, false);
        org.jfree.chart.plot.Plot plot14 = numberAxis3.getPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str19 = numberAxis18.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis18.setMarkerBand(markerAxisBand20);
        double double22 = numberAxis18.getLowerMargin();
        java.lang.Object obj23 = numberAxis18.clone();
        numberAxis18.setNegativeArrowVisible(false);
        numberAxis18.setVisible(false);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        org.jfree.chart.axis.AxisSpace axisSpace41 = numberAxis18.reserveSpace(graphics2D28, (org.jfree.chart.plot.Plot) categoryPlot36, rectangle2D38, rectangleEdge39, axisSpace40);
        categoryPlot16.setFixedRangeAxisSpace(axisSpace41);
        int int43 = categoryPlot16.getDatasetCount();
        categoryPlot16.configureRangeAxes();
        boolean boolean45 = categoryPlot16.isOutlineVisible();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertNull(plot14);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition1 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        boolean boolean6 = numberAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis1.setMarkerBand(markerAxisBand7);
        numberAxis1.setTickMarkOutsideLength(0.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        numberAxis1.setTickLabelInsets(rectangleInsets11);
        double double14 = rectangleInsets11.calculateLeftOutset((double) 10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        numberAxis3.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        java.lang.String str12 = valueMarker10.getLabel();
        valueMarker10.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str15 = valueMarker10.getLabel();
        java.awt.Stroke stroke16 = valueMarker10.getStroke();
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        java.lang.String str21 = valueMarker19.getLabel();
        valueMarker19.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint24 = valueMarker19.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke27 = numberAxis26.getTickMarkStroke();
        valueMarker19.setOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color7, stroke16, (java.awt.Paint) color17, stroke27, 0.0f);
        intervalMarker30.setStartValue((double) ' ');
        intervalMarker30.setEndValue((double) 1560495599999L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType35 = null;
        try {
            intervalMarker30.setLabelOffsetType(lengthAdjustmentType35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str15.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int3 = java.awt.Color.HSBtoRGB((float) 3, (float) 43629L, (float) 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-376) + "'", int3 == (-376));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        categoryPlot19.setAnchorValue((double) 0.5f);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot35.setDataset(categoryDataset37);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot35.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot35.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = valueMarker45.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor47 = valueMarker45.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker45.setLabelOffset(rectangleInsets48);
        java.awt.Stroke stroke50 = valueMarker45.getStroke();
        boolean boolean51 = categoryPlot35.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker45);
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot35);
        categoryPlot35.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        java.awt.Paint paint68 = xYPlot29.getRangeCrosshairPaint();
        org.jfree.chart.plot.ValueMarker valueMarker70 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = valueMarker70.getLabelAnchor();
        java.lang.String str72 = valueMarker70.getLabel();
        valueMarker70.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint75 = valueMarker70.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke78 = numberAxis77.getTickMarkStroke();
        valueMarker70.setOutlineStroke(stroke78);
        xYPlot29.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker70);
        xYPlot29.clearRangeMarkers();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = dateAxis0.getMinimumDate();
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot29.getRenderer();
        boolean boolean69 = xYPlot29.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray70 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot29.setRenderers(xYItemRendererArray70);
        xYPlot29.setBackgroundAlpha((float) 200);
        java.awt.Image image74 = null;
        xYPlot29.setBackgroundImage(image74);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray70);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        double double34 = numberAxis30.getLowerMargin();
        java.lang.Object obj35 = numberAxis30.clone();
        java.text.NumberFormat numberFormat36 = null;
        numberAxis30.setNumberFormatOverride(numberFormat36);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis39.setMarkerBand(markerAxisBand41);
        numberAxis39.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis39.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        categoryPlot45.setDataset(categoryDataset47);
        org.jfree.data.category.CategoryDataset categoryDataset50 = categoryPlot45.getDataset(0);
        categoryPlot45.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean53 = numberAxis30.hasListener((java.util.EventListener) categoryPlot45);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = valueMarker56.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str60 = numberAxis59.getLabelURL();
        java.awt.Color color62 = java.awt.Color.orange;
        java.awt.Color color63 = java.awt.Color.getColor("", color62);
        numberAxis59.setLabelPaint((java.awt.Paint) color63);
        valueMarker56.setOutlinePaint((java.awt.Paint) color63);
        org.jfree.chart.util.Layer layer66 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean68 = categoryPlot45.removeDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker56, layer66, false);
        java.util.Collection collection69 = categoryPlot19.getRangeMarkers(layer66);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent70 = null;
        categoryPlot19.notifyListeners(plotChangeEvent70);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(layer66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNull(collection69);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.lang.String str8 = valueMarker6.getLabel();
        float float9 = valueMarker6.getAlpha();
        java.awt.Stroke stroke10 = valueMarker6.getStroke();
        dateAxis0.setTickMarkStroke(stroke10);
        dateAxis0.zoomRange((double) (-15423), 0.0d);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=255,b=0]", timeZone16);
        dateAxis0.setTimeZone(timeZone16);
        java.text.DateFormat dateFormat19 = null;
        dateAxis0.setDateFormatOverride(dateFormat19);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = valueMarker32.getLabelAnchor();
        java.lang.String str34 = valueMarker32.getLabel();
        valueMarker32.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str37 = valueMarker32.getLabel();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot29.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker32, layer38, true);
        java.awt.Font font41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYPlot29.setNoDataMessageFont(font41);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str37.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(font41);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        numberAxis3.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        java.lang.String str12 = valueMarker10.getLabel();
        valueMarker10.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str15 = valueMarker10.getLabel();
        java.awt.Stroke stroke16 = valueMarker10.getStroke();
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        java.lang.String str21 = valueMarker19.getLabel();
        valueMarker19.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint24 = valueMarker19.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke27 = numberAxis26.getTickMarkStroke();
        valueMarker19.setOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color7, stroke16, (java.awt.Paint) color17, stroke27, 0.0f);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        intervalMarker30.setLabelPaint((java.awt.Paint) color31);
        double double33 = intervalMarker30.getEndValue();
        try {
            intervalMarker30.setAlpha((float) (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str15.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        categoryPlot7.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot7.setRowRenderingOrder(sortOrder15);
        categoryPlot7.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot7.setRenderer(categoryItemRenderer19);
        int int21 = categoryPlot7.getDatasetCount();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        categoryPlot19.setAnchorValue((double) 0.5f);
        categoryPlot19.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint30 = categoryPlot19.getRangeCrosshairPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        java.awt.Paint paint64 = xYPlot29.getRangeCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer66 = xYPlot29.getRenderer((int) (byte) -1);
        xYPlot29.setRangeZeroBaselineVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis69 = xYPlot29.getDomainAxis();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNull(xYItemRenderer66);
        org.junit.Assert.assertNotNull(valueAxis69);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Color color1 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.lengthToJava2D((double) (short) 100, rectangle2D8, rectangleEdge9);
        boolean boolean11 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        double double17 = numberAxis13.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str20 = numberAxis19.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis19.setMarkerBand(markerAxisBand21);
        double double23 = numberAxis19.getLowerMargin();
        java.lang.Object obj24 = numberAxis19.clone();
        java.lang.String str25 = numberAxis19.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis19.setTickUnit(numberTickUnit26, true, false);
        numberAxis13.setTickUnit(numberTickUnit26, false, true);
        numberAxis1.setTickUnit(numberTickUnit26);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit26);
        org.junit.Assert.assertNull(markerAxisBand34);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 0, (float) (short) 100, (float) 1L);
        java.awt.Color color4 = color3.darker();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        float float26 = categoryPlot19.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxisForDataset(500);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot19.getDomainAxisForDataset(255);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNull(categoryAxis30);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        boolean boolean33 = xYPlot29.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        numberAxis36.setNegativeArrowVisible(false);
        numberAxis36.setVisible(false);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        numberAxis48.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis36.reserveSpace(graphics2D46, (org.jfree.chart.plot.Plot) categoryPlot54, rectangle2D56, rectangleEdge57, axisSpace58);
        float float60 = categoryPlot54.getBackgroundImageAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str63 = numberAxis62.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = null;
        numberAxis62.setMarkerBand(markerAxisBand64);
        numberAxis62.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis62.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot68);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        java.awt.geom.Point2D point2D72 = null;
        categoryPlot68.zoomDomainAxes((double) (short) 100, plotRenderingInfo71, point2D72, true);
        org.jfree.chart.axis.AxisSpace axisSpace75 = categoryPlot68.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot76 = categoryPlot68.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent77 = null;
        plot76.notifyListeners(plotChangeEvent77);
        java.awt.Paint paint79 = plot76.getBackgroundPaint();
        categoryPlot54.setDomainGridlinePaint(paint79);
        java.awt.Stroke stroke81 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint79, stroke81);
        xYPlot29.setRangeGridlineStroke(stroke81);
        xYPlot29.clearRangeMarkers();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(axisSpace59);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.5f + "'", float60 == 0.5f);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNull(axisSpace75);
        org.junit.Assert.assertNotNull(plot76);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        categoryPlot19.setAnchorValue((double) 0.5f);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot35.setDataset(categoryDataset37);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot35.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot35.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker42);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = valueMarker45.getLabelAnchor();
        java.lang.String str47 = valueMarker45.getLabel();
        valueMarker45.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker45.setLabelOffset(rectangleInsets50);
        org.jfree.chart.util.Layer layer52 = null;
        boolean boolean53 = categoryPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker45, layer52);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder54 = categoryPlot35.getDatasetRenderingOrder();
        boolean boolean55 = categoryPlot19.equals((java.lang.Object) categoryPlot35);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str59 = numberAxis58.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = null;
        numberAxis58.setMarkerBand(markerAxisBand60);
        double double62 = numberAxis58.getLowerMargin();
        java.lang.Object obj63 = numberAxis58.clone();
        java.text.NumberFormat numberFormat64 = null;
        numberAxis58.setNumberFormatOverride(numberFormat64);
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str68 = numberAxis67.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand69 = null;
        numberAxis67.setMarkerBand(markerAxisBand69);
        numberAxis67.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis67.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot73);
        org.jfree.data.category.CategoryDataset categoryDataset75 = null;
        categoryPlot73.setDataset(categoryDataset75);
        org.jfree.data.category.CategoryDataset categoryDataset78 = categoryPlot73.getDataset(0);
        categoryPlot73.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean81 = numberAxis58.hasListener((java.util.EventListener) categoryPlot73);
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = valueMarker84.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis87 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str88 = numberAxis87.getLabelURL();
        java.awt.Color color90 = java.awt.Color.orange;
        java.awt.Color color91 = java.awt.Color.getColor("", color90);
        numberAxis87.setLabelPaint((java.awt.Paint) color91);
        valueMarker84.setOutlinePaint((java.awt.Paint) color91);
        org.jfree.chart.util.Layer layer94 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean96 = categoryPlot73.removeDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker84, layer94, false);
        org.jfree.chart.util.Layer layer97 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean98 = categoryPlot19.removeDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker84, layer97);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.05d + "'", double62 == 0.05d);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNull(categoryDataset78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNull(str88);
        org.junit.Assert.assertNotNull(color90);
        org.junit.Assert.assertNotNull(color91);
        org.junit.Assert.assertNotNull(layer94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(layer97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        java.util.List list16 = categoryPlot7.getAnnotations();
        boolean boolean17 = categoryPlot7.isRangeZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        java.lang.String str21 = valueMarker19.getLabel();
        valueMarker19.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker19.setLabelOffset(rectangleInsets24);
        double double27 = rectangleInsets24.extendHeight((double) 10L);
        double double29 = rectangleInsets24.calculateLeftOutset((double) 255);
        categoryPlot7.setInsets(rectangleInsets24);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.0d + "'", double27 == 14.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 4.0d + "'", double29 == 4.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = valueMarker32.getLabelAnchor();
        java.lang.String str34 = valueMarker32.getLabel();
        valueMarker32.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str37 = valueMarker32.getLabel();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot29.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker32, layer38, true);
        java.awt.Stroke stroke41 = xYPlot29.getDomainGridlineStroke();
        xYPlot29.mapDatasetToDomainAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str47 = numberAxis46.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        numberAxis46.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis46.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        categoryPlot52.setDataset(categoryDataset54);
        org.jfree.data.category.CategoryDataset categoryDataset57 = categoryPlot52.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot52.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker59);
        xYPlot29.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker59);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str37.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(categoryDataset57);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = valueMarker32.getLabelAnchor();
        java.lang.String str34 = valueMarker32.getLabel();
        valueMarker32.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str37 = valueMarker32.getLabel();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot29.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker32, layer38, true);
        java.awt.Stroke stroke41 = xYPlot29.getDomainGridlineStroke();
        java.awt.Paint paint42 = xYPlot29.getNoDataMessagePaint();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str37.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder44);
        categoryPlot19.setRowRenderingOrder(sortOrder44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = categoryPlot19.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot19.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = categoryPlot19.getRendererForDataset(categoryDataset49);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNull(categoryItemRenderer50);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        double double6 = numberAxis2.getLowerMargin();
        java.lang.Object obj7 = numberAxis2.clone();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, valueAxis8, xYItemRenderer9);
        xYPlot10.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.lang.String str8 = valueMarker6.getLabel();
        float float9 = valueMarker6.getAlpha();
        java.awt.Stroke stroke10 = valueMarker6.getStroke();
        dateAxis0.setTickMarkStroke(stroke10);
        java.text.DateFormat dateFormat12 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(dateFormat12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis10.setMarkerBand(markerAxisBand12);
        numberAxis10.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot16.setDataset(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot16.getDataset(0);
        categoryPlot16.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean24 = numberAxis1.hasListener((java.util.EventListener) categoryPlot16);
        boolean boolean25 = categoryPlot16.isRangeZoomable();
        categoryPlot16.configureDomainAxes();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(1.0E-8d);
        double double4 = rectangleInsets0.calculateRightOutset((double) (-1));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis1.getStandardTickUnits();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis1.getMarkerBand();
        numberAxis1.setLowerBound(0.05d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNull(markerAxisBand8);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.util.Date date5 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        double double4 = categoryAxis0.getLowerMargin();
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis6.getTickUnit();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean9 = dateAxis6.equals((java.lang.Object) font8);
        categoryAxis0.setTickLabelFont(font8);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(dateTickUnit7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis2.setMarkerBand(markerAxisBand30);
        boolean boolean32 = numberAxis2.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str6 = numberAxis5.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis5.setMarkerBand(markerAxisBand7);
        double double9 = numberAxis5.getLowerMargin();
        java.lang.Object obj10 = numberAxis5.clone();
        numberAxis5.setNegativeArrowVisible(false);
        numberAxis5.setVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        numberAxis17.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        org.jfree.chart.axis.AxisSpace axisSpace28 = numberAxis5.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot23, rectangle2D25, rectangleEdge26, axisSpace27);
        categoryPlot23.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        java.util.List list31 = categoryPlot23.getCategoriesForAxis(categoryAxis30);
        int int32 = categoryPlot23.getWeight();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis35.setStandardTickUnits(tickUnitSource40);
        numberAxis35.setAutoRange(false);
        org.jfree.data.Range range44 = numberAxis35.getDefaultAutoRange();
        boolean boolean45 = numberAxis35.isVerticalTickLabels();
        boolean boolean46 = categoryAxis0.equals((java.lang.Object) numberAxis35);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        org.jfree.data.Range range52 = numberAxis48.getDefaultAutoRange();
        java.awt.Shape shape53 = numberAxis48.getDownArrow();
        numberAxis35.setDownArrow(shape53);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(axisSpace28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(shape53);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setPositiveArrowVisible(true);
        java.awt.Paint paint7 = numberAxis1.getTickLabelPaint();
        numberAxis1.setLabelAngle(0.0d);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        double double18 = numberAxis14.getLowerMargin();
        java.lang.Object obj19 = numberAxis14.clone();
        java.text.NumberFormat numberFormat20 = null;
        numberAxis14.setNumberFormatOverride(numberFormat20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str24 = numberAxis23.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand25 = null;
        numberAxis23.setMarkerBand(markerAxisBand25);
        numberAxis23.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis23.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot29.setDataset(categoryDataset31);
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot29.getDataset(0);
        categoryPlot29.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean37 = numberAxis14.hasListener((java.util.EventListener) categoryPlot29);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis14, xYItemRenderer38);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str43 = numberAxis42.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand44 = null;
        numberAxis42.setMarkerBand(markerAxisBand44);
        double double46 = numberAxis42.getLowerMargin();
        java.lang.Object obj47 = numberAxis42.clone();
        numberAxis42.setNegativeArrowVisible(false);
        numberAxis42.setVisible(false);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str55 = numberAxis54.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis54.setMarkerBand(markerAxisBand56);
        numberAxis54.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis54.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        org.jfree.chart.axis.AxisSpace axisSpace65 = numberAxis42.reserveSpace(graphics2D52, (org.jfree.chart.plot.Plot) categoryPlot60, rectangle2D62, rectangleEdge63, axisSpace64);
        categoryPlot60.clearRangeMarkers();
        boolean boolean67 = categoryPlot60.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot60.setRangeAxisLocation(10, axisLocation69, false);
        xYPlot39.setRangeAxisLocation(4, axisLocation69);
        xYPlot39.setRangeCrosshairVisible(false);
        java.awt.Stroke stroke75 = xYPlot39.getRangeGridlineStroke();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot39);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.05d + "'", double46 == 0.05d);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(axisSpace65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        categoryPlot7.notifyListeners(plotChangeEvent16);
        categoryPlot7.setAnchorValue((double) 4, false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        numberAxis1.setLabelPaint((java.awt.Paint) color5);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setRangeAboutValue((double) (short) 100, (double) (short) 100);
        numberAxis1.setAutoRangeMinimumSize((double) 1560409200000L, true);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str20 = numberAxis19.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = null;
        numberAxis19.setMarkerBand(markerAxisBand21);
        numberAxis19.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis19.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot25);
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot25.removeChangeListener(plotChangeListener27);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        double double34 = numberAxis30.getLowerMargin();
        java.lang.Object obj35 = numberAxis30.clone();
        numberAxis30.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = null;
        numberAxis39.setMarkerBand(markerAxisBand41);
        double double43 = numberAxis39.getLowerMargin();
        java.awt.Font font44 = numberAxis39.getLabelFont();
        numberAxis30.setLabelFont(font44);
        categoryPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot25.getRangeAxisEdge();
        try {
            java.util.List list48 = numberAxis1.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot7.zoomDomainAxes((double) 0.5f, plotRenderingInfo17, point2D18, false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        numberAxis1.setRangeAboutValue((double) 'a', 0.0d);
        numberAxis1.zoomRange(0.05d, (double) (byte) 0);
        java.awt.Stroke stroke31 = numberAxis1.getAxisLineStroke();
        numberAxis1.setTickMarkOutsideLength((float) 'a');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.data.time.DateRange dateRange2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange2, true, true);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis6.getTickUnit();
        dateAxis0.setTickUnit(dateTickUnit7);
        org.junit.Assert.assertNotNull(dateRange2);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setLabelToolTip("java.awt.Color[r=255,g=255,b=0]");
        java.awt.Stroke stroke9 = numberAxis1.getTickMarkStroke();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str28 = numberAxis27.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        numberAxis27.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis27.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot33.zoomDomainAxes((double) (short) 100, plotRenderingInfo36, point2D37, true);
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot41 = categoryPlot33.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = null;
        plot41.notifyListeners(plotChangeEvent42);
        java.awt.Paint paint44 = plot41.getBackgroundPaint();
        categoryPlot19.setDomainGridlinePaint(paint44);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray46 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot19.setDomainAxes(categoryAxisArray46);
        java.lang.String str48 = categoryPlot19.getNoDataMessage();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(categoryAxisArray46);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot29.getRangeMarkers((int) (byte) 10, layer35);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot29.zoomDomainAxes((double) (-1L), plotRenderingInfo38, point2D39);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.data.Range range11 = numberAxis7.getDefaultAutoRange();
        java.awt.Shape shape12 = numberAxis7.getDownArrow();
        boolean boolean13 = numberAxis7.isInverted();
        boolean boolean14 = numberAxis7.getAutoRangeStickyZero();
        boolean boolean15 = dateAxis1.equals((java.lang.Object) boolean14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = null;
        try {
            dateAxis1.setLabelInsets(rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        xYPlot29.setRangeCrosshairVisible(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener65 = null;
        xYPlot29.removeChangeListener(plotChangeListener65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer67 = xYPlot29.getRenderer();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNull(xYItemRenderer67);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str6 = numberAxis5.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis5.setMarkerBand(markerAxisBand7);
        double double9 = numberAxis5.getLowerMargin();
        java.lang.Object obj10 = numberAxis5.clone();
        numberAxis5.setNegativeArrowVisible(false);
        numberAxis5.setVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        numberAxis17.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        org.jfree.chart.axis.AxisSpace axisSpace28 = numberAxis5.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot23, rectangle2D25, rectangleEdge26, axisSpace27);
        categoryPlot23.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        java.util.List list31 = categoryPlot23.getCategoriesForAxis(categoryAxis30);
        int int32 = categoryPlot23.getWeight();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis0.getTickLabelInsets();
        java.lang.String str35 = rectangleInsets34.toString();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(axisSpace28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str35.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot29.getAxisOffset();
        java.awt.Stroke stroke40 = xYPlot29.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYPlot29.rendererChanged(rendererChangeEvent41);
        xYPlot29.setNoDataMessage("java.awt.Color[r=255,g=255,b=0]");
        java.awt.Paint paint45 = xYPlot29.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        xYPlot29.setDataset(xYDataset46);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        numberAxis1.setRangeAboutValue((double) 'a', 0.0d);
        numberAxis1.zoomRange(0.05d, (double) (byte) 0);
        java.awt.Stroke stroke31 = numberAxis1.getAxisLineStroke();
        numberAxis1.setUpperMargin(0.0d);
        numberAxis1.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(markerAxisBand36);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1L), "UnitType.RELATIVE");
        java.lang.String str7 = categoryAxis0.getLabel();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        numberAxis1.setLabelPaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = numberAxis1.getTickLabelPaint();
        numberAxis1.setFixedAutoRange((double) (-3695));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        valueMarker1.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint6 = valueMarker1.getLabelPaint();
        float float7 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis1.java2DToValue((-1.0d), rectangle2D9, rectangleEdge10);
        double double12 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        numberAxis1.setLowerMargin(1.0d);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str10 = numberAxis9.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis9.setMarkerBand(markerAxisBand11);
        double double13 = numberAxis9.getLowerMargin();
        org.jfree.data.Range range14 = numberAxis9.getRange();
        numberAxis1.setRange(range14, false, false);
        numberAxis1.setAutoRangeMinimumSize((double) 10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(1.0E-8d);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color5 = java.awt.Color.orange;
        java.awt.Color color6 = color5.darker();
        java.awt.color.ColorSpace colorSpace7 = color5.getColorSpace();
        float[] floatArray12 = new float[] { (-1L), 1.0f, (-1.0f), (short) 1 };
        float[] floatArray13 = color4.getColorComponents(colorSpace7, floatArray12);
        boolean boolean14 = rectangleInsets0.equals((java.lang.Object) color4);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.configure();
        double double17 = dateAxis15.getLabelAngle();
        boolean boolean18 = rectangleInsets0.equals((java.lang.Object) double17);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot29.setQuadrantPaint(0, (java.awt.Paint) color31);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot9.getDomainAxis((int) (byte) 0);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot9.getOrientation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot9.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        xYPlot29.clearRangeAxes();
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str68 = numberAxis67.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand69 = null;
        numberAxis67.setMarkerBand(markerAxisBand69);
        double double71 = numberAxis67.getLowerMargin();
        java.lang.Object obj72 = numberAxis67.clone();
        numberAxis67.setNegativeArrowVisible(false);
        numberAxis67.setVisible(false);
        java.awt.Graphics2D graphics2D77 = null;
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str80 = numberAxis79.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand81 = null;
        numberAxis79.setMarkerBand(markerAxisBand81);
        numberAxis79.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis79.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot85);
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = null;
        org.jfree.chart.axis.AxisSpace axisSpace89 = null;
        org.jfree.chart.axis.AxisSpace axisSpace90 = numberAxis67.reserveSpace(graphics2D77, (org.jfree.chart.plot.Plot) categoryPlot85, rectangle2D87, rectangleEdge88, axisSpace89);
        boolean boolean91 = numberAxis67.getAutoRangeStickyZero();
        boolean boolean92 = numberAxis67.getAutoRangeStickyZero();
        java.awt.Shape shape93 = numberAxis67.getLeftArrow();
        xYPlot29.setDomainAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis67, false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.05d + "'", double71 == 0.05d);
        org.junit.Assert.assertNotNull(obj72);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNotNull(axisSpace90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(shape93);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker30.getLabelAnchor();
        java.lang.String str32 = valueMarker30.getLabel();
        valueMarker30.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker30.setLabelOffset(rectangleInsets35);
        categoryPlot19.setAxisOffset(rectangleInsets35);
        double double38 = rectangleInsets35.getBottom();
        java.awt.Color color39 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color39.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        boolean boolean46 = rectangleInsets35.equals((java.lang.Object) paintContext45);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.0d + "'", double38 == 2.0d);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        numberAxis1.setRangeAboutValue((double) 'a', 0.0d);
        numberAxis1.zoomRange(0.05d, (double) (byte) 0);
        java.awt.Stroke stroke31 = numberAxis1.getAxisLineStroke();
        numberAxis1.setUpperMargin(0.0d);
        org.jfree.chart.plot.Plot plot34 = null;
        numberAxis1.setPlot(plot34);
        java.lang.String str36 = numberAxis1.getLabel();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560452399999L + "'", long3 == 1560452399999L);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot7.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis12.getLowerMargin();
        java.lang.Object obj17 = numberAxis12.clone();
        numberAxis12.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str22 = numberAxis21.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis21.setMarkerBand(markerAxisBand23);
        double double25 = numberAxis21.getLowerMargin();
        java.awt.Font font26 = numberAxis21.getLabelFont();
        numberAxis12.setLabelFont(font26);
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.util.List list29 = categoryPlot7.getCategories();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation30 = null;
        try {
            categoryPlot7.addAnnotation(categoryAnnotation30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(list29);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.ABSOLUTE");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        numberAxis3.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        java.lang.String str12 = valueMarker10.getLabel();
        valueMarker10.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str15 = valueMarker10.getLabel();
        java.awt.Stroke stroke16 = valueMarker10.getStroke();
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        java.lang.String str21 = valueMarker19.getLabel();
        valueMarker19.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint24 = valueMarker19.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke27 = numberAxis26.getTickMarkStroke();
        valueMarker19.setOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color7, stroke16, (java.awt.Paint) color17, stroke27, 0.0f);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        intervalMarker30.setLabelPaint((java.awt.Paint) color31);
        double double33 = intervalMarker30.getEndValue();
        double double34 = intervalMarker30.getStartValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str15.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        xYPlot29.setBackgroundImageAlignment(2019);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.configure();
        org.jfree.chart.axis.Timeline timeline2 = dateAxis0.getTimeline();
        org.junit.Assert.assertNotNull(timeline2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        java.awt.Stroke stroke26 = categoryPlot19.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot19.getDomainAxisForDataset((-1));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categoryAxis28);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Color color0 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.lang.Object obj2 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.2d);
        double double2 = valueMarker1.getValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot29.getRenderer();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = xYPlot29.getAxisOffset();
        java.awt.Stroke stroke70 = xYPlot29.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis71 = xYPlot29.getDomainAxis();
        xYPlot29.mapDatasetToDomainAxis((-15423), (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(valueAxis71);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        boolean boolean33 = xYPlot29.isDomainGridlinesVisible();
        java.awt.Stroke stroke34 = xYPlot29.getRangeGridlineStroke();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder44);
        categoryPlot19.setColumnRenderingOrder(sortOrder44);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        categoryPlot19.setDomainAxis(2019, categoryAxis48, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        java.util.List list52 = categoryPlot19.getCategoriesForAxis(categoryAxis51);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str55 = numberAxis54.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand56 = null;
        numberAxis54.setMarkerBand(markerAxisBand56);
        double double58 = numberAxis54.getLowerMargin();
        java.lang.Object obj59 = numberAxis54.clone();
        numberAxis54.setNegativeArrowVisible(false);
        numberAxis54.setVisible(false);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str67 = numberAxis66.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand68 = null;
        numberAxis66.setMarkerBand(markerAxisBand68);
        numberAxis66.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis66.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot72);
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        org.jfree.chart.axis.AxisSpace axisSpace76 = null;
        org.jfree.chart.axis.AxisSpace axisSpace77 = numberAxis54.reserveSpace(graphics2D64, (org.jfree.chart.plot.Plot) categoryPlot72, rectangle2D74, rectangleEdge75, axisSpace76);
        categoryPlot72.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer79 = categoryPlot72.getRenderer();
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot72);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer81 = null;
        categoryPlot19.setRenderer(categoryItemRenderer81);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.05d + "'", double58 == 0.05d);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(axisSpace77);
        org.junit.Assert.assertNull(categoryItemRenderer79);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        java.lang.String str5 = numberAxis1.getLabelToolTip();
        numberAxis1.setLowerMargin(1.0d);
        boolean boolean8 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        java.awt.Font font10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis1.setLabelFont(font10);
        double double12 = numberAxis1.getLowerBound();
        numberAxis1.setLabelAngle((double) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource6);
        numberAxis1.setAutoRange(false);
        org.jfree.data.Range range10 = numberAxis1.getDefaultAutoRange();
        org.jfree.data.Range range11 = numberAxis1.getRange();
        float float12 = numberAxis1.getTickMarkOutsideLength();
        java.text.NumberFormat numberFormat13 = numberAxis1.getNumberFormatOverride();
        boolean boolean14 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke4 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.lang.String str8 = valueMarker6.getLabel();
        valueMarker6.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint11 = valueMarker6.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke14 = numberAxis13.getTickMarkStroke();
        valueMarker6.setOutlineStroke(stroke14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        numberAxis17.setPositiveArrowVisible(true);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis17.setTickMarkStroke(stroke23);
        valueMarker6.setStroke(stroke23);
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] { stroke4, stroke23 };
        java.awt.Stroke[] strokeArray27 = null;
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray26, strokeArray27, shapeArray28);
        java.lang.Object obj30 = defaultDrawingSupplier29.clone();
        java.lang.Object obj31 = defaultDrawingSupplier29.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=255,b=255]" + "'", str1.equals("java.awt.Color[r=64,g=255,b=255]"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke2 = numberAxis1.getTickMarkStroke();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        numberAxis4.setNegativeArrowVisible(false);
        numberAxis4.setVisible(false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis16.setMarkerBand(markerAxisBand18);
        numberAxis16.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis16.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        org.jfree.chart.axis.AxisSpace axisSpace27 = numberAxis4.reserveSpace(graphics2D14, (org.jfree.chart.plot.Plot) categoryPlot22, rectangle2D24, rectangleEdge25, axisSpace26);
        float float28 = categoryPlot22.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot22.setRenderer(categoryItemRenderer29, false);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis33.setMarkerBand(markerAxisBand35);
        numberAxis33.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        categoryPlot39.setDataset(categoryDataset41);
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot39.getDataset(0);
        categoryPlot39.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder47 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot39.setRowRenderingOrder(sortOrder47);
        categoryPlot22.setColumnRenderingOrder(sortOrder47);
        org.jfree.chart.LegendItemCollection legendItemCollection50 = categoryPlot22.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot22.setDomainAxis(12, categoryAxis52);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot22);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertNotNull(sortOrder47);
        org.junit.Assert.assertNotNull(legendItemCollection50);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        float float26 = categoryPlot19.getForegroundAlpha();
        java.lang.Class<?> wildcardClass27 = categoryPlot19.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertNotNull(class29);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        org.jfree.data.Range range11 = numberAxis7.getDefaultAutoRange();
        java.awt.Shape shape12 = numberAxis7.getDownArrow();
        boolean boolean13 = numberAxis7.isInverted();
        boolean boolean14 = numberAxis7.getAutoRangeStickyZero();
        boolean boolean15 = dateAxis1.equals((java.lang.Object) boolean14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.configure();
        java.util.Date date18 = dateAxis16.getMaximumDate();
        java.util.Date date19 = null;
        try {
            dateAxis1.setRange(date18, date19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        categoryPlot7.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot7.setRowRenderingOrder(sortOrder15);
        categoryPlot7.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke19 = categoryPlot7.getOutlineStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot7.addAnnotation(categoryAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.CrosshairState crosshairState34 = null;
        boolean boolean35 = xYPlot29.render(graphics2D30, rectangle2D31, 8, plotRenderingInfo33, crosshairState34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot29.getRangeAxisLocation((int) 'a');
        int int38 = xYPlot29.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double41 = rectangleInsets39.calculateTopInset(1.0E-8d);
        double double43 = rectangleInsets39.calculateTopInset((double) 1);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color45 = java.awt.Color.orange;
        java.awt.Color color46 = color45.darker();
        java.awt.color.ColorSpace colorSpace47 = color45.getColorSpace();
        float[] floatArray52 = new float[] { (-1L), 1.0f, (-1.0f), (short) 1 };
        float[] floatArray53 = color44.getColorComponents(colorSpace47, floatArray52);
        boolean boolean54 = rectangleInsets39.equals((java.lang.Object) floatArray52);
        xYPlot29.setInsets(rectangleInsets39);
        double double57 = rectangleInsets39.trimWidth((double) 43629L);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(colorSpace47);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 43621.0d + "'", double57 == 43621.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot16.setOutlinePaint(paint17);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot16.getRowRenderingOrder();
        categoryPlot7.setRowRenderingOrder(sortOrder19);
        java.awt.Color color22 = java.awt.Color.orange;
        java.awt.Color color23 = java.awt.Color.getColor("", color22);
        java.awt.Color color24 = color23.brighter();
        java.lang.String str25 = color24.toString();
        boolean boolean26 = sortOrder19.equals((java.lang.Object) color24);
        java.lang.String str27 = sortOrder19.toString();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=255,g=255,b=0]" + "'", str25.equals("java.awt.Color[r=255,g=255,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "SortOrder.ASCENDING" + "'", str27.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis10.setMarkerBand(markerAxisBand12);
        numberAxis10.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot16.setDataset(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot16.getDataset(0);
        categoryPlot16.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean24 = numberAxis1.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        try {
            categoryPlot16.addAnnotation(categoryAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        numberAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = numberAxis1.getTickLabelInsets();
        double double7 = rectangleInsets5.trimHeight((double) (short) 0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-4.0d) + "'", double7 == (-4.0d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        xYPlot29.setRangeCrosshairVisible(false);
        float float65 = xYPlot29.getBackgroundImageAlpha();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray66 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot29.setDomainAxes(valueAxisArray66);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertTrue("'" + float65 + "' != '" + 0.5f + "'", float65 == 0.5f);
        org.junit.Assert.assertNotNull(valueAxisArray66);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", 100);
        java.awt.Color color6 = java.awt.Color.RED;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color9 = java.awt.Color.orange;
        java.awt.Color color10 = color9.darker();
        java.awt.color.ColorSpace colorSpace11 = color9.getColorSpace();
        float[] floatArray16 = new float[] { (-1L), 1.0f, (-1.0f), (short) 1 };
        float[] floatArray17 = color8.getColorComponents(colorSpace11, floatArray16);
        float[] floatArray18 = color7.getRGBColorComponents(floatArray16);
        float[] floatArray19 = color6.getRGBComponents(floatArray18);
        float[] floatArray20 = java.awt.Color.RGBtoHSB(1, 100, 0, floatArray19);
        float[] floatArray21 = color2.getColorComponents(floatArray19);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Color color0 = java.awt.Color.WHITE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        double double11 = numberAxis7.getLowerMargin();
        java.lang.Object obj12 = numberAxis7.clone();
        java.lang.String str13 = numberAxis7.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit14, true, false);
        numberAxis1.setTickUnit(numberTickUnit14, false, true);
        float float21 = numberAxis1.getTickMarkOutsideLength();
        boolean boolean22 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        numberAxis3.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot9.setDataset(categoryDataset11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot9.getDataset(0);
        categoryPlot9.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder17 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot9.setRowRenderingOrder(sortOrder17);
        categoryPlot9.setRangeGridlinesVisible(true);
        java.awt.Stroke stroke21 = categoryPlot9.getOutlineStroke();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean23 = categoryPlot9.equals((java.lang.Object) chartChangeEventType22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0, jFreeChart1, chartChangeEventType22);
        java.lang.String str25 = chartChangeEventType22.toString();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str28 = numberAxis27.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        numberAxis27.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis27.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot33.zoomDomainAxes((double) (short) 100, plotRenderingInfo36, point2D37, true);
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot41 = categoryPlot33.getRootPlot();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis43.setMarkerBand(markerAxisBand45);
        double double47 = numberAxis43.getLowerMargin();
        java.lang.Object obj48 = numberAxis43.clone();
        numberAxis43.setNegativeArrowVisible(false);
        numberAxis43.setVisible(false);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str56 = numberAxis55.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = null;
        numberAxis55.setMarkerBand(markerAxisBand57);
        numberAxis55.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis55.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot61);
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        org.jfree.chart.axis.AxisSpace axisSpace66 = numberAxis43.reserveSpace(graphics2D53, (org.jfree.chart.plot.Plot) categoryPlot61, rectangle2D63, rectangleEdge64, axisSpace65);
        categoryPlot33.setFixedRangeAxisSpace(axisSpace66, true);
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str71 = numberAxis70.getLabelURL();
        java.awt.Color color73 = java.awt.Color.orange;
        java.awt.Color color74 = java.awt.Color.getColor("", color73);
        numberAxis70.setLabelPaint((java.awt.Paint) color74);
        java.awt.Paint paint76 = numberAxis70.getTickLabelPaint();
        org.jfree.data.Range range77 = categoryPlot33.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis70);
        categoryPlot33.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis80.setCategoryLabelPositionOffset(100);
        int int83 = categoryPlot33.getDomainAxisIndex(categoryAxis80);
        boolean boolean84 = chartChangeEventType22.equals((java.lang.Object) categoryAxis80);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(sortOrder17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str25.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.05d + "'", double47 == 0.05d);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(axisSpace66);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNull(range77);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        int int2 = objectList1.size();
        java.lang.Object obj4 = objectList1.get(2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int6 = color5.getGreen();
        int int7 = objectList1.indexOf((java.lang.Object) int6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = valueMarker17.getLabelAnchor();
        java.lang.String str19 = valueMarker17.getLabel();
        valueMarker17.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker17.setLabelOffset(rectangleInsets22);
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker17, layer24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot7.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot7.render(graphics2D27, rectangle2D28, 12, plotRenderingInfo30);
        boolean boolean32 = categoryPlot7.isDomainZoomable();
        boolean boolean33 = categoryPlot7.isRangeZoomable();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot7.setRenderer((int) '#', categoryItemRenderer10, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        categoryPlot7.setDrawingSupplier(drawingSupplier13);
        categoryPlot7.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource6);
        numberAxis1.setAutoRange(false);
        org.jfree.data.Range range10 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setRangeAboutValue((double) 1L, (double) 1);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str22 = numberAxis21.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis21.setMarkerBand(markerAxisBand23);
        double double25 = numberAxis21.getLowerMargin();
        java.lang.Object obj26 = numberAxis21.clone();
        java.text.NumberFormat numberFormat27 = null;
        numberAxis21.setNumberFormatOverride(numberFormat27);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean44 = numberAxis21.hasListener((java.util.EventListener) categoryPlot36);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer45);
        xYPlot46.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str53 = numberAxis52.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand54 = null;
        numberAxis52.setMarkerBand(markerAxisBand54);
        double double56 = numberAxis52.getLowerMargin();
        java.lang.Object obj57 = numberAxis52.clone();
        numberAxis52.setNegativeArrowVisible(false);
        numberAxis52.setVisible(false);
        java.awt.Graphics2D graphics2D62 = null;
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str65 = numberAxis64.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand66 = null;
        numberAxis64.setMarkerBand(markerAxisBand66);
        numberAxis64.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis64.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot70);
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = null;
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        org.jfree.chart.axis.AxisSpace axisSpace75 = numberAxis52.reserveSpace(graphics2D62, (org.jfree.chart.plot.Plot) categoryPlot70, rectangle2D72, rectangleEdge73, axisSpace74);
        categoryPlot70.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = null;
        java.util.List list78 = categoryPlot70.getCategoriesForAxis(categoryAxis77);
        xYPlot46.drawDomainTickBands(graphics2D49, rectangle2D50, list78);
        java.awt.Color color81 = java.awt.Color.orange;
        java.awt.Color color82 = java.awt.Color.getColor("", color81);
        java.awt.Color color83 = color82.brighter();
        xYPlot46.setRangeGridlinePaint((java.awt.Paint) color82);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer85 = xYPlot46.getRenderer();
        boolean boolean86 = xYPlot46.isRangeZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = xYPlot46.getRangeAxisEdge();
        try {
            java.util.List list88 = numberAxis1.refreshTicks(graphics2D14, axisState15, rectangle2D16, rectangleEdge87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertNotNull(axisSpace75);
        org.junit.Assert.assertNotNull(list78);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNull(xYItemRenderer85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(rectangleEdge87);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.CrosshairState crosshairState34 = null;
        boolean boolean35 = xYPlot29.render(graphics2D30, rectangle2D31, 8, plotRenderingInfo33, crosshairState34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot29.getRangeAxisLocation((int) 'a');
        int int38 = xYPlot29.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double41 = rectangleInsets39.calculateTopInset(1.0E-8d);
        double double43 = rectangleInsets39.calculateTopInset((double) 1);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color45 = java.awt.Color.orange;
        java.awt.Color color46 = color45.darker();
        java.awt.color.ColorSpace colorSpace47 = color45.getColorSpace();
        float[] floatArray52 = new float[] { (-1L), 1.0f, (-1.0f), (short) 1 };
        float[] floatArray53 = color44.getColorComponents(colorSpace47, floatArray52);
        boolean boolean54 = rectangleInsets39.equals((java.lang.Object) floatArray52);
        xYPlot29.setInsets(rectangleInsets39);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = xYPlot29.getOrientation();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.0d + "'", double41 == 2.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.0d + "'", double43 == 2.0d);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(colorSpace47);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(plotOrientation56);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color7 = java.awt.Color.orange;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color7.getColorSpace();
        float[] floatArray14 = new float[] { (-1L), 1.0f, (-1.0f), (short) 1 };
        float[] floatArray15 = color6.getColorComponents(colorSpace9, floatArray14);
        float[] floatArray16 = color5.getRGBColorComponents(floatArray14);
        float[] floatArray17 = color4.getRGBComponents(floatArray16);
        float[] floatArray18 = java.awt.Color.RGBtoHSB(1, 100, 0, floatArray17);
        float[] floatArray19 = color0.getComponents(floatArray17);
        java.awt.color.ColorSpace colorSpace20 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(colorSpace20);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setCategoryLabelPositionOffset(100);
        double double3 = categoryAxis0.getCategoryMargin();
        java.lang.Object obj4 = categoryAxis0.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        float float32 = xYPlot29.getBackgroundImageAlpha();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder33 = xYPlot29.getSeriesRenderingOrder();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.5f + "'", float32 == 0.5f);
        org.junit.Assert.assertNotNull(seriesRenderingOrder33);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        xYPlot29.setDataset(100, xYDataset34);
        xYPlot29.clearRangeMarkers();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot29.getRangeAxisEdge(12);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        xYPlot29.setRangeAxis(500, valueAxis40);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = valueMarker32.getLabelAnchor();
        java.lang.String str34 = valueMarker32.getLabel();
        valueMarker32.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str37 = valueMarker32.getLabel();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot29.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker32, layer38, true);
        java.awt.Stroke stroke41 = xYPlot29.getDomainGridlineStroke();
        xYPlot29.mapDatasetToDomainAxis(0, (int) (byte) 1);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        double double51 = numberAxis47.getLowerMargin();
        java.lang.Object obj52 = numberAxis47.clone();
        numberAxis47.setNegativeArrowVisible(false);
        numberAxis47.setVisible(false);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str60 = numberAxis59.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis59.setMarkerBand(markerAxisBand61);
        numberAxis59.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis59.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot65);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        org.jfree.chart.axis.AxisSpace axisSpace70 = numberAxis47.reserveSpace(graphics2D57, (org.jfree.chart.plot.Plot) categoryPlot65, rectangle2D67, rectangleEdge68, axisSpace69);
        java.awt.Paint paint71 = numberAxis47.getTickMarkPaint();
        xYPlot29.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) numberAxis47, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation74 = null;
        try {
            xYPlot29.addAnnotation(xYAnnotation74, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str37.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(axisSpace70);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder44);
        categoryPlot19.setColumnRenderingOrder(sortOrder44);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot19.getLegendItems();
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        categoryPlot19.addChangeListener(plotChangeListener48);
        boolean boolean50 = categoryPlot19.isRangeZoomable();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
//        java.lang.String str2 = numberAxis1.getLabelURL();
//        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
//        numberAxis1.setMarkerBand(markerAxisBand3);
//        numberAxis1.setAutoRangeMinimumSize((double) 10L);
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
//        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
//        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
//        categoryPlot7.setDataset(categoryDataset9);
//        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
//        categoryPlot7.setBackgroundImageAlignment((int) (byte) 1);
//        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.ASCENDING;
//        categoryPlot7.setRowRenderingOrder(sortOrder15);
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("SortOrder.ASCENDING");
//        boolean boolean19 = sortOrder15.equals((java.lang.Object) categoryAxis18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.String str22 = day20.toString();
//        long long23 = day20.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day20.previous();
//        boolean boolean25 = sortOrder15.equals((java.lang.Object) regularTimePeriod24);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertNull(categoryDataset12);
//        org.junit.Assert.assertNotNull(sortOrder15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis10.setMarkerBand(markerAxisBand12);
        numberAxis10.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot16.setDataset(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot16.getDataset(0);
        categoryPlot16.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean24 = numberAxis1.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = valueMarker27.getLabelAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        java.awt.Color color33 = java.awt.Color.orange;
        java.awt.Color color34 = java.awt.Color.getColor("", color33);
        numberAxis30.setLabelPaint((java.awt.Paint) color34);
        valueMarker27.setOutlinePaint((java.awt.Paint) color34);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean39 = categoryPlot16.removeDomainMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker27, layer37, false);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot16.getLegendItems();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(legendItemCollection40);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot29.getRenderer();
        boolean boolean69 = xYPlot29.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray70 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot29.setRenderers(xYItemRendererArray70);
        xYPlot29.setBackgroundAlpha((float) 200);
        org.jfree.chart.axis.AxisLocation axisLocation75 = xYPlot29.getRangeAxisLocation((int) (short) 10);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray70);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str6 = numberAxis5.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis5.setMarkerBand(markerAxisBand7);
        double double9 = numberAxis5.getLowerMargin();
        java.lang.Object obj10 = numberAxis5.clone();
        numberAxis5.setNegativeArrowVisible(false);
        numberAxis5.setVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        numberAxis17.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        org.jfree.chart.axis.AxisSpace axisSpace28 = numberAxis5.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot23, rectangle2D25, rectangleEdge26, axisSpace27);
        categoryPlot23.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        java.util.List list31 = categoryPlot23.getCategoriesForAxis(categoryAxis30);
        int int32 = categoryPlot23.getWeight();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.setTickMarkInsideLength((float) ' ');
        java.lang.String str37 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(axisSpace28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer8);
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis12.getLowerMargin();
        java.lang.Object obj17 = numberAxis12.clone();
        numberAxis12.setNegativeArrowVisible(false);
        numberAxis12.setVisible(false);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str25 = numberAxis24.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        numberAxis24.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis24.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        org.jfree.chart.axis.AxisSpace axisSpace35 = numberAxis12.reserveSpace(graphics2D22, (org.jfree.chart.plot.Plot) categoryPlot30, rectangle2D32, rectangleEdge33, axisSpace34);
        boolean boolean36 = objectList10.equals((java.lang.Object) axisSpace35);
        categoryPlot9.setFixedDomainAxisSpace(axisSpace35, false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(axisSpace35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.lang.String str34 = numberAxis31.getLabelToolTip();
        java.lang.String str35 = numberAxis31.getLabelToolTip();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(str35);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.lang.Class<?> wildcardClass2 = day0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        org.jfree.data.Range range5 = numberAxis1.getDefaultAutoRange();
        numberAxis1.setVisible(true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Color color1 = java.awt.Color.orange;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        java.awt.Color color3 = color2.brighter();
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        java.awt.Color color10 = color2.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintContext9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("SortOrder.ASCENDING");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        xYPlot29.setDataset(xYDataset63);
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean66 = xYPlot29.equals((java.lang.Object) stroke65);
        xYPlot29.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        double double21 = numberAxis17.getLowerMargin();
        java.lang.Object obj22 = numberAxis17.clone();
        numberAxis17.setNegativeArrowVisible(false);
        numberAxis17.setVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        org.jfree.chart.axis.AxisSpace axisSpace40 = numberAxis17.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot35, rectangle2D37, rectangleEdge38, axisSpace39);
        categoryPlot7.setFixedRangeAxisSpace(axisSpace40, true);
        org.jfree.chart.axis.ValueAxis valueAxis43 = categoryPlot7.getRangeAxis();
        java.awt.Color color44 = java.awt.Color.orange;
        java.awt.Color color45 = color44.darker();
        java.awt.Color color46 = color44.darker();
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color46);
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions50 = categoryAxis49.getCategoryLabelPositions();
        categoryAxis49.configure();
        java.util.List list52 = categoryPlot7.getCategoriesForAxis(categoryAxis49);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(axisSpace40);
        org.junit.Assert.assertNull(valueAxis43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(categoryLabelPositions50);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot7.setRenderer((int) '#', categoryItemRenderer10, false);
        org.jfree.data.general.DatasetGroup datasetGroup13 = categoryPlot7.getDatasetGroup();
        java.util.List list14 = categoryPlot7.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot16.getDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot16.setDomainAxisLocation(axisLocation18, true);
        categoryPlot7.setDomainAxisLocation(axisLocation18);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(datasetGroup13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        numberAxis1.setLabelPaint((java.awt.Paint) color5);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setRangeAboutValue((double) (short) 100, (double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        double double17 = numberAxis13.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis13.setStandardTickUnits(tickUnitSource18);
        numberAxis13.setAutoRange(false);
        org.jfree.data.Range range22 = numberAxis13.getDefaultAutoRange();
        org.jfree.data.Range range23 = numberAxis13.getRange();
        numberAxis1.setRange(range23, true, false);
        java.awt.Stroke stroke27 = numberAxis1.getAxisLineStroke();
        java.lang.String str28 = numberAxis1.getLabelURL();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = valueMarker40.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor42 = valueMarker40.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker40.setLabelOffset(rectangleInsets43);
        java.awt.Stroke stroke45 = valueMarker40.getStroke();
        float float46 = valueMarker40.getAlpha();
        java.awt.Paint paint47 = valueMarker40.getLabelPaint();
        xYPlot29.setDomainCrosshairPaint(paint47);
        java.awt.Paint paint49 = xYPlot29.getRangeCrosshairPaint();
        try {
            java.awt.Paint paint51 = xYPlot29.getQuadrantPaint(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (12) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.8f + "'", float46 == 0.8f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint49);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        int int3 = day0.getMonth();
//        int int4 = day0.getYear();
//        java.util.Calendar calendar5 = null;
//        try {
//            day0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        xYPlot29.setRangeCrosshairVisible(false);
        java.util.List list65 = xYPlot29.getAnnotations();
        xYPlot29.zoom((double) (-376));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(list65);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        xYPlot29.setRangeCrosshairVisible(false);
        java.awt.Stroke stroke65 = xYPlot29.getRangeGridlineStroke();
        java.awt.Paint paint66 = xYPlot29.getDomainCrosshairPaint();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot7.getDataset(0);
        categoryPlot7.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder15 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot7.setRowRenderingOrder(sortOrder15);
        categoryPlot7.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str22 = numberAxis21.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis21.setMarkerBand(markerAxisBand23);
        double double25 = numberAxis21.getLowerMargin();
        java.lang.Object obj26 = numberAxis21.clone();
        numberAxis21.setNegativeArrowVisible(false);
        numberAxis21.setVisible(false);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis33.setMarkerBand(markerAxisBand35);
        numberAxis33.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        org.jfree.chart.axis.AxisSpace axisSpace44 = numberAxis21.reserveSpace(graphics2D31, (org.jfree.chart.plot.Plot) categoryPlot39, rectangle2D41, rectangleEdge42, axisSpace43);
        numberAxis21.setRangeAboutValue((double) 'a', 0.0d);
        numberAxis21.setAutoTickUnitSelection(true);
        categoryPlot7.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) numberAxis21, false);
        boolean boolean52 = numberAxis21.isNegativeArrowVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(sortOrder15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(axisSpace44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        boolean boolean64 = xYPlot29.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot29.getRangeAxisEdge((int) (short) -1);
        xYPlot29.configureDomainAxes();
        xYPlot29.mapDatasetToDomainAxis(4, (int) (short) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection71 = xYPlot29.getLegendItems();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(legendItemCollection71);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder63 = xYPlot29.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(datasetRenderingOrder63);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot29.getAxisOffset();
        java.awt.Stroke stroke40 = xYPlot29.getRangeZeroBaselineStroke();
        java.awt.Paint[] paintArray41 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray42 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke45 = numberAxis44.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker47 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = valueMarker47.getLabelAnchor();
        java.lang.String str49 = valueMarker47.getLabel();
        valueMarker47.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint52 = valueMarker47.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke55 = numberAxis54.getTickMarkStroke();
        valueMarker47.setOutlineStroke(stroke55);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str59 = numberAxis58.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand60 = null;
        numberAxis58.setMarkerBand(markerAxisBand60);
        numberAxis58.setPositiveArrowVisible(true);
        java.awt.Stroke stroke64 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis58.setTickMarkStroke(stroke64);
        valueMarker47.setStroke(stroke64);
        java.awt.Stroke[] strokeArray67 = new java.awt.Stroke[] { stroke45, stroke64 };
        java.awt.Stroke[] strokeArray68 = null;
        java.awt.Shape[] shapeArray69 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier70 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray41, paintArray42, strokeArray67, strokeArray68, shapeArray69);
        java.awt.Stroke stroke71 = defaultDrawingSupplier70.getNextStroke();
        xYPlot29.setRangeCrosshairStroke(stroke71);
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis73.setTickLabelFont((java.lang.Comparable) 14.0d, font75);
        xYPlot29.setNoDataMessageFont(font75);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paintArray41);
        org.junit.Assert.assertNotNull(paintArray42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(strokeArray67);
        org.junit.Assert.assertNotNull(shapeArray69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font75);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource6);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis1.java2DToValue((-1.0d), rectangle2D9, rectangleEdge10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str21 = numberAxis20.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis20.setMarkerBand(markerAxisBand22);
        double double24 = numberAxis20.getLowerMargin();
        java.lang.Object obj25 = numberAxis20.clone();
        java.text.NumberFormat numberFormat26 = null;
        numberAxis20.setNumberFormatOverride(numberFormat26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        categoryPlot35.setDataset(categoryDataset37);
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot35.getDataset(0);
        categoryPlot35.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean43 = numberAxis20.hasListener((java.util.EventListener) categoryPlot35);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer44);
        xYPlot45.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str52 = numberAxis51.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = null;
        numberAxis51.setMarkerBand(markerAxisBand53);
        double double55 = numberAxis51.getLowerMargin();
        java.lang.Object obj56 = numberAxis51.clone();
        numberAxis51.setNegativeArrowVisible(false);
        numberAxis51.setVisible(false);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str64 = numberAxis63.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = null;
        numberAxis63.setMarkerBand(markerAxisBand65);
        numberAxis63.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis63.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot69);
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        org.jfree.chart.axis.AxisSpace axisSpace73 = null;
        org.jfree.chart.axis.AxisSpace axisSpace74 = numberAxis51.reserveSpace(graphics2D61, (org.jfree.chart.plot.Plot) categoryPlot69, rectangle2D71, rectangleEdge72, axisSpace73);
        categoryPlot69.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis76 = null;
        java.util.List list77 = categoryPlot69.getCategoriesForAxis(categoryAxis76);
        xYPlot45.drawDomainTickBands(graphics2D48, rectangle2D49, list77);
        java.awt.Color color80 = java.awt.Color.orange;
        java.awt.Color color81 = java.awt.Color.getColor("", color80);
        java.awt.Color color82 = color81.brighter();
        xYPlot45.setRangeGridlinePaint((java.awt.Paint) color81);
        java.awt.Paint paint84 = xYPlot45.getRangeCrosshairPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder85 = xYPlot45.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = xYPlot45.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo87 = null;
        try {
            org.jfree.chart.axis.AxisState axisState88 = numberAxis1.draw(graphics2D12, 0.0d, rectangle2D14, rectangle2D15, rectangleEdge86, plotRenderingInfo87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + Double.NEGATIVE_INFINITY + "'", double11 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(axisSpace74);
        org.junit.Assert.assertNotNull(list77);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(seriesRenderingOrder85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        valueMarker1.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint6 = valueMarker1.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke9 = numberAxis8.getTickMarkStroke();
        valueMarker1.setOutlineStroke(stroke9);
        valueMarker1.setLabel("hi!");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor13);
        java.awt.Stroke stroke15 = valueMarker1.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker1.getLabelOffset();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        int int16 = categoryPlot7.getDomainAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot7.setFixedRangeAxisSpace(axisSpace17);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        numberAxis36.setNegativeArrowVisible(false);
        numberAxis36.setVisible(false);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        numberAxis48.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis36.reserveSpace(graphics2D46, (org.jfree.chart.plot.Plot) categoryPlot54, rectangle2D56, rectangleEdge57, axisSpace58);
        categoryPlot54.clearRangeMarkers();
        boolean boolean61 = categoryPlot54.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot54.setRangeAxisLocation(10, axisLocation63, false);
        xYPlot29.setDomainAxisLocation((int) (short) 0, axisLocation63);
        java.awt.Paint paint67 = xYPlot29.getDomainGridlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str70 = numberAxis69.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand71 = null;
        numberAxis69.setMarkerBand(markerAxisBand71);
        numberAxis69.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis69.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot75);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = null;
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot75.zoomDomainAxes((double) (short) 100, plotRenderingInfo78, point2D79, true);
        org.jfree.chart.axis.AxisSpace axisSpace82 = categoryPlot75.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot83 = categoryPlot75.getRootPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection84 = categoryPlot75.getLegendItems();
        xYPlot29.setFixedLegendItems(legendItemCollection84);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(axisSpace59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertNull(axisSpace82);
        org.junit.Assert.assertNotNull(plot83);
        org.junit.Assert.assertNotNull(legendItemCollection84);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        categoryPlot19.drawBackgroundImage(graphics2D25, rectangle2D26);
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) 100, (float) 1560409200000L, (float) 10L);
        categoryPlot19.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str38 = numberAxis37.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand39 = null;
        numberAxis37.setMarkerBand(markerAxisBand39);
        double double41 = numberAxis37.getLowerMargin();
        java.lang.Object obj42 = numberAxis37.clone();
        java.text.NumberFormat numberFormat43 = null;
        numberAxis37.setNumberFormatOverride(numberFormat43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str47 = numberAxis46.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand48 = null;
        numberAxis46.setMarkerBand(markerAxisBand48);
        numberAxis46.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis46.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        categoryPlot52.setDataset(categoryDataset54);
        org.jfree.data.category.CategoryDataset categoryDataset57 = categoryPlot52.getDataset(0);
        categoryPlot52.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean60 = numberAxis37.hasListener((java.util.EventListener) categoryPlot52);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.plot.XYPlot xYPlot62 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer61);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str66 = numberAxis65.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = null;
        numberAxis65.setMarkerBand(markerAxisBand67);
        double double69 = numberAxis65.getLowerMargin();
        java.lang.Object obj70 = numberAxis65.clone();
        numberAxis65.setNegativeArrowVisible(false);
        numberAxis65.setVisible(false);
        java.awt.Graphics2D graphics2D75 = null;
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str78 = numberAxis77.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand79 = null;
        numberAxis77.setMarkerBand(markerAxisBand79);
        numberAxis77.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot83 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis77.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot83);
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        org.jfree.chart.axis.AxisSpace axisSpace87 = null;
        org.jfree.chart.axis.AxisSpace axisSpace88 = numberAxis65.reserveSpace(graphics2D75, (org.jfree.chart.plot.Plot) categoryPlot83, rectangle2D85, rectangleEdge86, axisSpace87);
        categoryPlot83.clearRangeMarkers();
        boolean boolean90 = categoryPlot83.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation92 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot83.setRangeAxisLocation(10, axisLocation92, false);
        xYPlot62.setRangeAxisLocation(4, axisLocation92);
        categoryPlot19.setRangeAxisLocation(axisLocation92);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer97 = categoryPlot19.getRenderer();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.05d + "'", double41 == 0.05d);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNull(categoryDataset57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.05d + "'", double69 == 0.05d);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(axisSpace88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertNull(categoryItemRenderer97);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        java.awt.Paint paint68 = xYPlot29.getRangeCrosshairPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder69 = xYPlot29.getSeriesRenderingOrder();
        xYPlot29.clearDomainAxes();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(seriesRenderingOrder69);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke7);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis1.setMarkerBand(markerAxisBand9);
        numberAxis1.setLabelAngle((double) 100);
        java.awt.Paint paint13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis1.setTickLabelPaint(paint13);
        numberAxis1.setTickMarkOutsideLength((-1.0f));
        java.awt.Color color17 = java.awt.Color.cyan;
        numberAxis1.setTickMarkPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        numberAxis1.setLabelPaint((java.awt.Paint) color5);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setRangeAboutValue((double) (short) 100, (double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        double double17 = numberAxis13.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis13.setStandardTickUnits(tickUnitSource18);
        numberAxis13.setAutoRange(false);
        org.jfree.data.Range range22 = numberAxis13.getDefaultAutoRange();
        org.jfree.data.Range range23 = numberAxis13.getRange();
        numberAxis1.setRangeWithMargins(range23, false, true);
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.getColor("SortOrder.ASCENDING", color28);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(markerAxisBand31);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        java.util.List list16 = categoryPlot7.getAnnotations();
        boolean boolean17 = categoryPlot7.isRangeZoomable();
        java.lang.String str18 = categoryPlot7.getNoDataMessage();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot29.getRenderer();
        boolean boolean69 = xYPlot29.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray70 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot29.setRenderers(xYItemRendererArray70);
        boolean boolean72 = xYPlot29.isDomainCrosshairLockedOnData();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean72);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot7.setRenderer((int) '#', categoryItemRenderer10, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot7.getDataset((int) ' ');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(categoryDataset14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        valueMarker1.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint6 = valueMarker1.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke9 = numberAxis8.getTickMarkStroke();
        valueMarker1.setOutlineStroke(stroke9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        numberAxis12.setPositiveArrowVisible(true);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis12.setTickMarkStroke(stroke18);
        valueMarker1.setStroke(stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        valueMarker1.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker1.getLabelAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, 14.0d, (double) 100, (double) 'a');
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        java.awt.Paint paint33 = xYPlot29.getDomainCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot29.getRangeAxisLocation((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str40 = numberAxis39.getLabelURL();
        java.awt.Color color42 = java.awt.Color.orange;
        java.awt.Color color43 = java.awt.Color.getColor("", color42);
        numberAxis39.setLabelPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = valueMarker46.getLabelAnchor();
        java.lang.String str48 = valueMarker46.getLabel();
        valueMarker46.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str51 = valueMarker46.getLabel();
        java.awt.Stroke stroke52 = valueMarker46.getStroke();
        java.awt.Color color53 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = valueMarker55.getLabelAnchor();
        java.lang.String str57 = valueMarker55.getLabel();
        valueMarker55.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint60 = valueMarker55.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke63 = numberAxis62.getTickMarkStroke();
        valueMarker55.setOutlineStroke(stroke63);
        org.jfree.chart.plot.IntervalMarker intervalMarker66 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color43, stroke52, (java.awt.Paint) color53, stroke63, 0.0f);
        intervalMarker66.setEndValue((double) (-1));
        double double69 = intervalMarker66.getStartValue();
        intervalMarker66.setEndValue((double) 100);
        xYPlot29.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker66);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str51.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.0d + "'", double69 == 2.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        double double2 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        valueMarker1.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint6 = valueMarker1.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke9 = numberAxis8.getTickMarkStroke();
        valueMarker1.setOutlineStroke(stroke9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis12.getLowerMargin();
        java.lang.Object obj17 = numberAxis12.clone();
        numberAxis12.setNegativeArrowVisible(false);
        numberAxis12.setVisible(false);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str25 = numberAxis24.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        numberAxis24.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis24.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        org.jfree.chart.axis.AxisSpace axisSpace35 = numberAxis12.reserveSpace(graphics2D22, (org.jfree.chart.plot.Plot) categoryPlot30, rectangle2D32, rectangleEdge33, axisSpace34);
        categoryPlot30.clearRangeMarkers();
        boolean boolean37 = categoryPlot30.getDrawSharedDomainAxis();
        boolean boolean38 = valueMarker1.equals((java.lang.Object) categoryPlot30);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        categoryPlot30.setRangeAxis(0, valueAxis40, true);
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot30.getColumnRenderingOrder();
        java.awt.Font font44 = categoryPlot30.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(axisSpace35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis1.setTickMarkStroke(stroke7);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis1.setMarkerBand(markerAxisBand9);
        numberAxis1.setLabelAngle((double) 100);
        java.awt.Paint paint13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        numberAxis1.setTickLabelPaint(paint13);
        boolean boolean15 = numberAxis1.isInverted();
        numberAxis1.setTickMarkInsideLength((float) (short) 10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot29.getAxisOffset();
        java.awt.Stroke stroke40 = xYPlot29.getRangeZeroBaselineStroke();
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = null;
        boolean boolean46 = xYPlot29.render(graphics2D41, rectangle2D42, 0, plotRenderingInfo44, crosshairState45);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis47.setTickUnit(dateTickUnit48, false, true);
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = valueMarker53.getLabelAnchor();
        java.lang.String str55 = valueMarker53.getLabel();
        float float56 = valueMarker53.getAlpha();
        java.awt.Stroke stroke57 = valueMarker53.getStroke();
        dateAxis47.setTickMarkStroke(stroke57);
        dateAxis47.zoomRange((double) (-15423), 0.0d);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=255,b=0]", timeZone63);
        dateAxis47.setTimeZone(timeZone63);
        org.jfree.data.Range range66 = xYPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis47);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTickUnit48);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.8f + "'", float56 == 0.8f);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(range66);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        double double21 = numberAxis17.getLowerMargin();
        java.lang.Object obj22 = numberAxis17.clone();
        numberAxis17.setNegativeArrowVisible(false);
        numberAxis17.setVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        org.jfree.chart.axis.AxisSpace axisSpace40 = numberAxis17.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot35, rectangle2D37, rectangleEdge38, axisSpace39);
        categoryPlot7.setFixedRangeAxisSpace(axisSpace40, true);
        org.jfree.chart.axis.ValueAxis valueAxis44 = categoryPlot7.getRangeAxis((-15423));
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str47 = numberAxis46.getLabelURL();
        numberAxis46.setAutoRangeMinimumSize((double) 1);
        java.awt.Color color50 = java.awt.Color.red;
        numberAxis46.setLabelPaint((java.awt.Paint) color50);
        java.lang.String str52 = color50.toString();
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color50);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(axisSpace40);
        org.junit.Assert.assertNull(valueAxis44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str52.equals("java.awt.Color[r=255,g=0,b=0]"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        numberAxis1.setLabelPaint((java.awt.Paint) color5);
        numberAxis1.resizeRange(0.0d);
        numberAxis1.setRangeAboutValue((double) (short) 100, (double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        double double17 = numberAxis13.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis13.setStandardTickUnits(tickUnitSource18);
        numberAxis13.setAutoRange(false);
        org.jfree.data.Range range22 = numberAxis13.getDefaultAutoRange();
        org.jfree.data.Range range23 = numberAxis13.getRange();
        numberAxis1.setRangeWithMargins(range23, false, true);
        java.awt.Color color28 = java.awt.Color.PINK;
        java.awt.Color color29 = java.awt.Color.getColor("SortOrder.ASCENDING", color28);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color29);
        java.awt.Color color31 = color29.brighter();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.plot.Plot plot26 = categoryPlot19.getParent();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertNull(plot26);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str7 = numberAxis6.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis6.setMarkerBand(markerAxisBand8);
        numberAxis6.setPositiveArrowVisible(true);
        java.awt.Paint paint12 = numberAxis6.getTickLabelPaint();
        numberAxis6.setLabelAngle(0.0d);
        java.lang.String str15 = numberAxis6.getLabel();
        float float16 = numberAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis6.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource17);
        org.jfree.data.Range range19 = dateAxis0.getDefaultAutoRange();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str25 = numberAxis24.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        double double28 = numberAxis24.getLowerMargin();
        java.lang.Object obj29 = numberAxis24.clone();
        java.text.NumberFormat numberFormat30 = null;
        numberAxis24.setNumberFormatOverride(numberFormat30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str34 = numberAxis33.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = null;
        numberAxis33.setMarkerBand(markerAxisBand35);
        numberAxis33.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis33.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        categoryPlot39.setDataset(categoryDataset41);
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot39.getDataset(0);
        categoryPlot39.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean47 = numberAxis24.hasListener((java.util.EventListener) categoryPlot39);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis24, xYItemRenderer48);
        xYPlot49.setRangeCrosshairValue((double) ' ');
        int int52 = xYPlot49.getDomainAxisCount();
        xYPlot49.setRangeCrosshairLockedOnData(false);
        java.awt.Color color56 = java.awt.Color.PINK;
        java.awt.Color color57 = java.awt.Color.getColor("SortOrder.ASCENDING", color56);
        xYPlot49.setDomainTickBandPaint((java.awt.Paint) color56);
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = valueMarker60.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor62 = valueMarker60.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker60.setLabelOffset(rectangleInsets63);
        java.awt.Stroke stroke65 = valueMarker60.getStroke();
        float float66 = valueMarker60.getAlpha();
        java.awt.Paint paint67 = valueMarker60.getLabelPaint();
        xYPlot49.setDomainCrosshairPaint(paint67);
        java.awt.Paint paint69 = xYPlot49.getRangeCrosshairPaint();
        dateAxis0.setTickLabelPaint(paint69);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(textAnchor62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + float66 + "' != '" + 0.8f + "'", float66 == 0.8f);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(paint69);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis3.setMarkerBand(markerAxisBand5);
        org.jfree.data.Range range7 = numberAxis3.getDefaultAutoRange();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3, categoryItemRenderer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot9.getDomainAxis((int) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker26);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker29.getLabelAnchor();
        java.lang.String str31 = valueMarker29.getLabel();
        valueMarker29.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker29.setLabelOffset(rectangleInsets34);
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker29, layer36);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot19.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = valueMarker41.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor43 = valueMarker41.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker41.setLabelOffset(rectangleInsets44);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str51 = numberAxis50.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand52 = null;
        numberAxis50.setMarkerBand(markerAxisBand52);
        double double54 = numberAxis50.getLowerMargin();
        java.lang.Object obj55 = numberAxis50.clone();
        java.text.NumberFormat numberFormat56 = null;
        numberAxis50.setNumberFormatOverride(numberFormat56);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str60 = numberAxis59.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis59.setMarkerBand(markerAxisBand61);
        numberAxis59.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis59.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot65);
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        categoryPlot65.setDataset(categoryDataset67);
        org.jfree.data.category.CategoryDataset categoryDataset70 = categoryPlot65.getDataset(0);
        categoryPlot65.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean73 = numberAxis50.hasListener((java.util.EventListener) categoryPlot65);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis48, (org.jfree.chart.axis.ValueAxis) numberAxis50, xYItemRenderer74);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder76 = xYPlot75.getDatasetRenderingOrder();
        org.jfree.chart.plot.ValueMarker valueMarker79 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor80 = valueMarker79.getLabelAnchor();
        java.lang.String str81 = valueMarker79.getLabel();
        valueMarker79.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.Layer layer84 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean85 = xYPlot75.removeRangeMarker((int) ' ', (org.jfree.chart.plot.Marker) valueMarker79, layer84);
        java.lang.String str86 = layer84.toString();
        categoryPlot19.addRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker41, layer84, false);
        java.util.Collection collection89 = categoryPlot9.getDomainMarkers(layer84);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNull(categoryDataset70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder76);
        org.junit.Assert.assertNotNull(rectangleAnchor80);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNotNull(layer84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "Layer.FOREGROUND" + "'", str86.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection89);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        java.lang.String str3 = valueMarker1.getLabel();
        valueMarker1.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint6 = valueMarker1.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke9 = numberAxis8.getTickMarkStroke();
        valueMarker1.setOutlineStroke(stroke9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        numberAxis12.setPositiveArrowVisible(true);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis12.setTickMarkStroke(stroke18);
        valueMarker1.setStroke(stroke18);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = valueMarker22.getLabelAnchor();
        java.lang.String str24 = valueMarker22.getLabel();
        valueMarker22.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str27 = valueMarker22.getLabel();
        java.awt.Stroke stroke28 = valueMarker22.getStroke();
        valueMarker1.setStroke(stroke28);
        java.awt.Paint paint30 = valueMarker1.getOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str27.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder44);
        categoryPlot19.setColumnRenderingOrder(sortOrder44);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot19.getLegendItems();
        org.jfree.chart.event.PlotChangeListener plotChangeListener48 = null;
        categoryPlot19.addChangeListener(plotChangeListener48);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str52 = numberAxis51.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand53 = null;
        numberAxis51.setMarkerBand(markerAxisBand53);
        double double55 = numberAxis51.getLowerMargin();
        java.lang.Object obj56 = numberAxis51.clone();
        numberAxis51.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str61 = numberAxis60.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis60.setMarkerBand(markerAxisBand62);
        double double64 = numberAxis60.getLowerMargin();
        java.lang.Object obj65 = numberAxis60.clone();
        numberAxis60.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str70 = numberAxis69.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand71 = null;
        numberAxis69.setMarkerBand(markerAxisBand71);
        double double73 = numberAxis69.getLowerMargin();
        java.awt.Font font74 = numberAxis69.getLabelFont();
        numberAxis60.setLabelFont(font74);
        numberAxis51.setLabelFont(font74);
        categoryPlot19.setNoDataMessageFont(font74);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.05d + "'", double64 == 0.05d);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(font74);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        java.util.List list27 = categoryPlot19.getCategoriesForAxis(categoryAxis26);
        int int28 = categoryPlot19.getWeight();
        categoryPlot19.setRangeGridlinesVisible(true);
        java.awt.Paint paint31 = categoryPlot19.getRangeGridlinePaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str28 = numberAxis27.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        numberAxis27.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis27.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot33.zoomDomainAxes((double) (short) 100, plotRenderingInfo36, point2D37, true);
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot41 = categoryPlot33.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = null;
        plot41.notifyListeners(plotChangeEvent42);
        java.awt.Paint paint44 = plot41.getBackgroundPaint();
        categoryPlot19.setDomainGridlinePaint(paint44);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray46 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot19.setDomainAxes(categoryAxisArray46);
        categoryPlot19.setRangeCrosshairValue((double) (-1L));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(categoryAxisArray46);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo13, point2D14);
        boolean boolean16 = categoryPlot7.isSubplot();
        categoryPlot7.clearAnnotations();
        double double18 = categoryPlot7.getAnchorValue();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str22 = numberAxis21.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis21.setMarkerBand(markerAxisBand23);
        numberAxis21.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis21.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot27.setDataset(categoryDataset29);
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot27.getDataset(0);
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 10);
        categoryPlot27.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = valueMarker37.getLabelAnchor();
        java.lang.String str39 = valueMarker37.getLabel();
        valueMarker37.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker37.setLabelOffset(rectangleInsets42);
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot27.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker37, layer44);
        valueMarker37.setValue((double) 1L);
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean50 = categoryPlot7.removeRangeMarker(7, (org.jfree.chart.plot.Marker) valueMarker37, layer48, false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot19.setRenderer(categoryItemRenderer26, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str31 = numberAxis30.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = null;
        numberAxis30.setMarkerBand(markerAxisBand32);
        numberAxis30.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis30.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot36.setDataset(categoryDataset38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = categoryPlot36.getDataset(0);
        categoryPlot36.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder44 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder44);
        categoryPlot19.setRowRenderingOrder(sortOrder44);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions49 = categoryAxis48.getCategoryLabelPositions();
        categoryAxis48.setCategoryLabelPositionOffset(0);
        categoryAxis48.removeCategoryLabelToolTip((java.lang.Comparable) "ChartChangeEventType.DATASET_UPDATED");
        double double54 = categoryAxis48.getUpperMargin();
        java.awt.Font font56 = categoryAxis48.getTickLabelFont((java.lang.Comparable) "UnitType.ABSOLUTE");
        categoryPlot19.setDomainAxis((int) '#', categoryAxis48);
        java.awt.Stroke stroke58 = categoryAxis48.getTickMarkStroke();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNull(categoryDataset41);
        org.junit.Assert.assertNotNull(sortOrder44);
        org.junit.Assert.assertNotNull(categoryLabelPositions49);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = valueMarker1.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor3 = valueMarker1.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker1.setLabelOffset(rectangleInsets4);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        java.lang.String str9 = valueMarker7.getLabel();
        valueMarker7.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint12 = valueMarker7.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke15 = numberAxis14.getTickMarkStroke();
        valueMarker7.setOutlineStroke(stroke15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str19 = numberAxis18.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis18.setMarkerBand(markerAxisBand20);
        numberAxis18.setPositiveArrowVisible(true);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis18.setTickMarkStroke(stroke24);
        valueMarker7.setStroke(stroke24);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        double double32 = numberAxis28.getLowerMargin();
        java.awt.Font font33 = numberAxis28.getLabelFont();
        valueMarker7.setLabelFont(font33);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor35 = valueMarker7.getLabelAnchor();
        valueMarker1.setLabelAnchor(rectangleAnchor35);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(rectangleAnchor35);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        java.awt.Color color64 = java.awt.Color.orange;
        java.awt.Color color65 = java.awt.Color.getColor("", color64);
        java.awt.Color color66 = color65.brighter();
        xYPlot29.setRangeGridlinePaint((java.awt.Paint) color65);
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str71 = numberAxis70.getLabelURL();
        numberAxis70.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = numberAxis70.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = numberAxis70.getLabelInsets();
        numberAxis70.centerRange(1.0d);
        java.lang.Object obj78 = numberAxis70.clone();
        xYPlot29.setDomainAxis(12, (org.jfree.chart.axis.ValueAxis) numberAxis70, false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(obj78);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        xYPlot29.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis31);
        java.lang.Object obj34 = null;
        boolean boolean35 = numberAxis31.equals(obj34);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        float float26 = categoryPlot19.getForegroundAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxisForDataset(500);
        categoryPlot19.setForegroundAlpha((float) (short) -1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str11 = numberAxis10.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis10.setMarkerBand(markerAxisBand12);
        numberAxis10.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis10.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot16.setDataset(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot16.getDataset(0);
        categoryPlot16.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean24 = numberAxis1.hasListener((java.util.EventListener) categoryPlot16);
        boolean boolean25 = categoryPlot16.isRangeZoomable();
        float float26 = categoryPlot16.getBackgroundAlpha();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        float float56 = categoryPlot50.getBackgroundImageAlpha();
        categoryPlot50.setAnchorValue((double) 0.5f);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str61 = numberAxis60.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand62 = null;
        numberAxis60.setMarkerBand(markerAxisBand62);
        double double64 = numberAxis60.getLowerMargin();
        java.lang.Object obj65 = numberAxis60.clone();
        numberAxis60.setNegativeArrowVisible(false);
        numberAxis60.setVisible(false);
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str73 = numberAxis72.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand74 = null;
        numberAxis72.setMarkerBand(markerAxisBand74);
        numberAxis72.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis72.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot78);
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        org.jfree.chart.axis.AxisSpace axisSpace82 = null;
        org.jfree.chart.axis.AxisSpace axisSpace83 = numberAxis60.reserveSpace(graphics2D70, (org.jfree.chart.plot.Plot) categoryPlot78, rectangle2D80, rectangleEdge81, axisSpace82);
        categoryPlot78.clearRangeMarkers();
        boolean boolean85 = categoryPlot78.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation87 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot78.setRangeAxisLocation(10, axisLocation87, false);
        categoryPlot50.setDomainAxisLocation(axisLocation87);
        xYPlot29.setDomainAxisLocation(200, axisLocation87, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer93 = null;
        xYPlot29.setRenderer(xYItemRenderer93);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + float56 + "' != '" + 0.5f + "'", float56 == 0.5f);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.05d + "'", double64 == 0.05d);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(axisSpace83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(axisLocation87);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str28 = numberAxis27.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis27.setMarkerBand(markerAxisBand29);
        numberAxis27.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis27.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot33.zoomDomainAxes((double) (short) 100, plotRenderingInfo36, point2D37, true);
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot33.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot41 = categoryPlot33.getRootPlot();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = null;
        plot41.notifyListeners(plotChangeEvent42);
        java.awt.Paint paint44 = plot41.getBackgroundPaint();
        categoryPlot19.setDomainGridlinePaint(paint44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot19.getLegendItems();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(legendItemCollection46);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        java.lang.Object obj40 = numberAxis35.clone();
        numberAxis35.setNegativeArrowVisible(false);
        numberAxis35.setVisible(false);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        numberAxis47.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis47.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot53);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis35.reserveSpace(graphics2D45, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D55, rectangleEdge56, axisSpace57);
        categoryPlot53.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        java.util.List list61 = categoryPlot53.getCategoriesForAxis(categoryAxis60);
        xYPlot29.drawDomainTickBands(graphics2D32, rectangle2D33, list61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot29.getRangeAxis();
        boolean boolean64 = xYPlot29.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = xYPlot29.getRangeAxisEdge((int) (short) -1);
        java.awt.Stroke stroke67 = xYPlot29.getOutlineStroke();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertNotNull(axisSpace58);
        org.junit.Assert.assertNotNull(list61);
        org.junit.Assert.assertNotNull(valueAxis63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertNotNull(stroke67);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        boolean boolean33 = xYPlot29.isDomainGridlinesVisible();
        org.jfree.chart.util.ObjectList objectList34 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        numberAxis36.setNegativeArrowVisible(false);
        numberAxis36.setVisible(false);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        numberAxis48.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis36.reserveSpace(graphics2D46, (org.jfree.chart.plot.Plot) categoryPlot54, rectangle2D56, rectangleEdge57, axisSpace58);
        boolean boolean60 = objectList34.equals((java.lang.Object) axisSpace59);
        xYPlot29.setFixedRangeAxisSpace(axisSpace59);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        int int63 = xYPlot29.getIndexOf(xYItemRenderer62);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(axisSpace59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        boolean boolean2 = categoryAxis0.equals((java.lang.Object) color1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        numberAxis4.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = numberAxis4.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = numberAxis4.getLabelInsets();
        java.awt.Color color10 = java.awt.Color.orange;
        java.awt.Color color11 = color10.darker();
        boolean boolean12 = rectangleInsets9.equals((java.lang.Object) color11);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color11);
        java.awt.Font font15 = categoryAxis0.getTickLabelFont((java.lang.Comparable) "TextAnchor.TOP_RIGHT");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str8 = numberAxis7.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand9 = null;
        numberAxis7.setMarkerBand(markerAxisBand9);
        double double11 = numberAxis7.getLowerMargin();
        java.lang.Object obj12 = numberAxis7.clone();
        java.lang.String str13 = numberAxis7.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis7.setTickUnit(numberTickUnit14, true, false);
        numberAxis1.setTickUnit(numberTickUnit14, false, true);
        float float21 = numberAxis1.getTickMarkOutsideLength();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = null;
        numberAxis1.setMarkerBand(markerAxisBand22);
        boolean boolean24 = numberAxis1.isVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        float float26 = categoryPlot19.getForegroundAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot19.getDomainAxis(10);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis31.setMarkerBand(markerAxisBand33);
        numberAxis31.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot37.setDataset(categoryDataset39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot37.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo43, point2D44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        categoryPlot37.setRenderer(categoryItemRenderer46);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = valueMarker49.getLabelAnchor();
        java.lang.String str51 = valueMarker49.getLabel();
        java.awt.Color color53 = java.awt.Color.orange;
        java.awt.Color color54 = java.awt.Color.getColor("", color53);
        java.awt.Color color55 = color54.brighter();
        valueMarker49.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot37.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker49, layer57);
        java.util.Collection collection59 = categoryPlot19.getRangeMarkers(3, layer57);
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = categoryPlot19.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str63 = numberAxis62.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = null;
        numberAxis62.setMarkerBand(markerAxisBand64);
        numberAxis62.setAutoRangeMinimumSize((double) 10L);
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis62.setTickMarkStroke(stroke68);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand70 = null;
        numberAxis62.setMarkerBand(markerAxisBand70);
        numberAxis62.setLabelAngle((double) 100);
        java.awt.Color color74 = java.awt.Color.ORANGE;
        numberAxis62.setTickLabelPaint((java.awt.Paint) color74);
        boolean boolean76 = plotOrientation60.equals((java.lang.Object) color74);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = valueMarker32.getLabelAnchor();
        java.lang.String str34 = valueMarker32.getLabel();
        valueMarker32.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str37 = valueMarker32.getLabel();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean40 = xYPlot29.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker32, layer38, true);
        java.awt.Paint paint41 = xYPlot29.getRangeGridlinePaint();
        xYPlot29.configureDomainAxes();
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            xYPlot29.drawOutline(graphics2D43, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str37.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource6);
        numberAxis1.setAutoRange(false);
        org.jfree.data.Range range10 = numberAxis1.getDefaultAutoRange();
        org.jfree.data.Range range11 = numberAxis1.getRange();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str17 = numberAxis16.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis16.setMarkerBand(markerAxisBand18);
        double double20 = numberAxis16.getLowerMargin();
        java.lang.Object obj21 = numberAxis16.clone();
        java.text.NumberFormat numberFormat22 = null;
        numberAxis16.setNumberFormatOverride(numberFormat22);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str26 = numberAxis25.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis25.setMarkerBand(markerAxisBand27);
        numberAxis25.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis25.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot31.setDataset(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot31.getDataset(0);
        categoryPlot31.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean39 = numberAxis16.hasListener((java.util.EventListener) categoryPlot31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer40);
        xYPlot41.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        double double51 = numberAxis47.getLowerMargin();
        java.lang.Object obj52 = numberAxis47.clone();
        numberAxis47.setNegativeArrowVisible(false);
        numberAxis47.setVisible(false);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str60 = numberAxis59.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis59.setMarkerBand(markerAxisBand61);
        numberAxis59.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis59.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot65);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        org.jfree.chart.axis.AxisSpace axisSpace70 = numberAxis47.reserveSpace(graphics2D57, (org.jfree.chart.plot.Plot) categoryPlot65, rectangle2D67, rectangleEdge68, axisSpace69);
        categoryPlot65.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        java.util.List list73 = categoryPlot65.getCategoriesForAxis(categoryAxis72);
        xYPlot41.drawDomainTickBands(graphics2D44, rectangle2D45, list73);
        java.awt.Stroke stroke75 = xYPlot41.getRangeGridlineStroke();
        java.awt.Stroke stroke76 = xYPlot41.getRangeZeroBaselineStroke();
        numberAxis1.setTickMarkStroke(stroke76);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNull(categoryDataset36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(axisSpace70);
        org.junit.Assert.assertNotNull(list73);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(stroke76);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis31.setMarkerBand(markerAxisBand33);
        double double35 = numberAxis31.getLowerMargin();
        java.lang.Object obj36 = numberAxis31.clone();
        numberAxis31.setNegativeArrowVisible(false);
        numberAxis31.setVisible(false);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis43.setMarkerBand(markerAxisBand45);
        numberAxis43.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis43.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot49);
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = numberAxis31.reserveSpace(graphics2D41, (org.jfree.chart.plot.Plot) categoryPlot49, rectangle2D51, rectangleEdge52, axisSpace53);
        xYPlot29.setFixedDomainAxisSpace(axisSpace54, true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(axisSpace54);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo13, point2D14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot7.setRenderer(categoryItemRenderer16);
        categoryPlot7.setAnchorValue(4.0d);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot7.getRangeAxis((-3695));
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis1.lengthToJava2D((double) (short) 100, rectangle2D8, rectangleEdge9);
        boolean boolean11 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setInverted(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = valueMarker17.getLabelAnchor();
        java.lang.String str19 = valueMarker17.getLabel();
        valueMarker17.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint22 = valueMarker17.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke25 = numberAxis24.getTickMarkStroke();
        valueMarker17.setOutlineStroke(stroke25);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        numberAxis28.setPositiveArrowVisible(true);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis28.setTickMarkStroke(stroke34);
        valueMarker17.setStroke(stroke34);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean39 = categoryPlot7.removeRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker17, layer37, true);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot7.setRangeCrosshairPaint((java.awt.Paint) color40);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = null;
        categoryPlot7.notifyListeners(plotChangeEvent42);
        org.jfree.chart.util.ObjectList objectList45 = new org.jfree.chart.util.ObjectList();
        objectList45.clear();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str50 = numberAxis49.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand51 = null;
        numberAxis49.setMarkerBand(markerAxisBand51);
        numberAxis49.setPositiveArrowVisible(true);
        java.awt.Paint paint55 = numberAxis49.getTickLabelPaint();
        numberAxis49.setLabelAngle(0.0d);
        java.lang.String str58 = numberAxis49.getLabel();
        float float59 = numberAxis49.getTickMarkInsideLength();
        org.jfree.chart.axis.TickUnitSource tickUnitSource60 = numberAxis49.getStandardTickUnits();
        objectList45.set(100, (java.lang.Object) tickUnitSource60);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str65 = numberAxis64.getLabelURL();
        numberAxis64.setAutoRangeMinimumSize((double) 1);
        java.awt.Color color68 = java.awt.Color.red;
        numberAxis64.setLabelPaint((java.awt.Paint) color68);
        objectList45.set(5, (java.lang.Object) numberAxis64);
        categoryPlot7.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis64, false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.0f + "'", float59 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource60);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertNotNull(color68);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str6 = numberAxis5.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis5.setMarkerBand(markerAxisBand7);
        double double9 = numberAxis5.getLowerMargin();
        java.lang.Object obj10 = numberAxis5.clone();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis5.setNumberFormatOverride(numberFormat11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str15 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis14.setMarkerBand(markerAxisBand16);
        numberAxis14.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis14.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot20.setDataset(categoryDataset22);
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot20.getDataset(0);
        categoryPlot20.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean28 = numberAxis5.hasListener((java.util.EventListener) categoryPlot20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer29);
        xYPlot30.setRangeCrosshairValue((double) ' ');
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        numberAxis36.setNegativeArrowVisible(false);
        numberAxis36.setVisible(false);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        numberAxis48.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis36.reserveSpace(graphics2D46, (org.jfree.chart.plot.Plot) categoryPlot54, rectangle2D56, rectangleEdge57, axisSpace58);
        categoryPlot54.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        java.util.List list62 = categoryPlot54.getCategoriesForAxis(categoryAxis61);
        xYPlot30.drawDomainTickBands(graphics2D33, rectangle2D34, list62);
        java.awt.Color color65 = java.awt.Color.orange;
        java.awt.Color color66 = java.awt.Color.getColor("", color65);
        java.awt.Color color67 = color66.brighter();
        xYPlot30.setRangeGridlinePaint((java.awt.Paint) color66);
        java.awt.Paint paint69 = xYPlot30.getRangeCrosshairPaint();
        org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = valueMarker71.getLabelAnchor();
        java.lang.String str73 = valueMarker71.getLabel();
        valueMarker71.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint76 = valueMarker71.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke79 = numberAxis78.getTickMarkStroke();
        valueMarker71.setOutlineStroke(stroke79);
        xYPlot30.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker71);
        boolean boolean82 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker71);
        org.jfree.chart.plot.ValueMarker valueMarker84 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor85 = valueMarker84.getLabelAnchor();
        java.lang.String str86 = valueMarker84.getLabel();
        valueMarker84.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str89 = valueMarker84.getLabel();
        valueMarker84.setValue(1.0E-8d);
        org.jfree.data.general.Dataset dataset92 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent93 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 1.0E-8d, dataset92);
        categoryPlot0.datasetChanged(datasetChangeEvent93);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(axisSpace59);
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor85);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str89.equals("TextAnchor.HALF_ASCENT_RIGHT"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color5 = java.awt.Color.getColor("", color4);
        numberAxis1.setLabelPaint((java.awt.Paint) color5);
        numberAxis1.resizeRange(0.0d);
        boolean boolean9 = numberAxis1.isAutoTickUnitSelection();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.plot.CrosshairState crosshairState34 = null;
        boolean boolean35 = xYPlot29.render(graphics2D30, rectangle2D31, 8, plotRenderingInfo33, crosshairState34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = xYPlot29.getRangeAxisLocation((int) 'a');
        int int38 = xYPlot29.getDomainAxisCount();
        java.awt.Stroke stroke39 = xYPlot29.getRangeCrosshairStroke();
        java.awt.Image image40 = xYPlot29.getBackgroundImage();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(image40);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = dateAxis0.getTickUnit();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = dateAxis0.getTickUnit();
        dateAxis0.setUpperBound(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str7 = numberAxis6.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis6.setMarkerBand(markerAxisBand8);
        numberAxis6.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis6.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot12.setDataset(categoryDataset14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot12.getDataset(0);
        categoryPlot12.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder20 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot12.setRowRenderingOrder(sortOrder20);
        categoryPlot12.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str27 = numberAxis26.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis26.setMarkerBand(markerAxisBand28);
        double double30 = numberAxis26.getLowerMargin();
        java.lang.Object obj31 = numberAxis26.clone();
        numberAxis26.setNegativeArrowVisible(false);
        numberAxis26.setVisible(false);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str39 = numberAxis38.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand40 = null;
        numberAxis38.setMarkerBand(markerAxisBand40);
        numberAxis38.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis38.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot44);
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        org.jfree.chart.axis.AxisSpace axisSpace49 = numberAxis26.reserveSpace(graphics2D36, (org.jfree.chart.plot.Plot) categoryPlot44, rectangle2D46, rectangleEdge47, axisSpace48);
        numberAxis26.setRangeAboutValue((double) 'a', 0.0d);
        numberAxis26.setAutoTickUnitSelection(true);
        categoryPlot12.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str59 = numberAxis58.getLabelURL();
        java.awt.Color color61 = java.awt.Color.orange;
        java.awt.Color color62 = java.awt.Color.getColor("", color61);
        numberAxis58.setLabelPaint((java.awt.Paint) color62);
        numberAxis58.resizeRange(0.0d);
        numberAxis58.setRangeAboutValue((double) (short) 100, (double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str71 = numberAxis70.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand72 = null;
        numberAxis70.setMarkerBand(markerAxisBand72);
        double double74 = numberAxis70.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource75 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis70.setStandardTickUnits(tickUnitSource75);
        numberAxis70.setAutoRange(false);
        org.jfree.data.Range range79 = numberAxis70.getDefaultAutoRange();
        org.jfree.data.Range range80 = numberAxis70.getRange();
        numberAxis58.setRange(range80, true, false);
        numberAxis26.setDefaultAutoRange(range80);
        dateAxis0.setRange(range80);
        double double86 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.05d + "'", double30 == 0.05d);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(axisSpace49);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.05d + "'", double74 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource75);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot29.getAxisOffset();
        java.awt.Stroke stroke40 = xYPlot29.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYPlot29.rendererChanged(rendererChangeEvent41);
        xYPlot29.setNoDataMessage("java.awt.Color[r=255,g=255,b=0]");
        java.awt.Paint paint45 = xYPlot29.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str48 = numberAxis47.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand49 = null;
        numberAxis47.setMarkerBand(markerAxisBand49);
        double double51 = numberAxis47.getLowerMargin();
        java.lang.Object obj52 = numberAxis47.clone();
        numberAxis47.setNegativeArrowVisible(false);
        numberAxis47.setVisible(false);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str60 = numberAxis59.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis59.setMarkerBand(markerAxisBand61);
        numberAxis59.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis59.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot65);
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = null;
        org.jfree.chart.axis.AxisSpace axisSpace69 = null;
        org.jfree.chart.axis.AxisSpace axisSpace70 = numberAxis47.reserveSpace(graphics2D57, (org.jfree.chart.plot.Plot) categoryPlot65, rectangle2D67, rectangleEdge68, axisSpace69);
        xYPlot29.setFixedDomainAxisSpace(axisSpace70);
        org.jfree.data.xy.XYDataset xYDataset73 = xYPlot29.getDataset((int) (byte) -1);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(axisSpace70);
        org.junit.Assert.assertNull(xYDataset73);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.configure();
        java.util.Date date4 = dateAxis2.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis5.setTickUnit(dateTickUnit6, false, true);
        java.util.Date date10 = dateAxis2.calculateLowestVisibleTickValue(dateTickUnit6);
        dateAxis1.setMinimumDate(date10);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getRGBComponents(floatArray5);
        float[] floatArray7 = color3.getColorComponents(floatArray5);
        float[] floatArray8 = java.awt.Color.RGBtoHSB(200, 12, (int) (short) -1, floatArray7);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str33 = numberAxis32.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis32.setMarkerBand(markerAxisBand34);
        double double36 = numberAxis32.getLowerMargin();
        java.lang.Object obj37 = numberAxis32.clone();
        numberAxis32.setNegativeArrowVisible(false);
        numberAxis32.setVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str45 = numberAxis44.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand46 = null;
        numberAxis44.setMarkerBand(markerAxisBand46);
        numberAxis44.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis44.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot50);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        org.jfree.chart.axis.AxisSpace axisSpace55 = numberAxis32.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot50, rectangle2D52, rectangleEdge53, axisSpace54);
        categoryPlot50.clearRangeMarkers();
        boolean boolean57 = categoryPlot50.getDrawSharedDomainAxis();
        org.jfree.chart.axis.AxisLocation axisLocation59 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot50.setRangeAxisLocation(10, axisLocation59, false);
        xYPlot29.setRangeAxisLocation(4, axisLocation59);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        xYPlot29.setRenderer(0, xYItemRenderer64);
        java.awt.Font font66 = xYPlot29.getNoDataMessageFont();
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot29.getRangeAxis((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str72 = numberAxis71.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand73 = null;
        numberAxis71.setMarkerBand(markerAxisBand73);
        double double75 = numberAxis71.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource76 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis71.setStandardTickUnits(tickUnitSource76);
        numberAxis71.setAutoRange(false);
        org.jfree.data.Range range80 = numberAxis71.getDefaultAutoRange();
        numberAxis71.setRangeAboutValue((double) 1L, (double) 1);
        xYPlot29.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis71);
        boolean boolean85 = numberAxis71.getAutoRangeIncludesZero();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(axisSpace55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNull(valueAxis68);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.05d + "'", double75 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource76);
        org.junit.Assert.assertNotNull(range80);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = valueMarker40.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor42 = valueMarker40.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        valueMarker40.setLabelOffset(rectangleInsets43);
        java.awt.Stroke stroke45 = valueMarker40.getStroke();
        float float46 = valueMarker40.getAlpha();
        java.awt.Paint paint47 = valueMarker40.getLabelPaint();
        xYPlot29.setDomainCrosshairPaint(paint47);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        xYPlot29.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier49);
        java.awt.Paint paint51 = defaultDrawingSupplier49.getNextPaint();
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.8f + "'", float46 == 0.8f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        xYPlot29.setRangeCrosshairValue((double) ' ');
        int int32 = xYPlot29.getDomainAxisCount();
        xYPlot29.setRangeCrosshairLockedOnData(false);
        java.awt.Color color36 = java.awt.Color.PINK;
        java.awt.Color color37 = java.awt.Color.getColor("SortOrder.ASCENDING", color36);
        xYPlot29.setDomainTickBandPaint((java.awt.Paint) color36);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot29.getAxisOffset();
        java.awt.Stroke stroke40 = xYPlot29.getRangeZeroBaselineStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
        xYPlot29.rendererChanged(rendererChangeEvent41);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = valueMarker44.getLabelAnchor();
        java.lang.String str46 = valueMarker44.getLabel();
        valueMarker44.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint49 = valueMarker44.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke52 = numberAxis51.getTickMarkStroke();
        valueMarker44.setOutlineStroke(stroke52);
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str56 = numberAxis55.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand57 = null;
        numberAxis55.setMarkerBand(markerAxisBand57);
        numberAxis55.setPositiveArrowVisible(true);
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis55.setTickMarkStroke(stroke61);
        valueMarker44.setStroke(stroke61);
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str66 = numberAxis65.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = null;
        numberAxis65.setMarkerBand(markerAxisBand67);
        double double69 = numberAxis65.getLowerMargin();
        java.awt.Font font70 = numberAxis65.getLabelFont();
        valueMarker44.setLabelFont(font70);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = valueMarker44.getLabelAnchor();
        boolean boolean73 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker44);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.05d + "'", double69 == 0.05d);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot7.setDataset(categoryDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot7.zoomRangeAxes(0.0d, (double) 0.0f, plotRenderingInfo13, point2D14);
        boolean boolean16 = categoryPlot7.isSubplot();
        categoryPlot7.setAnchorValue((double) 12);
        java.awt.Image image19 = null;
        categoryPlot7.setBackgroundImage(image19);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str4 = numberAxis3.getLabelURL();
        java.awt.Color color6 = java.awt.Color.orange;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        numberAxis3.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = valueMarker10.getLabelAnchor();
        java.lang.String str12 = valueMarker10.getLabel();
        valueMarker10.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.lang.String str15 = valueMarker10.getLabel();
        java.awt.Stroke stroke16 = valueMarker10.getStroke();
        java.awt.Color color17 = java.awt.Color.orange;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker19.getLabelAnchor();
        java.lang.String str21 = valueMarker19.getLabel();
        valueMarker19.setLabel("TextAnchor.HALF_ASCENT_RIGHT");
        java.awt.Paint paint24 = valueMarker19.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("");
        java.awt.Stroke stroke27 = numberAxis26.getTickMarkStroke();
        valueMarker19.setOutlineStroke(stroke27);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(2.0d, 0.0d, (java.awt.Paint) color7, stroke16, (java.awt.Paint) color17, stroke27, 0.0f);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        intervalMarker30.setLabelPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str35 = numberAxis34.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        numberAxis34.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis34.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        categoryPlot40.setDataset(categoryDataset42);
        categoryPlot40.setAnchorValue(0.0d, false);
        boolean boolean47 = intervalMarker30.equals((java.lang.Object) false);
        double double48 = intervalMarker30.getEndValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TextAnchor.HALF_ASCENT_RIGHT" + "'", str15.equals("TextAnchor.HALF_ASCENT_RIGHT"));
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis1.setTickUnit(dateTickUnit2, false, true);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) 10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        java.lang.String str9 = valueMarker7.getLabel();
        float float10 = valueMarker7.getAlpha();
        java.awt.Stroke stroke11 = valueMarker7.getStroke();
        dateAxis1.setTickMarkStroke(stroke11);
        dateAxis1.zoomRange((double) (-15423), 0.0d);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=255,g=255,b=0]", timeZone17);
        dateAxis1.setTimeZone(timeZone17);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.TOP_LEFT", timeZone17);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.8f + "'", float10 == 0.8f);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str5 = numberAxis4.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis4.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis4.getLowerMargin();
        java.lang.Object obj9 = numberAxis4.clone();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis4.setNumberFormatOverride(numberFormat10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot19.setDataset(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot19.getDataset(0);
        categoryPlot19.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean27 = numberAxis4.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis4, xYItemRenderer28);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean32 = xYPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker31);
        boolean boolean33 = xYPlot29.isDomainGridlinesVisible();
        org.jfree.chart.util.ObjectList objectList34 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        numberAxis36.setNegativeArrowVisible(false);
        numberAxis36.setVisible(false);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str49 = numberAxis48.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand50 = null;
        numberAxis48.setMarkerBand(markerAxisBand50);
        numberAxis48.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis48.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot54);
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        org.jfree.chart.axis.AxisSpace axisSpace59 = numberAxis36.reserveSpace(graphics2D46, (org.jfree.chart.plot.Plot) categoryPlot54, rectangle2D56, rectangleEdge57, axisSpace58);
        boolean boolean60 = objectList34.equals((java.lang.Object) axisSpace59);
        xYPlot29.setFixedRangeAxisSpace(axisSpace59);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = xYPlot29.getAxisOffset();
        double double64 = rectangleInsets62.calculateTopInset((double) ' ');
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(axisSpace59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 4.0d + "'", double64 == 4.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setOutlinePaint(paint1);
        boolean boolean3 = categoryPlot0.isDomainZoomable();
        double double4 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke5 = categoryPlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str6 = numberAxis5.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis5.setMarkerBand(markerAxisBand7);
        double double9 = numberAxis5.getLowerMargin();
        java.lang.Object obj10 = numberAxis5.clone();
        numberAxis5.setNegativeArrowVisible(false);
        numberAxis5.setVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        numberAxis17.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis17.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        org.jfree.chart.axis.AxisSpace axisSpace28 = numberAxis5.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot23, rectangle2D25, rectangleEdge26, axisSpace27);
        categoryPlot23.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        java.util.List list31 = categoryPlot23.getCategoriesForAxis(categoryAxis30);
        int int32 = categoryPlot23.getWeight();
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str36 = numberAxis35.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand37 = null;
        numberAxis35.setMarkerBand(markerAxisBand37);
        double double39 = numberAxis35.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource40 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis35.setStandardTickUnits(tickUnitSource40);
        numberAxis35.setAutoRange(false);
        org.jfree.data.Range range44 = numberAxis35.getDefaultAutoRange();
        boolean boolean45 = numberAxis35.isVerticalTickLabels();
        boolean boolean46 = categoryAxis0.equals((java.lang.Object) numberAxis35);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = numberAxis35.getTickLabelInsets();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(axisSpace28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource40);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangleInsets47);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str18 = numberAxis17.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = null;
        numberAxis17.setMarkerBand(markerAxisBand19);
        double double21 = numberAxis17.getLowerMargin();
        java.lang.Object obj22 = numberAxis17.clone();
        numberAxis17.setNegativeArrowVisible(false);
        numberAxis17.setVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str30 = numberAxis29.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis29.setMarkerBand(markerAxisBand31);
        numberAxis29.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis29.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        org.jfree.chart.axis.AxisSpace axisSpace40 = numberAxis17.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot35, rectangle2D37, rectangleEdge38, axisSpace39);
        categoryPlot7.setFixedRangeAxisSpace(axisSpace40, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis44.setCategoryLabelPositionOffset(100);
        int int47 = categoryAxis44.getMaximumCategoryLabelLines();
        categoryPlot7.setDomainAxis(0, categoryAxis44);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(axisSpace40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis0.setTickUnit(dateTickUnit1, false, true);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str7 = numberAxis6.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis6.setMarkerBand(markerAxisBand8);
        numberAxis6.setPositiveArrowVisible(true);
        java.awt.Paint paint12 = numberAxis6.getTickLabelPaint();
        numberAxis6.setLabelAngle(0.0d);
        java.lang.String str15 = numberAxis6.getLabel();
        float float16 = numberAxis6.getTickMarkInsideLength();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis6.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource17);
        org.jfree.data.Range range19 = dateAxis0.getDefaultAutoRange();
        java.util.Date date20 = dateAxis0.getMaximumDate();
        dateAxis0.setLowerMargin(10.0d);
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot7.removeChangeListener(plotChangeListener9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str13 = numberAxis12.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = null;
        numberAxis12.setMarkerBand(markerAxisBand14);
        double double16 = numberAxis12.getLowerMargin();
        java.lang.Object obj17 = numberAxis12.clone();
        numberAxis12.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str22 = numberAxis21.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis21.setMarkerBand(markerAxisBand23);
        double double25 = numberAxis21.getLowerMargin();
        java.awt.Font font26 = numberAxis21.getLabelFont();
        numberAxis12.setLabelFont(font26);
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str35 = numberAxis34.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = null;
        numberAxis34.setMarkerBand(markerAxisBand36);
        double double38 = numberAxis34.getLowerMargin();
        java.lang.Object obj39 = numberAxis34.clone();
        java.text.NumberFormat numberFormat40 = null;
        numberAxis34.setNumberFormatOverride(numberFormat40);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str44 = numberAxis43.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = null;
        numberAxis43.setMarkerBand(markerAxisBand45);
        numberAxis43.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis43.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot49);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        categoryPlot49.setDataset(categoryDataset51);
        org.jfree.data.category.CategoryDataset categoryDataset54 = categoryPlot49.getDataset(0);
        categoryPlot49.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean57 = numberAxis34.hasListener((java.util.EventListener) categoryPlot49);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer58);
        xYPlot59.setRangeCrosshairValue((double) ' ');
        int int62 = xYPlot59.getDomainAxisCount();
        xYPlot59.setRangeCrosshairLockedOnData(false);
        java.awt.Color color66 = java.awt.Color.PINK;
        java.awt.Color color67 = java.awt.Color.getColor("SortOrder.ASCENDING", color66);
        xYPlot59.setDomainTickBandPaint((java.awt.Paint) color66);
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot59.getDomainAxisLocation((int) (short) 10);
        categoryPlot7.setDomainAxisLocation(5, axisLocation70, true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNull(categoryDataset54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(axisLocation70);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        numberAxis1.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot7.zoomDomainAxes((double) (short) 100, plotRenderingInfo10, point2D11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.Plot plot15 = categoryPlot7.getRootPlot();
        java.util.List list16 = categoryPlot7.getAnnotations();
        boolean boolean17 = categoryPlot7.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str23 = numberAxis22.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand24 = null;
        numberAxis22.setMarkerBand(markerAxisBand24);
        double double26 = numberAxis22.getLowerMargin();
        java.lang.Object obj27 = numberAxis22.clone();
        java.text.NumberFormat numberFormat28 = null;
        numberAxis22.setNumberFormatOverride(numberFormat28);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str32 = numberAxis31.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = null;
        numberAxis31.setMarkerBand(markerAxisBand33);
        numberAxis31.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot37.setDataset(categoryDataset39);
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot37.getDataset(0);
        categoryPlot37.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean45 = numberAxis22.hasListener((java.util.EventListener) categoryPlot37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis22, xYItemRenderer46);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) 10);
        boolean boolean50 = xYPlot47.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker49);
        org.jfree.chart.axis.AxisLocation axisLocation51 = xYPlot47.getDomainAxisLocation();
        boolean boolean52 = categoryPlot7.equals((java.lang.Object) axisLocation51);
        java.awt.Paint[] paintArray53 = null;
        java.awt.Color color54 = java.awt.Color.red;
        java.awt.image.ColorModel colorModel55 = null;
        java.awt.Rectangle rectangle56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        java.awt.geom.AffineTransform affineTransform58 = null;
        java.awt.RenderingHints renderingHints59 = null;
        java.awt.PaintContext paintContext60 = color54.createContext(colorModel55, rectangle56, rectangle2D57, affineTransform58, renderingHints59);
        java.awt.Paint[] paintArray61 = new java.awt.Paint[] { color54 };
        java.awt.Stroke[] strokeArray62 = null;
        java.awt.Stroke[] strokeArray63 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str66 = numberAxis65.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = null;
        numberAxis65.setMarkerBand(markerAxisBand67);
        numberAxis65.setPositiveArrowVisible(true);
        java.awt.Paint paint71 = numberAxis65.getTickLabelPaint();
        numberAxis65.setLabelAngle(0.0d);
        java.lang.String str74 = numberAxis65.getLabel();
        float float75 = numberAxis65.getTickMarkInsideLength();
        java.awt.Shape shape76 = numberAxis65.getDownArrow();
        java.awt.Shape shape77 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.axis.NumberAxis numberAxis79 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str80 = numberAxis79.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand81 = null;
        numberAxis79.setMarkerBand(markerAxisBand81);
        org.jfree.data.Range range83 = numberAxis79.getDefaultAutoRange();
        java.awt.Shape shape84 = numberAxis79.getDownArrow();
        java.awt.Shape shape85 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape86 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray87 = new java.awt.Shape[] { shape76, shape77, shape84, shape85, shape86 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier88 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray53, paintArray61, strokeArray62, strokeArray63, shapeArray87);
        java.awt.Paint paint89 = defaultDrawingSupplier88.getNextOutlinePaint();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier88);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(plot15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(paintContext60);
        org.junit.Assert.assertNotNull(paintArray61);
        org.junit.Assert.assertNotNull(strokeArray63);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 0.0f + "'", float75 == 0.0f);
        org.junit.Assert.assertNotNull(shape76);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(shape84);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(shape86);
        org.junit.Assert.assertNotNull(shapeArray87);
        org.junit.Assert.assertNotNull(paint89);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str2 = numberAxis1.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis1.setMarkerBand(markerAxisBand3);
        double double5 = numberAxis1.getLowerMargin();
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str14 = numberAxis13.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis13.setMarkerBand(markerAxisBand15);
        numberAxis13.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis13.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        org.jfree.chart.axis.AxisSpace axisSpace24 = numberAxis1.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D21, rectangleEdge22, axisSpace23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        java.awt.Stroke stroke26 = categoryPlot19.getRangeCrosshairStroke();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str29 = numberAxis28.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis28.setMarkerBand(markerAxisBand30);
        double double32 = numberAxis28.getLowerMargin();
        java.lang.Object obj33 = numberAxis28.clone();
        numberAxis28.setNegativeArrowVisible(false);
        numberAxis28.setVisible(false);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str41 = numberAxis40.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = null;
        numberAxis40.setMarkerBand(markerAxisBand42);
        numberAxis40.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis40.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot46);
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        org.jfree.chart.axis.AxisSpace axisSpace51 = numberAxis28.reserveSpace(graphics2D38, (org.jfree.chart.plot.Plot) categoryPlot46, rectangle2D48, rectangleEdge49, axisSpace50);
        float float52 = categoryPlot46.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        categoryPlot46.setRenderer(categoryItemRenderer53, false);
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str58 = numberAxis57.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = null;
        numberAxis57.setMarkerBand(markerAxisBand59);
        numberAxis57.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis57.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot63);
        org.jfree.data.category.CategoryDataset categoryDataset65 = null;
        categoryPlot63.setDataset(categoryDataset65);
        org.jfree.data.category.CategoryDataset categoryDataset68 = categoryPlot63.getDataset(0);
        categoryPlot63.setBackgroundImageAlignment((int) (byte) 1);
        org.jfree.chart.util.SortOrder sortOrder71 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot63.setRowRenderingOrder(sortOrder71);
        categoryPlot46.setRowRenderingOrder(sortOrder71);
        java.lang.Object obj74 = null;
        boolean boolean75 = sortOrder71.equals(obj74);
        categoryPlot19.setColumnRenderingOrder(sortOrder71);
        float float77 = categoryPlot19.getBackgroundAlpha();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(axisSpace24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.05d + "'", double32 == 0.05d);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(axisSpace51);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.5f + "'", float52 == 0.5f);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNull(categoryDataset68);
        org.junit.Assert.assertNotNull(sortOrder71);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + float77 + "' != '" + 1.0f + "'", float77 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str3 = numberAxis2.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis2.setMarkerBand(markerAxisBand4);
        double double6 = numberAxis2.getLowerMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis2.setStandardTickUnits(tickUnitSource7);
        numberAxis2.setAutoRange(false);
        org.jfree.data.Range range11 = numberAxis2.getDefaultAutoRange();
        org.jfree.data.Range range12 = numberAxis2.getRange();
        float float13 = numberAxis2.getTickMarkOutsideLength();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str16 = numberAxis15.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis15.setMarkerBand(markerAxisBand17);
        double double19 = numberAxis15.getLowerMargin();
        java.lang.Object obj20 = numberAxis15.clone();
        numberAxis15.setNegativeArrowVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str25 = numberAxis24.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis24.setMarkerBand(markerAxisBand26);
        double double28 = numberAxis24.getLowerMargin();
        java.awt.Font font29 = numberAxis24.getLabelFont();
        numberAxis15.setLabelFont(font29);
        numberAxis2.setTickLabelFont(font29);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str37 = numberAxis36.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis36.setMarkerBand(markerAxisBand38);
        double double40 = numberAxis36.getLowerMargin();
        java.lang.Object obj41 = numberAxis36.clone();
        java.text.NumberFormat numberFormat42 = null;
        numberAxis36.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str46 = numberAxis45.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand47 = null;
        numberAxis45.setMarkerBand(markerAxisBand47);
        numberAxis45.setAutoRangeMinimumSize((double) 10L);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        numberAxis45.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot51);
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        categoryPlot51.setDataset(categoryDataset53);
        org.jfree.data.category.CategoryDataset categoryDataset56 = categoryPlot51.getDataset(0);
        categoryPlot51.setBackgroundImageAlignment((int) (byte) 1);
        boolean boolean59 = numberAxis36.hasListener((java.util.EventListener) categoryPlot51);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer60);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str64 = numberAxis63.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand65 = null;
        numberAxis63.setMarkerBand(markerAxisBand65);
        double double67 = numberAxis63.getLowerMargin();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis("");
        java.lang.String str70 = numberAxis69.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand71 = null;
        numberAxis69.setMarkerBand(markerAxisBand71);
        double double73 = numberAxis69.getLowerMargin();
        java.lang.Object obj74 = numberAxis69.clone();
        java.lang.String str75 = numberAxis69.getLabel();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit76 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis69.setTickUnit(numberTickUnit76, true, false);
        numberAxis63.setTickUnit(numberTickUnit76, false, true);
        java.awt.Shape shape83 = numberAxis63.getLeftArrow();
        numberAxis36.setUpArrow(shape83);
        java.awt.Shape shape85 = numberAxis36.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer86 = null;
        org.jfree.chart.plot.XYPlot xYPlot87 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer86);
        java.awt.Color color91 = java.awt.Color.getHSBColor((float) 100, (float) 1560409200000L, (float) 10L);
        numberAxis2.setTickMarkPaint((java.awt.Paint) color91);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.05d + "'", double40 == 0.05d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(categoryDataset56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.05d + "'", double67 == 0.05d);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.05d + "'", double73 == 0.05d);
        org.junit.Assert.assertNotNull(obj74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertNotNull(numberTickUnit76);
        org.junit.Assert.assertNotNull(shape83);
        org.junit.Assert.assertNotNull(shape85);
        org.junit.Assert.assertNotNull(color91);
    }
}

