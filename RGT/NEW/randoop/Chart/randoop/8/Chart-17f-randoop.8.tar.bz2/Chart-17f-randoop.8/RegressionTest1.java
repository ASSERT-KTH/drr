import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a', 2147483647, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.removeChangeListener(seriesChangeListener11);
        try {
            timeSeries2.delete(13, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.fireSeriesChanged();
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener13);
        try {
            timeSeries7.update(100, (java.lang.Number) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection12);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
//        long long7 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond10.peg(calendar11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10L);
//        java.util.List list15 = timeSeries8.getItems();
//        timeSeries8.setDescription("Third");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        int int20 = day18.getDayOfMonth();
//        java.lang.String str21 = day18.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond24, class25);
//        timeSeries26.setMaximumItemCount(100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond31.previous();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond31.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond31.getStart();
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
//        long long38 = year37.getFirstMillisecond();
//        long long39 = year37.getSerialIndex();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(6, year37);
//        long long41 = year37.getFirstMillisecond();
//        int int42 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) year37);
//        java.lang.Number number43 = null;
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) year37, number43, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-31507200000L) + "'", long38 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1969L + "'", long39 == 1969L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-31507200000L) + "'", long41 == (-31507200000L));
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        java.util.Date date9 = fixedMillisecond7.getTime();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getFirstMillisecond(calendar10);
        java.lang.Object obj12 = null;
        boolean boolean13 = fixedMillisecond7.equals(obj12);
        timeSeries2.setKey((java.lang.Comparable) boolean13);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.String str16 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.util.Date date24 = fixedMillisecond18.getTime();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.previous();
        long long19 = fixedMillisecond15.getSerialIndex();
        java.util.Date date20 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date10, timeZone21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date10, timeZone24);
        java.lang.Class<?> wildcardClass26 = day25.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("January");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        long long12 = fixedMillisecond7.getLastMillisecond();
        int int13 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond7);
        long long14 = fixedMillisecond7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
//        boolean boolean4 = timeSeries3.isEmpty();
//        java.lang.Class class5 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        int int8 = day6.getDayOfMonth();
//        boolean boolean9 = timeSeries3.equals((java.lang.Object) int8);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNull(class5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        boolean boolean7 = timeSeries2.equals((java.lang.Object) '4');
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        try {
            timeSeries2.removeAgedItems((long) (-1), true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 0);
        long long12 = fixedMillisecond6.getSerialIndex();
        long long13 = fixedMillisecond6.getLastMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries2.setDescription("31-December-1969");
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond18.getStart();
        java.util.Date date23 = fixedMillisecond18.getTime();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod26, (java.lang.Number) (byte) 100);
        int int30 = timeSeriesDataItem28.compareTo((java.lang.Object) "January");
        try {
            timeSeries2.add(timeSeriesDataItem28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.previous();
        long long18 = fixedMillisecond14.getSerialIndex();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.lang.Class<?> wildcardClass20 = date19.getClass();
        java.net.URL uRL21 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass20);
        java.net.URL uRL22 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass20);
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long26 = fixedMillisecond25.getFirstMillisecond();
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond25.getLastMillisecond(calendar27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond25.previous();
        java.util.Date date30 = fixedMillisecond25.getTime();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date30, timeZone32);
        java.io.InputStream inputStream34 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass20);
        try {
            org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) calendar7, (java.lang.Class) wildcardClass20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNull(uRL21);
        org.junit.Assert.assertNotNull(uRL22);
        org.junit.Assert.assertNull(inputStream23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(inputStream34);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        long long6 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        timeSeries7.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        long long12 = timeSeries2.getMaximumItemAge();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries2.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        int int11 = year10.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        int int16 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.previous();
        long long18 = month14.getLastMillisecond();
        java.lang.String str19 = month14.toString();
        int int20 = year10.compareTo((java.lang.Object) month14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.previous();
        long long26 = fixedMillisecond22.getSerialIndex();
        java.util.Date date27 = fixedMillisecond22.getTime();
        java.lang.Class<?> wildcardClass28 = date27.getClass();
        java.lang.ClassLoader classLoader29 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass28);
        int int30 = year10.compareTo((java.lang.Object) classLoader29);
        long long31 = year10.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62109475200001L) + "'", long18 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "October 0" + "'", str19.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(classLoader29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1969L + "'", long31 == 1969L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 0);
        long long12 = fixedMillisecond6.getSerialIndex();
        long long13 = fixedMillisecond6.getLastMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries2.setDescription("31-December-1969");
        try {
            timeSeries2.update(2147483647, (java.lang.Number) 1969L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(6, year8);
        long long12 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year8.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 2);
        timeSeriesDataItem6.setValue((java.lang.Number) (short) 0);
        java.lang.Object obj9 = timeSeriesDataItem6.clone();
        java.lang.Class<?> wildcardClass10 = obj9.getClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries(comparable0, "September 0", "October", (java.lang.Class) wildcardClass10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.removeChangeListener(seriesChangeListener11);
        int int13 = timeSeries2.getMaximumItemCount();
        timeSeries2.clear();
        java.util.List list15 = timeSeries2.getItems();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, class1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond4.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond4.getStart();
        java.util.Date date9 = fixedMillisecond4.getTime();
        java.util.Calendar calendar10 = null;
        fixedMillisecond4.peg(calendar10);
        java.lang.Number number12 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        java.lang.String str13 = timeSeries2.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: hi!");
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class5);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        timeSeries6.clear();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        timeSeries11.setDescription("");
//        timeSeries11.setDescription("");
//        java.util.List list19 = timeSeries11.getItems();
//        boolean boolean20 = day0.equals((java.lang.Object) timeSeries11);
//        java.util.Collection collection21 = timeSeries11.getTimePeriods();
//        try {
//            java.lang.Number number23 = timeSeries11.getValue((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(collection21);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 29);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        try {
            timeSeries2.delete((int) (byte) 100, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getMiddleMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.previous();
        long long9 = fixedMillisecond5.getSerialIndex();
        java.util.Date date10 = fixedMillisecond5.getTime();
        java.lang.Class<?> wildcardClass11 = date10.getClass();
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("September 0", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream13 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("13-June-2019", (java.lang.Class) wildcardClass11);
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("31-October-1970", (java.lang.Class) wildcardClass11);
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertNull(inputStream13);
        org.junit.Assert.assertNull(uRL14);
        org.junit.Assert.assertNull(inputStream15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year7.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(6, year8);
        long long12 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.next();
        java.util.Calendar calendar14 = null;
        try {
            year8.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
//        timeSeries3.setMaximumItemCount(100);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.previous();
//        int int11 = day6.getYear();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        int int5 = spreadsheetDate4.getYYYY();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.getDayOfMonth();
        java.util.Date date8 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond15.previous();
        long long19 = fixedMillisecond15.getSerialIndex();
        java.util.Date date20 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20, timeZone21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date10, timeZone21);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date10, timeZone24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date10, timeZone26);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class11);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        timeSeries12.clear();
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.addAndOrUpdate(timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries7.removeChangeListener(seriesChangeListener16);
        boolean boolean18 = fixedMillisecond1.equals((java.lang.Object) seriesChangeListener16);
        long long19 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        long long6 = month2.getLastMillisecond();
        long long7 = month2.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getFirstMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getStart();
        java.util.Date date16 = fixedMillisecond11.getTime();
        java.util.Calendar calendar17 = null;
        fixedMillisecond11.peg(calendar17);
        java.util.Date date19 = fixedMillisecond11.getEnd();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths(10, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        int int24 = day23.getYear();
        int int25 = month2.compareTo((java.lang.Object) int24);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62143689600000L) + "'", long7 == (-62143689600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1970 + "'", int24 == 1970);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        try {
            java.lang.Number number19 = timeSeries11.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 0);
        long long12 = fixedMillisecond6.getSerialIndex();
        long long13 = fixedMillisecond6.getLastMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries2.setDescription("31-October-1970");
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class18);
        java.lang.Class class20 = timeSeries19.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond24.getStart();
        java.util.Date date29 = fixedMillisecond24.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        java.util.Date date32 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(10, serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        boolean boolean37 = timeSeries19.equals((java.lang.Object) day36);
        long long38 = day36.getFirstMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) 1560409200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNull(class20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 23526000000L + "'", long38 == 23526000000L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, 8, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        int int11 = year10.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        int int16 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.previous();
        long long18 = month14.getLastMillisecond();
        java.lang.String str19 = month14.toString();
        int int20 = year10.compareTo((java.lang.Object) month14);
        int int22 = month14.compareTo((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62109475200001L) + "'", long18 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "October 0" + "'", str19.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, class1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond4.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond4.getStart();
        java.util.Date date9 = fixedMillisecond4.getTime();
        java.util.Calendar calendar10 = null;
        fixedMillisecond4.peg(calendar10);
        java.lang.Number number12 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        long long13 = fixedMillisecond4.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        java.util.Date date8 = fixedMillisecond6.getTime();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(4);
        int int13 = spreadsheetDate12.getYYYY();
        boolean boolean14 = spreadsheetDate2.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond16.getStart();
        java.util.Date date21 = fixedMillisecond16.getTime();
        java.util.Calendar calendar22 = null;
        fixedMillisecond16.peg(calendar22);
        java.util.Date date24 = fixedMillisecond16.getEnd();
        long long25 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long25);
        java.util.Collection collection27 = timeSeries26.getTimePeriods();
        boolean boolean28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) boolean14, (java.lang.Object) collection27);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', (int) (short) 1, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(11, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        long long10 = year8.getSerialIndex();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class17);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        timeSeries18.clear();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries18);
        timeSeries18.setDescription("");
        timeSeries18.setDescription("");
        boolean boolean26 = year8.equals((java.lang.Object) "");
        try {
            org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) 'a', year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        boolean boolean9 = day0.equals((java.lang.Object) year8);
//        int int10 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 13 + "'", int10 == 13);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(51L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month3);
        boolean boolean7 = month3.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.next();
        java.lang.String str9 = month3.toString();
        long long10 = month3.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 0" + "'", str9.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62143689600000L) + "'", long10 == (-62143689600000L));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        java.util.Date date9 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, 6, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = fixedMillisecond0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.Class class11 = timeSeries2.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeries2.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class11);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        boolean boolean3 = day0.equals((java.lang.Object) 11);
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7);
        java.lang.String str11 = day10.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        timeSeries13.fireSeriesChanged();
        java.util.Collection collection18 = timeSeries13.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getFirstMillisecond(calendar24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        timeSeries28.clear();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class32);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        timeSeries33.clear();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries28.addAndOrUpdate(timeSeries33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries28.removeChangeListener(seriesChangeListener37);
        boolean boolean39 = fixedMillisecond22.equals((java.lang.Object) seriesChangeListener37);
        timeSeries13.setKey((java.lang.Comparable) boolean39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries2.addAndOrUpdate(timeSeries13);
        try {
            timeSeries13.delete(1969, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        boolean boolean3 = day0.equals((java.lang.Object) 11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (-62126582400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        int int5 = spreadsheetDate4.getYYYY();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate10.getDayOfWeek();
        boolean boolean13 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int14 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        boolean boolean3 = day0.equals((java.lang.Object) (byte) 1);
        int int4 = day0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond8.getStart();
        java.util.Date date13 = fixedMillisecond8.getTime();
        java.util.Calendar calendar14 = null;
        fixedMillisecond8.peg(calendar14);
        java.util.Date date16 = fixedMillisecond8.getEnd();
        long long17 = fixedMillisecond8.getFirstMillisecond();
        int int18 = day6.compareTo((java.lang.Object) long17);
        org.jfree.data.time.SerialDate serialDate19 = day6.getSerialDate();
        int int20 = month2.compareTo((java.lang.Object) day6);
        java.util.Date date21 = day6.getStart();
        java.lang.Class class22 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond24.getStart();
        java.util.Date date29 = fixedMillisecond24.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        java.util.Date date32 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date32, timeZone34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond37.previous();
        long long41 = fixedMillisecond37.getSerialIndex();
        java.util.Date date42 = fixedMillisecond37.getTime();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date42, timeZone43);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date32, timeZone43);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date32, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date21, timeZone46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond50.previous();
        long long54 = fixedMillisecond50.getSerialIndex();
        java.util.Date date55 = fixedMillisecond50.getTime();
        java.lang.Class<?> wildcardClass56 = date55.getClass();
        java.lang.ClassLoader classLoader57 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date21, (java.lang.Class) wildcardClass56);
        boolean boolean59 = timeSeries58.getNotify();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62109475200001L) + "'", long5 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 52L + "'", long41 == 52L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 52L + "'", long52 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 52L + "'", long54 == 52L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertNotNull(classLoader57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond10.getStart();
        java.util.Date date15 = fixedMillisecond10.getTime();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.lang.String str19 = year16.toString();
        java.lang.Class class20 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getFirstMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond22.getStart();
        java.util.Date date27 = fixedMillisecond22.getTime();
        java.util.Calendar calendar28 = null;
        fixedMillisecond22.peg(calendar28);
        java.util.Date date30 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date30, timeZone32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.previous();
        long long39 = fixedMillisecond35.getSerialIndex();
        java.util.Date date40 = fixedMillisecond35.getTime();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40, timeZone41);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date30, timeZone41);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date30, timeZone44);
        boolean boolean46 = year16.equals((java.lang.Object) timeZone44);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date6, timeZone44);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969" + "'", str19.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 52L + "'", long37 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        timeSeries2.clear();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        timeSeries7.clear();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener11);
//        timeSeries2.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond16, class17);
//        timeSeries18.setMaximumItemCount(100);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 100);
//        java.util.Collection collection25 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        java.lang.Class class26 = timeSeries2.getTimePeriodClass();
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNull(class26);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) (byte) 100);
        java.lang.Object obj12 = null;
        int int13 = timeSeriesDataItem11.compareTo(obj12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long16 = fixedMillisecond15.getFirstMillisecond();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.previous();
        java.lang.String str22 = fixedMillisecond20.toString();
        int int23 = fixedMillisecond15.compareTo((java.lang.Object) str22);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        timeSeries26.clear();
        long long29 = timeSeries26.getMaximumItemAge();
        timeSeries26.setDescription("");
        timeSeries26.clear();
        boolean boolean33 = fixedMillisecond15.equals((java.lang.Object) timeSeries26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries26.addChangeListener(seriesChangeListener34);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
        int int40 = month38.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.previous();
        long long42 = month38.getLastMillisecond();
        java.lang.String str43 = month38.toString();
        int int44 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month38);
        int int45 = timeSeriesDataItem11.compareTo((java.lang.Object) month38);
        java.lang.String str46 = month38.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.previous();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond48.getFirstMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond48.getStart();
        java.util.Date date53 = fixedMillisecond48.getTime();
        java.util.Calendar calendar54 = null;
        fixedMillisecond48.peg(calendar54);
        java.util.Date date56 = fixedMillisecond48.getEnd();
        java.util.Date date57 = fixedMillisecond48.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
        boolean boolean59 = month38.equals((java.lang.Object) fixedMillisecond58);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str22.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62109475200001L) + "'", long42 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "October 0" + "'", str43.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "October 0" + "'", str46.equals("October 0"));
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(6, year8);
        java.lang.Object obj12 = null;
        int int13 = year8.compareTo(obj12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year8.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond1.getStart();
//        java.util.Date date6 = fixedMillisecond1.getTime();
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond1.peg(calendar7);
//        java.util.Date date9 = fixedMillisecond1.getEnd();
//        long long10 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long10);
//        java.util.List list12 = timeSeries11.getItems();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day13.previous();
//        java.lang.Object obj16 = null;
//        boolean boolean17 = day13.equals(obj16);
//        java.util.Date date18 = day13.getStart();
//        try {
//            timeSeries11.update((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 25841L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(date18);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        boolean boolean9 = day0.equals((java.lang.Object) year8);
//        int int10 = year8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year8.previous();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = year8.getFirstMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond8.previous();
        long long12 = fixedMillisecond8.getSerialIndex();
        java.util.Date date13 = fixedMillisecond8.getTime();
        java.lang.Class<?> wildcardClass14 = date13.getClass();
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass14);
        java.io.InputStream inputStream17 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long20 = fixedMillisecond19.getFirstMillisecond();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getLastMillisecond(calendar21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond19.previous();
        java.util.Date date24 = fixedMillisecond19.getTime();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date24, timeZone26);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ThreadContext", "org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond35.previous();
        long long39 = fixedMillisecond35.getSerialIndex();
        java.util.Date date40 = fixedMillisecond35.getTime();
        java.lang.Class<?> wildcardClass41 = date40.getClass();
        java.net.URL uRL42 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass41);
        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass41);
        java.io.InputStream inputStream44 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long47 = fixedMillisecond46.getFirstMillisecond();
        java.util.Calendar calendar48 = null;
        long long49 = fixedMillisecond46.getLastMillisecond(calendar48);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = fixedMillisecond46.previous();
        java.util.Date date51 = fixedMillisecond46.getTime();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date51, timeZone53);
        java.io.InputStream inputStream55 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass41);
        java.io.InputStream inputStream56 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass41);
        java.lang.Object obj57 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass14, (java.lang.Class) wildcardClass41);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNotNull(uRL16);
        org.junit.Assert.assertNull(inputStream17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 52L + "'", long37 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNull(uRL42);
        org.junit.Assert.assertNotNull(uRL43);
        org.junit.Assert.assertNull(inputStream44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 52L + "'", long47 == 52L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 52L + "'", long49 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNull(inputStream55);
        org.junit.Assert.assertNull(inputStream56);
        org.junit.Assert.assertNull(obj57);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day24, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (java.lang.Number) 2);
        timeSeriesDataItem3.setValue((java.lang.Number) (short) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        boolean boolean3 = day0.equals((java.lang.Object) "13-June-2019");
//        int int4 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        long long11 = fixedMillisecond7.getSerialIndex();
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.lang.Class<?> wildcardClass13 = date12.getClass();
        java.net.URL uRL14 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass13);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass13);
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long19 = fixedMillisecond18.getFirstMillisecond();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond18.getLastMillisecond(calendar20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond18.previous();
        java.util.Date date23 = fixedMillisecond18.getTime();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date23, timeZone25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "ThreadContext", "org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass13);
        java.lang.ClassLoader classLoader28 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass13);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(uRL14);
        org.junit.Assert.assertNotNull(uRL15);
        org.junit.Assert.assertNull(inputStream16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(classLoader28);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        int int6 = spreadsheetDate2.getMonth();
        try {
            java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        timeSeries2.clear();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        timeSeries7.clear();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
//        timeSeries7.setDescription("");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        int int15 = day13.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        long long19 = fixedMillisecond18.getFirstMillisecond();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        boolean boolean22 = day13.equals((java.lang.Object) year21);
//        int int23 = timeSeries7.getIndex((org.jfree.data.time.RegularTimePeriod) day13);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getFirstMillisecond(calendar7);
        long long9 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "Third", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getStart();
        java.util.Date date8 = fixedMillisecond3.getTime();
        java.util.Calendar calendar9 = null;
        fixedMillisecond3.peg(calendar9);
        java.util.Date date11 = fixedMillisecond3.getEnd();
        long long12 = fixedMillisecond3.getFirstMillisecond();
        int int13 = day1.compareTo((java.lang.Object) long12);
        org.jfree.data.time.SerialDate serialDate14 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate14);
        serialDate15.setDescription("31-October-1970");
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.String str6 = timeSeries2.getDomainDescription();
        int int7 = timeSeries2.getItemCount();
        java.lang.Class class8 = timeSeries2.getTimePeriodClass();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(class8);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        int int6 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(4);
        int int9 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(4);
        int int12 = spreadsheetDate11.getYYYY();
        boolean boolean13 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int14 = spreadsheetDate8.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int19 = spreadsheetDate17.getDayOfWeek();
        boolean boolean20 = spreadsheetDate8.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean21 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        java.util.Date date9 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year11.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.String str5 = timeSeries2.getDescription();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries8.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        int int24 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Collection collection25 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries8.fireSeriesChanged();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(collection25);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.lang.String str8 = fixedMillisecond6.toString();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) str8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class11);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        timeSeries12.clear();
        long long15 = timeSeries12.getMaximumItemAge();
        timeSeries12.setDescription("");
        timeSeries12.clear();
        boolean boolean19 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        try {
            timeSeries12.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str8.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month3);
        boolean boolean7 = month3.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.next();
        java.lang.String str9 = month3.toString();
        long long10 = month3.getLastMillisecond();
        long long11 = month3.getSerialIndex();
        java.lang.String str12 = month3.toString();
        long long13 = month3.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 0" + "'", str9.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "October 0" + "'", str12.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(29);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) (byte) 100);
        java.lang.Object obj12 = null;
        int int13 = timeSeriesDataItem11.compareTo(obj12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long16 = fixedMillisecond15.getFirstMillisecond();
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond15.getLastMillisecond(calendar17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.previous();
        java.lang.String str22 = fixedMillisecond20.toString();
        int int23 = fixedMillisecond15.compareTo((java.lang.Object) str22);
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        timeSeries26.clear();
        long long29 = timeSeries26.getMaximumItemAge();
        timeSeries26.setDescription("");
        timeSeries26.clear();
        boolean boolean33 = fixedMillisecond15.equals((java.lang.Object) timeSeries26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries26.addChangeListener(seriesChangeListener34);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month38.next();
        int int40 = month38.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.previous();
        long long42 = month38.getLastMillisecond();
        java.lang.String str43 = month38.toString();
        int int44 = timeSeries26.getIndex((org.jfree.data.time.RegularTimePeriod) month38);
        int int45 = timeSeriesDataItem11.compareTo((java.lang.Object) month38);
        java.lang.Object obj46 = timeSeriesDataItem11.clone();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str22.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62109475200001L) + "'", long42 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "October 0" + "'", str43.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getStart();
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.Calendar calendar15 = null;
        fixedMillisecond9.peg(calendar15);
        java.util.Date date17 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(10, serialDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond23.getStart();
        java.util.Date date28 = fixedMillisecond23.getTime();
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(10, serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = serialDate18.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond40.getStart();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(10, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate35.getEndOfCurrentMonth(serialDate51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.previous();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond55.getFirstMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond55.getStart();
        java.util.Date date60 = fixedMillisecond55.getTime();
        java.util.Calendar calendar61 = null;
        fixedMillisecond55.peg(calendar61);
        java.util.Date date63 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears(29, serialDate64);
        boolean boolean66 = spreadsheetDate2.isInRange(serialDate51, serialDate64);
        int int67 = spreadsheetDate2.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 52L + "'", long43 == 52L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 52L + "'", long58 == 52L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 4 + "'", int67 == 4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.util.Date date0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.lang.String str11 = year8.toString();
        java.lang.Class class12 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date22, timeZone24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.previous();
        long long31 = fixedMillisecond27.getSerialIndex();
        java.util.Date date32 = fixedMillisecond27.getTime();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date22, timeZone33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date22, timeZone36);
        boolean boolean38 = year8.equals((java.lang.Object) timeZone36);
        try {
            org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date0, timeZone36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
//        java.lang.String str4 = month2.toString();
//        long long5 = month2.getLastMillisecond();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond8.getStart();
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        java.util.Calendar calendar14 = null;
//        fixedMillisecond8.peg(calendar14);
//        java.util.Date date16 = fixedMillisecond8.getEnd();
//        long long17 = fixedMillisecond8.getFirstMillisecond();
//        int int18 = day6.compareTo((java.lang.Object) long17);
//        org.jfree.data.time.SerialDate serialDate19 = day6.getSerialDate();
//        int int20 = month2.compareTo((java.lang.Object) day6);
//        java.util.Date date21 = day6.getStart();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
//        java.util.Date date28 = fixedMillisecond24.getStart();
//        java.util.Date date29 = fixedMillisecond24.getTime();
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond24.peg(calendar30);
//        java.util.Date date32 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date32, timeZone34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond37.previous();
//        long long41 = fixedMillisecond37.getSerialIndex();
//        java.util.Date date42 = fixedMillisecond37.getTime();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date42, timeZone43);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date32, timeZone43);
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date32, timeZone46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date21, timeZone46);
//        int int49 = day48.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62109475200001L) + "'", long5 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 52L + "'", long41 == 52L);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 13 + "'", int49 == 13);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries2.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.addChangeListener(seriesChangeListener5);
        try {
            timeSeries2.removeAgedItems(1546329600000L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) ' ');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        timeSeries2.fireSeriesChanged();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(12, year14);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        int int6 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(30);
        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
        int int10 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getEnd();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(10, serialDate23);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        java.lang.String str27 = serialDate25.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond30.getFirstMillisecond(calendar32);
        java.util.Date date34 = fixedMillisecond30.getStart();
        java.util.Date date35 = fixedMillisecond30.getTime();
        java.util.Calendar calendar36 = null;
        fixedMillisecond30.peg(calendar36);
        java.util.Date date38 = fixedMillisecond30.getEnd();
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance(date38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears(29, serialDate39);
        org.jfree.data.time.SerialDate serialDate41 = serialDate25.getEndOfCurrentMonth(serialDate39);
        boolean boolean42 = spreadsheetDate2.isAfter(serialDate41);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "30-September-1970" + "'", str27.equals("30-September-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
//        long long7 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day9.previous();
//        java.lang.Object obj12 = null;
//        boolean boolean13 = day9.equals(obj12);
//        java.util.Date date14 = day9.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(date14);
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.String str16 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.String str24 = fixedMillisecond18.toString();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond18.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond18.getTime();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str24.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getMonth();
        int int6 = spreadsheetDate3.getDayOfMonth();
        int int7 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(30);
        boolean boolean10 = spreadsheetDate3.isOnOrAfter(serialDate9);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, serialDate9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        timeSeries7.setDescription("");
        try {
            timeSeries7.removeAgedItems((long) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        java.lang.Comparable comparable5 = timeSeries2.getKey();
        boolean boolean6 = timeSeries2.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (-1.0f) + "'", comparable5.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        java.util.Date date8 = fixedMillisecond6.getTime();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(4);
        int int13 = spreadsheetDate12.getYYYY();
        boolean boolean14 = spreadsheetDate2.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(4);
        int int17 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(4);
        int int20 = spreadsheetDate19.getYYYY();
        boolean boolean21 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int22 = spreadsheetDate16.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean25 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate24.getYYYY();
        boolean boolean27 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1900 + "'", int22 == 1900);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond7.peg(calendar13);
        java.util.Date date15 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(10, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        boolean boolean20 = timeSeries2.equals((java.lang.Object) day19);
        long long21 = day19.getSerialIndex();
        long long22 = day19.getSerialIndex();
        java.util.Date date23 = day19.getEnd();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25841L + "'", long21 == 25841L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 25841L + "'", long22 == 25841L);
        org.junit.Assert.assertNotNull(date23);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        java.util.Date date9 = fixedMillisecond1.getEnd();
        java.util.Date date10 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        long long13 = regularTimePeriod12.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 51L + "'", long13 == 51L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(31, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        long long3 = month2.getLastMillisecond();
        long long4 = month2.getSerialIndex();
        int int5 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62109475200001L) + "'", long3 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(10, serialDate11);
        serialDate12.setDescription("30-September-1970");
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        int int11 = year10.getYear();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        int int16 = month14.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.previous();
        long long18 = month14.getLastMillisecond();
        java.lang.String str19 = month14.toString();
        int int20 = year10.compareTo((java.lang.Object) month14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.previous();
        long long26 = fixedMillisecond22.getSerialIndex();
        java.util.Date date27 = fixedMillisecond22.getTime();
        java.lang.Class<?> wildcardClass28 = date27.getClass();
        java.lang.ClassLoader classLoader29 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass28);
        int int30 = year10.compareTo((java.lang.Object) classLoader29);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader29);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader29);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader29);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62109475200001L) + "'", long18 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "October 0" + "'", str19.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(classLoader29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries2.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        boolean boolean28 = spreadsheetDate23.isBefore(serialDate27);
        java.util.Date date29 = spreadsheetDate23.toDate();
        boolean boolean30 = timeSeries2.equals((java.lang.Object) spreadsheetDate23);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        long long6 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getFirstMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getStart();
        java.util.Date date16 = fixedMillisecond11.getTime();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getFirstMillisecond();
        long long19 = year17.getSerialIndex();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(6, year17);
        long long21 = year17.getSerialIndex();
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) long21);
        long long23 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar24 = null;
        fixedMillisecond1.peg(calendar24);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1969L + "'", long19 == 1969L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1969L + "'", long21 == 1969L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        int int2 = day0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        timeSeries2.removeAgedItems(true);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod11, (java.lang.Number) 2);
        try {
            timeSeries2.add(timeSeriesDataItem13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        int int8 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        java.lang.Class class10 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond12.getStart();
        java.util.Date date17 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date17, timeZone18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        java.lang.String str25 = month23.toString();
        long long26 = month23.getLastMillisecond();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond29.getFirstMillisecond(calendar31);
        java.util.Date date33 = fixedMillisecond29.getStart();
        java.util.Date date34 = fixedMillisecond29.getTime();
        java.util.Calendar calendar35 = null;
        fixedMillisecond29.peg(calendar35);
        java.util.Date date37 = fixedMillisecond29.getEnd();
        long long38 = fixedMillisecond29.getFirstMillisecond();
        int int39 = day27.compareTo((java.lang.Object) long38);
        org.jfree.data.time.SerialDate serialDate40 = day27.getSerialDate();
        int int41 = month23.compareTo((java.lang.Object) day27);
        java.util.Date date42 = day27.getStart();
        java.lang.Class class43 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond45.previous();
        java.util.Calendar calendar47 = null;
        long long48 = fixedMillisecond45.getFirstMillisecond(calendar47);
        java.util.Date date49 = fixedMillisecond45.getStart();
        java.util.Date date50 = fixedMillisecond45.getTime();
        java.util.Calendar calendar51 = null;
        fixedMillisecond45.peg(calendar51);
        java.util.Date date53 = fixedMillisecond45.getEnd();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date53, timeZone55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar59 = null;
        long long60 = fixedMillisecond58.getMiddleMillisecond(calendar59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = fixedMillisecond58.previous();
        long long62 = fixedMillisecond58.getSerialIndex();
        java.util.Date date63 = fixedMillisecond58.getTime();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(date63, timeZone64);
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date53, timeZone64);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date53, timeZone67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date42, timeZone67);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date17, timeZone67);
        int int71 = year7.compareTo((java.lang.Object) day70);
        int int72 = day70.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "October 0" + "'", str25.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-62109475200001L) + "'", long26 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 52L + "'", long38 == 52L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 52L + "'", long48 == 52L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 52L + "'", long60 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 52L + "'", long62 == 52L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1969 + "'", int72 == 1969);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        timeSeries7.setDescription("");
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        java.util.Collection collection19 = timeSeries17.getTimePeriods();
        java.util.Collection collection20 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeries7.getTimePeriod(1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1969, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(collection20);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        java.util.Collection collection4 = timeSeries2.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.addChangeListener(seriesChangeListener5);
        try {
            java.lang.Number number8 = timeSeries2.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(collection4);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("January");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(1900);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears(31, serialDate2);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.fireSeriesChanged();
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        timeSeries22.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class26);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        timeSeries27.clear();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries22.addAndOrUpdate(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries22.removeChangeListener(seriesChangeListener31);
        boolean boolean33 = fixedMillisecond16.equals((java.lang.Object) seriesChangeListener31);
        timeSeries7.setKey((java.lang.Comparable) boolean33);
        java.lang.String str35 = timeSeries7.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries7.createCopy((int) (short) 0, 9999);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond40.getStart();
        java.util.Date date45 = fixedMillisecond40.getTime();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        java.lang.String str49 = year46.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year46, 0.0d);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 52L + "'", long43 == 52L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem51);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.removeChangeListener(seriesChangeListener11);
        timeSeries2.setNotify(false);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.previous();
        java.lang.Number number21 = timeSeries2.getValue(regularTimePeriod20);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month25);
        boolean boolean29 = month25.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month25.next();
        java.lang.String str31 = month25.toString();
        long long32 = month25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month25.previous();
        java.lang.Class class34 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond36.getFirstMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond36.getStart();
        java.util.Date date41 = fixedMillisecond36.getTime();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date41, timeZone42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date41);
        long long45 = year44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.previous();
        int int47 = month25.compareTo((java.lang.Object) regularTimePeriod46);
        timeSeries2.delete(regularTimePeriod46);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries2.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "October 0" + "'", str31.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62109475200001L) + "'", long32 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-31507200000L) + "'", long45 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(2958465);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "Third", class3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
        timeSeries3.setMaximumItemCount(100);
        timeSeries3.setNotify(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond10.getStart();
        java.util.Date date15 = fixedMillisecond10.getTime();
        java.util.Calendar calendar16 = null;
        fixedMillisecond10.peg(calendar16);
        java.util.Date date18 = fixedMillisecond10.getEnd();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.previous();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(4, year20);
        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month22);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond7.peg(calendar13);
        java.util.Date date15 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(10, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        boolean boolean20 = timeSeries2.equals((java.lang.Object) day19);
        long long21 = day19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25841L + "'", long21 == 25841L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10L);
        java.util.List list15 = timeSeries8.getItems();
        timeSeries8.setDescription("Third");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getEnd();
        java.util.Date date28 = fixedMillisecond19.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond29.previous();
        timeSeries8.delete(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560495599999L + "'", long4 == 1560495599999L);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getStart();
        java.util.Date date8 = fixedMillisecond3.getTime();
        java.util.Calendar calendar9 = null;
        fixedMillisecond3.peg(calendar9);
        java.util.Date date11 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(29, serialDate12);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        boolean boolean21 = day18.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond24.getStart();
        java.util.Date date29 = fixedMillisecond24.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        java.util.Date date32 = fixedMillisecond24.getEnd();
        long long33 = fixedMillisecond24.getFirstMillisecond();
        int int34 = day22.compareTo((java.lang.Object) long33);
        int int35 = day18.compareTo((java.lang.Object) int34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.previous();
        long long44 = fixedMillisecond40.getSerialIndex();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.lang.Class<?> wildcardClass46 = date45.getClass();
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int34, "ThreadContext", "", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long51 = fixedMillisecond50.getFirstMillisecond();
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond50.getLastMillisecond(calendar52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond50.previous();
        java.util.Date date55 = fixedMillisecond50.getTime();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond59.getMiddleMillisecond(calendar60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond59.previous();
        long long63 = fixedMillisecond59.getSerialIndex();
        java.util.Date date64 = fixedMillisecond59.getTime();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date64, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date55, timeZone65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar73 = null;
        long long74 = fixedMillisecond72.getMiddleMillisecond(calendar73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond72.previous();
        long long76 = fixedMillisecond72.getSerialIndex();
        java.util.Date date77 = fixedMillisecond72.getTime();
        java.lang.Class<?> wildcardClass78 = date77.getClass();
        java.net.URL uRL79 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass78);
        java.net.URL uRL80 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass78);
        java.io.InputStream inputStream81 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass78);
        java.lang.Object obj82 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", (java.lang.Class) wildcardClass46, (java.lang.Class) wildcardClass78);
        java.net.URL uRL83 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Third", (java.lang.Class) wildcardClass78);
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12, "", "31-December-1969", (java.lang.Class) wildcardClass78);
        java.lang.Class class85 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass78);
        java.net.URL uRL86 = org.jfree.chart.util.ObjectUtilities.getResource("Saturday", (java.lang.Class) wildcardClass78);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 52L + "'", long42 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 52L + "'", long44 == 52L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 52L + "'", long53 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 52L + "'", long61 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 52L + "'", long63 == 52L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 52L + "'", long74 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 52L + "'", long76 == 52L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(uRL79);
        org.junit.Assert.assertNotNull(uRL80);
        org.junit.Assert.assertNull(inputStream81);
        org.junit.Assert.assertNull(obj82);
        org.junit.Assert.assertNull(uRL83);
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertNull(uRL86);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        long long5 = month2.getLastMillisecond();
        int int6 = month2.getYearValue();
        java.util.Date date7 = month2.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62109475200001L) + "'", long5 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Saturday");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
        timeSeries3.setMaximumItemCount(100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        int int10 = month8.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.previous();
        long long12 = month8.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month8, (double) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        timeSeries22.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class26);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        timeSeries27.clear();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries22.addAndOrUpdate(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries22.removeChangeListener(seriesChangeListener31);
        boolean boolean33 = fixedMillisecond16.equals((java.lang.Object) seriesChangeListener31);
        boolean boolean34 = month8.equals((java.lang.Object) seriesChangeListener31);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62109475200001L) + "'", long12 == (-62109475200001L));
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        int int5 = spreadsheetDate4.getYYYY();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        try {
            org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getFollowingDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "Third", class3);
        timeSeries4.fireSeriesChanged();
        timeSeries4.setNotify(true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        long long11 = fixedMillisecond2.getFirstMillisecond();
        int int12 = day0.compareTo((java.lang.Object) long11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day0.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        java.lang.String str15 = month13.toString();
        long long16 = month13.getLastMillisecond();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getEnd();
        long long28 = fixedMillisecond19.getFirstMillisecond();
        int int29 = day17.compareTo((java.lang.Object) long28);
        org.jfree.data.time.SerialDate serialDate30 = day17.getSerialDate();
        int int31 = month13.compareTo((java.lang.Object) day17);
        java.util.Date date32 = day17.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond35.previous();
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond35.getFirstMillisecond(calendar37);
        java.util.Date date39 = fixedMillisecond35.getStart();
        java.util.Date date40 = fixedMillisecond35.getTime();
        java.util.Calendar calendar41 = null;
        fixedMillisecond35.peg(calendar41);
        java.util.Date date43 = fixedMillisecond35.getEnd();
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance(date43);
        java.util.TimeZone timeZone45 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date43, timeZone45);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar49 = null;
        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond48.previous();
        long long52 = fixedMillisecond48.getSerialIndex();
        java.util.Date date53 = fixedMillisecond48.getTime();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date53, timeZone54);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month(date43, timeZone54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date43, timeZone57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date32, timeZone57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date7, timeZone57);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "October 0" + "'", str15.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62109475200001L) + "'", long16 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 52L + "'", long38 == 52L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 52L + "'", long50 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 52L + "'", long52 == 52L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(timeZone57);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod10, (java.lang.Number) (byte) 100);
        int int14 = timeSeriesDataItem12.compareTo((java.lang.Object) "January");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month18.next();
        boolean boolean20 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month18);
        boolean boolean22 = month18.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month18.next();
        java.lang.String str24 = month18.toString();
        long long25 = month18.getLastMillisecond();
        long long26 = month18.getSerialIndex();
        boolean boolean27 = timeSeriesDataItem12.equals((java.lang.Object) long26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond31.previous();
        long long35 = fixedMillisecond31.getSerialIndex();
        java.util.Date date36 = fixedMillisecond31.getTime();
        java.lang.Class<?> wildcardClass37 = date36.getClass();
        java.net.URL uRL38 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass37);
        java.net.URL uRL39 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass37);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean27, class40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.previous();
        boolean boolean45 = day42.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.previous();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond48.getFirstMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond48.getStart();
        java.util.Date date53 = fixedMillisecond48.getTime();
        java.util.Calendar calendar54 = null;
        fixedMillisecond48.peg(calendar54);
        java.util.Date date56 = fixedMillisecond48.getEnd();
        long long57 = fixedMillisecond48.getFirstMillisecond();
        int int58 = day46.compareTo((java.lang.Object) long57);
        int int59 = day42.compareTo((java.lang.Object) int58);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond64.getMiddleMillisecond(calendar65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = fixedMillisecond64.previous();
        long long68 = fixedMillisecond64.getSerialIndex();
        java.util.Date date69 = fixedMillisecond64.getTime();
        java.lang.Class<?> wildcardClass70 = date69.getClass();
        java.net.URL uRL71 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass70);
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int58, "ThreadContext", "", (java.lang.Class) wildcardClass70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long75 = fixedMillisecond74.getFirstMillisecond();
        java.util.Calendar calendar76 = null;
        long long77 = fixedMillisecond74.getLastMillisecond(calendar76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = fixedMillisecond74.previous();
        java.util.Date date79 = fixedMillisecond74.getTime();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date79);
        org.jfree.data.time.Month month81 = new org.jfree.data.time.Month(date79);
        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar84 = null;
        long long85 = fixedMillisecond83.getMiddleMillisecond(calendar84);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = fixedMillisecond83.previous();
        long long87 = fixedMillisecond83.getSerialIndex();
        java.util.Date date88 = fixedMillisecond83.getTime();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month90 = new org.jfree.data.time.Month(date88, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date79, timeZone89);
        java.lang.Object obj92 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class40, (java.lang.Class) wildcardClass70);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "October 0" + "'", str24.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62109475200001L) + "'", long25 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 10L + "'", long26 == 10L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 52L + "'", long35 == 52L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNull(uRL38);
        org.junit.Assert.assertNotNull(uRL39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 52L + "'", long57 == 52L);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 52L + "'", long66 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 52L + "'", long68 == 52L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(uRL71);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 52L + "'", long75 == 52L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 52L + "'", long77 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 52L + "'", long85 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 52L + "'", long87 == 52L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNull(obj92);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        timeSeries7.setDescription("");
        timeSeries7.setRangeDescription("");
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        long long9 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1969L + "'", long9 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        int int5 = spreadsheetDate4.getYYYY();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str7 = spreadsheetDate4.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "3-January-1900" + "'", str7.equals("3-January-1900"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond10.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-June-2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-June-2019"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(23526000000L);
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, class3);
//        timeSeries4.setMaximumItemCount(100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 100);
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) -1, serialDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(13, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getSerialIndex();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class8);
        java.lang.Class class10 = timeSeries9.getTimePeriodClass();
        timeSeries9.clear();
        java.lang.String str12 = timeSeries9.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond20.previous();
        long long24 = fixedMillisecond20.getSerialIndex();
        java.util.Date date25 = fixedMillisecond20.getTime();
        int int26 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        long long27 = fixedMillisecond20.getLastMillisecond();
        int int28 = fixedMillisecond1.compareTo((java.lang.Object) fixedMillisecond20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(class10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 52L + "'", long16 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = spreadsheetDate1.isBefore(serialDate5);
        java.util.Date date7 = spreadsheetDate1.toDate();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.next();
        int int12 = month10.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.previous();
        long long14 = month10.getLastMillisecond();
        int int15 = month10.getMonth();
        boolean boolean16 = spreadsheetDate1.equals((java.lang.Object) int15);
        org.jfree.data.time.SerialDate serialDate17 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.previous();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getFirstMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond20.getStart();
        java.util.Date date25 = fixedMillisecond20.getTime();
        java.util.Calendar calendar26 = null;
        fixedMillisecond20.peg(calendar26);
        java.util.Date date28 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(29, serialDate29);
        try {
            boolean boolean32 = spreadsheetDate1.isInRange(serialDate17, serialDate30, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62109475200001L) + "'", long14 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class17);
        java.lang.Class class19 = timeSeries18.getTimePeriodClass();
        timeSeries18.clear();
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries13.addAndOrUpdate(timeSeries18);
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        java.lang.String str27 = timeSeries24.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries24.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        java.lang.Number number34 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean35 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries7, (java.lang.Object) fixedMillisecond29);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNull(class19);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.String str16 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        timeSeries7.fireSeriesChanged();
        java.lang.Object obj25 = timeSeries7.clone();
        timeSeries7.clear();
        int int27 = timeSeries7.getMaximumItemCount();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond8.getStart();
        java.util.Date date13 = fixedMillisecond8.getTime();
        java.util.Calendar calendar14 = null;
        fixedMillisecond8.peg(calendar14);
        java.util.Date date16 = fixedMillisecond8.getEnd();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(10, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        java.lang.String str21 = serialDate19.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond24.getStart();
        java.util.Date date29 = fixedMillisecond24.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        java.util.Date date32 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears(29, serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = serialDate19.getEndOfCurrentMonth(serialDate33);
        int int36 = spreadsheetDate4.compare(serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond38.previous();
        java.util.Calendar calendar40 = null;
        long long41 = fixedMillisecond38.getFirstMillisecond(calendar40);
        java.lang.Class class43 = null;
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class43);
        java.lang.Class class45 = timeSeries44.getTimePeriodClass();
        timeSeries44.clear();
        long long47 = timeSeries44.getMaximumItemAge();
        int int48 = fixedMillisecond38.compareTo((java.lang.Object) long47);
        java.util.Calendar calendar49 = null;
        fixedMillisecond38.peg(calendar49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond54.previous();
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond54.getFirstMillisecond(calendar56);
        java.util.Date date58 = fixedMillisecond54.getStart();
        java.util.Date date59 = fixedMillisecond54.getTime();
        java.util.Calendar calendar60 = null;
        fixedMillisecond54.peg(calendar60);
        java.util.Date date62 = fixedMillisecond54.getEnd();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addMonths(10, serialDate63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate64);
        java.lang.String str66 = serialDate65.getDescription();
        boolean boolean67 = fixedMillisecond38.equals((java.lang.Object) serialDate65);
        boolean boolean68 = spreadsheetDate1.isInRange(serialDate35, serialDate65);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-September-1970" + "'", str21.equals("30-September-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-25558) + "'", int36 == (-25558));
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 52L + "'", long41 == 52L);
        org.junit.Assert.assertNull(class45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 9223372036854775807L + "'", long47 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 52L + "'", long57 == 52L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries2.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) (short) 0);
        long long29 = fixedMillisecond23.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 2147483647);
        try {
            timeSeries2.add(timeSeriesDataItem31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 0);
        long long12 = fixedMillisecond6.getSerialIndex();
        long long13 = fixedMillisecond6.getLastMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
        java.util.Date date20 = fixedMillisecond16.getStart();
        java.util.Date date21 = fixedMillisecond16.getTime();
        java.util.Calendar calendar22 = null;
        fixedMillisecond16.peg(calendar22);
        java.util.Date date24 = fixedMillisecond16.getEnd();
        java.util.Date date25 = fixedMillisecond16.getTime();
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        java.util.Date date11 = fixedMillisecond2.getTime();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(29, serialDate12);
        java.lang.String str14 = serialDate13.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(29, serialDate11);
        try {
            org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        java.util.Date date9 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(4);
        int int14 = spreadsheetDate13.getYYYY();
        boolean boolean15 = spreadsheetDate3.isInRange(serialDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond17.getFirstMillisecond(calendar19);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        timeSeries23.clear();
        long long26 = timeSeries23.getMaximumItemAge();
        int int27 = fixedMillisecond17.compareTo((java.lang.Object) long26);
        java.util.Calendar calendar28 = null;
        fixedMillisecond17.peg(calendar28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond33.getFirstMillisecond(calendar35);
        java.util.Date date37 = fixedMillisecond33.getStart();
        java.util.Date date38 = fixedMillisecond33.getTime();
        java.util.Calendar calendar39 = null;
        fixedMillisecond33.peg(calendar39);
        java.util.Date date41 = fixedMillisecond33.getEnd();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(10, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate43);
        java.lang.String str45 = serialDate44.getDescription();
        boolean boolean46 = fixedMillisecond17.equals((java.lang.Object) serialDate44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.previous();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond48.getFirstMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond48.getStart();
        java.util.Date date53 = fixedMillisecond48.getTime();
        java.util.Calendar calendar54 = null;
        fixedMillisecond48.peg(calendar54);
        java.util.Date date56 = fixedMillisecond48.getEnd();
        java.util.Date date57 = fixedMillisecond48.getTime();
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance(date57);
        boolean boolean59 = spreadsheetDate3.isInRange(serialDate44, serialDate58);
        try {
            org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, serialDate58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 52L + "'", long36 == 52L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.fireSeriesChanged();
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.previous();
        java.util.Calendar calendar18 = null;
        long long19 = fixedMillisecond16.getFirstMillisecond(calendar18);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        timeSeries22.clear();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class26);
        java.lang.Class class28 = timeSeries27.getTimePeriodClass();
        timeSeries27.clear();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries22.addAndOrUpdate(timeSeries27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries22.removeChangeListener(seriesChangeListener31);
        boolean boolean33 = fixedMillisecond16.equals((java.lang.Object) seriesChangeListener31);
        timeSeries7.setKey((java.lang.Comparable) boolean33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener35);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 52L + "'", long19 == 52L);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNull(class28);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.removeChangeListener(seriesChangeListener11);
        timeSeries2.setNotify(false);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.previous();
        java.lang.Number number21 = timeSeries2.getValue(regularTimePeriod20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener22);
        timeSeries2.clear();
        int int25 = timeSeries2.getItemCount();
        timeSeries2.setDomainDescription("");
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month3);
        boolean boolean7 = month3.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.next();
        java.lang.String str9 = month3.toString();
        long long10 = month3.getLastMillisecond();
        long long11 = month3.getSerialIndex();
        long long12 = month3.getSerialIndex();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month3.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 0" + "'", str9.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        fixedMillisecond1.peg(calendar7);
        java.util.Date date9 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9);
        long long12 = year11.getLastMillisecond();
        java.lang.String str13 = year11.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        long long10 = timeSeries7.getMaximumItemAge();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) long10);
        java.util.Calendar calendar12 = null;
        fixedMillisecond1.peg(calendar12);
        long long14 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getStart();
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.Calendar calendar15 = null;
        fixedMillisecond9.peg(calendar15);
        java.util.Date date17 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(10, serialDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond23.getStart();
        java.util.Date date28 = fixedMillisecond23.getTime();
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(10, serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = serialDate18.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond40.getStart();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(10, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate35.getEndOfCurrentMonth(serialDate51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.previous();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond55.getFirstMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond55.getStart();
        java.util.Date date60 = fixedMillisecond55.getTime();
        java.util.Calendar calendar61 = null;
        fixedMillisecond55.peg(calendar61);
        java.util.Date date63 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears(29, serialDate64);
        boolean boolean66 = spreadsheetDate2.isInRange(serialDate51, serialDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(4);
        int int73 = spreadsheetDate72.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(4);
        int int76 = spreadsheetDate75.getYYYY();
        boolean boolean77 = spreadsheetDate72.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean78 = spreadsheetDate2.isInRange(serialDate70, (org.jfree.data.time.SerialDate) spreadsheetDate72);
        serialDate70.setDescription("31-December-1969");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 52L + "'", long43 == 52L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 52L + "'", long58 == 52L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1900 + "'", int76 == 1900);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62109475200001L) + "'", long3 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries2.removeAgedItems(false);
        timeSeries2.setMaximumItemAge((long) 'a');
        java.lang.String str22 = timeSeries2.getDescription();
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries2.createCopy((int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", class1);
        timeSeries2.setNotify(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getLastMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond6.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond6.getMiddleMillisecond(calendar11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond14.getFirstMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        fixedMillisecond14.peg(calendar22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month26.next();
        java.lang.String str28 = month26.toString();
        java.util.Date date29 = month26.getStart();
        boolean boolean30 = fixedMillisecond14.equals((java.lang.Object) date29);
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "October 0" + "'", str28.equals("October 0"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeSeries31);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond7.peg(calendar13);
        java.util.Date date15 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(10, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        boolean boolean20 = timeSeries2.equals((java.lang.Object) day19);
        java.util.Date date21 = day19.getEnd();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "Third", class3);
        timeSeries4.fireSeriesChanged();
        java.lang.Class class6 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond8.getStart();
        java.util.Date date13 = fixedMillisecond8.getTime();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date13);
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 28799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getStart();
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.Calendar calendar15 = null;
        fixedMillisecond9.peg(calendar15);
        java.util.Date date17 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(10, serialDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond23.getStart();
        java.util.Date date28 = fixedMillisecond23.getTime();
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(10, serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = serialDate18.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond40.getStart();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(10, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate35.getEndOfCurrentMonth(serialDate51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.previous();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond55.getFirstMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond55.getStart();
        java.util.Date date60 = fixedMillisecond55.getTime();
        java.util.Calendar calendar61 = null;
        fixedMillisecond55.peg(calendar61);
        java.util.Date date63 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears(29, serialDate64);
        boolean boolean66 = spreadsheetDate2.isInRange(serialDate51, serialDate64);
        int int67 = spreadsheetDate2.getDayOfMonth();
        int int68 = spreadsheetDate2.getYYYY();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 52L + "'", long43 == 52L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 52L + "'", long58 == 52L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1900 + "'", int68 == 1900);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond8.getStart();
        java.util.Date date13 = fixedMillisecond8.getTime();
        java.util.Calendar calendar14 = null;
        fixedMillisecond8.peg(calendar14);
        java.util.Date date16 = fixedMillisecond8.getEnd();
        long long17 = fixedMillisecond8.getFirstMillisecond();
        int int18 = day6.compareTo((java.lang.Object) long17);
        org.jfree.data.time.SerialDate serialDate19 = day6.getSerialDate();
        int int20 = month2.compareTo((java.lang.Object) day6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month2.next();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62109475200001L) + "'", long5 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
        timeSeries3.setMaximumItemCount(100);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond8, class9);
        boolean boolean11 = timeSeries10.isEmpty();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = timeSeries3.equals((java.lang.Object) class12);
        timeSeries3.setMaximumItemAge(1560495599999L);
        int int16 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.Calendar calendar8 = null;
        fixedMillisecond2.peg(calendar8);
        java.util.Date date10 = fixedMillisecond2.getEnd();
        long long11 = fixedMillisecond2.getFirstMillisecond();
        int int12 = day0.compareTo((java.lang.Object) long11);
        int int13 = day0.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        int int10 = year7.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond12.previous();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
        java.util.Date date16 = fixedMillisecond12.getStart();
        java.util.Date date17 = fixedMillisecond12.getTime();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (short) 0);
        java.lang.Object obj28 = timeSeriesDataItem27.clone();
        boolean boolean29 = year18.equals(obj28);
        int int30 = year18.getYear();
        int int31 = year7.compareTo((java.lang.Object) int30);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year7.getLastMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        long long6 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        int int8 = month2.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7);
        java.lang.Class<?> wildcardClass11 = date7.getClass();
        java.lang.Class<?> wildcardClass12 = date7.getClass();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        timeSeries7.setDescription("");
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class16);
        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
        java.util.Collection collection19 = timeSeries17.getTimePeriods();
        java.util.Collection collection20 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        boolean boolean21 = timeSeries17.isEmpty();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        java.lang.String str2 = spreadsheetDate1.toString();
        int int3 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3-January-1900" + "'", str2.equals("3-January-1900"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        int int6 = spreadsheetDate2.getMonth();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        timeSeries7.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries7.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.fireSeriesChanged();
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getLastMillisecond(calendar16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond14.previous();
        java.lang.Number number19 = timeSeries7.getValue(regularTimePeriod18);
        try {
            timeSeries7.update(8, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.fireSeriesChanged();
        java.util.List list12 = timeSeries7.getItems();
        try {
            timeSeries7.update(0, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        long long9 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getStart();
        java.util.Date date8 = fixedMillisecond3.getTime();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        long long10 = year9.getFirstMillisecond();
        long long11 = year9.getSerialIndex();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(6, year9);
        java.util.Date date13 = year9.getEnd();
        long long14 = year9.getSerialIndex();
        int int15 = year9.getYear();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(9, year9);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-31507200000L) + "'", long10 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1969L + "'", long14 == 1969L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, (int) (byte) 1, 9999);
        long long4 = day3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 253370879999999L + "'", long4 == 253370879999999L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(6, year8);
        long long12 = year8.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year8.next();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod17, (java.lang.Number) 2);
        timeSeriesDataItem19.setValue((java.lang.Number) (short) 0);
        java.lang.Object obj22 = timeSeriesDataItem19.clone();
        java.lang.Class<?> wildcardClass23 = obj22.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year8, "October", "org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass23);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = day0.equals(obj3);
//        java.util.Date date5 = day0.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date5);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month((int) (byte) 10, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
//        java.lang.String str11 = month9.toString();
//        long long12 = month9.getLastMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond15.previous();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond15.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond15.getStart();
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        java.util.Calendar calendar21 = null;
//        fixedMillisecond15.peg(calendar21);
//        java.util.Date date23 = fixedMillisecond15.getEnd();
//        long long24 = fixedMillisecond15.getFirstMillisecond();
//        int int25 = day13.compareTo((java.lang.Object) long24);
//        org.jfree.data.time.SerialDate serialDate26 = day13.getSerialDate();
//        int int27 = month9.compareTo((java.lang.Object) day13);
//        java.util.Date date28 = day13.getStart();
//        java.lang.Class class29 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond31.previous();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond31.getFirstMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond31.getStart();
//        java.util.Date date36 = fixedMillisecond31.getTime();
//        java.util.Calendar calendar37 = null;
//        fixedMillisecond31.peg(calendar37);
//        java.util.Date date39 = fixedMillisecond31.getEnd();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date39, timeZone41);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond44.previous();
//        long long48 = fixedMillisecond44.getSerialIndex();
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(date49, timeZone50);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(date39, timeZone50);
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date39, timeZone53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date28, timeZone53);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date5, timeZone53);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "October 0" + "'", str11.equals("October 0"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62109475200001L) + "'", long12 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 52L + "'", long46 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 52L + "'", long48 == 52L);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(timeZone53);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        int int6 = spreadsheetDate2.getYYYY();
        java.util.Date date7 = spreadsheetDate2.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate10.getMonth();
        int int13 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond17.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond17.getStart();
        java.util.Date date22 = fixedMillisecond17.getTime();
        java.util.Calendar calendar23 = null;
        fixedMillisecond17.peg(calendar23);
        java.util.Date date25 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(10, serialDate26);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond31.previous();
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond31.getFirstMillisecond(calendar33);
        java.util.Date date35 = fixedMillisecond31.getStart();
        java.util.Date date36 = fixedMillisecond31.getTime();
        java.util.Calendar calendar37 = null;
        fixedMillisecond31.peg(calendar37);
        java.util.Date date39 = fixedMillisecond31.getEnd();
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance(date39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(10, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = serialDate26.getEndOfCurrentMonth(serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond48.previous();
        java.util.Calendar calendar50 = null;
        long long51 = fixedMillisecond48.getFirstMillisecond(calendar50);
        java.util.Date date52 = fixedMillisecond48.getStart();
        java.util.Date date53 = fixedMillisecond48.getTime();
        java.util.Calendar calendar54 = null;
        fixedMillisecond48.peg(calendar54);
        java.util.Date date56 = fixedMillisecond48.getEnd();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(date56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(10, serialDate57);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate58);
        org.jfree.data.time.SerialDate serialDate60 = serialDate43.getEndOfCurrentMonth(serialDate59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = fixedMillisecond63.previous();
        java.util.Calendar calendar65 = null;
        long long66 = fixedMillisecond63.getFirstMillisecond(calendar65);
        java.util.Date date67 = fixedMillisecond63.getStart();
        java.util.Date date68 = fixedMillisecond63.getTime();
        java.util.Calendar calendar69 = null;
        fixedMillisecond63.peg(calendar69);
        java.util.Date date71 = fixedMillisecond63.getEnd();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date71);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears(29, serialDate72);
        boolean boolean74 = spreadsheetDate10.isInRange(serialDate59, serialDate72);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(4);
        int int81 = spreadsheetDate80.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(4);
        int int84 = spreadsheetDate83.getYYYY();
        boolean boolean85 = spreadsheetDate80.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate83);
        boolean boolean86 = spreadsheetDate10.isInRange(serialDate78, (org.jfree.data.time.SerialDate) spreadsheetDate80);
        boolean boolean87 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 52L + "'", long66 == 52L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1900 + "'", int81 == 1900);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1900 + "'", int84 == 1900);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
//        timeSeries3.setMaximumItemCount(100);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100);
//        long long10 = day6.getMiddleMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) (-1L));
//        int int15 = day6.compareTo((java.lang.Object) day11);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.previous();
        long long8 = fixedMillisecond4.getSerialIndex();
        java.util.Date date9 = fixedMillisecond4.getTime();
        java.lang.Class<?> wildcardClass10 = date9.getClass();
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass10);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass10);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResource("Saturday", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNotNull(uRL12);
        org.junit.Assert.assertNull(uRL13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("Third");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str7 = seriesException6.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException6);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str12 = seriesException11.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str7.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str12.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month3);
        long long6 = month3.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            month3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62126582400001L) + "'", long6 == (-62126582400001L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("September 0");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getSerialIndex();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.lang.String str9 = fixedMillisecond7.toString();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond7.getFirstMillisecond(calendar10);
        int int12 = month2.compareTo((java.lang.Object) long11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month2.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str9.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.String str6 = timeSeries2.getDomainDescription();
        int int7 = timeSeries2.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = null;
        try {
            timeSeries2.update(regularTimePeriod8, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries2.removeAgedItems(false);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class21);
        java.lang.Class class23 = timeSeries22.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.previous();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond27.getFirstMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond27.getStart();
        java.util.Date date32 = fixedMillisecond27.getTime();
        java.util.Calendar calendar33 = null;
        fixedMillisecond27.peg(calendar33);
        java.util.Date date35 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(10, serialDate36);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(serialDate38);
        boolean boolean40 = timeSeries22.equals((java.lang.Object) day39);
        long long41 = day39.getSerialIndex();
        long long42 = day39.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day39, (double) (-62143689600000L));
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNull(class23);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 25841L + "'", long41 == 25841L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25841L + "'", long42 == 25841L);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ThreadContext");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getStart();
        java.util.Date date8 = fixedMillisecond3.getTime();
        java.util.Calendar calendar9 = null;
        fixedMillisecond3.peg(calendar9);
        java.util.Date date11 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(10, serialDate12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond17.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond17.getStart();
        java.util.Date date22 = fixedMillisecond17.getTime();
        java.util.Calendar calendar23 = null;
        fixedMillisecond17.peg(calendar23);
        java.util.Date date25 = fixedMillisecond17.getEnd();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(10, serialDate26);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate27);
        org.jfree.data.time.SerialDate serialDate29 = serialDate12.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond34.previous();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond34.getFirstMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond34.getStart();
        java.util.Date date39 = fixedMillisecond34.getTime();
        java.util.Calendar calendar40 = null;
        fixedMillisecond34.peg(calendar40);
        java.util.Date date42 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths(10, serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate44);
        org.jfree.data.time.SerialDate serialDate46 = serialDate29.getEndOfCurrentMonth(serialDate45);
        java.lang.String str47 = serialDate45.getDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 52L + "'", long37 == 52L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond6.getStart();
        java.util.Date date11 = fixedMillisecond6.getTime();
        java.util.Calendar calendar12 = null;
        fixedMillisecond6.peg(calendar12);
        java.util.Date date14 = fixedMillisecond6.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(10, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        java.lang.String str19 = serialDate17.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getFirstMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond22.getStart();
        java.util.Date date27 = fixedMillisecond22.getTime();
        java.util.Calendar calendar28 = null;
        fixedMillisecond22.peg(calendar28);
        java.util.Date date30 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears(29, serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = serialDate17.getEndOfCurrentMonth(serialDate31);
        int int34 = spreadsheetDate2.compare(serialDate33);
        int int35 = spreadsheetDate2.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "30-September-1970" + "'", str19.equals("30-September-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-25558) + "'", int34 == (-25558));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getStart();
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.Calendar calendar15 = null;
        fixedMillisecond9.peg(calendar15);
        java.util.Date date17 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(10, serialDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond23.getStart();
        java.util.Date date28 = fixedMillisecond23.getTime();
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(10, serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = serialDate18.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond40.getStart();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(10, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate35.getEndOfCurrentMonth(serialDate51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.previous();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond55.getFirstMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond55.getStart();
        java.util.Date date60 = fixedMillisecond55.getTime();
        java.util.Calendar calendar61 = null;
        fixedMillisecond55.peg(calendar61);
        java.util.Date date63 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears(29, serialDate64);
        boolean boolean66 = spreadsheetDate2.isInRange(serialDate51, serialDate64);
        int int67 = spreadsheetDate2.getDayOfMonth();
        try {
            org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate2.getFollowingDayOfWeek(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 52L + "'", long43 == 52L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 52L + "'", long58 == 52L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10L);
        long long15 = fixedMillisecond10.getFirstMillisecond();
        java.lang.Class<?> wildcardClass16 = fixedMillisecond10.getClass();
        long long17 = fixedMillisecond10.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        try {
            org.jfree.data.time.SerialDate serialDate3 = spreadsheetDate1.getNearestDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) (byte) 100);
        int int13 = timeSeriesDataItem11.compareTo((java.lang.Object) "January");
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month17);
        boolean boolean21 = month17.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month17.next();
        java.lang.String str23 = month17.toString();
        long long24 = month17.getLastMillisecond();
        long long25 = month17.getSerialIndex();
        boolean boolean26 = timeSeriesDataItem11.equals((java.lang.Object) long25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond30.previous();
        long long34 = fixedMillisecond30.getSerialIndex();
        java.util.Date date35 = fixedMillisecond30.getTime();
        java.lang.Class<?> wildcardClass36 = date35.getClass();
        java.net.URL uRL37 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass36);
        java.net.URL uRL38 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass36);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass36);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean26, class39);
        timeSeries40.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 0" + "'", str23.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62109475200001L) + "'", long24 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNull(uRL37);
        org.junit.Assert.assertNotNull(uRL38);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-460));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.String str5 = timeSeries2.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.lang.Class class12 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date19);
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class24);
        java.lang.Class class26 = timeSeries25.getTimePeriodClass();
        java.util.Collection collection27 = timeSeries25.getTimePeriods();
        java.util.Collection collection28 = org.jfree.chart.util.ObjectUtilities.deepClone(collection27);
        int int29 = day22.compareTo((java.lang.Object) collection28);
        int int30 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries2.addChangeListener(seriesChangeListener31);
        timeSeries2.removeAgedItems(false);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(class26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4);
        int int4 = spreadsheetDate3.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(4);
        int int7 = spreadsheetDate6.getYYYY();
        boolean boolean8 = spreadsheetDate3.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int9 = spreadsheetDate3.getDayOfMonth();
        int int10 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int4 = spreadsheetDate2.getMonth();
//        int int5 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = day6.equals(obj9);
//        java.util.Date date11 = day6.getStart();
//        long long12 = day6.getSerialIndex();
//        boolean boolean13 = spreadsheetDate2.equals((java.lang.Object) day6);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getLastMillisecond();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62109475200001L) + "'", long5 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62109475200001L) + "'", long6 == (-62109475200001L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        boolean boolean8 = timeSeries3.equals((java.lang.Object) '4');
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.String str5 = timeSeries2.getDescription();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries8.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        int int24 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Collection collection25 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.previous();
        java.lang.String str29 = fixedMillisecond27.toString();
        int int30 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        try {
            java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) int30);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str29.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 2147483647);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getFirstMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getStart();
        java.util.Date date16 = fixedMillisecond11.getTime();
        java.util.Calendar calendar17 = null;
        fixedMillisecond11.peg(calendar17);
        java.util.Date date19 = fixedMillisecond11.getEnd();
        long long20 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long20);
        boolean boolean22 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries21);
        java.lang.String str23 = timeSeries21.getDomainDescription();
        java.lang.Class class25 = null;
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class25);
        java.lang.Class class27 = timeSeries26.getTimePeriodClass();
        timeSeries26.clear();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class30);
        java.lang.Class class32 = timeSeries31.getTimePeriodClass();
        timeSeries31.clear();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries26.addAndOrUpdate(timeSeries31);
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class36);
        java.lang.Class class38 = timeSeries37.getTimePeriodClass();
        timeSeries37.clear();
        java.lang.String str40 = timeSeries37.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond42.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.lang.Number number47 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        java.util.Calendar calendar48 = null;
        fixedMillisecond42.peg(calendar48);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = month53.next();
        boolean boolean55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month53);
        boolean boolean57 = month53.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = month53.next();
        java.lang.String str59 = month53.toString();
        long long60 = month53.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = month53.next();
        long long62 = month53.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (org.jfree.data.time.RegularTimePeriod) month53);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNull(class27);
        org.junit.Assert.assertNull(class32);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNull(class38);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 52L + "'", long44 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNull(timeSeriesDataItem46);
        org.junit.Assert.assertNull(number47);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "October 0" + "'", str59.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-62109475200001L) + "'", long60 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
        org.junit.Assert.assertNotNull(timeSeries63);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.String str5 = timeSeries2.getDescription();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries8.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        int int24 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Collection collection25 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        int int26 = timeSeries2.getItemCount();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, class1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond4.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond4.getStart();
        java.util.Date date9 = fixedMillisecond4.getTime();
        java.util.Calendar calendar10 = null;
        fixedMillisecond4.peg(calendar10);
        java.lang.Number number12 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond4.next();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month3);
        boolean boolean7 = month3.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.next();
        java.lang.String str9 = month3.toString();
        long long10 = month3.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month3, (java.lang.Number) (-2649600000L));
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) 0);
        int int15 = timeSeriesDataItem12.compareTo((java.lang.Object) 0);
        timeSeriesDataItem12.setValue((java.lang.Number) (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 0" + "'", str9.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(4);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(4);
        int int5 = spreadsheetDate4.getYYYY();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int7 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(4);
        int int10 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(4);
        int int13 = spreadsheetDate12.getYYYY();
        boolean boolean14 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int15 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean18 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate21 = spreadsheetDate1.getPreviousDayOfWeek(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1900 + "'", int2 == 1900);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1900 + "'", int5 == 1900);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1900 + "'", int15 == 1900);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.setDescription("");
        timeSeries7.setDescription("");
        timeSeries7.clear();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries2.removeAgedItems(false);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries2.addChangeListener(seriesChangeListener22);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.String str6 = timeSeries2.getDomainDescription();
        int int7 = timeSeries2.getItemCount();
        int int8 = timeSeries2.getMaximumItemCount();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond4.previous();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond4.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond4.getStart();
        java.util.Date date9 = fixedMillisecond4.getTime();
        java.util.Calendar calendar10 = null;
        fixedMillisecond4.peg(calendar10);
        java.util.Date date12 = fixedMillisecond4.getEnd();
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance(date12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(10, serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        java.lang.String str17 = serialDate15.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.previous();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getFirstMillisecond(calendar22);
        java.util.Date date24 = fixedMillisecond20.getStart();
        java.util.Date date25 = fixedMillisecond20.getTime();
        java.util.Calendar calendar26 = null;
        fixedMillisecond20.peg(calendar26);
        java.util.Date date28 = fixedMillisecond20.getEnd();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears(29, serialDate29);
        org.jfree.data.time.SerialDate serialDate31 = serialDate15.getEndOfCurrentMonth(serialDate29);
        try {
            org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), serialDate31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "30-September-1970" + "'", str17.equals("30-September-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.removeChangeListener(seriesChangeListener11);
        timeSeries2.setNotify(false);
        long long15 = timeSeries2.getMaximumItemAge();
        timeSeries2.setMaximumItemCount(2019);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod27, (java.lang.Number) (byte) 100);
        int int31 = timeSeriesDataItem29.compareTo((java.lang.Object) "January");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month35);
        boolean boolean39 = month35.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = month35.next();
        java.lang.String str41 = month35.toString();
        long long42 = month35.getLastMillisecond();
        long long43 = month35.getSerialIndex();
        boolean boolean44 = timeSeriesDataItem29.equals((java.lang.Object) long43);
        try {
            timeSeries2.add(timeSeriesDataItem29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "October 0" + "'", str41.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62109475200001L) + "'", long42 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10L + "'", long43 == 10L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
//        long long7 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond10.peg(calendar11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10L);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond18, class19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.next();
//        boolean boolean22 = day15.equals((java.lang.Object) fixedMillisecond18);
//        java.lang.Number number23 = null;
//        try {
//            timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, number23);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond2, class3);
//        timeSeries4.setMaximumItemCount(100);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 100);
//        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
//        try {
//            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2147483647, serialDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        long long6 = fixedMillisecond1.getMiddleMillisecond();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries2.addChangeListener(seriesChangeListener6);
        timeSeries2.setRangeDescription("13-June-2019");
        try {
            java.lang.Number number11 = timeSeries2.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        boolean boolean5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month3);
        boolean boolean7 = month3.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month3.next();
        java.lang.String str9 = month3.toString();
        long long10 = month3.getLastMillisecond();
        java.util.Date date11 = month3.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 0" + "'", str9.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-62109475200001L) + "'", long10 == (-62109475200001L));
        org.junit.Assert.assertNotNull(date11);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
//        timeSeries2.fireSeriesChanged();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        int int8 = day6.getDayOfMonth();
//        java.lang.String str9 = day6.toString();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class11);
//        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
//        timeSeries12.clear();
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class16);
//        java.lang.Class class18 = timeSeries17.getTimePeriodClass();
//        timeSeries17.clear();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries12.addAndOrUpdate(timeSeries17);
//        timeSeries17.setDescription("");
//        timeSeries17.setDescription("");
//        java.util.List list25 = timeSeries17.getItems();
//        boolean boolean26 = day6.equals((java.lang.Object) timeSeries17);
//        long long27 = day6.getFirstMillisecond();
//        int int28 = timeSeries2.getIndex((org.jfree.data.time.RegularTimePeriod) day6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.previous();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond30.getFirstMillisecond(calendar32);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class35);
//        java.lang.Class class37 = timeSeries36.getTimePeriodClass();
//        timeSeries36.clear();
//        long long39 = timeSeries36.getMaximumItemAge();
//        int int40 = fixedMillisecond30.compareTo((java.lang.Object) long39);
//        try {
//            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) (-2649600000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(class13);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
//        org.junit.Assert.assertNull(class37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9223372036854775807L + "'", long39 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("September 0");
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        long long9 = fixedMillisecond1.getMiddleMillisecond();
        long long10 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "", class1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond4.getLastMillisecond(calendar6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond4.previous();
        try {
            timeSeries2.add(regularTimePeriod8, (java.lang.Number) 10L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        try {
            timeSeries2.removeAgedItems(1560452399999L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        timeSeries2.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        java.util.Date date12 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod15, (java.lang.Number) (byte) 100);
        java.lang.Object obj18 = null;
        int int19 = timeSeriesDataItem17.compareTo(obj18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getFirstMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond22.getStart();
        java.util.Date date27 = fixedMillisecond22.getTime();
        java.util.Calendar calendar28 = null;
        fixedMillisecond22.peg(calendar28);
        java.util.Date date30 = fixedMillisecond22.getEnd();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(10, serialDate31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond36.previous();
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond36.getFirstMillisecond(calendar38);
        java.util.Date date40 = fixedMillisecond36.getStart();
        java.util.Date date41 = fixedMillisecond36.getTime();
        java.util.Calendar calendar42 = null;
        fixedMillisecond36.peg(calendar42);
        java.util.Date date44 = fixedMillisecond36.getEnd();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths(10, serialDate45);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate46);
        org.jfree.data.time.SerialDate serialDate48 = serialDate31.getEndOfCurrentMonth(serialDate47);
        java.lang.String str49 = serialDate31.toString();
        java.lang.String str50 = serialDate31.getDescription();
        boolean boolean51 = timeSeriesDataItem17.equals((java.lang.Object) str50);
        boolean boolean52 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeries2, (java.lang.Object) timeSeriesDataItem17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeriesDataItem17.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 52L + "'", long39 == 52L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31-December-1969" + "'", str49.equals("31-December-1969"));
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        java.util.Date date6 = fixedMillisecond1.getTime();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getLastMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond1.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond16.previous();
        long long20 = fixedMillisecond16.getSerialIndex();
        java.util.Date date21 = fixedMillisecond16.getTime();
        java.lang.Class<?> wildcardClass22 = date21.getClass();
        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long28 = fixedMillisecond27.getFirstMillisecond();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond27.getLastMillisecond(calendar29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
        java.util.Date date32 = fixedMillisecond27.getTime();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date32, timeZone34);
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass22);
        java.io.InputStream inputStream37 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod9, (java.lang.Class) wildcardClass22);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 52L + "'", long18 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(uRL23);
        org.junit.Assert.assertNotNull(uRL24);
        org.junit.Assert.assertNull(inputStream25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(inputStream36);
        org.junit.Assert.assertNull(inputStream37);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        long long3 = month2.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (-1.0d));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62109475200001L) + "'", long3 == (-62109475200001L));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond10.getStart();
        java.util.Date date15 = fixedMillisecond10.getTime();
        java.util.Calendar calendar16 = null;
        fixedMillisecond10.peg(calendar16);
        java.util.Date date18 = fixedMillisecond10.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(10, serialDate19);
        java.lang.String str21 = serialDate20.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond23.getStart();
        java.util.Date date28 = fixedMillisecond23.getTime();
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        boolean boolean34 = spreadsheetDate6.isInRange(serialDate20, serialDate32, 30);
        java.lang.String str35 = spreadsheetDate6.toString();
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-October-1970" + "'", str21.equals("31-October-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "3-January-1900" + "'", str35.equals("3-January-1900"));
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        int int3 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(4);
        int int6 = spreadsheetDate5.getYYYY();
        boolean boolean7 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate5);
        int int8 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean11 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1900 + "'", int8 == 1900);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond6.getStart();
        java.util.Date date11 = fixedMillisecond6.getTime();
        java.util.Calendar calendar12 = null;
        fixedMillisecond6.peg(calendar12);
        java.util.Date date14 = fixedMillisecond6.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(10, serialDate15);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        boolean boolean30 = spreadsheetDate2.isInRange(serialDate16, serialDate28, 30);
        int int31 = spreadsheetDate2.getMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-October-1970" + "'", str17.equals("31-October-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        timeSeries2.clear();
//        long long5 = timeSeries2.getMaximumItemAge();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries2.addChangeListener(seriesChangeListener6);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class9);
//        java.lang.Class class11 = timeSeries10.getTimePeriodClass();
//        timeSeries10.clear();
//        long long13 = timeSeries10.getMaximumItemAge();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries10.addChangeListener(seriesChangeListener14);
//        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) seriesChangeListener6, (java.lang.Object) timeSeries10);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond19.getStart();
//        java.util.Date date24 = fixedMillisecond19.getTime();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond19.peg(calendar25);
//        java.util.Date date27 = fixedMillisecond19.getEnd();
//        long long28 = fixedMillisecond19.getFirstMillisecond();
//        int int29 = day17.compareTo((java.lang.Object) long28);
//        long long30 = day17.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond33.previous();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond33.getFirstMillisecond(calendar35);
//        java.util.Date date37 = fixedMillisecond33.getStart();
//        java.util.Date date38 = fixedMillisecond33.getTime();
//        java.util.Calendar calendar39 = null;
//        fixedMillisecond33.peg(calendar39);
//        java.util.Date date41 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(4, year43);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) day17, (org.jfree.data.time.RegularTimePeriod) year43);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNull(class11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 52L + "'", long28 == 52L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43629L + "'", long30 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 52L + "'", long36 == 52L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(timeSeries46);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener3);
        timeSeries2.fireSeriesChanged();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries8.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        int int24 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (double) '#', true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond6.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (short) 0);
        long long12 = fixedMillisecond6.getSerialIndex();
        long long13 = fixedMillisecond6.getLastMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        timeSeries2.setDescription("hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.previous();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond18.getFirstMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond18.getStart();
        long long23 = fixedMillisecond18.getLastMillisecond();
        long long24 = fixedMillisecond18.getMiddleMillisecond();
        timeSeries2.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        boolean boolean13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month11);
        boolean boolean15 = month11.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month11.next();
        java.lang.String str17 = month11.toString();
        long long18 = month11.getLastMillisecond();
        boolean boolean19 = year7.equals((java.lang.Object) long18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year7.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "October 0" + "'", str17.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62109475200001L) + "'", long18 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        long long10 = timeSeries7.getMaximumItemAge();
        int int11 = fixedMillisecond1.compareTo((java.lang.Object) long10);
        java.util.Calendar calendar12 = null;
        fixedMillisecond1.peg(calendar12);
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond1.getMiddleMillisecond(calendar14);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        java.util.Date date5 = month2.getStart();
        int int6 = month2.getMonth();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month2.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond4.getMiddleMillisecond(calendar5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond4.previous();
        long long8 = fixedMillisecond4.getSerialIndex();
        java.util.Date date9 = fixedMillisecond4.getTime();
        java.lang.Class<?> wildcardClass10 = date9.getClass();
        java.io.InputStream inputStream11 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("September 0", (java.lang.Class) wildcardClass10);
        java.io.InputStream inputStream12 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October", (java.lang.Class) wildcardClass10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond14.getFirstMillisecond(calendar16);
        java.util.Date date18 = fixedMillisecond14.getStart();
        java.util.Date date19 = fixedMillisecond14.getTime();
        java.util.Calendar calendar20 = null;
        fixedMillisecond14.peg(calendar20);
        java.util.Date date22 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.previous();
        long long31 = fixedMillisecond27.getSerialIndex();
        java.util.Date date32 = fixedMillisecond27.getTime();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date22, timeZone33);
        java.io.InputStream inputStream36 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("1969", (java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 52L + "'", long8 == 52L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(inputStream11);
        org.junit.Assert.assertNull(inputStream12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 52L + "'", long29 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(inputStream36);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond9.previous();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getFirstMillisecond(calendar11);
        java.util.Date date13 = fixedMillisecond9.getStart();
        java.util.Date date14 = fixedMillisecond9.getTime();
        java.util.Calendar calendar15 = null;
        fixedMillisecond9.peg(calendar15);
        java.util.Date date17 = fixedMillisecond9.getEnd();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(10, serialDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond23.getFirstMillisecond(calendar25);
        java.util.Date date27 = fixedMillisecond23.getStart();
        java.util.Date date28 = fixedMillisecond23.getTime();
        java.util.Calendar calendar29 = null;
        fixedMillisecond23.peg(calendar29);
        java.util.Date date31 = fixedMillisecond23.getEnd();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(10, serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = serialDate18.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond40.previous();
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond40.getFirstMillisecond(calendar42);
        java.util.Date date44 = fixedMillisecond40.getStart();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.util.Calendar calendar46 = null;
        fixedMillisecond40.peg(calendar46);
        java.util.Date date48 = fixedMillisecond40.getEnd();
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance(date48);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(10, serialDate49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = serialDate35.getEndOfCurrentMonth(serialDate51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.previous();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond55.getFirstMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond55.getStart();
        java.util.Date date60 = fixedMillisecond55.getTime();
        java.util.Calendar calendar61 = null;
        fixedMillisecond55.peg(calendar61);
        java.util.Date date63 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears(29, serialDate64);
        boolean boolean66 = spreadsheetDate2.isInRange(serialDate51, serialDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate69);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate72 = new org.jfree.data.time.SpreadsheetDate(4);
        int int73 = spreadsheetDate72.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(4);
        int int76 = spreadsheetDate75.getYYYY();
        boolean boolean77 = spreadsheetDate72.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean78 = spreadsheetDate2.isInRange(serialDate70, (org.jfree.data.time.SerialDate) spreadsheetDate72);
        java.lang.Class class79 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = fixedMillisecond81.previous();
        java.util.Calendar calendar83 = null;
        long long84 = fixedMillisecond81.getFirstMillisecond(calendar83);
        java.util.Date date85 = fixedMillisecond81.getStart();
        java.util.Date date86 = fixedMillisecond81.getTime();
        java.util.TimeZone timeZone87 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance(class79, date86, timeZone87);
        org.jfree.data.time.FixedMillisecond fixedMillisecond89 = new org.jfree.data.time.FixedMillisecond(date86);
        boolean boolean90 = spreadsheetDate72.equals((java.lang.Object) fixedMillisecond89);
        java.lang.String str91 = fixedMillisecond89.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 52L + "'", long26 == 52L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 52L + "'", long43 == 52L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 52L + "'", long58 == 52L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1900 + "'", int73 == 1900);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1900 + "'", int76 == 1900);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 52L + "'", long84 == 52L);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNull(regularTimePeriod88);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str91.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
        boolean boolean4 = timeSeries3.isEmpty();
        java.lang.Class class5 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        java.util.Date date12 = fixedMillisecond7.getTime();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        timeSeries3.setKey((java.lang.Comparable) date12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        timeSeries3.removeAgedItems(true);
        try {
            timeSeries3.delete((int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        boolean boolean8 = timeSeries3.equals((java.lang.Object) '4');
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("31-October-1970", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries2.removeChangeListener(seriesChangeListener11);
        timeSeries2.setNotify(false);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
        int int19 = month17.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.previous();
        java.lang.Number number21 = timeSeries2.getValue(regularTimePeriod20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener22);
        timeSeries2.clear();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries2.addChangeListener(seriesChangeListener25);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(number21);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 0);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        boolean boolean18 = year7.equals(obj17);
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year7.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        timeSeries2.setDescription("");
        java.lang.Object obj8 = timeSeries2.clone();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
        timeSeries11.clear();
        java.lang.String str14 = timeSeries11.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries11.removeChangeListener(seriesChangeListener15);
        java.util.Collection collection17 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries2.removeAgedItems(false);
        timeSeries2.setMaximumItemAge((long) 'a');
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class23);
        java.lang.Class class25 = timeSeries24.getTimePeriodClass();
        timeSeries24.clear();
        long long27 = timeSeries24.getMaximumItemAge();
        timeSeries24.setDescription("");
        java.lang.Object obj30 = timeSeries24.clone();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class32);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        timeSeries33.clear();
        java.lang.String str36 = timeSeries33.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries33.removeChangeListener(seriesChangeListener37);
        java.util.Collection collection39 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.util.Collection collection40 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.lang.String str41 = timeSeries33.getRangeDescription();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNull(class25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9223372036854775807L + "'", long27 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Value" + "'", str41.equals("Value"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod9, (java.lang.Number) (byte) 100);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        int int16 = month14.getYearValue();
        long long17 = month14.getLastMillisecond();
        int int18 = month14.getYearValue();
        boolean boolean19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) timeSeriesDataItem11, (java.lang.Object) month14);
        try {
            org.jfree.data.time.Year year20 = month14.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62109475200001L) + "'", long17 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date7);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) date7);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int4 = spreadsheetDate2.getMonth();
//        int int5 = spreadsheetDate2.getDayOfMonth();
//        int int6 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(30);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        int int10 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        int int13 = day11.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (double) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond19.getStart();
//        java.util.Date date24 = fixedMillisecond19.getTime();
//        java.util.Calendar calendar25 = null;
//        fixedMillisecond19.peg(calendar25);
//        java.util.Date date27 = fixedMillisecond19.getEnd();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(10, serialDate28);
//        boolean boolean30 = day11.equals((java.lang.Object) serialDate29);
//        boolean boolean31 = spreadsheetDate2.isOn(serialDate29);
//        int int32 = spreadsheetDate2.getDayOfWeek();
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 13 + "'", int13 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.lang.Class class4 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        long long11 = fixedMillisecond7.getSerialIndex();
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.lang.Class<?> wildcardClass13 = date12.getClass();
        java.io.InputStream inputStream14 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("September 0", (java.lang.Class) wildcardClass13);
        java.lang.Object obj15 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("31-October-1970", class4, (java.lang.Class) wildcardClass13);
        java.io.InputStream inputStream16 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Third", (java.lang.Class) wildcardClass13);
        java.net.URL uRL17 = org.jfree.chart.util.ObjectUtilities.getResource("31-October-1970", (java.lang.Class) wildcardClass13);
        java.io.InputStream inputStream18 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass13);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(inputStream14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(inputStream16);
        org.junit.Assert.assertNull(uRL17);
        org.junit.Assert.assertNull(inputStream18);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond6.getStart();
        java.util.Date date11 = fixedMillisecond6.getTime();
        java.util.Calendar calendar12 = null;
        fixedMillisecond6.peg(calendar12);
        java.util.Date date14 = fixedMillisecond6.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(10, serialDate15);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        boolean boolean30 = spreadsheetDate2.isInRange(serialDate16, serialDate28, 30);
        java.lang.String str31 = spreadsheetDate2.toString();
        int int32 = spreadsheetDate2.toSerial();
        int int33 = spreadsheetDate2.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-October-1970" + "'", str17.equals("31-October-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "3-January-1900" + "'", str31.equals("3-January-1900"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
        timeSeries3.setMaximumItemCount(100);
        timeSeries3.setDomainDescription("January");
        timeSeries3.fireSeriesChanged();
        timeSeries3.setNotify(false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Third");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        long long9 = year8.getFirstMillisecond();
        long long10 = year8.getSerialIndex();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(6, year8);
        java.util.Date date12 = year8.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        timeSeries7.fireSeriesChanged();
        java.util.Collection collection12 = timeSeries7.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries7.getTimePeriod(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "October" + "'", str1.equals("October"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "31-December-1969");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.previous();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month8.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "Third", class3);
        timeSeries4.fireSeriesChanged();
        java.lang.String str6 = timeSeries4.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        boolean boolean7 = timeSeries2.equals((java.lang.Object) '4');
        java.lang.Class<?> wildcardClass8 = timeSeries2.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond7.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond7.getStart();
        java.util.Date date12 = fixedMillisecond7.getTime();
        java.util.Calendar calendar13 = null;
        fixedMillisecond7.peg(calendar13);
        java.util.Date date15 = fixedMillisecond7.getEnd();
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(10, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
        boolean boolean20 = timeSeries2.equals((java.lang.Object) day19);
        long long21 = day19.getSerialIndex();
        int int22 = day19.getMonth();
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 25841L + "'", long21 == 25841L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        long long6 = fixedMillisecond5.getFirstMillisecond();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        boolean boolean9 = day0.equals((java.lang.Object) year8);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day0.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getStart();
        java.util.Date date8 = fixedMillisecond3.getTime();
        java.util.Calendar calendar9 = null;
        fixedMillisecond3.peg(calendar9);
        java.util.Date date11 = fixedMillisecond3.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears(29, serialDate12);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        boolean boolean21 = day18.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond24.getStart();
        java.util.Date date29 = fixedMillisecond24.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        java.util.Date date32 = fixedMillisecond24.getEnd();
        long long33 = fixedMillisecond24.getFirstMillisecond();
        int int34 = day22.compareTo((java.lang.Object) long33);
        int int35 = day18.compareTo((java.lang.Object) int34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.previous();
        long long44 = fixedMillisecond40.getSerialIndex();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.lang.Class<?> wildcardClass46 = date45.getClass();
        java.net.URL uRL47 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int34, "ThreadContext", "", (java.lang.Class) wildcardClass46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long51 = fixedMillisecond50.getFirstMillisecond();
        java.util.Calendar calendar52 = null;
        long long53 = fixedMillisecond50.getLastMillisecond(calendar52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond50.previous();
        java.util.Date date55 = fixedMillisecond50.getTime();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond59.getMiddleMillisecond(calendar60);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond59.previous();
        long long63 = fixedMillisecond59.getSerialIndex();
        java.util.Date date64 = fixedMillisecond59.getTime();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(date64, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date55, timeZone65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar73 = null;
        long long74 = fixedMillisecond72.getMiddleMillisecond(calendar73);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = fixedMillisecond72.previous();
        long long76 = fixedMillisecond72.getSerialIndex();
        java.util.Date date77 = fixedMillisecond72.getTime();
        java.lang.Class<?> wildcardClass78 = date77.getClass();
        java.net.URL uRL79 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: hi!", (java.lang.Class) wildcardClass78);
        java.net.URL uRL80 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass78);
        java.io.InputStream inputStream81 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Last", (java.lang.Class) wildcardClass78);
        java.lang.Object obj82 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", (java.lang.Class) wildcardClass46, (java.lang.Class) wildcardClass78);
        java.net.URL uRL83 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Third", (java.lang.Class) wildcardClass78);
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate12, "", "31-December-1969", (java.lang.Class) wildcardClass78);
        java.io.InputStream inputStream85 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("3-January-1900", (java.lang.Class) wildcardClass78);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 52L + "'", long42 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 52L + "'", long44 == 52L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNull(uRL47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 52L + "'", long51 == 52L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 52L + "'", long53 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 52L + "'", long61 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 52L + "'", long63 == 52L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 52L + "'", long74 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 52L + "'", long76 == 52L);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(wildcardClass78);
        org.junit.Assert.assertNull(uRL79);
        org.junit.Assert.assertNotNull(uRL80);
        org.junit.Assert.assertNull(inputStream81);
        org.junit.Assert.assertNull(obj82);
        org.junit.Assert.assertNull(uRL83);
        org.junit.Assert.assertNull(inputStream85);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getLastMillisecond();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond8.getFirstMillisecond(calendar10);
        java.util.Date date12 = fixedMillisecond8.getStart();
        java.util.Date date13 = fixedMillisecond8.getTime();
        java.util.Calendar calendar14 = null;
        fixedMillisecond8.peg(calendar14);
        java.util.Date date16 = fixedMillisecond8.getEnd();
        long long17 = fixedMillisecond8.getFirstMillisecond();
        int int18 = day6.compareTo((java.lang.Object) long17);
        org.jfree.data.time.SerialDate serialDate19 = day6.getSerialDate();
        int int20 = month2.compareTo((java.lang.Object) day6);
        java.util.Date date21 = day6.getStart();
        int int22 = day6.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 0" + "'", str4.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62109475200001L) + "'", long5 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getMonth();
        int int6 = spreadsheetDate3.getDayOfMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond10.getFirstMillisecond(calendar12);
        java.util.Date date14 = fixedMillisecond10.getStart();
        java.util.Date date15 = fixedMillisecond10.getTime();
        java.util.Calendar calendar16 = null;
        fixedMillisecond10.peg(calendar16);
        java.util.Date date18 = fixedMillisecond10.getEnd();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addMonths(10, serialDate19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond24.getFirstMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond24.getStart();
        java.util.Date date29 = fixedMillisecond24.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond24.peg(calendar30);
        java.util.Date date32 = fixedMillisecond24.getEnd();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths(10, serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate34);
        org.jfree.data.time.SerialDate serialDate36 = serialDate19.getEndOfCurrentMonth(serialDate35);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond41.previous();
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond41.getFirstMillisecond(calendar43);
        java.util.Date date45 = fixedMillisecond41.getStart();
        java.util.Date date46 = fixedMillisecond41.getTime();
        java.util.Calendar calendar47 = null;
        fixedMillisecond41.peg(calendar47);
        java.util.Date date49 = fixedMillisecond41.getEnd();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance(date49);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(10, serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths((-1), serialDate51);
        org.jfree.data.time.SerialDate serialDate53 = serialDate36.getEndOfCurrentMonth(serialDate52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond56.previous();
        java.util.Calendar calendar58 = null;
        long long59 = fixedMillisecond56.getFirstMillisecond(calendar58);
        java.util.Date date60 = fixedMillisecond56.getStart();
        java.util.Date date61 = fixedMillisecond56.getTime();
        java.util.Calendar calendar62 = null;
        fixedMillisecond56.peg(calendar62);
        java.util.Date date64 = fixedMillisecond56.getEnd();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance(date64);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addYears(29, serialDate65);
        boolean boolean67 = spreadsheetDate3.isInRange(serialDate52, serialDate65);
        try {
            org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 52L + "'", long27 == 52L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 52L + "'", long44 == 52L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 52L + "'", long59 == 52L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        long long6 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        long long8 = timeSeries7.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond3.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond3.getFirstMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond3.getStart();
        java.util.Date date8 = fixedMillisecond3.getTime();
        java.util.Calendar calendar9 = null;
        fixedMillisecond3.peg(calendar9);
        java.util.Date date11 = fixedMillisecond3.getEnd();
        long long12 = fixedMillisecond3.getFirstMillisecond();
        int int13 = day1.compareTo((java.lang.Object) long12);
        org.jfree.data.time.SerialDate serialDate14 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate14);
        serialDate14.setDescription("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10, (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        timeSeries13.fireSeriesChanged();
        java.util.Collection collection18 = timeSeries13.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getFirstMillisecond(calendar24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        timeSeries28.clear();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class32);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        timeSeries33.clear();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries28.addAndOrUpdate(timeSeries33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries28.removeChangeListener(seriesChangeListener37);
        boolean boolean39 = fixedMillisecond22.equals((java.lang.Object) seriesChangeListener37);
        timeSeries13.setKey((java.lang.Comparable) boolean39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries2.addAndOrUpdate(timeSeries13);
        timeSeries13.removeAgedItems(false);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
        long long7 = fixedMillisecond1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) 0);
        java.util.Calendar calendar11 = null;
        fixedMillisecond10.peg(calendar11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10L);
        java.util.List list15 = timeSeries8.getItems();
        timeSeries8.setDescription("Third");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
        boolean boolean23 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) (short) 10, (java.lang.Object) month21);
        boolean boolean25 = month21.equals((java.lang.Object) "");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month21.next();
        java.lang.String str27 = month21.toString();
        long long28 = month21.getLastMillisecond();
        long long29 = month21.getSerialIndex();
        int int30 = month21.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (double) 2019);
        timeSeries8.setMaximumItemCount((int) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "October 0" + "'", str27.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62109475200001L) + "'", long28 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 10L + "'", long29 == 10L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (short) 0);
//        java.lang.Object obj6 = timeSeriesDataItem5.clone();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(obj6);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        java.lang.String str16 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond18.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.Number number23 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        timeSeries7.setMaximumItemCount(100);
        java.lang.String str26 = timeSeries7.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries7.getTimePeriod(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Value" + "'", str26.equals("Value"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        int int6 = month2.compareTo((java.lang.Object) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getDayOfWeek();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        java.util.Date date8 = fixedMillisecond6.getTime();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(4);
        int int13 = spreadsheetDate12.getYYYY();
        boolean boolean14 = spreadsheetDate2.isInRange(serialDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.previous();
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond21.getFirstMillisecond(calendar23);
        java.util.Date date25 = fixedMillisecond21.getStart();
        java.util.Date date26 = fixedMillisecond21.getTime();
        java.util.Calendar calendar27 = null;
        fixedMillisecond21.peg(calendar27);
        java.util.Date date29 = fixedMillisecond21.getEnd();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(10, serialDate30);
        java.lang.String str32 = serialDate31.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond34.previous();
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond34.getFirstMillisecond(calendar36);
        java.util.Date date38 = fixedMillisecond34.getStart();
        java.util.Date date39 = fixedMillisecond34.getTime();
        java.util.Calendar calendar40 = null;
        fixedMillisecond34.peg(calendar40);
        java.util.Date date42 = fixedMillisecond34.getEnd();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        boolean boolean45 = spreadsheetDate17.isInRange(serialDate31, serialDate43, 30);
        boolean boolean46 = spreadsheetDate2.isOnOrAfter(serialDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate51);
        boolean boolean53 = spreadsheetDate48.isBefore(serialDate52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond55.previous();
        java.util.Calendar calendar57 = null;
        long long58 = fixedMillisecond55.getFirstMillisecond(calendar57);
        java.util.Date date59 = fixedMillisecond55.getStart();
        java.util.Date date60 = fixedMillisecond55.getTime();
        java.util.Calendar calendar61 = null;
        fixedMillisecond55.peg(calendar61);
        java.util.Date date63 = fixedMillisecond55.getEnd();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        serialDate64.setDescription("Aug");
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond70.previous();
        java.util.Calendar calendar72 = null;
        long long73 = fixedMillisecond70.getFirstMillisecond(calendar72);
        java.util.Date date74 = fixedMillisecond70.getStart();
        java.util.Date date75 = fixedMillisecond70.getTime();
        java.util.Calendar calendar76 = null;
        fixedMillisecond70.peg(calendar76);
        java.util.Date date78 = fixedMillisecond70.getEnd();
        long long79 = fixedMillisecond70.getFirstMillisecond();
        int int80 = day68.compareTo((java.lang.Object) long79);
        org.jfree.data.time.SerialDate serialDate81 = day68.getSerialDate();
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addYears((int) (byte) 10, serialDate81);
        boolean boolean84 = spreadsheetDate48.isInRange(serialDate64, serialDate82, 0);
        try {
            int int85 = spreadsheetDate2.compareTo((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 52L + "'", long7 == 52L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 52L + "'", long24 == 52L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "31-October-1970" + "'", str32.equals("31-October-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 52L + "'", long37 == 52L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 52L + "'", long58 == 52L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 52L + "'", long73 == 52L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 52L + "'", long79 == 52L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        java.lang.Class class0 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond2.previous();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond2.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond2.getStart();
        java.util.Date date7 = fixedMillisecond2.getTime();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date7, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7);
        int int11 = year10.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year10.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        long long5 = timeSeries2.getMaximumItemAge();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        timeSeries13.fireSeriesChanged();
        java.util.Collection collection18 = timeSeries13.getTimePeriods();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond22.getFirstMillisecond(calendar24);
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class27);
        java.lang.Class class29 = timeSeries28.getTimePeriodClass();
        timeSeries28.clear();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class32);
        java.lang.Class class34 = timeSeries33.getTimePeriodClass();
        timeSeries33.clear();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries28.addAndOrUpdate(timeSeries33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries28.removeChangeListener(seriesChangeListener37);
        boolean boolean39 = fixedMillisecond22.equals((java.lang.Object) seriesChangeListener37);
        timeSeries13.setKey((java.lang.Comparable) boolean39);
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries2.addAndOrUpdate(timeSeries13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries13.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 52L + "'", long25 == 52L);
        org.junit.Assert.assertNull(class29);
        org.junit.Assert.assertNull(class34);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(timeSeries41);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getLastMillisecond(calendar3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.lang.String str8 = fixedMillisecond6.toString();
        int int9 = fixedMillisecond1.compareTo((java.lang.Object) str8);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class11);
        java.lang.Class class13 = timeSeries12.getTimePeriodClass();
        timeSeries12.clear();
        long long15 = timeSeries12.getMaximumItemAge();
        timeSeries12.setDescription("");
        timeSeries12.clear();
        boolean boolean19 = fixedMillisecond1.equals((java.lang.Object) timeSeries12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries12.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month24.next();
        int int26 = month24.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.previous();
        long long28 = month24.getLastMillisecond();
        java.lang.String str29 = month24.toString();
        int int30 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month24);
        timeSeries12.setMaximumItemCount((int) 'a');
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month35.next();
        int int37 = month35.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.previous();
        long long39 = month35.getLastMillisecond();
        java.lang.String str40 = month35.toString();
        java.lang.Number number41 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) month35);
        try {
            org.jfree.data.time.TimeSeries timeSeries44 = timeSeries12.createCopy((int) (short) 100, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str8.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(class13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62109475200001L) + "'", long28 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "October 0" + "'", str29.equals("October 0"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62109475200001L) + "'", long39 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "October 0" + "'", str40.equals("October 0"));
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month5.next();
        java.lang.String str7 = month5.toString();
        long long8 = month5.getLastMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond11.getFirstMillisecond(calendar13);
        java.util.Date date15 = fixedMillisecond11.getStart();
        java.util.Date date16 = fixedMillisecond11.getTime();
        java.util.Calendar calendar17 = null;
        fixedMillisecond11.peg(calendar17);
        java.util.Date date19 = fixedMillisecond11.getEnd();
        long long20 = fixedMillisecond11.getFirstMillisecond();
        int int21 = day9.compareTo((java.lang.Object) long20);
        org.jfree.data.time.SerialDate serialDate22 = day9.getSerialDate();
        int int23 = month5.compareTo((java.lang.Object) day9);
        java.util.Date date24 = day9.getStart();
        java.lang.Class class25 = null;
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.previous();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond27.getFirstMillisecond(calendar29);
        java.util.Date date31 = fixedMillisecond27.getStart();
        java.util.Date date32 = fixedMillisecond27.getTime();
        java.util.Calendar calendar33 = null;
        fixedMillisecond27.peg(calendar33);
        java.util.Date date35 = fixedMillisecond27.getEnd();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date35, timeZone37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond40.previous();
        long long44 = fixedMillisecond40.getSerialIndex();
        java.util.Date date45 = fixedMillisecond40.getTime();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date45, timeZone46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date35, timeZone46);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date35, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date24, timeZone49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond53.getMiddleMillisecond(calendar54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond53.previous();
        long long57 = fixedMillisecond53.getSerialIndex();
        java.util.Date date58 = fixedMillisecond53.getTime();
        java.lang.Class<?> wildcardClass59 = date58.getClass();
        java.lang.ClassLoader classLoader60 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass59);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date24, (java.lang.Class) wildcardClass59);
        java.io.InputStream inputStream62 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October", (java.lang.Class) wildcardClass59);
        java.net.URL uRL63 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]", (java.lang.Class) wildcardClass59);
        java.net.URL uRL64 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Third", (java.lang.Class) wildcardClass59);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "October 0" + "'", str7.equals("October 0"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62109475200001L) + "'", long8 == (-62109475200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 52L + "'", long14 == 52L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 52L + "'", long42 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 52L + "'", long44 == 52L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 52L + "'", long55 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 52L + "'", long57 == 52L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertNotNull(classLoader60);
        org.junit.Assert.assertNull(inputStream62);
        org.junit.Assert.assertNull(uRL63);
        org.junit.Assert.assertNull(uRL64);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class5);
//        java.lang.Class class7 = timeSeries6.getTimePeriodClass();
//        timeSeries6.clear();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class10);
//        java.lang.Class class12 = timeSeries11.getTimePeriodClass();
//        timeSeries11.clear();
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries6.addAndOrUpdate(timeSeries11);
//        timeSeries11.setDescription("");
//        timeSeries11.setDescription("");
//        java.util.List list19 = timeSeries11.getItems();
//        boolean boolean20 = day0.equals((java.lang.Object) timeSeries11);
//        long long21 = day0.getFirstMillisecond();
//        int int22 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNull(class7);
//        org.junit.Assert.assertNull(class12);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(list19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("31-October-1970");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) (short) 0);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        java.lang.Object obj8 = timeSeriesDataItem6.clone();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        int int11 = day9.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day9.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (double) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.previous();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond17.getFirstMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond17.getStart();
//        java.util.Date date22 = fixedMillisecond17.getTime();
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond17.peg(calendar23);
//        java.util.Date date25 = fixedMillisecond17.getEnd();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(10, serialDate26);
//        boolean boolean28 = day9.equals((java.lang.Object) serialDate27);
//        int int29 = timeSeriesDataItem6.compareTo((java.lang.Object) serialDate27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        long long32 = fixedMillisecond31.getFirstMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond31.getLastMillisecond(calendar33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond31.previous();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod35);
//        boolean boolean37 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) int29, (java.lang.Object) seriesChangeEvent36);
//        java.lang.String str38 = seriesChangeEvent36.toString();
//        java.lang.String str39 = seriesChangeEvent36.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 52L + "'", long20 == 52L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 52L + "'", long32 == 52L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 52L + "'", long34 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]" + "'", str38.equals("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]" + "'", str39.equals("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]"));
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, class2);
//        timeSeries3.setMaximumItemCount(100);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 100);
//        long long10 = day6.getMiddleMillisecond();
//        long long11 = day6.getLastMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day6.getSerialDate();
//        java.lang.String str13 = serialDate12.getDescription();
//        org.jfree.data.time.SerialDate serialDate15 = serialDate12.getFollowingDayOfWeek(1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(serialDate15);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.String str5 = timeSeries2.getDescription();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class7);
        java.lang.Class class9 = timeSeries8.getTimePeriodClass();
        timeSeries8.clear();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class12);
        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
        timeSeries13.clear();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries8.addAndOrUpdate(timeSeries13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries8.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond20.getLastMillisecond(calendar22);
        int int24 = timeSeries8.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        java.util.Collection collection25 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.previous();
        java.util.Calendar calendar29 = null;
        long long30 = fixedMillisecond27.getFirstMillisecond(calendar29);
        java.lang.Number number31 = null;
        try {
            timeSeries2.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number31);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(class9);
        org.junit.Assert.assertNull(class14);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 52L + "'", long21 == 52L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 52L + "'", long23 == 52L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 52L + "'", long30 == 52L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        int int5 = timeSeries2.getItemCount();
        java.lang.String str6 = timeSeries2.getDomainDescription();
        int int7 = timeSeries2.getItemCount();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        long long11 = month10.getLastMillisecond();
        try {
            timeSeries2.add((org.jfree.data.time.RegularTimePeriod) month10, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
//        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
//        timeSeries2.clear();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
//        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
//        timeSeries7.clear();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries2.removeChangeListener(seriesChangeListener11);
//        timeSeries2.setNotify(false);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month((int) (byte) 10, 0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.previous();
//        java.lang.Number number21 = timeSeries2.getValue(regularTimePeriod20);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries2.addPropertyChangeListener(propertyChangeListener22);
//        timeSeries2.clear();
//        int int25 = timeSeries2.getMaximumItemCount();
//        timeSeries2.fireSeriesChanged();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        int int29 = day27.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day27.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (double) (short) 0);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 1);
//        timeSeries2.removeAgedItems(false);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class38);
//        java.lang.Class class40 = timeSeries39.getTimePeriodClass();
//        java.util.Collection collection41 = timeSeries39.getTimePeriods();
//        timeSeries39.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond44.previous();
//        java.util.Calendar calendar46 = null;
//        long long47 = fixedMillisecond44.getFirstMillisecond(calendar46);
//        java.util.Date date48 = fixedMillisecond44.getStart();
//        java.util.Date date49 = fixedMillisecond44.getTime();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) '4');
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) (short) 0);
//        java.lang.Object obj60 = timeSeriesDataItem59.clone();
//        boolean boolean61 = year50.equals(obj60);
//        int int62 = year50.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year50.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year50.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries39.addOrUpdate(regularTimePeriod64, (java.lang.Number) 29);
//        java.util.List list67 = timeSeries39.getItems();
//        boolean boolean68 = timeSeries2.equals((java.lang.Object) list67);
//        org.junit.Assert.assertNull(class3);
//        org.junit.Assert.assertNull(class8);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNull(class40);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 52L + "'", long47 == 52L);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 52L + "'", long56 == 52L);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(obj60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1969 + "'", int62 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertNotNull(list67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class1);
        java.lang.Class class3 = timeSeries2.getTimePeriodClass();
        timeSeries2.clear();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), class6);
        java.lang.Class class8 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries2.addAndOrUpdate(timeSeries7);
        java.lang.String str11 = timeSeries10.getDescription();
        java.lang.String str12 = timeSeries10.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.previous();
        java.util.Calendar calendar16 = null;
        long long17 = regularTimePeriod15.getMiddleMillisecond(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond29.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (double) (short) 0);
        java.lang.Object obj35 = timeSeriesDataItem34.clone();
        boolean boolean36 = year25.equals(obj35);
        long long37 = year25.getSerialIndex();
        long long38 = year25.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries10.createCopy(regularTimePeriod15, (org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond41, class42);
        boolean boolean44 = timeSeries43.isEmpty();
        java.lang.Class class45 = timeSeries43.getTimePeriodClass();
        java.lang.String str46 = timeSeries43.getDomainDescription();
        java.util.Collection collection47 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        org.junit.Assert.assertNull(class3);
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Value" + "'", str12.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 51L + "'", long17 == 51L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 52L + "'", long31 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1969L + "'", long37 == 1969L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1969L + "'", long38 == 1969L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(class45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
        org.junit.Assert.assertNotNull(collection47);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, class1);
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries2.equals(obj3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries2.removeChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1, class1);
        java.lang.Object obj3 = null;
        boolean boolean4 = timeSeries2.equals(obj3);
        try {
            timeSeries2.delete(3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        int int4 = month2.getYearValue();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "13-June-2019");
        boolean boolean7 = month2.equals((java.lang.Object) seriesChangeEvent6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f, "", "Third", class3);
        timeSeries4.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond7.previous();
        long long11 = fixedMillisecond7.getSerialIndex();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1969);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 52L + "'", long11 == 52L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) 'a', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("3-January-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '4');
        long long10 = fixedMillisecond9.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond9.getLastMillisecond(calendar11);
        int int13 = year7.compareTo((java.lang.Object) calendar11);
        int int14 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year7.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 52L + "'", long10 == 52L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 52L + "'", long12 == 52L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Date date5 = fixedMillisecond1.getStart();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '4');
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 0);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        boolean boolean18 = year7.equals(obj17);
        int int19 = year7.getYear();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod21, (java.lang.Number) 2);
        timeSeriesDataItem23.setValue((java.lang.Number) (short) 0);
        java.lang.Object obj26 = timeSeriesDataItem23.clone();
        java.lang.Object obj27 = timeSeriesDataItem23.clone();
        java.lang.Number number28 = timeSeriesDataItem23.getValue();
        java.lang.Class<?> wildcardClass29 = number28.getClass();
        int int30 = year7.compareTo((java.lang.Object) wildcardClass29);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 52L + "'", long4 == 52L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1969 + "'", int19 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 0 + "'", number28.equals((short) 0));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(4);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getFirstMillisecond(calendar8);
        java.util.Date date10 = fixedMillisecond6.getStart();
        java.util.Date date11 = fixedMillisecond6.getTime();
        java.util.Calendar calendar12 = null;
        fixedMillisecond6.peg(calendar12);
        java.util.Date date14 = fixedMillisecond6.getEnd();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(10, serialDate15);
        java.lang.String str17 = serialDate16.toString();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond19.previous();
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond19.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond19.getStart();
        java.util.Date date24 = fixedMillisecond19.getTime();
        java.util.Calendar calendar25 = null;
        fixedMillisecond19.peg(calendar25);
        java.util.Date date27 = fixedMillisecond19.getEnd();
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance(date27);
        boolean boolean30 = spreadsheetDate2.isInRange(serialDate16, serialDate28, 30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(4);
        int int33 = spreadsheetDate32.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(4);
        int int36 = spreadsheetDate35.getYYYY();
        boolean boolean37 = spreadsheetDate32.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate35);
        int int38 = spreadsheetDate32.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        boolean boolean41 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        int int42 = spreadsheetDate40.getYYYY();
        boolean boolean43 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 52L + "'", long9 == 52L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "31-October-1970" + "'", str17.equals("31-October-1970"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 52L + "'", long22 == 52L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1900 + "'", int36 == 1900);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }
}

